// Write C++ code here.
//
// Do not forget to dynamically load the C++ library into your application.
//
// For instance,
//
// In MainActivity.java:
//    static {
//       System.loadLibrary("main");
//    }
//
// Or, in MainActivity.kt:
//    companion object {
//      init {
//         System.loadLibrary("main")
//      }
//    }

#include <jni.h>
#include <string>


// Replace with your real credentials (from Protectt.ai document)
std::string packageName       = "net.one97.paytm";
std::string appName           = "Paytm";
std::string channelLicenseKey = "9265b954-00f6-466a-93b7-8570fa52794b";
int clientId          = 136;
int channelId         = 13601;
std::string password          = "24b4455401c94204aa76ea4afd549790";

std::string pChannelLicenseKey = "d287c972-a533-4085-ad13-1742915c9104";
int pClientId          = 3;
int pChannelId         = 301;
std::string pPassword          = "232b5ee263ea425e9886fb3c2a692f08";
//


// --------------------------------------------------
extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_appPackageName(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(packageName.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_appName(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(appName.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_channelLicenseKey(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(channelLicenseKey.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_pchannelLicenseKey(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(pChannelLicenseKey.c_str());
}


extern "C" JNIEXPORT jint JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_clientId(JNIEnv *env, jobject /* this */) {
    return clientId;
}

extern "C" JNIEXPORT jint JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_pclientId(JNIEnv *env, jobject /* this */) {
    return pClientId;
}


extern "C" JNIEXPORT jint JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_channelId(JNIEnv *env, jobject /* this */) {
    return channelId;
}
extern "C" JNIEXPORT jint JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_pchannelId(JNIEnv *env, jobject /* this */) {
    return pChannelId;
}

extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_password(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(password.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_app_CJRJarvisApplication_ppassword(JNIEnv *env, jobject /* this */) {
    return env->NewStringUTF(pPassword.c_str());
}


// Instance method Kotlin: net.one97.paytm.pps.PBIDGenerator.pbidUuid()
extern "C" JNIEXPORT jstring JNICALL
Java_net_one97_paytm_pps_PBIDGenerator_pbidUuid(JNIEnv *env, jobject /* this */) {
    // Widevine system id (canonical UUID string for MediaDrm)
    return env->NewStringUTF("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed");
}





