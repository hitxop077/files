package Ke;

import kotlin.Metadata;
import p562sd.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\b\u0017\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003R\"\u0010\u000b\u001a\u00020\u00048\u0004@\u0004X\u0084\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\f"}, d2 = {"LKe/MY3jR;", "Lsd/HicDZW;", "<init>", "()V", "", "njNibPNp", "Z", "getShouldShowNetworkErrorOnStart", "()Z", "setShouldShowNetworkErrorOnStart", "(Z)V", "shouldShowNetworkErrorOnStart", "moneytransfer_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public class MY3jR extends HicDZW {

    /* JADX INFO: renamed from: njNibPNp, reason: from kotlin metadata */
    public boolean shouldShowNetworkErrorOnStart = true;
}
