package K7;

import android.content.Context;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes10.dex */
public final class MY3jR {
    public static final C0104MY3jR aXYSYCVY = new C0104MY3jR(null);
    public static final int eLbhX59K = 8;
    public static MY3jR zDWsfFRp;
    public boolean eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public interface AAnYcst {
    }

    /* JADX INFO: renamed from: K7.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static final class C0104MY3jR {
        public /* synthetic */ C0104MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final MY3jR aXYSYCVY() {
            return MY3jR.zDWsfFRp;
        }

        public final void eLbhX59K(MY3jR mY3jR) {
            MY3jR.zDWsfFRp = mY3jR;
        }

        public final MY3jR eszJ2B0a() {
            if (aXYSYCVY() == null) {
                synchronized (MY3jR.class) {
                    try {
                        C0104MY3jR c0104MY3jR = MY3jR.aXYSYCVY;
                        if (c0104MY3jR.aXYSYCVY() == null) {
                            c0104MY3jR.eLbhX59K(new MY3jR());
                        }
                        Unit unit = Unit.INSTANCE;
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            }
            return aXYSYCVY();
        }

        public C0104MY3jR() {
        }
    }

    public static final MY3jR eLbhX59K() {
        return aXYSYCVY.eszJ2B0a();
    }

    public final void zDWsfFRp(Context context, boolean z10, AAnYcst aAnYcst) {
        if (context == null) {
            return;
        }
        this.eszJ2B0a = z10;
        K7.AAnYcst.eszJ2B0a.aXYSYCVY(context);
    }
}
