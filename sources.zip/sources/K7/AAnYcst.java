package K7;

import android.content.Context;
import kotlin.jvm.internal.Intrinsics;
import p497q7.FtRxP0tp;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class AAnYcst {
    public static final AAnYcst eszJ2B0a = new AAnYcst();

    public final String aXYSYCVY(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (FtRxP0tp.eLbhX59K() != null) {
            FtRxP0tp.eLbhX59K().ivfTYNl(context, "kyc status", "", "getKYCName");
        }
        return "";
    }

    public final String eLbhX59K(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (FtRxP0tp.eLbhX59K() != null) {
            FtRxP0tp.eLbhX59K().ivfTYNl(context, "kyc status", "", "getKYCType");
        }
        return "";
    }

    public final boolean eszJ2B0a(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (FtRxP0tp.eLbhX59K() == null) {
            return false;
        }
        FtRxP0tp.eLbhX59K().ivfTYNl(context, "kyc status", "", "getIsMinKyc");
        return false;
    }

    public final int zDWsfFRp(Context context) {
        if (FtRxP0tp.eLbhX59K() == null) {
            return -1;
        }
        FtRxP0tp.eLbhX59K().ivfTYNl(context, "kyc status", "", "getKYCUserStatus");
        return -1;
    }
}
