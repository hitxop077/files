package K3;

import android.content.Context;
import com.paytm.network.CJRCommonNetworkCall;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class AAnYcst implements K3.MY3jR {
    public static final MY3jR eLbhX59K = new MY3jR(null);
    public static final int zDWsfFRp = 8;
    public final C6.AAnYcst aXYSYCVY;
    public final Context eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public /* synthetic */ MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public MY3jR() {
        }
    }

    public AAnYcst(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.eszJ2B0a = context;
        this.aXYSYCVY = C6.AAnYcst.aXYSYCVY.osx7Pl0E(context, CJRCommonNetworkCall.VerticalId.PAYTM_DISCOVERY);
    }

    @Override // K3.MY3jR
    public void aXYSYCVY(int i10) {
        this.aXYSYCVY.eTQUrp("mte_reminder_anim_tooltip_shown_count", i10, false);
    }

    @Override // K3.MY3jR
    public int bsO5Vo() {
        return this.aXYSYCVY.rJCQt16("mte_reminder_anim_tooltip_shown_count", 0, false);
    }

    @Override // K3.MY3jR
    public void dUI84(boolean z10) {
        this.aXYSYCVY.eImdmIyv("scanner_burst_sound_muted", z10, false);
    }

    @Override // K3.MY3jR
    public Long eLbhX59K() {
        long jRtsRj = this.aXYSYCVY.rtsRj("last_shown_suggested_favourites_sheet", -1L, false);
        if (jRtsRj == -1) {
            return null;
        }
        return Long.valueOf(jRtsRj);
    }

    @Override // K3.MY3jR
    public void eszJ2B0a(Long l10) {
        if (l10 == null) {
            this.aXYSYCVY.oZ7qYn("mte_last_shown_reminder_anim_tooltip_ts", false);
        } else {
            this.aXYSYCVY.nyeBEo("mte_last_shown_reminder_anim_tooltip_ts", l10.longValue(), false);
        }
    }

    @Override // K3.MY3jR
    public int ivfTYNl() {
        return this.aXYSYCVY.rJCQt16("mte_new_copy_paste_banner_impressions", 0, false);
    }

    @Override // K3.MY3jR
    public Object jAM6dcNA(Continuation continuation) {
        this.aXYSYCVY.rjljd6i();
        return Unit.INSTANCE;
    }

    @Override // K3.MY3jR
    public long mTWLV() {
        return this.aXYSYCVY.rtsRj("mte_copy_paste_banner_interaction_timestamp", -1L, false);
    }

    @Override // K3.MY3jR
    public long n84TFkA9() {
        return this.aXYSYCVY.rtsRj("mte_pin_sound_last_synced_timestamp", 0L, false);
    }

    @Override // K3.MY3jR
    public boolean oZ7qYn() {
        return this.aXYSYCVY.qLLw0g("scanner_burst_sound_muted", false, false);
    }

    @Override // K3.MY3jR
    public void osx7Pl0E() {
        this.aXYSYCVY.eTQUrp("mte_new_copy_paste_banner_impressions", 0, false);
    }

    @Override // K3.MY3jR
    public String oyaOvpOs() {
        return C6.AAnYcst.sMxPLer(this.aXYSYCVY, "lastPublishedReminderDataOnHome", null, false, 4, null);
    }

    @Override // K3.MY3jR
    public void q1ORKN(long j10) {
        this.aXYSYCVY.nyeBEo("mte_copy_paste_banner_interaction_timestamp", j10, false);
    }

    @Override // K3.MY3jR
    public void qLLw0g(long j10) {
        this.aXYSYCVY.nyeBEo("last_shown_receive_money_avatar_nudge_at", j10, false);
    }

    @Override // K3.MY3jR
    public boolean rJCQt16() {
        return this.aXYSYCVY.qLLw0g("mte_one_time_scanner_popup_external_url", true, false);
    }

    @Override // K3.MY3jR
    public void rjljd6i() {
        this.aXYSYCVY.eImdmIyv("is_reminder_bulk_api_success", true, false);
    }

    @Override // K3.MY3jR
    public void rtsRj(long j10) {
        this.aXYSYCVY.nyeBEo("mte_pin_sound_last_synced_timestamp", j10, false);
    }

    @Override // K3.MY3jR
    public Long sMxPLer() {
        long jRtsRj = this.aXYSYCVY.rtsRj("last_shown_receive_money_avatar_nudge_at", -1L, false);
        if (jRtsRj == -1) {
            return null;
        }
        return Long.valueOf(jRtsRj);
    }

    @Override // K3.MY3jR
    public void uTIfLNK0(long j10) {
        this.aXYSYCVY.nyeBEo("last_shown_suggested_favourites_sheet", j10, false);
    }

    @Override // K3.MY3jR
    public Long uYRSwDm() {
        long jRtsRj = this.aXYSYCVY.rtsRj("mte_last_shown_reminder_anim_tooltip_ts", -1L, false);
        if (jRtsRj == -1) {
            return null;
        }
        return Long.valueOf(jRtsRj);
    }

    @Override // K3.MY3jR
    public void yxejkub() {
        this.aXYSYCVY.eTQUrp("mte_new_copy_paste_banner_impressions", this.aXYSYCVY.rJCQt16("mte_new_copy_paste_banner_impressions", 0, false) + 1, false);
    }

    @Override // K3.MY3jR
    public void zDWsfFRp(String data) {
        Intrinsics.checkNotNullParameter(data, "data");
        this.aXYSYCVY.wtGiK9b("lastPublishedReminderDataOnHome", data, false);
    }

    @Override // K3.MY3jR
    public boolean zPJpxWz() {
        return this.aXYSYCVY.qLLw0g("is_reminder_bulk_api_success", false, false);
    }
}
