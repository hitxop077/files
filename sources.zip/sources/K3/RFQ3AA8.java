package K3;

import X9.JQAVH;
import X9.N1vNRFSd;
import android.content.Context;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class RFQ3AA8 implements N1vNRFSd {
    public final JQAVH aXYSYCVY;

    public RFQ3AA8(JQAVH jqavh) {
        this.aXYSYCVY = jqavh;
    }

    public static AAnYcst eLbhX59K(Context context) {
        return new AAnYcst(context);
    }

    public static RFQ3AA8 eszJ2B0a(JQAVH jqavh) {
        return new RFQ3AA8(jqavh);
    }

    @Override // p134eb.MY3jR
    /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
    public AAnYcst get() {
        return eLbhX59K((Context) this.aXYSYCVY.get());
    }
}
