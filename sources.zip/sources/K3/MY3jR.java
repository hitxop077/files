package K3;

import kotlin.coroutines.Continuation;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes9.dex */
public interface MY3jR {
    void aXYSYCVY(int i10);

    int bsO5Vo();

    void dUI84(boolean z10);

    Long eLbhX59K();

    void eszJ2B0a(Long l10);

    int ivfTYNl();

    Object jAM6dcNA(Continuation continuation);

    long mTWLV();

    long n84TFkA9();

    boolean oZ7qYn();

    void osx7Pl0E();

    String oyaOvpOs();

    void q1ORKN(long j10);

    void qLLw0g(long j10);

    boolean rJCQt16();

    void rjljd6i();

    void rtsRj(long j10);

    Long sMxPLer();

    void uTIfLNK0(long j10);

    Long uYRSwDm();

    void yxejkub();

    void zDWsfFRp(String str);

    boolean zPJpxWz();
}
