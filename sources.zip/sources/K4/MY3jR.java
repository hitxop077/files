package K4;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes9.dex */
public enum MY3jR {
    FRONT,
    BACK
}
