package K5;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class MY3jR {
}
