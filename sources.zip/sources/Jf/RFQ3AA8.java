package Jf;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class RFQ3AA8 implements O0DWnU {
    public static final RFQ3AA8 eszJ2B0a = new RFQ3AA8();

    @Override // Jf.O0DWnU
    public void eszJ2B0a(String reason) {
        Intrinsics.checkNotNullParameter(reason, "reason");
    }

    @Override // Jf.O0DWnU
    public void aXYSYCVY(String str) {
    }
}
