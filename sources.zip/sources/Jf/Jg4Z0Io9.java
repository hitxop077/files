package Jf;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public interface Jg4Z0Io9 {
    void fJF5ikJ(String str);

    void iSYsk6K(String str);

    void m9CVKvQy();
}
