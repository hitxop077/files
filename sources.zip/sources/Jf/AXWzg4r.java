package Jf;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class AXWzg4r {
    public final boolean aXYSYCVY;
    public final boolean eLbhX59K;
    public final String eszJ2B0a;
    public final boolean ivfTYNl;
    public final boolean zDWsfFRp;

    public AXWzg4r(String str, boolean z10, boolean z11, boolean z12, boolean z13) {
        this.eszJ2B0a = str;
        this.aXYSYCVY = z10;
        this.eLbhX59K = z11;
        this.zDWsfFRp = z12;
        this.ivfTYNl = z13;
    }

    public final boolean aXYSYCVY() {
        return this.aXYSYCVY;
    }

    public final boolean eLbhX59K() {
        return this.ivfTYNl;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AXWzg4r)) {
            return false;
        }
        AXWzg4r aXWzg4r = (AXWzg4r) obj;
        return Intrinsics.areEqual(this.eszJ2B0a, aXWzg4r.eszJ2B0a) && this.aXYSYCVY == aXWzg4r.aXYSYCVY && this.eLbhX59K == aXWzg4r.eLbhX59K && this.zDWsfFRp == aXWzg4r.zDWsfFRp && this.ivfTYNl == aXWzg4r.ivfTYNl;
    }

    public final boolean eszJ2B0a() {
        return this.eLbhX59K;
    }

    public int hashCode() {
        String str = this.eszJ2B0a;
        return ((((((((str == null ? 0 : str.hashCode()) * 31) + Boolean.hashCode(this.aXYSYCVY)) * 31) + Boolean.hashCode(this.eLbhX59K)) * 31) + Boolean.hashCode(this.zDWsfFRp)) * 31) + Boolean.hashCode(this.ivfTYNl);
    }

    public final boolean ivfTYNl() {
        return this.zDWsfFRp;
    }

    public String toString() {
        return "PostPaymentSseSubscribeParams(txnAmount=" + this.eszJ2B0a + ", multiLanguage=" + this.aXYSYCVY + ", modifyCtaPlacement=" + this.eLbhX59K + ", isShareReceipt=" + this.zDWsfFRp + ", paymentSummaryCard=" + this.ivfTYNl + ")";
    }

    public final String zDWsfFRp() {
        return this.eszJ2B0a;
    }
}
