package Jf;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class H8UuVVi {
    public static final H8UuVVi eszJ2B0a = new H8UuVVi();
    public static volatile XR9Xco aXYSYCVY = XR9Xco.NONE;
    public static final int eLbhX59K = 8;

    public final void aXYSYCVY() {
        aXYSYCVY = XR9Xco.NONE;
    }

    public final void eszJ2B0a(XR9Xco source) {
        Intrinsics.checkNotNullParameter(source, "source");
        aXYSYCVY = source;
    }
}
