package Jf;

import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.pluginupi.common.model.transaction.UpiPluginCommonPayRequestModelPlugin;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class QChIE25g {
    public static final QChIE25g eszJ2B0a = new QChIE25g();

    public final boolean aXYSYCVY(boolean z10, boolean z11) {
        return z10 || z11;
    }

    public final boolean eszJ2B0a(UpiPluginCommonPayRequestModelPlugin request, boolean z10) {
        Intrinsics.checkNotNullParameter(request, "request");
        return aXYSYCVY(request.getIntlTxnReqDetails() != null, z10);
    }
}
