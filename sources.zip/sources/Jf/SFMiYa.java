package Jf;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public interface SFMiYa {
    void aXYSYCVY(String str, String str2);

    void dUI84(String str, String str2);

    void eLbhX59K(String str);

    void eszJ2B0a(net.one97.paytm.pluginupi.common.model.AAnYcst aAnYcst, Af.MY3jR mY3jR);

    void ivfTYNl(int i10);

    void oZ7qYn(String str, String str2, String str3);

    void osx7Pl0E(String str);

    void rjljd6i(net.one97.paytm.pluginupi.common.model.AAnYcst aAnYcst, Af.MY3jR mY3jR);

    void zDWsfFRp(net.one97.paytm.pluginupi.common.model.AAnYcst aAnYcst, boolean z10, Af.MY3jR mY3jR);

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public static void eszJ2B0a(SFMiYa sFMiYa, String str) {
        }
    }
}
