package Jf;

import com.paytm.android.chat.managers.connectivity.EK.lLImZ;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public enum XR9Xco {
    GTM_DEFAULT("pps_cta_gtm_default"),
    TERMINAL(lLImZ.lVDptYN),
    NONE("pps_cta_none");

    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries(values());
    private final String pulseLabel;

    XR9Xco(String str) {
        this.pulseLabel = str;
    }

    public static EnumEntries<XR9Xco> getEntries() {
        return $ENTRIES;
    }

    public final String getPulseLabel() {
        return this.pulseLabel;
    }
}
