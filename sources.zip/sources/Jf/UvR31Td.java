package Jf;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class UvR31Td {
    public final String aXYSYCVY;
    public final boolean dUI84;
    public final Long eLbhX59K;
    public final String eszJ2B0a;
    public final Long ivfTYNl;
    public final String oZ7qYn;
    public final Long osx7Pl0E;
    public final String q1ORKN;
    public final Boolean qLLw0g;
    public final Long rjljd6i;
    public final Long zDWsfFRp;
    public final Long zPJpxWz;

    public UvR31Td(String str, String str2, Long l10, Long l11, Long l12, Long l13, boolean z10, String ppsDisplayMode, Long l14, Long l15, Boolean bool, String str3) {
        Intrinsics.checkNotNullParameter(ppsDisplayMode, "ppsDisplayMode");
        this.eszJ2B0a = str;
        this.aXYSYCVY = str2;
        this.eLbhX59K = l10;
        this.zDWsfFRp = l11;
        this.ivfTYNl = l12;
        this.osx7Pl0E = l13;
        this.dUI84 = z10;
        this.oZ7qYn = ppsDisplayMode;
        this.rjljd6i = l14;
        this.zPJpxWz = l15;
        this.qLLw0g = bool;
        this.q1ORKN = str3;
    }

    public final Long aXYSYCVY() {
        return this.zPJpxWz;
    }

    public final Boolean dUI84() {
        return this.qLLw0g;
    }

    public final boolean eLbhX59K() {
        return this.dUI84;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof UvR31Td)) {
            return false;
        }
        UvR31Td uvR31Td = (UvR31Td) obj;
        return Intrinsics.areEqual(this.eszJ2B0a, uvR31Td.eszJ2B0a) && Intrinsics.areEqual(this.aXYSYCVY, uvR31Td.aXYSYCVY) && Intrinsics.areEqual(this.eLbhX59K, uvR31Td.eLbhX59K) && Intrinsics.areEqual(this.zDWsfFRp, uvR31Td.zDWsfFRp) && Intrinsics.areEqual(this.ivfTYNl, uvR31Td.ivfTYNl) && Intrinsics.areEqual(this.osx7Pl0E, uvR31Td.osx7Pl0E) && this.dUI84 == uvR31Td.dUI84 && Intrinsics.areEqual(this.oZ7qYn, uvR31Td.oZ7qYn) && Intrinsics.areEqual(this.rjljd6i, uvR31Td.rjljd6i) && Intrinsics.areEqual(this.zPJpxWz, uvR31Td.zPJpxWz) && Intrinsics.areEqual(this.qLLw0g, uvR31Td.qLLw0g) && Intrinsics.areEqual(this.q1ORKN, uvR31Td.q1ORKN);
    }

    public final Long eszJ2B0a() {
        return this.osx7Pl0E;
    }

    public int hashCode() {
        String str = this.eszJ2B0a;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.aXYSYCVY;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        Long l10 = this.eLbhX59K;
        int iHashCode3 = (iHashCode2 + (l10 == null ? 0 : l10.hashCode())) * 31;
        Long l11 = this.zDWsfFRp;
        int iHashCode4 = (iHashCode3 + (l11 == null ? 0 : l11.hashCode())) * 31;
        Long l12 = this.ivfTYNl;
        int iHashCode5 = (iHashCode4 + (l12 == null ? 0 : l12.hashCode())) * 31;
        Long l13 = this.osx7Pl0E;
        int iHashCode6 = (((((iHashCode5 + (l13 == null ? 0 : l13.hashCode())) * 31) + Boolean.hashCode(this.dUI84)) * 31) + this.oZ7qYn.hashCode()) * 31;
        Long l14 = this.rjljd6i;
        int iHashCode7 = (iHashCode6 + (l14 == null ? 0 : l14.hashCode())) * 31;
        Long l15 = this.zPJpxWz;
        int iHashCode8 = (iHashCode7 + (l15 == null ? 0 : l15.hashCode())) * 31;
        Boolean bool = this.qLLw0g;
        int iHashCode9 = (iHashCode8 + (bool == null ? 0 : bool.hashCode())) * 31;
        String str3 = this.q1ORKN;
        return iHashCode9 + (str3 != null ? str3.hashCode() : 0);
    }

    public final String ivfTYNl() {
        return this.oZ7qYn;
    }

    public final String oZ7qYn() {
        return this.q1ORKN;
    }

    public final Long osx7Pl0E() {
        return this.zDWsfFRp;
    }

    public final String qLLw0g() {
        return this.aXYSYCVY;
    }

    public final String rjljd6i() {
        return this.eszJ2B0a;
    }

    public String toString() {
        return "ShadowBenchmarkResult(txnId=" + this.eszJ2B0a + ", winnerSource=" + this.aXYSYCVY + ", winnerMs=" + this.eLbhX59K + ", sseTerminalMs=" + this.zDWsfFRp + ", pollTerminalMs=" + this.ivfTYNl + ", deltaMs=" + this.osx7Pl0E + ", loserTimedOut=" + this.dUI84 + ", ppsDisplayMode=" + this.oZ7qYn + ", firstPpsFromPayMs=" + this.rjljd6i + ", interimToTerminalMs=" + this.zPJpxWz + ", terminalUiEnriched=" + this.qLLw0g + ", terminalUiSkipReason=" + this.q1ORKN + ")";
    }

    public final Long zDWsfFRp() {
        return this.ivfTYNl;
    }

    public final Long zPJpxWz() {
        return this.eLbhX59K;
    }
}
