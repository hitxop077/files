package Jf;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public interface O0DWnU {
    void aXYSYCVY(String str);

    void eszJ2B0a(String str);
}
