package Jf;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class Gyx10a {
    public static final Gyx10a eszJ2B0a = new Gyx10a();

    public static final void aXYSYCVY(String str, String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        if (str != null) {
            StringsKt.isBlank(str);
        }
    }

    public static final void dUI84(String str, String flow, String tier, String str2, String str3, Boolean bool, String str4) {
        Intrinsics.checkNotNullParameter(flow, "flow");
        Intrinsics.checkNotNullParameter(tier, "tier");
        ivfTYNl("UI_APPLY", str, flow, tier, str2, str3, bool, true, str4);
    }

    public static final void eLbhX59K(String str, String flow, String tier, String str2, String str3, Boolean bool, boolean z10) {
        Intrinsics.checkNotNullParameter(flow, "flow");
        Intrinsics.checkNotNullParameter(tier, "tier");
        osx7Pl0E("ORCHESTRATION", str, flow, tier, str2, str3, bool, z10, null, 256, null);
    }

    public static final void eszJ2B0a(String message) {
        Intrinsics.checkNotNullParameter(message, "message");
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0040  */
    /* JADX WARN: Code duplicated, block: B:28:0x0067  */
    public static final void ivfTYNl(String str, String str2, String str3, String str4, String str5, String str6, Boolean bool, boolean z10, String str7) {
        String str8;
        String str9;
        String str10;
        String str11 = null;
        if (str2 != null) {
            if (StringsKt.isBlank(str2)) {
                str2 = null;
            }
            if (str2 != null) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("txnId=");
                sb2.append(str2);
                sb2.append(" ");
            }
        }
        if (str5 == null) {
            str8 = null;
        } else {
            if (StringsKt.isBlank(str5)) {
                str5 = null;
            }
            if (str5 != null) {
                str8 = "status=" + str5 + " ";
            } else {
                str8 = null;
            }
        }
        if (str8 == null) {
            str8 = "";
        }
        if (str6 == null) {
            str9 = null;
        } else {
            if (StringsKt.isBlank(str6)) {
                str6 = null;
            }
            if (str6 != null) {
                str9 = "rc=" + str6 + " ";
            } else {
                str9 = null;
            }
        }
        if (str9 == null) {
            str9 = "";
        }
        if (bool != null) {
            str10 = "animate=" + bool.booleanValue() + " ";
        } else {
            str10 = null;
        }
        if (str10 == null) {
            str10 = "";
        }
        if (str7 != null) {
            if (StringsKt.isBlank(str7)) {
                str7 = null;
            }
            if (str7 != null) {
                str11 = "detail=\"" + str7 + "\" ";
            }
        }
        StringsKt.trimEnd((CharSequence) ("flow=" + str3 + " tier=" + str4 + " " + str8 + str9 + str10 + (str11 != null ? str11 : ""))).toString();
    }

    public static /* synthetic */ void oZ7qYn(String str, String str2, String str3, String str4, String str5, Boolean bool, String str6, int i10, Object obj) {
        if ((i10 & 32) != 0) {
            bool = null;
        }
        if ((i10 & 64) != 0) {
            str6 = null;
        }
        dUI84(str, str2, str3, str4, str5, bool, str6);
    }

    public static /* synthetic */ void osx7Pl0E(String str, String str2, String str3, String str4, String str5, String str6, Boolean bool, boolean z10, String str7, int i10, Object obj) {
        if ((i10 & 64) != 0) {
            bool = null;
        }
        if ((i10 & 128) != 0) {
            z10 = true;
        }
        if ((i10 & 256) != 0) {
            str7 = null;
        }
        ivfTYNl(str, str2, str3, str4, str5, str6, bool, z10, str7);
    }

    public static /* synthetic */ void zDWsfFRp(String str, String str2, String str3, String str4, String str5, Boolean bool, boolean z10, int i10, Object obj) {
        if ((i10 & 32) != 0) {
            bool = null;
        }
        Boolean bool2 = bool;
        if ((i10 & 64) != 0) {
            z10 = true;
        }
        eLbhX59K(str, str2, str3, str4, str5, bool2, z10);
    }
}
