package Kg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import easypay.manager.Constants;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Kg.LNd998w, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\b\u0087\b\u0018\u00002\u00020\u0001B9\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\n\u0010\u000bJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\u000bJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\u000bJ\u0012\u0010\u000e\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\u000bJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u000bJL\u0010\u0010\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u000bJ\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0019\u001a\u00020\u00182\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016HÖ\u0003¢\u0006\u0004\b\u0019\u0010\u001aR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u001b\u001a\u0004\b\u001c\u0010\u000bR\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001b\u001a\u0004\b\u001d\u0010\u000bR\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u001b\u001a\u0004\b\u001e\u0010\u000bR\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u001b\u001a\u0004\b\u001f\u0010\u000bR\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010\u001b\u001a\u0004\b \u0010\u000b¨\u0006!"}, d2 = {"LKg/LNd998w;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "vpa", "bankAccount", Constants.EVENTS_BANK_NAME, "ifsc", "name", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "component5", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LKg/LNd998w;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getVpa", "getBankAccount", "getBankName", "getIfsc", "getName", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class PayeeDetails extends IJRPaytmDataModel {
    public static final int $stable = 0;

    @SerializedName("bankAccount")
    private final String bankAccount;

    @SerializedName(Constants.EVENTS_BANK_NAME)
    private final String bankName;

    @SerializedName("ifsc")
    private final String ifsc;

    @SerializedName("name")
    private final String name;

    @SerializedName("vpa")
    private final String vpa;

    public PayeeDetails(String str, String str2, String str3, String str4, String str5) {
        this.vpa = str;
        this.bankAccount = str2;
        this.bankName = str3;
        this.ifsc = str4;
        this.name = str5;
    }

    public static /* synthetic */ PayeeDetails copy$default(PayeeDetails payeeDetails, String str, String str2, String str3, String str4, String str5, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = payeeDetails.vpa;
        }
        if ((i10 & 2) != 0) {
            str2 = payeeDetails.bankAccount;
        }
        if ((i10 & 4) != 0) {
            str3 = payeeDetails.bankName;
        }
        if ((i10 & 8) != 0) {
            str4 = payeeDetails.ifsc;
        }
        if ((i10 & 16) != 0) {
            str5 = payeeDetails.name;
        }
        String str6 = str5;
        String str7 = str3;
        return payeeDetails.copy(str, str2, str7, str4, str6);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getVpa() {
        return this.vpa;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getBankAccount() {
        return this.bankAccount;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getBankName() {
        return this.bankName;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getIfsc() {
        return this.ifsc;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getName() {
        return this.name;
    }

    public final PayeeDetails copy(String vpa, String bankAccount, String bankName, String ifsc, String name) {
        return new PayeeDetails(vpa, bankAccount, bankName, ifsc, name);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PayeeDetails)) {
            return false;
        }
        PayeeDetails payeeDetails = (PayeeDetails) other;
        return Intrinsics.areEqual(this.vpa, payeeDetails.vpa) && Intrinsics.areEqual(this.bankAccount, payeeDetails.bankAccount) && Intrinsics.areEqual(this.bankName, payeeDetails.bankName) && Intrinsics.areEqual(this.ifsc, payeeDetails.ifsc) && Intrinsics.areEqual(this.name, payeeDetails.name);
    }

    public final String getBankAccount() {
        return this.bankAccount;
    }

    public final String getBankName() {
        return this.bankName;
    }

    public final String getIfsc() {
        return this.ifsc;
    }

    public final String getName() {
        return this.name;
    }

    public final String getVpa() {
        return this.vpa;
    }

    public int hashCode() {
        String str = this.vpa;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.bankAccount;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.bankName;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.ifsc;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.name;
        return iHashCode4 + (str5 != null ? str5.hashCode() : 0);
    }

    public String toString() {
        return "PayeeDetails(vpa=" + this.vpa + ", bankAccount=" + this.bankAccount + ", bankName=" + this.bankName + ", ifsc=" + this.ifsc + ", name=" + this.name + ")";
    }
}
