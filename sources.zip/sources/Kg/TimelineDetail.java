package Kg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import p497q7.SFMiYa;

/* JADX INFO: renamed from: Kg.W7Cnq5, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001Ba\u0012\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\n\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\r\u0010\u000eJ\u0018\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u0011\u0010\u0012J\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u0013\u0010\u0012J\u0012\u0010\u0014\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u0014\u0010\u0012J\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u0015\u0010\u0012J\u0012\u0010\u0016\u001a\u0004\u0018\u00010\nHÆ\u0003¢\u0006\u0004\b\u0016\u0010\u0017J\u0012\u0010\u0018\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u0018\u0010\u0012Jj\u0010\u0019\u001a\u00020\u00002\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0004\b\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0005HÖ\u0001¢\u0006\u0004\b\u001b\u0010\u0012J\u0010\u0010\u001c\u001a\u00020\nHÖ\u0001¢\u0006\u0004\b\u001c\u0010\u001dJ\u001a\u0010!\u001a\u00020 2\b\u0010\u001f\u001a\u0004\u0018\u00010\u001eHÖ\u0003¢\u0006\u0004\b!\u0010\"R\"\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010#\u001a\u0004\b$\u0010\u0010R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010%\u001a\u0004\b&\u0010\u0012R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010%\u001a\u0004\b'\u0010\u0012R$\u0010\b\u001a\u0004\u0018\u00010\u00058\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\b\u0010%\u001a\u0004\b(\u0010\u0012\"\u0004\b)\u0010*R\u001c\u0010\t\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010%\u001a\u0004\b+\u0010\u0012R\u001c\u0010\u000b\u001a\u0004\u0018\u00010\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u000b\u0010,\u001a\u0004\b-\u0010\u0017R\u001c\u0010\f\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\f\u0010%\u001a\u0004\b.\u0010\u0012¨\u0006/"}, d2 = {"LKg/W7Cnq5;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "LKg/AAnYcst;", "ctaList", "", SFMiYa.UTILITY_KEY_DESCRIPTION, SFMiYa.KEY_CONTACT_IMAGEURL, "lastUpdatedTimeStamp", "nodeStatus", "", "serialNo", "title", "<init>", "(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V", "component1", "()Ljava/util/List;", "component2", "()Ljava/lang/String;", "component3", "component4", "component5", "component6", "()Ljava/lang/Integer;", "component7", "copy", "(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)LKg/W7Cnq5;", "toString", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/util/List;", "getCtaList", "Ljava/lang/String;", "getDescription", "getImageUrl", "getLastUpdatedTimeStamp", "setLastUpdatedTimeStamp", "(Ljava/lang/String;)V", "getNodeStatus", "Ljava/lang/Integer;", "getSerialNo", "getTitle", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class TimelineDetail extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("ctaList")
    private final List<Cta> ctaList;

    @SerializedName(SFMiYa.UTILITY_KEY_DESCRIPTION)
    private final String description;

    @SerializedName(SFMiYa.KEY_CONTACT_IMAGEURL)
    private final String imageUrl;

    @SerializedName("lastUpdatedTimeStamp")
    private String lastUpdatedTimeStamp;

    @SerializedName("nodeStatus")
    private final String nodeStatus;

    @SerializedName("serialNo")
    private final Integer serialNo;

    @SerializedName("title")
    private final String title;

    public TimelineDetail() {
        this(null, null, null, null, null, null, null, 127, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ TimelineDetail copy$default(TimelineDetail timelineDetail, List list, String str, String str2, String str3, String str4, Integer num, String str5, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            list = timelineDetail.ctaList;
        }
        if ((i10 & 2) != 0) {
            str = timelineDetail.description;
        }
        if ((i10 & 4) != 0) {
            str2 = timelineDetail.imageUrl;
        }
        if ((i10 & 8) != 0) {
            str3 = timelineDetail.lastUpdatedTimeStamp;
        }
        if ((i10 & 16) != 0) {
            str4 = timelineDetail.nodeStatus;
        }
        if ((i10 & 32) != 0) {
            num = timelineDetail.serialNo;
        }
        if ((i10 & 64) != 0) {
            str5 = timelineDetail.title;
        }
        Integer num2 = num;
        String str6 = str5;
        String str7 = str4;
        String str8 = str2;
        return timelineDetail.copy(list, str, str8, str3, str7, num2, str6);
    }

    public final List<Cta> component1() {
        return this.ctaList;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getDescription() {
        return this.description;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getImageUrl() {
        return this.imageUrl;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getLastUpdatedTimeStamp() {
        return this.lastUpdatedTimeStamp;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getNodeStatus() {
        return this.nodeStatus;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final Integer getSerialNo() {
        return this.serialNo;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    public final TimelineDetail copy(List<Cta> ctaList, String description, String imageUrl, String lastUpdatedTimeStamp, String nodeStatus, Integer serialNo, String title) {
        return new TimelineDetail(ctaList, description, imageUrl, lastUpdatedTimeStamp, nodeStatus, serialNo, title);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TimelineDetail)) {
            return false;
        }
        TimelineDetail timelineDetail = (TimelineDetail) other;
        return Intrinsics.areEqual(this.ctaList, timelineDetail.ctaList) && Intrinsics.areEqual(this.description, timelineDetail.description) && Intrinsics.areEqual(this.imageUrl, timelineDetail.imageUrl) && Intrinsics.areEqual(this.lastUpdatedTimeStamp, timelineDetail.lastUpdatedTimeStamp) && Intrinsics.areEqual(this.nodeStatus, timelineDetail.nodeStatus) && Intrinsics.areEqual(this.serialNo, timelineDetail.serialNo) && Intrinsics.areEqual(this.title, timelineDetail.title);
    }

    public final List<Cta> getCtaList() {
        return this.ctaList;
    }

    public final String getDescription() {
        return this.description;
    }

    public final String getImageUrl() {
        return this.imageUrl;
    }

    public final String getLastUpdatedTimeStamp() {
        return this.lastUpdatedTimeStamp;
    }

    public final String getNodeStatus() {
        return this.nodeStatus;
    }

    public final Integer getSerialNo() {
        return this.serialNo;
    }

    public final String getTitle() {
        return this.title;
    }

    public int hashCode() {
        List<Cta> list = this.ctaList;
        int iHashCode = (list == null ? 0 : list.hashCode()) * 31;
        String str = this.description;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.imageUrl;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.lastUpdatedTimeStamp;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.nodeStatus;
        int iHashCode5 = (iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
        Integer num = this.serialNo;
        int iHashCode6 = (iHashCode5 + (num == null ? 0 : num.hashCode())) * 31;
        String str5 = this.title;
        return iHashCode6 + (str5 != null ? str5.hashCode() : 0);
    }

    public final void setLastUpdatedTimeStamp(String str) {
        this.lastUpdatedTimeStamp = str;
    }

    public String toString() {
        return "TimelineDetail(ctaList=" + this.ctaList + ", description=" + this.description + ", imageUrl=" + this.imageUrl + ", lastUpdatedTimeStamp=" + this.lastUpdatedTimeStamp + ", nodeStatus=" + this.nodeStatus + ", serialNo=" + this.serialNo + ", title=" + this.title + ")";
    }

    public /* synthetic */ TimelineDetail(List list, String str, String str2, String str3, String str4, Integer num, String str5, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? CollectionsKt.emptyList() : list, (i10 & 2) != 0 ? "" : str, (i10 & 4) != 0 ? "" : str2, (i10 & 8) != 0 ? null : str3, (i10 & 16) != 0 ? "" : str4, (i10 & 32) != 0 ? 0 : num, (i10 & 64) != 0 ? "" : str5);
    }

    public TimelineDetail(List<Cta> list, String str, String str2, String str3, String str4, Integer num, String str5) {
        this.ctaList = list;
        this.description = str;
        this.imageUrl = str2;
        this.lastUpdatedTimeStamp = str3;
        this.nodeStatus = str4;
        this.serialNo = num;
        this.title = str5;
    }
}
