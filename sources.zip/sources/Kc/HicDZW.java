package Kc;

/* JADX INFO: loaded from: classes12.dex */
public abstract class HicDZW {
    public static final int circular_loder = 2131951633;
    public static final int complete = 2131951634;
    public static final int error_state = 2131951646;
    public static final int firebase_common_keep = 2131951648;
    public static final int firebase_crashlytics_keep = 2131951649;
    public static final int keep = 2131951654;
    public static final int keep_cronet_api = 2131951655;
    public static final int mic_listening = 2131951662;
    public static final int search_loader = 2131951689;
    public static final int search_loader_dark = 2131951690;
}
