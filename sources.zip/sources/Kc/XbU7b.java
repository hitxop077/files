package Kc;

/* JADX INFO: loaded from: classes12.dex */
public abstract class XbU7b {
    public static final int inter = 2131296260;
    public static final int inter_bold = 2131296261;
    public static final int inter_medium = 2131296262;
    public static final int inter_regular = 2131296263;
    public static final int inter_semi_bold = 2131296264;
    public static final int montserrat_extra_bold = 2131296265;
}
