package Kc;

import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public abstract class MY3jR {
    public static Tc.AAnYcst aXYSYCVY;
    public static final C0106MY3jR eszJ2B0a = new C0106MY3jR(null);

    /* JADX INFO: renamed from: Kc.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static final class C0106MY3jR {
        public /* synthetic */ C0106MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void aXYSYCVY(Tc.AAnYcst aAnYcst) {
            MY3jR.aXYSYCVY = aAnYcst;
        }

        public final void eLbhX59K() {
            try {
                Qk.RFQ3AA8.MY3jR mY3jR = Qk.RFQ3AA8.eszJ2B0a;
                Qk.RFQ3AA8.class.getMethod("initDesignModule", null).invoke(null, null);
            } catch (Exception e10) {
                e10.getMessage();
            }
        }

        public final Tc.AAnYcst eszJ2B0a() {
            if (MY3jR.aXYSYCVY == null) {
                eLbhX59K();
            }
            return MY3jR.aXYSYCVY;
        }

        public C0106MY3jR() {
        }
    }
}
