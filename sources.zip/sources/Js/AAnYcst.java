package Js;

/* JADX INFO: loaded from: classes5.dex */
public abstract class AAnYcst extends Or.AAnYcst {
    public RFQ3AA8 vo5p9AUA;

    public AAnYcst(boolean z10, RFQ3AA8 rfq3aa8) {
        super(z10);
        this.vo5p9AUA = rfq3aa8;
    }

    public RFQ3AA8 aXYSYCVY() {
        return this.vo5p9AUA;
    }
}
