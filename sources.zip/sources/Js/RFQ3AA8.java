package Js;

import org.bouncycastle.crypto.JQAVH;
import p497q7.SFMiYa;

/* JADX INFO: loaded from: classes5.dex */
public class RFQ3AA8 implements JQAVH {
    public MY3jR dNE3s;
    public int fdmP9GD;
    public int gmzPK;
    public String njNibPNp;
    public final int pz7TsV;
    public int vo5p9AUA;
    public int vskcqLTQ;
    public int xINpNt2d;
    public int zYD7SXW6;
    public static final RFQ3AA8 i2VlO = new RFQ3AA8("bike128", 12323, 142, 134, 256, 5, 3, 128);
    public static final RFQ3AA8 zigsCJW = new RFQ3AA8("bike192", 24659, 206, SFMiYa.PP_SAVED_CARD_REQUEST_CODE, 256, 5, 3, 192);
    public static final RFQ3AA8 ca3iT = new RFQ3AA8("bike256", 40973, 274, 264, 256, 5, 3, 256);

    public RFQ3AA8(String str, int i10, int i11, int i12, int i13, int i14, int i15, int i16) {
        this.njNibPNp = str;
        this.vo5p9AUA = i10;
        this.gmzPK = i11;
        this.zYD7SXW6 = i12;
        this.xINpNt2d = i13;
        this.fdmP9GD = i14;
        this.vskcqLTQ = i15;
        this.pz7TsV = i16;
        this.dNE3s = new MY3jR(i10, i11, i12, i13, i14, i15);
    }

    public int aXYSYCVY() {
        return (this.vo5p9AUA + 7) / 8;
    }

    public String eszJ2B0a() {
        return this.njNibPNp;
    }
}
