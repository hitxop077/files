package Js;

/* JADX INFO: loaded from: classes5.dex */
public class MY3jR {
    public int aXYSYCVY;
    public final XbU7b dUI84;
    public int eLbhX59K;
    public int eszJ2B0a;
    public int ivfTYNl;
    public int oZ7qYn;
    public int osx7Pl0E;
    public int rjljd6i;
    public int zDWsfFRp;
    public int zPJpxWz;

    public MY3jR(int i10, int i11, int i12, int i13, int i14, int i15) {
        this.eszJ2B0a = i10;
        this.aXYSYCVY = i11;
        this.zDWsfFRp = i12;
        this.ivfTYNl = i14;
        this.osx7Pl0E = i15;
        this.eLbhX59K = i11 / 2;
        this.oZ7qYn = i13 / 8;
        this.rjljd6i = (i10 + 7) >>> 3;
        this.zPJpxWz = ((i10 * 2) + 7) >>> 3;
        this.dUI84 = new XbU7b(i10);
    }
}
