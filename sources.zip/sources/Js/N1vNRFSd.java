package Js;

/* JADX INFO: loaded from: classes5.dex */
public class N1vNRFSd extends AAnYcst {
    public byte[] gmzPK;

    public N1vNRFSd(RFQ3AA8 rfq3aa8, byte[] bArr) {
        super(false, rfq3aa8);
        this.gmzPK = wt.MY3jR.oZ7qYn(bArr);
    }

    public byte[] getEncoded() {
        return wt.MY3jR.oZ7qYn(this.gmzPK);
    }
}
