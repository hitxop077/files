package Js;

/* JADX INFO: loaded from: classes5.dex */
public class LNd998w extends AAnYcst {
    public byte[] gmzPK;
    public byte[] xINpNt2d;
    public byte[] zYD7SXW6;

    public LNd998w(RFQ3AA8 rfq3aa8, byte[] bArr, byte[] bArr2, byte[] bArr3) {
        super(true, rfq3aa8);
        this.gmzPK = wt.MY3jR.oZ7qYn(bArr);
        this.zYD7SXW6 = wt.MY3jR.oZ7qYn(bArr2);
        this.xINpNt2d = wt.MY3jR.oZ7qYn(bArr3);
    }

    public byte[] getEncoded() {
        return wt.MY3jR.rJCQt16(this.gmzPK, this.zYD7SXW6, this.xINpNt2d);
    }
}
