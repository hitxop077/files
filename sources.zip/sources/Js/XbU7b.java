package Js;

import java.util.HashMap;
import java.util.Map;
import wt.HicDZW;

/* JADX INFO: loaded from: classes5.dex */
public class XbU7b {
    public final int aXYSYCVY;
    public final int eLbhX59K;
    public final int eszJ2B0a;
    public final Map zDWsfFRp;

    public XbU7b(int i10) {
        HashMap map = new HashMap();
        this.zDWsfFRp = map;
        if (((-65535) & i10) != 1) {
            throw new IllegalArgumentException();
        }
        this.eszJ2B0a = i10;
        int i11 = (i10 + 63) >>> 6;
        this.aXYSYCVY = i11;
        this.eLbhX59K = i11 * 2;
        aXYSYCVY(map, i10);
    }

    public static void aXYSYCVY(Map map, int i10) {
        int i11;
        int i12 = i10 - 2;
        int iEszJ2B0a = 32 - HicDZW.eszJ2B0a(i12);
        int iUTIfLNK0 = Cs.RFQ3AA8.uTIfLNK0(-i10);
        for (int i13 = 1; i13 < iEszJ2B0a; i13++) {
            int i14 = 1 << (i13 - 1);
            if (i14 >= 64 && !map.containsKey(HicDZW.ivfTYNl(i14))) {
                map.put(HicDZW.ivfTYNl(i14), HicDZW.ivfTYNl(eszJ2B0a(i10, iUTIfLNK0, i14)));
            }
            int i15 = 1 << i13;
            if ((i12 & i15) != 0 && (i11 = (i15 - 1) & i12) >= 64 && !map.containsKey(HicDZW.ivfTYNl(i11))) {
                map.put(HicDZW.ivfTYNl(i11), HicDZW.ivfTYNl(eszJ2B0a(i10, iUTIfLNK0, i11)));
            }
        }
    }

    public static int eszJ2B0a(int i10, int i11, int i12) {
        int i13 = 1;
        while (i12 >= 32) {
            i13 = (int) ((((4294967295L & ((long) (i11 * i13))) * ((long) i10)) + ((long) i13)) >>> 32);
            i12 -= 32;
        }
        if (i12 <= 0) {
            return i13;
        }
        return (int) ((((4294967295L & ((long) ((i11 * i13) & ((-1) >>> (-i12))))) * ((long) i10)) + ((long) i13)) >>> i12);
    }
}
