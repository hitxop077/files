package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jj.AAnYcst, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000b\b\u0087\b\u0018\u00002\u00020\u0001B%\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\r\u0010\t\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\r\u0010\u000b\u001a\u00020\b¢\u0006\u0004\b\u000b\u0010\nJ\r\u0010\r\u001a\u00020\f¢\u0006\u0004\b\r\u0010\u000eJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0011\u0010\u0010J\u0012\u0010\u0012\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0012\u0010\u0010J4\u0010\u0013\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\u0013\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0015\u0010\u0010J\u0010\u0010\u0016\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b\u0016\u0010\u000eJ\u001a\u0010\u001a\u001a\u00020\u00192\b\u0010\u0018\u001a\u0004\u0018\u00010\u0017HÖ\u0003¢\u0006\u0004\b\u001a\u0010\u001bR$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u001c\u001a\u0004\b\u001d\u0010\u0010\"\u0004\b\u001e\u0010\u001fR$\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u001c\u001a\u0004\b \u0010\u0010\"\u0004\b!\u0010\u001fR$\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001c\u001a\u0004\b\"\u0010\u0010\"\u0004\b#\u0010\u001f¨\u0006$"}, d2 = {"LJj/AAnYcst;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "initialDelay", "pollingTime", "maxRetries", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "", "getInitialDelaySec", "()J", "getPollingTimeSec", "", "getMaxRetriesInt", "()I", "component1", "()Ljava/lang/String;", "component2", "component3", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LJj/AAnYcst;", "toString", "hashCode", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getInitialDelay", "setInitialDelay", "(Ljava/lang/String;)V", "getPollingTime", "setPollingTime", "getMaxRetries", "setMaxRetries", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class RegisterLiteDetails extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("initialDelay")
    private String initialDelay;

    @SerializedName("maxTries")
    private String maxRetries;

    @SerializedName("pollTime")
    private String pollingTime;

    public RegisterLiteDetails(String str, String str2, String str3) {
        this.initialDelay = str;
        this.pollingTime = str2;
        this.maxRetries = str3;
    }

    public static /* synthetic */ RegisterLiteDetails copy$default(RegisterLiteDetails registerLiteDetails, String str, String str2, String str3, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = registerLiteDetails.initialDelay;
        }
        if ((i10 & 2) != 0) {
            str2 = registerLiteDetails.pollingTime;
        }
        if ((i10 & 4) != 0) {
            str3 = registerLiteDetails.maxRetries;
        }
        return registerLiteDetails.copy(str, str2, str3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getInitialDelay() {
        return this.initialDelay;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getPollingTime() {
        return this.pollingTime;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getMaxRetries() {
        return this.maxRetries;
    }

    public final RegisterLiteDetails copy(String initialDelay, String pollingTime, String maxRetries) {
        return new RegisterLiteDetails(initialDelay, pollingTime, maxRetries);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RegisterLiteDetails)) {
            return false;
        }
        RegisterLiteDetails registerLiteDetails = (RegisterLiteDetails) other;
        return Intrinsics.areEqual(this.initialDelay, registerLiteDetails.initialDelay) && Intrinsics.areEqual(this.pollingTime, registerLiteDetails.pollingTime) && Intrinsics.areEqual(this.maxRetries, registerLiteDetails.maxRetries);
    }

    public final String getInitialDelay() {
        return this.initialDelay;
    }

    public final long getInitialDelaySec() {
        Long longOrNull;
        String str = this.initialDelay;
        if (str == null || (longOrNull = StringsKt.toLongOrNull(str)) == null) {
            return 0L;
        }
        return longOrNull.longValue();
    }

    public final String getMaxRetries() {
        return this.maxRetries;
    }

    public final int getMaxRetriesInt() {
        Integer intOrNull;
        String str = this.maxRetries;
        if (str == null || (intOrNull = StringsKt.toIntOrNull(str)) == null) {
            return 0;
        }
        return intOrNull.intValue();
    }

    public final String getPollingTime() {
        return this.pollingTime;
    }

    public final long getPollingTimeSec() {
        Long longOrNull;
        String str = this.pollingTime;
        if (str == null || (longOrNull = StringsKt.toLongOrNull(str)) == null) {
            return 0L;
        }
        return longOrNull.longValue();
    }

    public int hashCode() {
        String str = this.initialDelay;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.pollingTime;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.maxRetries;
        return iHashCode2 + (str3 != null ? str3.hashCode() : 0);
    }

    public final void setInitialDelay(String str) {
        this.initialDelay = str;
    }

    public final void setMaxRetries(String str) {
        this.maxRetries = str;
    }

    public final void setPollingTime(String str) {
        this.pollingTime = str;
    }

    public String toString() {
        return "RegisterLiteDetails(initialDelay=" + this.initialDelay + ", pollingTime=" + this.pollingTime + ", maxRetries=" + this.maxRetries + ")";
    }
}
