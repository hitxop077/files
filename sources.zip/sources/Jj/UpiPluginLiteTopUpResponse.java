package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: renamed from: Jj.W7Cnq5, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0012\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0087\b\u0018\u00002\u00020\u0001BC\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0002\u0012\b\b\u0002\u0010\b\u001a\u00020\u0002¢\u0006\u0004\b\t\u0010\nJ\u0010\u0010\u000b\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000b\u0010\fJ\u0010\u0010\r\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\fJ\u0010\u0010\u000e\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\fJ\u0010\u0010\u000f\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\fJ\u0010\u0010\u0010\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u0010\u0010\fJ\u0010\u0010\u0011\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u0011\u0010\fJL\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u00022\b\b\u0002\u0010\u0005\u001a\u00020\u00022\b\b\u0002\u0010\u0006\u001a\u00020\u00022\b\b\u0002\u0010\u0007\u001a\u00020\u00022\b\b\u0002\u0010\b\u001a\u00020\u0002HÆ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0014\u0010\fJ\u0010\u0010\u0016\u001a\u00020\u0015HÖ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u001a\u0010\u001b\u001a\u00020\u001a2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u001d\u001a\u0004\b\u001e\u0010\fR\u001a\u0010\u0004\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001d\u001a\u0004\b\u001f\u0010\fR\u001a\u0010\u0005\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u001d\u001a\u0004\b \u0010\fR\u001a\u0010\u0006\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u001d\u001a\u0004\b!\u0010\fR\u001a\u0010\u0007\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010\u001d\u001a\u0004\b\"\u0010\fR\u001a\u0010\b\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010\u001d\u001a\u0004\b#\u0010\f¨\u0006$"}, d2 = {"LJj/W7Cnq5;", "Lnet/one97/paytm/pluginupi/common/model/SFMiYa;", "", "status", "responseCode", "responseMessage", "txnId", "bankRRN", "requestId", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "component5", "component6", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LJj/W7Cnq5;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getStatus", "getResponseCode", "getResponseMessage", "getTxnId", "getBankRRN", "getRequestId", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UpiPluginLiteTopUpResponse extends SFMiYa {
    public static final int $stable = 0;

    @SerializedName("bankRRN")
    private final String bankRRN;

    @SerializedName("requestId")
    private final String requestId;

    @SerializedName("respCode")
    private final String responseCode;

    @SerializedName("respMessage")
    private final String responseMessage;

    @SerializedName("status")
    private final String status;

    @SerializedName("txnId")
    private final String txnId;

    public UpiPluginLiteTopUpResponse() {
        this(null, null, null, null, null, null, 63, null);
    }

    public static /* synthetic */ UpiPluginLiteTopUpResponse copy$default(UpiPluginLiteTopUpResponse upiPluginLiteTopUpResponse, String str, String str2, String str3, String str4, String str5, String str6, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = upiPluginLiteTopUpResponse.status;
        }
        if ((i10 & 2) != 0) {
            str2 = upiPluginLiteTopUpResponse.responseCode;
        }
        if ((i10 & 4) != 0) {
            str3 = upiPluginLiteTopUpResponse.responseMessage;
        }
        if ((i10 & 8) != 0) {
            str4 = upiPluginLiteTopUpResponse.txnId;
        }
        if ((i10 & 16) != 0) {
            str5 = upiPluginLiteTopUpResponse.bankRRN;
        }
        if ((i10 & 32) != 0) {
            str6 = upiPluginLiteTopUpResponse.requestId;
        }
        String str7 = str5;
        String str8 = str6;
        return upiPluginLiteTopUpResponse.copy(str, str2, str3, str4, str7, str8);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getResponseCode() {
        return this.responseCode;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getResponseMessage() {
        return this.responseMessage;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getTxnId() {
        return this.txnId;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getBankRRN() {
        return this.bankRRN;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getRequestId() {
        return this.requestId;
    }

    public final UpiPluginLiteTopUpResponse copy(String status, String responseCode, String responseMessage, String txnId, String bankRRN, String requestId) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(txnId, "txnId");
        Intrinsics.checkNotNullParameter(bankRRN, "bankRRN");
        Intrinsics.checkNotNullParameter(requestId, "requestId");
        return new UpiPluginLiteTopUpResponse(status, responseCode, responseMessage, txnId, bankRRN, requestId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UpiPluginLiteTopUpResponse)) {
            return false;
        }
        UpiPluginLiteTopUpResponse upiPluginLiteTopUpResponse = (UpiPluginLiteTopUpResponse) other;
        return Intrinsics.areEqual(this.status, upiPluginLiteTopUpResponse.status) && Intrinsics.areEqual(this.responseCode, upiPluginLiteTopUpResponse.responseCode) && Intrinsics.areEqual(this.responseMessage, upiPluginLiteTopUpResponse.responseMessage) && Intrinsics.areEqual(this.txnId, upiPluginLiteTopUpResponse.txnId) && Intrinsics.areEqual(this.bankRRN, upiPluginLiteTopUpResponse.bankRRN) && Intrinsics.areEqual(this.requestId, upiPluginLiteTopUpResponse.requestId);
    }

    public final String getBankRRN() {
        return this.bankRRN;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getResponseCode() {
        return this.responseCode;
    }

    public final String getResponseMessage() {
        return this.responseMessage;
    }

    public final String getStatus() {
        return this.status;
    }

    public final String getTxnId() {
        return this.txnId;
    }

    public int hashCode() {
        return (((((((((this.status.hashCode() * 31) + this.responseCode.hashCode()) * 31) + this.responseMessage.hashCode()) * 31) + this.txnId.hashCode()) * 31) + this.bankRRN.hashCode()) * 31) + this.requestId.hashCode();
    }

    public String toString() {
        return "UpiPluginLiteTopUpResponse(status=" + this.status + ", responseCode=" + this.responseCode + ", responseMessage=" + this.responseMessage + ", txnId=" + this.txnId + ", bankRRN=" + this.bankRRN + ", requestId=" + this.requestId + ")";
    }

    public /* synthetic */ UpiPluginLiteTopUpResponse(String str, String str2, String str3, String str4, String str5, String str6, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? "" : str2, (i10 & 4) != 0 ? "" : str3, (i10 & 8) != 0 ? "" : str4, (i10 & 16) != 0 ? "" : str5, (i10 & 32) != 0 ? "" : str6);
    }

    public UpiPluginLiteTopUpResponse(String status, String responseCode, String responseMessage, String txnId, String bankRRN, String requestId) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(txnId, "txnId");
        Intrinsics.checkNotNullParameter(bankRRN, "bankRRN");
        Intrinsics.checkNotNullParameter(requestId, "requestId");
        this.status = status;
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
        this.txnId = txnId;
        this.bankRRN = bankRRN;
        this.requestId = requestId;
    }
}
