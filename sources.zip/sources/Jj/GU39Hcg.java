package Jj;

import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
public final class GU39Hcg extends SFMiYa {
    public static final int $stable = 0;
    private final String lrn;
    private final String respXML;

    public GU39Hcg(String lrn, String respXML) {
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        Intrinsics.checkNotNullParameter(respXML, "respXML");
        this.lrn = lrn;
        this.respXML = respXML;
    }

    public static /* synthetic */ GU39Hcg copy$default(GU39Hcg gU39Hcg, String str, String str2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = gU39Hcg.lrn;
        }
        if ((i10 & 2) != 0) {
            str2 = gU39Hcg.respXML;
        }
        return gU39Hcg.copy(str, str2);
    }

    public final String component1() {
        return this.lrn;
    }

    public final String component2() {
        return this.respXML;
    }

    public final GU39Hcg copy(String lrn, String respXML) {
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        Intrinsics.checkNotNullParameter(respXML, "respXML");
        return new GU39Hcg(lrn, respXML);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof GU39Hcg)) {
            return false;
        }
        GU39Hcg gU39Hcg = (GU39Hcg) obj;
        return Intrinsics.areEqual(this.lrn, gU39Hcg.lrn) && Intrinsics.areEqual(this.respXML, gU39Hcg.respXML);
    }

    public final String getLrn() {
        return this.lrn;
    }

    public final String getRespXML() {
        return this.respXML;
    }

    public int hashCode() {
        return (this.lrn.hashCode() * 31) + this.respXML.hashCode();
    }

    public String toString() {
        return "UpiPluginRegisterLiteResponse(lrn=" + this.lrn + ", respXML=" + this.respXML + ")";
    }
}
