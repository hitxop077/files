package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: renamed from: Jj.XbU7b, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\f\b\u0087\b\u0018\u00002\u00020\u0001BC\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0002\u0012\b\b\u0002\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u0010\u0010\f\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u000e\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\rJ\u0010\u0010\u000f\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\rJ\u0010\u0010\u0010\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u0010\u0010\rJ\u0010\u0010\u0011\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u0011\u0010\rJ\u0010\u0010\u0012\u001a\u00020\bHÆ\u0003¢\u0006\u0004\b\u0012\u0010\u0013JL\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u00022\b\b\u0002\u0010\u0005\u001a\u00020\u00022\b\b\u0002\u0010\u0006\u001a\u00020\u00022\b\b\u0002\u0010\u0007\u001a\u00020\u00022\b\b\u0002\u0010\t\u001a\u00020\bHÆ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0016\u0010\rJ\u0010\u0010\u0018\u001a\u00020\u0017HÖ\u0001¢\u0006\u0004\b\u0018\u0010\u0019J\u001a\u0010\u001c\u001a\u00020\b2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001aHÖ\u0003¢\u0006\u0004\b\u001c\u0010\u001dR\u001a\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u001e\u001a\u0004\b\u001f\u0010\rR\u001a\u0010\u0004\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001e\u001a\u0004\b \u0010\rR\u001a\u0010\u0005\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u001e\u001a\u0004\b!\u0010\rR\u001a\u0010\u0006\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u001e\u001a\u0004\b\"\u0010\rR\u001a\u0010\u0007\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010\u001e\u001a\u0004\b#\u0010\rR\u001a\u0010\t\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010$\u001a\u0004\b%\u0010\u0013¨\u0006&"}, d2 = {"LJj/XbU7b;", "Lnet/one97/paytm/pluginupi/common/model/SFMiYa;", "", "status", "requestId", "responseMessage", "responseCode", "arpc", "", "deregisteredArpc", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "component5", "component6", "()Z", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)LJj/XbU7b;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getStatus", "getRequestId", "getResponseMessage", "getResponseCode", "getArpc", "Z", "getDeregisteredArpc", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UpiPluginLiteSyncApiResponse extends SFMiYa {
    public static final int $stable = 0;

    @SerializedName("arpc")
    private final String arpc;

    @SerializedName("deregisteredArpc")
    private final boolean deregisteredArpc;

    @SerializedName("requestId")
    private final String requestId;

    @SerializedName("respCode")
    private final String responseCode;

    @SerializedName("respMessage")
    private final String responseMessage;

    @SerializedName("status")
    private final String status;

    public UpiPluginLiteSyncApiResponse() {
        this(null, null, null, null, null, false, 63, null);
    }

    public static /* synthetic */ UpiPluginLiteSyncApiResponse copy$default(UpiPluginLiteSyncApiResponse upiPluginLiteSyncApiResponse, String str, String str2, String str3, String str4, String str5, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = upiPluginLiteSyncApiResponse.status;
        }
        if ((i10 & 2) != 0) {
            str2 = upiPluginLiteSyncApiResponse.requestId;
        }
        if ((i10 & 4) != 0) {
            str3 = upiPluginLiteSyncApiResponse.responseMessage;
        }
        if ((i10 & 8) != 0) {
            str4 = upiPluginLiteSyncApiResponse.responseCode;
        }
        if ((i10 & 16) != 0) {
            str5 = upiPluginLiteSyncApiResponse.arpc;
        }
        if ((i10 & 32) != 0) {
            z10 = upiPluginLiteSyncApiResponse.deregisteredArpc;
        }
        String str6 = str5;
        boolean z11 = z10;
        return upiPluginLiteSyncApiResponse.copy(str, str2, str3, str4, str6, z11);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getRequestId() {
        return this.requestId;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getResponseMessage() {
        return this.responseMessage;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getResponseCode() {
        return this.responseCode;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getArpc() {
        return this.arpc;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final boolean getDeregisteredArpc() {
        return this.deregisteredArpc;
    }

    public final UpiPluginLiteSyncApiResponse copy(String status, String requestId, String responseMessage, String responseCode, String arpc, boolean deregisteredArpc) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(requestId, "requestId");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(arpc, "arpc");
        return new UpiPluginLiteSyncApiResponse(status, requestId, responseMessage, responseCode, arpc, deregisteredArpc);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UpiPluginLiteSyncApiResponse)) {
            return false;
        }
        UpiPluginLiteSyncApiResponse upiPluginLiteSyncApiResponse = (UpiPluginLiteSyncApiResponse) other;
        return Intrinsics.areEqual(this.status, upiPluginLiteSyncApiResponse.status) && Intrinsics.areEqual(this.requestId, upiPluginLiteSyncApiResponse.requestId) && Intrinsics.areEqual(this.responseMessage, upiPluginLiteSyncApiResponse.responseMessage) && Intrinsics.areEqual(this.responseCode, upiPluginLiteSyncApiResponse.responseCode) && Intrinsics.areEqual(this.arpc, upiPluginLiteSyncApiResponse.arpc) && this.deregisteredArpc == upiPluginLiteSyncApiResponse.deregisteredArpc;
    }

    public final String getArpc() {
        return this.arpc;
    }

    public final boolean getDeregisteredArpc() {
        return this.deregisteredArpc;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getResponseCode() {
        return this.responseCode;
    }

    public final String getResponseMessage() {
        return this.responseMessage;
    }

    public final String getStatus() {
        return this.status;
    }

    public int hashCode() {
        return (((((((((this.status.hashCode() * 31) + this.requestId.hashCode()) * 31) + this.responseMessage.hashCode()) * 31) + this.responseCode.hashCode()) * 31) + this.arpc.hashCode()) * 31) + Boolean.hashCode(this.deregisteredArpc);
    }

    public String toString() {
        return "UpiPluginLiteSyncApiResponse(status=" + this.status + ", requestId=" + this.requestId + ", responseMessage=" + this.responseMessage + ", responseCode=" + this.responseCode + ", arpc=" + this.arpc + ", deregisteredArpc=" + this.deregisteredArpc + ")";
    }

    public /* synthetic */ UpiPluginLiteSyncApiResponse(String str, String str2, String str3, String str4, String str5, boolean z10, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? "" : str2, (i10 & 4) != 0 ? "" : str3, (i10 & 8) != 0 ? "" : str4, (i10 & 16) != 0 ? "" : str5, (i10 & 32) != 0 ? false : z10);
    }

    public UpiPluginLiteSyncApiResponse(String status, String requestId, String responseMessage, String responseCode, String arpc, boolean z10) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(requestId, "requestId");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(arpc, "arpc");
        this.status = status;
        this.requestId = requestId;
        this.responseMessage = responseMessage;
        this.responseCode = responseCode;
        this.arpc = arpc;
        this.deregisteredArpc = z10;
    }
}
