package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jj.RFQ3AA8, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0087\b\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\t\u0010\nJ\u0010\u0010\u000b\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000b\u0010\fJ\u0010\u0010\r\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\fJ\u0010\u0010\u000e\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\fJ\u0010\u0010\u000f\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\fJ\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u0010\u0010\u0011JD\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u00022\b\b\u0002\u0010\u0005\u001a\u00020\u00022\b\b\u0002\u0010\u0006\u001a\u00020\u00022\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007HÆ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u0010\u0010\u0014\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0014\u0010\fJ\u0010\u0010\u0016\u001a\u00020\u0015HÖ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u001a\u0010\u001b\u001a\u00020\u001a2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u001d\u001a\u0004\b\u001e\u0010\fR\u001a\u0010\u0004\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001d\u001a\u0004\b\u001f\u0010\fR\u001a\u0010\u0005\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u001d\u001a\u0004\b \u0010\fR\u001a\u0010\u0006\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u001d\u001a\u0004\b!\u0010\fR\u001c\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010\"\u001a\u0004\b#\u0010\u0011¨\u0006$"}, d2 = {"LJj/RFQ3AA8;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "status", "responseCode", "responseMessage", SDKConstants.SEQUENCE_NUMBER, "LJj/MY3jR;", "liteRegister", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LJj/MY3jR;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "component5", "()LJj/MY3jR;", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LJj/MY3jR;)LJj/RFQ3AA8;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getStatus", "getResponseCode", "getResponseMessage", "getSeqNo", "LJj/MY3jR;", "getLiteRegister", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class RegisterUpiLiteModel extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("respDetails")
    private final LiteRegister liteRegister;

    @SerializedName("respCode")
    private final String responseCode;

    @SerializedName("respMessage")
    private final String responseMessage;

    @SerializedName(SDKConstants.SEQUENCE_NUMBER)
    private final String seqNo;

    @SerializedName("status")
    private final String status;

    public RegisterUpiLiteModel(String status, String responseCode, String responseMessage, String seqNo, LiteRegister liteRegister) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(seqNo, "seqNo");
        this.status = status;
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
        this.seqNo = seqNo;
        this.liteRegister = liteRegister;
    }

    public static /* synthetic */ RegisterUpiLiteModel copy$default(RegisterUpiLiteModel registerUpiLiteModel, String str, String str2, String str3, String str4, LiteRegister liteRegister, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = registerUpiLiteModel.status;
        }
        if ((i10 & 2) != 0) {
            str2 = registerUpiLiteModel.responseCode;
        }
        if ((i10 & 4) != 0) {
            str3 = registerUpiLiteModel.responseMessage;
        }
        if ((i10 & 8) != 0) {
            str4 = registerUpiLiteModel.seqNo;
        }
        if ((i10 & 16) != 0) {
            liteRegister = registerUpiLiteModel.liteRegister;
        }
        LiteRegister liteRegister2 = liteRegister;
        String str5 = str3;
        return registerUpiLiteModel.copy(str, str2, str5, str4, liteRegister2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getResponseCode() {
        return this.responseCode;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getResponseMessage() {
        return this.responseMessage;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getSeqNo() {
        return this.seqNo;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final LiteRegister getLiteRegister() {
        return this.liteRegister;
    }

    public final RegisterUpiLiteModel copy(String status, String responseCode, String responseMessage, String seqNo, LiteRegister liteRegister) {
        Intrinsics.checkNotNullParameter(status, "status");
        Intrinsics.checkNotNullParameter(responseCode, "responseCode");
        Intrinsics.checkNotNullParameter(responseMessage, "responseMessage");
        Intrinsics.checkNotNullParameter(seqNo, "seqNo");
        return new RegisterUpiLiteModel(status, responseCode, responseMessage, seqNo, liteRegister);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RegisterUpiLiteModel)) {
            return false;
        }
        RegisterUpiLiteModel registerUpiLiteModel = (RegisterUpiLiteModel) other;
        return Intrinsics.areEqual(this.status, registerUpiLiteModel.status) && Intrinsics.areEqual(this.responseCode, registerUpiLiteModel.responseCode) && Intrinsics.areEqual(this.responseMessage, registerUpiLiteModel.responseMessage) && Intrinsics.areEqual(this.seqNo, registerUpiLiteModel.seqNo) && Intrinsics.areEqual(this.liteRegister, registerUpiLiteModel.liteRegister);
    }

    public final LiteRegister getLiteRegister() {
        return this.liteRegister;
    }

    public final String getResponseCode() {
        return this.responseCode;
    }

    public final String getResponseMessage() {
        return this.responseMessage;
    }

    public final String getSeqNo() {
        return this.seqNo;
    }

    public final String getStatus() {
        return this.status;
    }

    public int hashCode() {
        int iHashCode = ((((((this.status.hashCode() * 31) + this.responseCode.hashCode()) * 31) + this.responseMessage.hashCode()) * 31) + this.seqNo.hashCode()) * 31;
        LiteRegister liteRegister = this.liteRegister;
        return iHashCode + (liteRegister == null ? 0 : liteRegister.hashCode());
    }

    public String toString() {
        return "RegisterUpiLiteModel(status=" + this.status + ", responseCode=" + this.responseCode + ", responseMessage=" + this.responseMessage + ", seqNo=" + this.seqNo + ", liteRegister=" + this.liteRegister + ")";
    }
}
