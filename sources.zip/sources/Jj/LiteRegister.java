package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.nativesdk.transcation.PayUtility;

/* JADX INFO: renamed from: Jj.MY3jR, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\b\u0087\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u0010\u0010\u0007\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010\t\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b\t\u0010\bJ$\u0010\n\u001a\u00020\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u0002HÆ\u0001¢\u0006\u0004\b\n\u0010\u000bJ\u0010\u0010\f\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\f\u0010\bJ\u0010\u0010\u000e\u001a\u00020\rHÖ\u0001¢\u0006\u0004\b\u000e\u0010\u000fJ\u001a\u0010\u0013\u001a\u00020\u00122\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010HÖ\u0003¢\u0006\u0004\b\u0013\u0010\u0014R\"\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u0015\u001a\u0004\b\u0016\u0010\b\"\u0004\b\u0017\u0010\u0018R\"\u0010\u0004\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u0015\u001a\u0004\b\u0019\u0010\b\"\u0004\b\u001a\u0010\u0018¨\u0006\u001b"}, d2 = {"LJj/MY3jR;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", PayUtility.LRN, "respXML", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "copy", "(Ljava/lang/String;Ljava/lang/String;)LJj/MY3jR;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getLrn", "setLrn", "(Ljava/lang/String;)V", "getRespXML", "setRespXML", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class LiteRegister extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName(PayUtility.LRN)
    private String lrn;

    @SerializedName("respXML")
    private String respXML;

    public LiteRegister(String lrn, String respXML) {
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        Intrinsics.checkNotNullParameter(respXML, "respXML");
        this.lrn = lrn;
        this.respXML = respXML;
    }

    public static /* synthetic */ LiteRegister copy$default(LiteRegister liteRegister, String str, String str2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = liteRegister.lrn;
        }
        if ((i10 & 2) != 0) {
            str2 = liteRegister.respXML;
        }
        return liteRegister.copy(str, str2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getLrn() {
        return this.lrn;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getRespXML() {
        return this.respXML;
    }

    public final LiteRegister copy(String lrn, String respXML) {
        Intrinsics.checkNotNullParameter(lrn, "lrn");
        Intrinsics.checkNotNullParameter(respXML, "respXML");
        return new LiteRegister(lrn, respXML);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof LiteRegister)) {
            return false;
        }
        LiteRegister liteRegister = (LiteRegister) other;
        return Intrinsics.areEqual(this.lrn, liteRegister.lrn) && Intrinsics.areEqual(this.respXML, liteRegister.respXML);
    }

    public final String getLrn() {
        return this.lrn;
    }

    public final String getRespXML() {
        return this.respXML;
    }

    public int hashCode() {
        return (this.lrn.hashCode() * 31) + this.respXML.hashCode();
    }

    public final void setLrn(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.lrn = str;
    }

    public final void setRespXML(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.respXML = str;
    }

    public String toString() {
        return "LiteRegister(lrn=" + this.lrn + ", respXML=" + this.respXML + ")";
    }
}
