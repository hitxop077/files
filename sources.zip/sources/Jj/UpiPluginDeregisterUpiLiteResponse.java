package Jj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.pluginupi.common.model.H8UuVVi;

/* JADX INFO: renamed from: Jj.N1vNRFSd, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000b\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\b\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\n\u0010\tJ\u0012\u0010\u000b\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000b\u0010\tJ4\u0010\f\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u000e\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u000e\u0010\tJ\u0010\u0010\u0010\u001a\u00020\u000fHÖ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u001a\u0010\u0015\u001a\u00020\u00142\b\u0010\u0013\u001a\u0004\u0018\u00010\u0012HÖ\u0003¢\u0006\u0004\b\u0015\u0010\u0016R$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u0017\u001a\u0004\b\u0018\u0010\t\"\u0004\b\u0019\u0010\u001aR$\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u0017\u001a\u0004\b\u001b\u0010\t\"\u0004\b\u001c\u0010\u001aR$\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u0017\u001a\u0004\b\u001d\u0010\t\"\u0004\b\u001e\u0010\u001a¨\u0006\u001f"}, d2 = {"LJj/N1vNRFSd;", "Lnet/one97/paytm/pluginupi/common/model/H8UuVVi;", "", "txnId", "bankRRN", "requestId", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LJj/N1vNRFSd;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getTxnId", "setTxnId", "(Ljava/lang/String;)V", "getBankRRN", "setBankRRN", "getRequestId", "setRequestId", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UpiPluginDeregisterUpiLiteResponse extends H8UuVVi {
    public static final int $stable = 8;

    @SerializedName("bankRRN")
    private String bankRRN;

    @SerializedName("requestId")
    private String requestId;

    @SerializedName("txnId")
    private String txnId;

    public UpiPluginDeregisterUpiLiteResponse() {
        this(null, null, null, 7, null);
    }

    public static /* synthetic */ UpiPluginDeregisterUpiLiteResponse copy$default(UpiPluginDeregisterUpiLiteResponse upiPluginDeregisterUpiLiteResponse, String str, String str2, String str3, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = upiPluginDeregisterUpiLiteResponse.txnId;
        }
        if ((i10 & 2) != 0) {
            str2 = upiPluginDeregisterUpiLiteResponse.bankRRN;
        }
        if ((i10 & 4) != 0) {
            str3 = upiPluginDeregisterUpiLiteResponse.requestId;
        }
        return upiPluginDeregisterUpiLiteResponse.copy(str, str2, str3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getTxnId() {
        return this.txnId;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getBankRRN() {
        return this.bankRRN;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getRequestId() {
        return this.requestId;
    }

    public final UpiPluginDeregisterUpiLiteResponse copy(String txnId, String bankRRN, String requestId) {
        return new UpiPluginDeregisterUpiLiteResponse(txnId, bankRRN, requestId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UpiPluginDeregisterUpiLiteResponse)) {
            return false;
        }
        UpiPluginDeregisterUpiLiteResponse upiPluginDeregisterUpiLiteResponse = (UpiPluginDeregisterUpiLiteResponse) other;
        return Intrinsics.areEqual(this.txnId, upiPluginDeregisterUpiLiteResponse.txnId) && Intrinsics.areEqual(this.bankRRN, upiPluginDeregisterUpiLiteResponse.bankRRN) && Intrinsics.areEqual(this.requestId, upiPluginDeregisterUpiLiteResponse.requestId);
    }

    public final String getBankRRN() {
        return this.bankRRN;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public final String getTxnId() {
        return this.txnId;
    }

    public int hashCode() {
        String str = this.txnId;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.bankRRN;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.requestId;
        return iHashCode2 + (str3 != null ? str3.hashCode() : 0);
    }

    public final void setBankRRN(String str) {
        this.bankRRN = str;
    }

    public final void setRequestId(String str) {
        this.requestId = str;
    }

    public final void setTxnId(String str) {
        this.txnId = str;
    }

    public String toString() {
        return "UpiPluginDeregisterUpiLiteResponse(txnId=" + this.txnId + ", bankRRN=" + this.bankRRN + ", requestId=" + this.requestId + ")";
    }

    public /* synthetic */ UpiPluginDeregisterUpiLiteResponse(String str, String str2, String str3, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? null : str2, (i10 & 4) != 0 ? null : str3);
    }

    public UpiPluginDeregisterUpiLiteResponse(String str, String str2, String str3) {
        this.txnId = str;
        this.bankRRN = str2;
        this.requestId = str3;
    }
}
