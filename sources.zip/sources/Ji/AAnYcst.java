package Ji;

import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public enum AAnYcst {
    ON_PAGE_IDLE,
    ON_PAGE_STARTED,
    ON_PAGE_FINISHED,
    ON_PAGE_FINISHED_SKIPPED,
    ON_RECEIVED_ERROR;

    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries(values());

    public static EnumEntries<AAnYcst> getEntries() {
        return $ENTRIES;
    }
}
