package Ji;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class MY3jR {
    public int aXYSYCVY;
    public boolean eszJ2B0a = true;
    public Set eLbhX59K = new LinkedHashSet();
    public AAnYcst zDWsfFRp = AAnYcst.ON_PAGE_IDLE;

    public final void aXYSYCVY() {
        this.zDWsfFRp = AAnYcst.ON_PAGE_FINISHED_SKIPPED;
    }

    public final void dUI84() {
        this.zDWsfFRp = AAnYcst.ON_PAGE_IDLE;
    }

    public final void eLbhX59K() {
        this.zDWsfFRp = AAnYcst.ON_PAGE_FINISHED;
        Iterator it2 = this.eLbhX59K.iterator();
        while (it2.hasNext()) {
            ((InterfaceC0095MY3jR) it2.next()).egwiL(this.eszJ2B0a);
        }
        this.eszJ2B0a = false;
    }

    public final AAnYcst eszJ2B0a() {
        return this.zDWsfFRp;
    }

    public final void ivfTYNl() {
        this.zDWsfFRp = AAnYcst.ON_RECEIVED_ERROR;
        Iterator it2 = this.eLbhX59K.iterator();
        while (it2.hasNext()) {
            ((InterfaceC0095MY3jR) it2.next()).rGuJugJ(this.eszJ2B0a);
        }
        this.eszJ2B0a = false;
    }

    public final void oZ7qYn(int i10) {
        this.aXYSYCVY = i10;
        Iterator it2 = this.eLbhX59K.iterator();
        while (it2.hasNext()) {
            ((InterfaceC0095MY3jR) it2.next()).baCZg(i10, this.eszJ2B0a);
        }
    }

    public final void osx7Pl0E(InterfaceC0095MY3jR progressCallback) {
        Intrinsics.checkNotNullParameter(progressCallback, "progressCallback");
        if (this.eLbhX59K.contains(progressCallback)) {
            return;
        }
        this.eLbhX59K.add(progressCallback);
    }

    public final void rjljd6i(InterfaceC0095MY3jR progressCallback) {
        Intrinsics.checkNotNullParameter(progressCallback, "progressCallback");
        this.eLbhX59K.remove(progressCallback);
    }

    public final void zDWsfFRp() {
        this.zDWsfFRp = AAnYcst.ON_PAGE_STARTED;
        Iterator it2 = this.eLbhX59K.iterator();
        while (it2.hasNext()) {
            ((InterfaceC0095MY3jR) it2.next()).mVdmkF(this.eszJ2B0a);
        }
    }

    /* JADX INFO: renamed from: Ji.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public interface InterfaceC0095MY3jR {
        void baCZg(int i10, boolean z10);

        void egwiL(boolean z10);

        void mVdmkF(boolean z10);

        void rGuJugJ(boolean z10);

        /* JADX INFO: renamed from: Ji.MY3jR$MY3jR$MY3jR, reason: collision with other inner class name */
        /* JADX INFO: compiled from: Obfuscated */
        public static final class C0096MY3jR {
            public static void aXYSYCVY(InterfaceC0095MY3jR interfaceC0095MY3jR, boolean z10) {
            }

            public static void eszJ2B0a(InterfaceC0095MY3jR interfaceC0095MY3jR, boolean z10) {
            }

            public static void zDWsfFRp(InterfaceC0095MY3jR interfaceC0095MY3jR, boolean z10) {
            }

            public static void eLbhX59K(InterfaceC0095MY3jR interfaceC0095MY3jR, int i10, boolean z10) {
            }
        }
    }
}
