package Kj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: renamed from: Kj.AAnYcst, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\f\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u0012\u0010\t\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\t\u0010\nJ\u0012\u0010\u000b\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u000b\u0010\fJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\nJ4\u0010\u000e\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\u000e\u0010\u000fJ\u0010\u0010\u0010\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0010\u0010\nJ\u0010\u0010\u0012\u001a\u00020\u0011HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u001a\u0010\u0017\u001a\u00020\u00162\b\u0010\u0015\u001a\u0004\u0018\u00010\u0014HÖ\u0003¢\u0006\u0004\b\u0017\u0010\u0018R$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u0019\u001a\u0004\b\u0003\u0010\n\"\u0004\b\u001a\u0010\u001bR$\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001c\u001a\u0004\b\u001d\u0010\f\"\u0004\b\u001e\u0010\u001fR$\u0010\u0006\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0006\u0010\u0019\u001a\u0004\b \u0010\n\"\u0004\b!\u0010\u001b¨\u0006\""}, d2 = {"LKj/AAnYcst;", "Lnet/one97/paytm/pluginupi/common/model/SFMiYa;", "", "isActiveMandate", "LKj/MY3jR;", "mandateMetadata", "requestId", "<init>", "(Ljava/lang/String;LKj/MY3jR;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "()LKj/MY3jR;", "component3", "copy", "(Ljava/lang/String;LKj/MY3jR;Ljava/lang/String;)LKj/AAnYcst;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "setActiveMandate", "(Ljava/lang/String;)V", "LKj/MY3jR;", "getMandateMetadata", "setMandateMetadata", "(LKj/MY3jR;)V", "getRequestId", "setRequestId", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class RespDetails extends SFMiYa {
    public static final int $stable = 8;

    @SerializedName("isActiveMandate")
    private String isActiveMandate;

    @SerializedName("mandateMetadata")
    private MandateMetadata mandateMetadata;

    @SerializedName("requestId")
    private String requestId;

    public RespDetails() {
        this(null, null, null, 7, null);
    }

    public static /* synthetic */ RespDetails copy$default(RespDetails respDetails, String str, MandateMetadata mandateMetadata, String str2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = respDetails.isActiveMandate;
        }
        if ((i10 & 2) != 0) {
            mandateMetadata = respDetails.mandateMetadata;
        }
        if ((i10 & 4) != 0) {
            str2 = respDetails.requestId;
        }
        return respDetails.copy(str, mandateMetadata, str2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getIsActiveMandate() {
        return this.isActiveMandate;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final MandateMetadata getMandateMetadata() {
        return this.mandateMetadata;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getRequestId() {
        return this.requestId;
    }

    public final RespDetails copy(String isActiveMandate, MandateMetadata mandateMetadata, String requestId) {
        return new RespDetails(isActiveMandate, mandateMetadata, requestId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RespDetails)) {
            return false;
        }
        RespDetails respDetails = (RespDetails) other;
        return Intrinsics.areEqual(this.isActiveMandate, respDetails.isActiveMandate) && Intrinsics.areEqual(this.mandateMetadata, respDetails.mandateMetadata) && Intrinsics.areEqual(this.requestId, respDetails.requestId);
    }

    public final MandateMetadata getMandateMetadata() {
        return this.mandateMetadata;
    }

    public final String getRequestId() {
        return this.requestId;
    }

    public int hashCode() {
        String str = this.isActiveMandate;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        MandateMetadata mandateMetadata = this.mandateMetadata;
        int iHashCode2 = (iHashCode + (mandateMetadata == null ? 0 : mandateMetadata.hashCode())) * 31;
        String str2 = this.requestId;
        return iHashCode2 + (str2 != null ? str2.hashCode() : 0);
    }

    public final String isActiveMandate() {
        return this.isActiveMandate;
    }

    public final void setActiveMandate(String str) {
        this.isActiveMandate = str;
    }

    public final void setMandateMetadata(MandateMetadata mandateMetadata) {
        this.mandateMetadata = mandateMetadata;
    }

    public final void setRequestId(String str) {
        this.requestId = str;
    }

    public String toString() {
        return "RespDetails(isActiveMandate=" + this.isActiveMandate + ", mandateMetadata=" + this.mandateMetadata + ", requestId=" + this.requestId + ")";
    }

    public /* synthetic */ RespDetails(String str, MandateMetadata mandateMetadata, String str2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? new MandateMetadata(null, null, null, null, null, null, null, 127, null) : mandateMetadata, (i10 & 4) == 0 ? str2 : null);
    }

    public RespDetails(String str, MandateMetadata mandateMetadata, String str2) {
        this.isActiveMandate = str;
        this.mandateMetadata = mandateMetadata;
        this.requestId = str2;
    }
}
