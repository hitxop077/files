package Kj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.nativesdk.transcation.PayUtility;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: renamed from: Kj.MY3jR, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0014\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0013\b\u0087\b\u0018\u00002\u00020\u0001B[\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\rJ\u0012\u0010\u000e\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\rJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000f\u0010\rJ\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0010\u0010\rJ\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0011\u0010\rJ\u0012\u0010\u0012\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0012\u0010\rJ\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0013\u0010\rJd\u0010\u0014\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0016\u0010\rJ\u0010\u0010\u0018\u001a\u00020\u0017HÖ\u0001¢\u0006\u0004\b\u0018\u0010\u0019J\u001a\u0010\u001d\u001a\u00020\u001c2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001aHÖ\u0003¢\u0006\u0004\b\u001d\u0010\u001eR$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u001f\u001a\u0004\b \u0010\r\"\u0004\b!\u0010\"R$\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u001f\u001a\u0004\b#\u0010\r\"\u0004\b$\u0010\"R$\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001f\u001a\u0004\b%\u0010\r\"\u0004\b&\u0010\"R$\u0010\u0006\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0006\u0010\u001f\u001a\u0004\b'\u0010\r\"\u0004\b(\u0010\"R$\u0010\u0007\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0007\u0010\u001f\u001a\u0004\b)\u0010\r\"\u0004\b*\u0010\"R$\u0010\b\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\b\u0010\u001f\u001a\u0004\b+\u0010\r\"\u0004\b,\u0010\"R$\u0010\t\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\t\u0010\u001f\u001a\u0004\b-\u0010\r\"\u0004\b.\u0010\"¨\u0006/"}, d2 = {"LKj/MY3jR;", "Lnet/one97/paytm/pluginupi/common/model/SFMiYa;", "", "maxAmount", "topupAmount", "balanceThreshold", "mandateStatus", "validityEndDate", PayUtility.LRN, "umn", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LKj/MY3jR;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getMaxAmount", "setMaxAmount", "(Ljava/lang/String;)V", "getTopupAmount", "setTopupAmount", "getBalanceThreshold", "setBalanceThreshold", "getMandateStatus", "setMandateStatus", "getValidityEndDate", "setValidityEndDate", "getLrn", "setLrn", "getUmn", "setUmn", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class MandateMetadata extends SFMiYa {
    public static final int $stable = 8;

    @SerializedName("balanceThreshold")
    private String balanceThreshold;

    @SerializedName(PayUtility.LRN)
    private String lrn;

    @SerializedName("mandateStatus")
    private String mandateStatus;

    @SerializedName("maxAmount")
    private String maxAmount;

    @SerializedName("topupAmount")
    private String topupAmount;

    @SerializedName("umn")
    private String umn;

    @SerializedName("validityEndDate")
    private String validityEndDate;

    public MandateMetadata() {
        this(null, null, null, null, null, null, null, 127, null);
    }

    public static /* synthetic */ MandateMetadata copy$default(MandateMetadata mandateMetadata, String str, String str2, String str3, String str4, String str5, String str6, String str7, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = mandateMetadata.maxAmount;
        }
        if ((i10 & 2) != 0) {
            str2 = mandateMetadata.topupAmount;
        }
        if ((i10 & 4) != 0) {
            str3 = mandateMetadata.balanceThreshold;
        }
        if ((i10 & 8) != 0) {
            str4 = mandateMetadata.mandateStatus;
        }
        if ((i10 & 16) != 0) {
            str5 = mandateMetadata.validityEndDate;
        }
        if ((i10 & 32) != 0) {
            str6 = mandateMetadata.lrn;
        }
        if ((i10 & 64) != 0) {
            str7 = mandateMetadata.umn;
        }
        String str8 = str6;
        String str9 = str7;
        String str10 = str5;
        String str11 = str3;
        return mandateMetadata.copy(str, str2, str11, str4, str10, str8, str9);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getMaxAmount() {
        return this.maxAmount;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getTopupAmount() {
        return this.topupAmount;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getBalanceThreshold() {
        return this.balanceThreshold;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getMandateStatus() {
        return this.mandateStatus;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getValidityEndDate() {
        return this.validityEndDate;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getLrn() {
        return this.lrn;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getUmn() {
        return this.umn;
    }

    public final MandateMetadata copy(String maxAmount, String topupAmount, String balanceThreshold, String mandateStatus, String validityEndDate, String lrn, String umn) {
        return new MandateMetadata(maxAmount, topupAmount, balanceThreshold, mandateStatus, validityEndDate, lrn, umn);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MandateMetadata)) {
            return false;
        }
        MandateMetadata mandateMetadata = (MandateMetadata) other;
        return Intrinsics.areEqual(this.maxAmount, mandateMetadata.maxAmount) && Intrinsics.areEqual(this.topupAmount, mandateMetadata.topupAmount) && Intrinsics.areEqual(this.balanceThreshold, mandateMetadata.balanceThreshold) && Intrinsics.areEqual(this.mandateStatus, mandateMetadata.mandateStatus) && Intrinsics.areEqual(this.validityEndDate, mandateMetadata.validityEndDate) && Intrinsics.areEqual(this.lrn, mandateMetadata.lrn) && Intrinsics.areEqual(this.umn, mandateMetadata.umn);
    }

    public final String getBalanceThreshold() {
        return this.balanceThreshold;
    }

    public final String getLrn() {
        return this.lrn;
    }

    public final String getMandateStatus() {
        return this.mandateStatus;
    }

    public final String getMaxAmount() {
        return this.maxAmount;
    }

    public final String getTopupAmount() {
        return this.topupAmount;
    }

    public final String getUmn() {
        return this.umn;
    }

    public final String getValidityEndDate() {
        return this.validityEndDate;
    }

    public int hashCode() {
        String str = this.maxAmount;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.topupAmount;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.balanceThreshold;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.mandateStatus;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.validityEndDate;
        int iHashCode5 = (iHashCode4 + (str5 == null ? 0 : str5.hashCode())) * 31;
        String str6 = this.lrn;
        int iHashCode6 = (iHashCode5 + (str6 == null ? 0 : str6.hashCode())) * 31;
        String str7 = this.umn;
        return iHashCode6 + (str7 != null ? str7.hashCode() : 0);
    }

    public final void setBalanceThreshold(String str) {
        this.balanceThreshold = str;
    }

    public final void setLrn(String str) {
        this.lrn = str;
    }

    public final void setMandateStatus(String str) {
        this.mandateStatus = str;
    }

    public final void setMaxAmount(String str) {
        this.maxAmount = str;
    }

    public final void setTopupAmount(String str) {
        this.topupAmount = str;
    }

    public final void setUmn(String str) {
        this.umn = str;
    }

    public final void setValidityEndDate(String str) {
        this.validityEndDate = str;
    }

    public String toString() {
        return "MandateMetadata(maxAmount=" + this.maxAmount + ", topupAmount=" + this.topupAmount + ", balanceThreshold=" + this.balanceThreshold + ", mandateStatus=" + this.mandateStatus + ", validityEndDate=" + this.validityEndDate + ", lrn=" + this.lrn + ", umn=" + this.umn + ")";
    }

    public /* synthetic */ MandateMetadata(String str, String str2, String str3, String str4, String str5, String str6, String str7, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? null : str2, (i10 & 4) != 0 ? null : str3, (i10 & 8) != 0 ? null : str4, (i10 & 16) != 0 ? null : str5, (i10 & 32) != 0 ? null : str6, (i10 & 64) != 0 ? null : str7);
    }

    public MandateMetadata(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.maxAmount = str;
        this.topupAmount = str2;
        this.balanceThreshold = str3;
        this.mandateStatus = str4;
        this.validityEndDate = str5;
        this.lrn = str6;
        this.umn = str7;
    }
}
