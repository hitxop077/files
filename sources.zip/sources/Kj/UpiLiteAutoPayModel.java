package Kj;

import com.google.gson.annotations.SerializedName;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.pluginupi.common.model.SFMiYa;

/* JADX INFO: renamed from: Kj.RFQ3AA8, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0006¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\n\u0010\u000bJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\u000bJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\u000bJ\u0012\u0010\u000e\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0004\b\u000e\u0010\u000fJ@\u0010\u0010\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0006HÆ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u000bJ\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0019\u001a\u00020\u00182\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016HÖ\u0003¢\u0006\u0004\b\u0019\u0010\u001aR$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u001b\u001a\u0004\b\u001c\u0010\u000b\"\u0004\b\u001d\u0010\u001eR$\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u0010\u001b\u001a\u0004\b\u001f\u0010\u000b\"\u0004\b \u0010\u001eR$\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001b\u001a\u0004\b!\u0010\u000b\"\u0004\b\"\u0010\u001eR$\u0010\u0007\u001a\u0004\u0018\u00010\u00068\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0007\u0010#\u001a\u0004\b$\u0010\u000f\"\u0004\b%\u0010&¨\u0006'"}, d2 = {"LKj/RFQ3AA8;", "Lnet/one97/paytm/pluginupi/common/model/SFMiYa;", "", "status", "respCode", "respMessage", "LKj/AAnYcst;", "respDetails", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LKj/AAnYcst;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "component4", "()LKj/AAnYcst;", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LKj/AAnYcst;)LKj/RFQ3AA8;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getStatus", "setStatus", "(Ljava/lang/String;)V", "getRespCode", "setRespCode", "getRespMessage", "setRespMessage", "LKj/AAnYcst;", "getRespDetails", "setRespDetails", "(LKj/AAnYcst;)V", "paytmupiplugin_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UpiLiteAutoPayModel extends SFMiYa {
    public static final int $stable = 8;

    @SerializedName("respCode")
    private String respCode;

    @SerializedName("respDetails")
    private RespDetails respDetails;

    @SerializedName("respMessage")
    private String respMessage;

    @SerializedName("status")
    private String status;

    public UpiLiteAutoPayModel() {
        this(null, null, null, null, 15, null);
    }

    public static /* synthetic */ UpiLiteAutoPayModel copy$default(UpiLiteAutoPayModel upiLiteAutoPayModel, String str, String str2, String str3, RespDetails respDetails, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = upiLiteAutoPayModel.status;
        }
        if ((i10 & 2) != 0) {
            str2 = upiLiteAutoPayModel.respCode;
        }
        if ((i10 & 4) != 0) {
            str3 = upiLiteAutoPayModel.respMessage;
        }
        if ((i10 & 8) != 0) {
            respDetails = upiLiteAutoPayModel.respDetails;
        }
        return upiLiteAutoPayModel.copy(str, str2, str3, respDetails);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getRespCode() {
        return this.respCode;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getRespMessage() {
        return this.respMessage;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final RespDetails getRespDetails() {
        return this.respDetails;
    }

    public final UpiLiteAutoPayModel copy(String status, String respCode, String respMessage, RespDetails respDetails) {
        return new UpiLiteAutoPayModel(status, respCode, respMessage, respDetails);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UpiLiteAutoPayModel)) {
            return false;
        }
        UpiLiteAutoPayModel upiLiteAutoPayModel = (UpiLiteAutoPayModel) other;
        return Intrinsics.areEqual(this.status, upiLiteAutoPayModel.status) && Intrinsics.areEqual(this.respCode, upiLiteAutoPayModel.respCode) && Intrinsics.areEqual(this.respMessage, upiLiteAutoPayModel.respMessage) && Intrinsics.areEqual(this.respDetails, upiLiteAutoPayModel.respDetails);
    }

    public final String getRespCode() {
        return this.respCode;
    }

    public final RespDetails getRespDetails() {
        return this.respDetails;
    }

    public final String getRespMessage() {
        return this.respMessage;
    }

    public final String getStatus() {
        return this.status;
    }

    public int hashCode() {
        String str = this.status;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.respCode;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.respMessage;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        RespDetails respDetails = this.respDetails;
        return iHashCode3 + (respDetails != null ? respDetails.hashCode() : 0);
    }

    public final void setRespCode(String str) {
        this.respCode = str;
    }

    public final void setRespDetails(RespDetails respDetails) {
        this.respDetails = respDetails;
    }

    public final void setRespMessage(String str) {
        this.respMessage = str;
    }

    public final void setStatus(String str) {
        this.status = str;
    }

    public String toString() {
        return "UpiLiteAutoPayModel(status=" + this.status + ", respCode=" + this.respCode + ", respMessage=" + this.respMessage + ", respDetails=" + this.respDetails + ")";
    }

    public /* synthetic */ UpiLiteAutoPayModel(String str, String str2, String str3, RespDetails respDetails, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? null : str2, (i10 & 4) != 0 ? null : str3, (i10 & 8) != 0 ? new RespDetails(null, null, null, 7, null) : respDetails);
    }

    public UpiLiteAutoPayModel(String str, String str2, String str3, RespDetails respDetails) {
        this.status = str;
        this.respCode = str2;
        this.respMessage = str3;
        this.respDetails = respDetails;
    }
}
