package ju;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface AAnYcst {
    void onComplete();

    void onError(Throwable th2);

    void onNext(Object obj);

    void onSubscribe(RFQ3AA8 rfq3aa8);
}
