package ju;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface RFQ3AA8 {
    void cancel();

    void request(long j10);
}
