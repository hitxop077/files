package ju;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface MY3jR {
    void eszJ2B0a(AAnYcst aAnYcst);
}
