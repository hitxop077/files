package jo8yzlz;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.SparseArray;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import p497q7.SFMiYa;
import t3jmd7k.GMtmhHQ;
import t3jmd7k.O5Z56VT6;
import t3jmd7k.YcaGN;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class AAnYcst {
    public static final byte[] oZ7qYn = {0, 7, 8, 15};
    public static final byte[] rjljd6i = {0, 119, -120, -1};
    public static final byte[] zPJpxWz = {0, 17, 34, 51, 68, 85, 102, 119, -120, -103, -86, -69, -52, -35, -18, -1};
    public final Paint aXYSYCVY;
    public Bitmap dUI84;
    public final Canvas eLbhX59K;
    public final Paint eszJ2B0a;
    public final MY3jR ivfTYNl;
    public final GU39Hcg osx7Pl0E;
    public final C1482AAnYcst zDWsfFRp;

    /* JADX INFO: renamed from: jo8yzlz.AAnYcst$AAnYcst, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static final class C1482AAnYcst {
        public final int aXYSYCVY;
        public final int eLbhX59K;
        public final int eszJ2B0a;
        public final int ivfTYNl;
        public final int osx7Pl0E;
        public final int zDWsfFRp;

        public C1482AAnYcst(int i10, int i11, int i12, int i13, int i14, int i15) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = i11;
            this.eLbhX59K = i12;
            this.zDWsfFRp = i13;
            this.ivfTYNl = i14;
            this.osx7Pl0E = i15;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class GU39Hcg {
        public final int aXYSYCVY;
        public final int eszJ2B0a;
        public C1482AAnYcst oZ7qYn;
        public LNd998w rjljd6i;
        public final SparseArray eLbhX59K = new SparseArray();
        public final SparseArray zDWsfFRp = new SparseArray();
        public final SparseArray ivfTYNl = new SparseArray();
        public final SparseArray osx7Pl0E = new SparseArray();
        public final SparseArray dUI84 = new SparseArray();

        public GU39Hcg(int i10, int i11) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = i11;
        }

        public void eszJ2B0a() {
            this.eLbhX59K.clear();
            this.zDWsfFRp.clear();
            this.ivfTYNl.clear();
            this.osx7Pl0E.clear();
            this.dUI84.clear();
            this.oZ7qYn = null;
            this.rjljd6i = null;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class LNd998w {
        public final int aXYSYCVY;
        public final int eLbhX59K;
        public final int eszJ2B0a;
        public final SparseArray zDWsfFRp;

        public LNd998w(int i10, int i11, int i12, SparseArray sparseArray) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = i11;
            this.eLbhX59K = i12;
            this.zDWsfFRp = sparseArray;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public final int[] aXYSYCVY;
        public final int[] eLbhX59K;
        public final int eszJ2B0a;
        public final int[] zDWsfFRp;

        public MY3jR(int i10, int[] iArr, int[] iArr2, int[] iArr3) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = iArr;
            this.eLbhX59K = iArr2;
            this.zDWsfFRp = iArr3;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class N1vNRFSd {
        public final int aXYSYCVY;
        public final int eszJ2B0a;

        public N1vNRFSd(int i10, int i11) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = i11;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class RFQ3AA8 {
        public final boolean aXYSYCVY;
        public final byte[] eLbhX59K;
        public final int eszJ2B0a;
        public final byte[] zDWsfFRp;

        public RFQ3AA8(int i10, boolean z10, byte[] bArr, byte[] bArr2) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = z10;
            this.eLbhX59K = bArr;
            this.zDWsfFRp = bArr2;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class W7Cnq5 {
        public final int aXYSYCVY;
        public final int eLbhX59K;
        public final int eszJ2B0a;
        public final int ivfTYNl;
        public final int osx7Pl0E;
        public final int zDWsfFRp;

        public W7Cnq5(int i10, int i11, int i12, int i13, int i14, int i15) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = i11;
            this.eLbhX59K = i12;
            this.zDWsfFRp = i13;
            this.ivfTYNl = i14;
            this.osx7Pl0E = i15;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class XbU7b {
        public final boolean aXYSYCVY;
        public final int dUI84;
        public final int eLbhX59K;
        public final int eszJ2B0a;
        public final int ivfTYNl;
        public final int oZ7qYn;
        public final int osx7Pl0E;
        public final SparseArray qLLw0g;
        public final int rjljd6i;
        public final int zDWsfFRp;
        public final int zPJpxWz;

        public XbU7b(int i10, boolean z10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, SparseArray sparseArray) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = z10;
            this.eLbhX59K = i11;
            this.zDWsfFRp = i12;
            this.ivfTYNl = i13;
            this.osx7Pl0E = i14;
            this.dUI84 = i15;
            this.oZ7qYn = i16;
            this.rjljd6i = i17;
            this.zPJpxWz = i18;
            this.qLLw0g = sparseArray;
        }

        public void eszJ2B0a(XbU7b xbU7b) {
            SparseArray sparseArray = xbU7b.qLLw0g;
            for (int i10 = 0; i10 < sparseArray.size(); i10++) {
                this.qLLw0g.put(sparseArray.keyAt(i10), (W7Cnq5) sparseArray.valueAt(i10));
            }
        }
    }

    public AAnYcst(int i10, int i11) {
        Paint paint = new Paint();
        this.eszJ2B0a = paint;
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        paint.setPathEffect(null);
        Paint paint2 = new Paint();
        this.aXYSYCVY = paint2;
        paint2.setStyle(Paint.Style.FILL);
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER));
        paint2.setPathEffect(null);
        this.eLbhX59K = new Canvas();
        this.zDWsfFRp = new C1482AAnYcst(719, 575, 0, 719, 0, 575);
        this.ivfTYNl = new MY3jR(0, eLbhX59K(), zDWsfFRp(), ivfTYNl());
        this.osx7Pl0E = new GU39Hcg(i10, i11);
    }

    public static int dUI84(GMtmhHQ gMtmhHQ, int[] iArr, byte[] bArr, int i10, int i11, Paint paint, Canvas canvas) {
        int i12;
        int iOZ7qYn;
        int iOZ7qYn2;
        boolean z10 = false;
        while (true) {
            int iOZ7qYn3 = gMtmhHQ.oZ7qYn(2);
            if (iOZ7qYn3 != 0) {
                z10 = z10;
                i12 = 1;
            } else {
                if (gMtmhHQ.dUI84()) {
                    iOZ7qYn = gMtmhHQ.oZ7qYn(3) + 3;
                    iOZ7qYn2 = gMtmhHQ.oZ7qYn(2);
                } else {
                    if (gMtmhHQ.dUI84()) {
                        i12 = 1;
                    } else {
                        int iOZ7qYn4 = gMtmhHQ.oZ7qYn(2);
                        if (iOZ7qYn4 == 0) {
                            z10 = true;
                        } else if (iOZ7qYn4 == 1) {
                            i12 = 2;
                        } else if (iOZ7qYn4 == 2) {
                            iOZ7qYn = gMtmhHQ.oZ7qYn(4) + 12;
                            iOZ7qYn2 = gMtmhHQ.oZ7qYn(2);
                        } else if (iOZ7qYn4 != 3) {
                            z10 = z10;
                        } else {
                            iOZ7qYn = gMtmhHQ.oZ7qYn(8) + 29;
                            iOZ7qYn2 = gMtmhHQ.oZ7qYn(2);
                        }
                        iOZ7qYn3 = 0;
                        i12 = 0;
                    }
                    iOZ7qYn3 = 0;
                }
                z10 = z10;
                i12 = iOZ7qYn;
                iOZ7qYn3 = iOZ7qYn2;
            }
            if (i12 != 0 && paint != null) {
                if (bArr != null) {
                    iOZ7qYn3 = bArr[iOZ7qYn3];
                }
                paint.setColor(iArr[iOZ7qYn3]);
                canvas.drawRect(i10, i11, i10 + i12, 1 + i11, paint);
            }
            i10 += i12;
            if (z10) {
                return i10;
            }
            z10 = z10;
        }
    }

    public static int[] eLbhX59K() {
        return new int[]{0, -1, SFMiYa.QR_KEY_BLACK, -8421505};
    }

    public static byte[] eszJ2B0a(int i10, int i11, GMtmhHQ gMtmhHQ) {
        byte[] bArr = new byte[i10];
        for (int i12 = 0; i12 < i10; i12++) {
            bArr[i12] = (byte) gMtmhHQ.oZ7qYn(i11);
        }
        return bArr;
    }

    public static int[] ivfTYNl() {
        int[] iArr = new int[256];
        iArr[0] = 0;
        for (int i10 = 0; i10 < 256; i10++) {
            if (i10 < 8) {
                iArr[i10] = osx7Pl0E(63, (i10 & 1) != 0 ? 255 : 0, (i10 & 2) != 0 ? 255 : 0, (i10 & 4) == 0 ? 0 : 255);
            } else {
                int i11 = i10 & 136;
                if (i11 == 0) {
                    iArr[i10] = osx7Pl0E(255, ((i10 & 1) != 0 ? 85 : 0) + ((i10 & 16) != 0 ? 170 : 0), ((i10 & 2) != 0 ? 85 : 0) + ((i10 & 32) != 0 ? 170 : 0), ((i10 & 4) == 0 ? 0 : 85) + ((i10 & 64) == 0 ? 0 : 170));
                } else if (i11 == 8) {
                    iArr[i10] = osx7Pl0E(127, ((i10 & 1) != 0 ? 85 : 0) + ((i10 & 16) != 0 ? 170 : 0), ((i10 & 2) != 0 ? 85 : 0) + ((i10 & 32) != 0 ? 170 : 0), ((i10 & 4) == 0 ? 0 : 85) + ((i10 & 64) == 0 ? 0 : 170));
                } else if (i11 == 128) {
                    iArr[i10] = osx7Pl0E(255, ((i10 & 1) != 0 ? 43 : 0) + 127 + ((i10 & 16) != 0 ? 85 : 0), ((i10 & 2) != 0 ? 43 : 0) + 127 + ((i10 & 32) != 0 ? 85 : 0), ((i10 & 4) == 0 ? 0 : 43) + 127 + ((i10 & 64) == 0 ? 0 : 85));
                } else if (i11 == 136) {
                    iArr[i10] = osx7Pl0E(255, ((i10 & 1) != 0 ? 43 : 0) + ((i10 & 16) != 0 ? 85 : 0), ((i10 & 2) != 0 ? 43 : 0) + ((i10 & 32) != 0 ? 85 : 0), ((i10 & 4) == 0 ? 0 : 43) + ((i10 & 64) == 0 ? 0 : 85));
                }
            }
        }
        return iArr;
    }

    public static XbU7b mTWLV(GMtmhHQ gMtmhHQ, int i10) {
        int i11;
        int iOZ7qYn;
        int iOZ7qYn2;
        char c10;
        int iOZ7qYn3 = gMtmhHQ.oZ7qYn(8);
        int i12 = 4;
        gMtmhHQ.jAM6dcNA(4);
        boolean zDUI84 = gMtmhHQ.dUI84();
        gMtmhHQ.jAM6dcNA(3);
        int i13 = 16;
        int iOZ7qYn4 = gMtmhHQ.oZ7qYn(16);
        int iOZ7qYn5 = gMtmhHQ.oZ7qYn(16);
        int iOZ7qYn6 = gMtmhHQ.oZ7qYn(3);
        int iOZ7qYn7 = gMtmhHQ.oZ7qYn(3);
        int i14 = 2;
        gMtmhHQ.jAM6dcNA(2);
        int iOZ7qYn8 = gMtmhHQ.oZ7qYn(8);
        int iOZ7qYn9 = gMtmhHQ.oZ7qYn(8);
        int iOZ7qYn10 = gMtmhHQ.oZ7qYn(4);
        int iOZ7qYn11 = gMtmhHQ.oZ7qYn(2);
        gMtmhHQ.jAM6dcNA(2);
        int i15 = i10 - 10;
        SparseArray sparseArray = new SparseArray();
        while (i15 > 0) {
            int iOZ7qYn12 = gMtmhHQ.oZ7qYn(i13);
            int iOZ7qYn13 = gMtmhHQ.oZ7qYn(i14);
            int iOZ7qYn14 = gMtmhHQ.oZ7qYn(i14);
            int iOZ7qYn15 = gMtmhHQ.oZ7qYn(12);
            gMtmhHQ.jAM6dcNA(i12);
            int iOZ7qYn16 = gMtmhHQ.oZ7qYn(12);
            int i16 = i15 - 6;
            if (iOZ7qYn13 != 1) {
                i11 = 2;
                if (iOZ7qYn13 != 2) {
                    iOZ7qYn2 = 0;
                    iOZ7qYn = 0;
                    i15 = i16;
                    c10 = '\b';
                }
                sparseArray.put(iOZ7qYn12, new W7Cnq5(iOZ7qYn13, iOZ7qYn14, iOZ7qYn15, iOZ7qYn16, iOZ7qYn2, iOZ7qYn));
                i13 = 16;
                i14 = i11;
                i12 = 4;
            } else {
                i11 = 2;
            }
            c10 = '\b';
            i15 -= 8;
            iOZ7qYn2 = gMtmhHQ.oZ7qYn(8);
            iOZ7qYn = gMtmhHQ.oZ7qYn(8);
            sparseArray.put(iOZ7qYn12, new W7Cnq5(iOZ7qYn13, iOZ7qYn14, iOZ7qYn15, iOZ7qYn16, iOZ7qYn2, iOZ7qYn));
            i13 = 16;
            i14 = i11;
            i12 = 4;
        }
        return new XbU7b(iOZ7qYn3, zDUI84, iOZ7qYn4, iOZ7qYn5, iOZ7qYn6, iOZ7qYn7, iOZ7qYn8, iOZ7qYn9, iOZ7qYn10, iOZ7qYn11, sparseArray);
    }

    public static int oZ7qYn(GMtmhHQ gMtmhHQ, int[] iArr, byte[] bArr, int i10, int i11, Paint paint, Canvas canvas) {
        int i12;
        int iOZ7qYn;
        int iOZ7qYn2;
        boolean z10 = false;
        while (true) {
            int iOZ7qYn3 = gMtmhHQ.oZ7qYn(4);
            if (iOZ7qYn3 != 0) {
                z10 = z10;
                i12 = 1;
            } else if (gMtmhHQ.dUI84()) {
                if (gMtmhHQ.dUI84()) {
                    int iOZ7qYn4 = gMtmhHQ.oZ7qYn(2);
                    if (iOZ7qYn4 == 0) {
                        i12 = 1;
                        iOZ7qYn3 = 0;
                    } else if (iOZ7qYn4 == 1) {
                        iOZ7qYn3 = 0;
                        i12 = 2;
                        z10 = z10;
                    } else if (iOZ7qYn4 == 2) {
                        iOZ7qYn = gMtmhHQ.oZ7qYn(4) + 9;
                        iOZ7qYn2 = gMtmhHQ.oZ7qYn(4);
                    } else if (iOZ7qYn4 != 3) {
                        z10 = z10;
                        iOZ7qYn3 = 0;
                        i12 = 0;
                    } else {
                        iOZ7qYn = gMtmhHQ.oZ7qYn(8) + 25;
                        iOZ7qYn2 = gMtmhHQ.oZ7qYn(4);
                    }
                } else {
                    iOZ7qYn = gMtmhHQ.oZ7qYn(2) + 4;
                    iOZ7qYn2 = gMtmhHQ.oZ7qYn(4);
                }
                z10 = z10;
                i12 = iOZ7qYn;
                iOZ7qYn3 = iOZ7qYn2;
            } else {
                int iOZ7qYn5 = gMtmhHQ.oZ7qYn(3);
                if (iOZ7qYn5 != 0) {
                    i12 = iOZ7qYn5 + 2;
                    iOZ7qYn3 = 0;
                } else {
                    z10 = true;
                    iOZ7qYn3 = 0;
                    i12 = 0;
                }
            }
            if (i12 != 0 && paint != null) {
                if (bArr != null) {
                    iOZ7qYn3 = bArr[iOZ7qYn3];
                }
                paint.setColor(iArr[iOZ7qYn3]);
                canvas.drawRect(i10, i11, i10 + i12, 1 + i11, paint);
            }
            i10 += i12;
            if (z10) {
                return i10;
            }
            z10 = z10;
        }
    }

    public static int osx7Pl0E(int i10, int i11, int i12, int i13) {
        return (i10 << 24) | (i11 << 16) | (i12 << 8) | i13;
    }

    public static MY3jR q1ORKN(GMtmhHQ gMtmhHQ, int i10) {
        int[] iArr;
        int iOZ7qYn;
        int i11;
        int iOZ7qYn2;
        int iOZ7qYn3;
        int iOZ7qYn4;
        int i12 = 8;
        int iOZ7qYn5 = gMtmhHQ.oZ7qYn(8);
        gMtmhHQ.jAM6dcNA(8);
        int i13 = 2;
        int i14 = i10 - 2;
        int[] iArrELbhX59K = eLbhX59K();
        int[] iArrZDWsfFRp = zDWsfFRp();
        int[] iArrIvfTYNl = ivfTYNl();
        while (i14 > 0) {
            int iOZ7qYn6 = gMtmhHQ.oZ7qYn(i12);
            int iOZ7qYn7 = gMtmhHQ.oZ7qYn(i12);
            if ((iOZ7qYn7 & 128) != 0) {
                iArr = iArrELbhX59K;
            } else {
                iArr = (iOZ7qYn7 & 64) != 0 ? iArrZDWsfFRp : iArrIvfTYNl;
            }
            if ((iOZ7qYn7 & 1) != 0) {
                iOZ7qYn3 = gMtmhHQ.oZ7qYn(i12);
                iOZ7qYn4 = gMtmhHQ.oZ7qYn(i12);
                iOZ7qYn = gMtmhHQ.oZ7qYn(i12);
                iOZ7qYn2 = gMtmhHQ.oZ7qYn(i12);
                i11 = i14 - 6;
            } else {
                int iOZ7qYn8 = gMtmhHQ.oZ7qYn(6) << i13;
                int iOZ7qYn9 = gMtmhHQ.oZ7qYn(4) << 4;
                iOZ7qYn = gMtmhHQ.oZ7qYn(4) << 4;
                i11 = i14 - 4;
                iOZ7qYn2 = gMtmhHQ.oZ7qYn(i13) << 6;
                iOZ7qYn3 = iOZ7qYn8;
                iOZ7qYn4 = iOZ7qYn9;
            }
            if (iOZ7qYn3 == 0) {
                iOZ7qYn2 = 255;
                iOZ7qYn4 = 0;
                iOZ7qYn = 0;
            }
            double d10 = iOZ7qYn3;
            double d11 = iOZ7qYn4 - 128;
            double d12 = iOZ7qYn - 128;
            iArr[iOZ7qYn6] = osx7Pl0E((byte) (255 - (iOZ7qYn2 & 255)), YcaGN.mTWLV((int) (d10 + (1.402d * d11)), 0, 255), YcaGN.mTWLV((int) ((d10 - (0.34414d * d12)) - (d11 * 0.71414d)), 0, 255), YcaGN.mTWLV((int) (d10 + (d12 * 1.772d)), 0, 255));
            i14 = i11;
            iOZ7qYn5 = iOZ7qYn5;
            i12 = 8;
            i13 = 2;
        }
        return new MY3jR(iOZ7qYn5, iArrELbhX59K, iArrZDWsfFRp, iArrIvfTYNl);
    }

    public static void qLLw0g(RFQ3AA8 rfq3aa8, MY3jR mY3jR, int i10, int i11, int i12, Paint paint, Canvas canvas) {
        int[] iArr;
        if (i10 == 3) {
            iArr = mY3jR.zDWsfFRp;
        } else {
            iArr = i10 == 2 ? mY3jR.eLbhX59K : mY3jR.aXYSYCVY;
        }
        int[] iArr2 = iArr;
        zPJpxWz(rfq3aa8.eLbhX59K, iArr2, i10, i11, i12, paint, canvas);
        zPJpxWz(rfq3aa8.zDWsfFRp, iArr2, i10, i11, i12 + 1, paint, canvas);
    }

    public static void rJCQt16(GMtmhHQ gMtmhHQ, GU39Hcg gU39Hcg) {
        XbU7b xbU7b;
        int iOZ7qYn = gMtmhHQ.oZ7qYn(8);
        int iOZ7qYn2 = gMtmhHQ.oZ7qYn(16);
        int iOZ7qYn3 = gMtmhHQ.oZ7qYn(16);
        int iZDWsfFRp = gMtmhHQ.zDWsfFRp() + iOZ7qYn3;
        if (iOZ7qYn3 * 8 > gMtmhHQ.aXYSYCVY()) {
            O5Z56VT6.rjljd6i("DvbParser", "Data field length exceeds limit");
            gMtmhHQ.jAM6dcNA(gMtmhHQ.aXYSYCVY());
            return;
        }
        switch (iOZ7qYn) {
            case 16:
                if (iOZ7qYn2 == gU39Hcg.eszJ2B0a) {
                    LNd998w lNd998w = gU39Hcg.rjljd6i;
                    LNd998w lNd998wYxejkub = yxejkub(gMtmhHQ, iOZ7qYn3);
                    if (lNd998wYxejkub.eLbhX59K != 0) {
                        gU39Hcg.rjljd6i = lNd998wYxejkub;
                        gU39Hcg.eLbhX59K.clear();
                        gU39Hcg.zDWsfFRp.clear();
                        gU39Hcg.ivfTYNl.clear();
                    } else if (lNd998w != null && lNd998w.aXYSYCVY != lNd998wYxejkub.aXYSYCVY) {
                        gU39Hcg.rjljd6i = lNd998wYxejkub;
                    }
                }
                break;
            case 17:
                LNd998w lNd998w2 = gU39Hcg.rjljd6i;
                if (iOZ7qYn2 == gU39Hcg.eszJ2B0a && lNd998w2 != null) {
                    XbU7b xbU7bMTWLV = mTWLV(gMtmhHQ, iOZ7qYn3);
                    if (lNd998w2.eLbhX59K == 0 && (xbU7b = (XbU7b) gU39Hcg.eLbhX59K.get(xbU7bMTWLV.eszJ2B0a)) != null) {
                        xbU7bMTWLV.eszJ2B0a(xbU7b);
                    }
                    gU39Hcg.eLbhX59K.put(xbU7bMTWLV.eszJ2B0a, xbU7bMTWLV);
                }
                break;
            case 18:
                if (iOZ7qYn2 == gU39Hcg.eszJ2B0a) {
                    MY3jR mY3jRQ1ORKN = q1ORKN(gMtmhHQ, iOZ7qYn3);
                    gU39Hcg.zDWsfFRp.put(mY3jRQ1ORKN.eszJ2B0a, mY3jRQ1ORKN);
                } else if (iOZ7qYn2 == gU39Hcg.aXYSYCVY) {
                    MY3jR mY3jRQ1ORKN2 = q1ORKN(gMtmhHQ, iOZ7qYn3);
                    gU39Hcg.osx7Pl0E.put(mY3jRQ1ORKN2.eszJ2B0a, mY3jRQ1ORKN2);
                }
                break;
            case 19:
                if (iOZ7qYn2 == gU39Hcg.eszJ2B0a) {
                    RFQ3AA8 rfq3aa8UYRSwDm = uYRSwDm(gMtmhHQ);
                    gU39Hcg.ivfTYNl.put(rfq3aa8UYRSwDm.eszJ2B0a, rfq3aa8UYRSwDm);
                } else if (iOZ7qYn2 == gU39Hcg.aXYSYCVY) {
                    RFQ3AA8 rfq3aa8UYRSwDm2 = uYRSwDm(gMtmhHQ);
                    gU39Hcg.dUI84.put(rfq3aa8UYRSwDm2.eszJ2B0a, rfq3aa8UYRSwDm2);
                }
                break;
            case 20:
                if (iOZ7qYn2 == gU39Hcg.eszJ2B0a) {
                    gU39Hcg.oZ7qYn = uTIfLNK0(gMtmhHQ);
                }
                break;
        }
        gMtmhHQ.rtsRj(iZDWsfFRp - gMtmhHQ.zDWsfFRp());
    }

    public static int rjljd6i(GMtmhHQ gMtmhHQ, int[] iArr, byte[] bArr, int i10, int i11, Paint paint, Canvas canvas) {
        boolean z10;
        int iOZ7qYn;
        boolean z11 = false;
        while (true) {
            int iOZ7qYn2 = gMtmhHQ.oZ7qYn(8);
            if (iOZ7qYn2 != 0) {
                z10 = z11;
                iOZ7qYn = 1;
            } else if (gMtmhHQ.dUI84()) {
                z10 = z11;
                iOZ7qYn = gMtmhHQ.oZ7qYn(7);
                iOZ7qYn2 = gMtmhHQ.oZ7qYn(8);
            } else {
                int iOZ7qYn3 = gMtmhHQ.oZ7qYn(7);
                if (iOZ7qYn3 != 0) {
                    z10 = z11;
                    iOZ7qYn = iOZ7qYn3;
                    iOZ7qYn2 = 0;
                } else {
                    z10 = true;
                    iOZ7qYn2 = 0;
                    iOZ7qYn = 0;
                }
            }
            if (iOZ7qYn != 0 && paint != null) {
                if (bArr != null) {
                    iOZ7qYn2 = bArr[iOZ7qYn2];
                }
                paint.setColor(iArr[iOZ7qYn2]);
                canvas.drawRect(i10, i11, i10 + iOZ7qYn, 1 + i11, paint);
            }
            i10 += iOZ7qYn;
            if (z10) {
                return i10;
            }
            z11 = z10;
        }
    }

    public static C1482AAnYcst uTIfLNK0(GMtmhHQ gMtmhHQ) {
        int i10;
        int i11;
        int i12;
        int iOZ7qYn;
        gMtmhHQ.jAM6dcNA(4);
        boolean zDUI84 = gMtmhHQ.dUI84();
        gMtmhHQ.jAM6dcNA(3);
        int iOZ7qYn2 = gMtmhHQ.oZ7qYn(16);
        int iOZ7qYn3 = gMtmhHQ.oZ7qYn(16);
        if (zDUI84) {
            int iOZ7qYn4 = gMtmhHQ.oZ7qYn(16);
            int iOZ7qYn5 = gMtmhHQ.oZ7qYn(16);
            int iOZ7qYn6 = gMtmhHQ.oZ7qYn(16);
            iOZ7qYn = gMtmhHQ.oZ7qYn(16);
            i12 = iOZ7qYn5;
            i11 = iOZ7qYn6;
            i10 = iOZ7qYn4;
        } else {
            i10 = 0;
            i11 = 0;
            i12 = iOZ7qYn2;
            iOZ7qYn = iOZ7qYn3;
        }
        return new C1482AAnYcst(iOZ7qYn2, iOZ7qYn3, i10, i12, i11, iOZ7qYn);
    }

    public static RFQ3AA8 uYRSwDm(GMtmhHQ gMtmhHQ) {
        byte[] bArr;
        int iOZ7qYn = gMtmhHQ.oZ7qYn(16);
        gMtmhHQ.jAM6dcNA(4);
        int iOZ7qYn2 = gMtmhHQ.oZ7qYn(2);
        boolean zDUI84 = gMtmhHQ.dUI84();
        gMtmhHQ.jAM6dcNA(1);
        byte[] bArr2 = YcaGN.osx7Pl0E;
        if (iOZ7qYn2 != 1) {
            if (iOZ7qYn2 == 0) {
                int iOZ7qYn3 = gMtmhHQ.oZ7qYn(16);
                int iOZ7qYn4 = gMtmhHQ.oZ7qYn(16);
                if (iOZ7qYn3 > 0) {
                    bArr2 = new byte[iOZ7qYn3];
                    gMtmhHQ.qLLw0g(bArr2, 0, iOZ7qYn3);
                }
                if (iOZ7qYn4 > 0) {
                    bArr = new byte[iOZ7qYn4];
                    gMtmhHQ.qLLw0g(bArr, 0, iOZ7qYn4);
                }
            }
            return new RFQ3AA8(iOZ7qYn, zDUI84, bArr2, bArr);
        }
        gMtmhHQ.jAM6dcNA(gMtmhHQ.oZ7qYn(8) * 16);
        bArr = bArr2;
        return new RFQ3AA8(iOZ7qYn, zDUI84, bArr2, bArr);
    }

    public static LNd998w yxejkub(GMtmhHQ gMtmhHQ, int i10) {
        int iOZ7qYn = gMtmhHQ.oZ7qYn(8);
        int iOZ7qYn2 = gMtmhHQ.oZ7qYn(4);
        int iOZ7qYn3 = gMtmhHQ.oZ7qYn(2);
        gMtmhHQ.jAM6dcNA(2);
        int i11 = i10 - 2;
        SparseArray sparseArray = new SparseArray();
        while (i11 > 0) {
            int iOZ7qYn4 = gMtmhHQ.oZ7qYn(8);
            gMtmhHQ.jAM6dcNA(8);
            i11 -= 6;
            sparseArray.put(iOZ7qYn4, new N1vNRFSd(gMtmhHQ.oZ7qYn(16), gMtmhHQ.oZ7qYn(16)));
        }
        return new LNd998w(iOZ7qYn, iOZ7qYn2, iOZ7qYn3, sparseArray);
    }

    public static int[] zDWsfFRp() {
        int[] iArr = new int[16];
        iArr[0] = 0;
        for (int i10 = 1; i10 < 16; i10++) {
            if (i10 < 8) {
                iArr[i10] = osx7Pl0E(255, (i10 & 1) != 0 ? 255 : 0, (i10 & 2) != 0 ? 255 : 0, (i10 & 4) != 0 ? 255 : 0);
            } else {
                iArr[i10] = osx7Pl0E(255, (i10 & 1) != 0 ? 127 : 0, (i10 & 2) != 0 ? 127 : 0, (i10 & 4) == 0 ? 0 : 127);
            }
        }
        return iArr;
    }

    public static void zPJpxWz(byte[] bArr, int[] iArr, int i10, int i11, int i12, Paint paint, Canvas canvas) {
        int[] iArr2;
        Paint paint2;
        Canvas canvas2;
        byte[] bArr2;
        byte[] bArr3;
        GMtmhHQ gMtmhHQ = new GMtmhHQ(bArr);
        byte[] bArrEszJ2B0a = null;
        byte[] bArrEszJ2B0a2 = null;
        int iDUI84 = i11;
        int i13 = i12;
        byte[] bArrEszJ2B0a3 = null;
        while (gMtmhHQ.aXYSYCVY() != 0) {
            int iOZ7qYn = gMtmhHQ.oZ7qYn(8);
            if (iOZ7qYn != 240) {
                switch (iOZ7qYn) {
                    case 16:
                        iArr2 = iArr;
                        paint2 = paint;
                        canvas2 = canvas;
                        if (i10 != 3) {
                            if (i10 == 2) {
                                bArr3 = bArrEszJ2B0a2 == null ? oZ7qYn : bArrEszJ2B0a2;
                            } else {
                                bArr2 = null;
                            }
                            iDUI84 = dUI84(gMtmhHQ, iArr2, bArr2, iDUI84, i13, paint2, canvas2);
                            gMtmhHQ.eLbhX59K();
                        } else {
                            bArr3 = bArrEszJ2B0a3 == null ? rjljd6i : bArrEszJ2B0a3;
                        }
                        bArr2 = bArr3;
                        iDUI84 = dUI84(gMtmhHQ, iArr2, bArr2, iDUI84, i13, paint2, canvas2);
                        gMtmhHQ.eLbhX59K();
                        break;
                    case 17:
                        iArr2 = iArr;
                        Paint paint3 = paint;
                        canvas2 = canvas;
                        paint2 = paint3;
                        iDUI84 = oZ7qYn(gMtmhHQ, iArr2, i10 == 3 ? bArrEszJ2B0a == null ? zPJpxWz : bArrEszJ2B0a : null, iDUI84, i13, paint2, canvas2);
                        gMtmhHQ.eLbhX59K();
                        break;
                    case 18:
                        iArr2 = iArr;
                        paint2 = paint;
                        canvas2 = canvas;
                        iDUI84 = rjljd6i(gMtmhHQ, iArr2, null, iDUI84, i13, paint2, canvas2);
                        break;
                    default:
                        switch (iOZ7qYn) {
                            case 32:
                                bArrEszJ2B0a2 = eszJ2B0a(4, 4, gMtmhHQ);
                                break;
                            case 33:
                                bArrEszJ2B0a3 = eszJ2B0a(4, 8, gMtmhHQ);
                                break;
                            case 34:
                                bArrEszJ2B0a = eszJ2B0a(16, 8, gMtmhHQ);
                                break;
                        }
                        iArr2 = iArr;
                        paint2 = paint;
                        canvas2 = canvas;
                        break;
                }
            } else {
                iArr2 = iArr;
                paint2 = paint;
                canvas2 = canvas;
                i13 += 2;
                iDUI84 = i11;
            }
            iArr = iArr2;
            paint = paint2;
            canvas = canvas2;
        }
    }

    public List aXYSYCVY(byte[] bArr, int i10) {
        int i11;
        GMtmhHQ gMtmhHQ = new GMtmhHQ(bArr, i10);
        while (gMtmhHQ.aXYSYCVY() >= 48 && gMtmhHQ.oZ7qYn(8) == 15) {
            rJCQt16(gMtmhHQ, this.osx7Pl0E);
        }
        GU39Hcg gU39Hcg = this.osx7Pl0E;
        LNd998w lNd998w = gU39Hcg.rjljd6i;
        if (lNd998w == null) {
            return Collections.EMPTY_LIST;
        }
        C1482AAnYcst c1482AAnYcst = gU39Hcg.oZ7qYn;
        if (c1482AAnYcst == null) {
            c1482AAnYcst = this.zDWsfFRp;
        }
        Bitmap bitmap = this.dUI84;
        if (bitmap == null || c1482AAnYcst.eszJ2B0a + 1 != bitmap.getWidth() || c1482AAnYcst.aXYSYCVY + 1 != this.dUI84.getHeight()) {
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(c1482AAnYcst.eszJ2B0a + 1, c1482AAnYcst.aXYSYCVY + 1, Bitmap.Config.ARGB_8888);
            this.dUI84 = bitmapCreateBitmap;
            this.eLbhX59K.setBitmap(bitmapCreateBitmap);
        }
        ArrayList arrayList = new ArrayList();
        SparseArray sparseArray = lNd998w.zDWsfFRp;
        int i12 = 0;
        while (i12 < sparseArray.size()) {
            this.eLbhX59K.save();
            N1vNRFSd n1vNRFSd = (N1vNRFSd) sparseArray.valueAt(i12);
            XbU7b xbU7b = (XbU7b) this.osx7Pl0E.eLbhX59K.get(sparseArray.keyAt(i12));
            int i13 = n1vNRFSd.eszJ2B0a + c1482AAnYcst.eLbhX59K;
            int i14 = n1vNRFSd.aXYSYCVY + c1482AAnYcst.ivfTYNl;
            this.eLbhX59K.clipRect(i13, i14, Math.min(xbU7b.eLbhX59K + i13, c1482AAnYcst.zDWsfFRp), Math.min(xbU7b.zDWsfFRp + i14, c1482AAnYcst.osx7Pl0E));
            MY3jR mY3jR = (MY3jR) this.osx7Pl0E.zDWsfFRp.get(xbU7b.dUI84);
            if (mY3jR == null && (mY3jR = (MY3jR) this.osx7Pl0E.osx7Pl0E.get(xbU7b.dUI84)) == null) {
                mY3jR = this.ivfTYNl;
            }
            MY3jR mY3jR2 = mY3jR;
            SparseArray sparseArray2 = xbU7b.qLLw0g;
            int i15 = 0;
            while (i15 < sparseArray2.size()) {
                int iKeyAt = sparseArray2.keyAt(i15);
                W7Cnq5 w7Cnq5 = (W7Cnq5) sparseArray2.valueAt(i15);
                RFQ3AA8 rfq3aa8 = (RFQ3AA8) this.osx7Pl0E.ivfTYNl.get(iKeyAt);
                if (rfq3aa8 == null) {
                    rfq3aa8 = (RFQ3AA8) this.osx7Pl0E.dUI84.get(iKeyAt);
                }
                if (rfq3aa8 != null) {
                    qLLw0g(rfq3aa8, mY3jR2, xbU7b.osx7Pl0E, w7Cnq5.eLbhX59K + i13, w7Cnq5.zDWsfFRp + i14, rfq3aa8.aXYSYCVY ? null : this.eszJ2B0a, this.eLbhX59K);
                }
                i15++;
                sparseArray = sparseArray;
            }
            SparseArray sparseArray3 = sparseArray;
            if (xbU7b.aXYSYCVY) {
                int i16 = xbU7b.osx7Pl0E;
                if (i16 == 3) {
                    i11 = mY3jR2.zDWsfFRp[xbU7b.oZ7qYn];
                } else {
                    i11 = i16 == 2 ? mY3jR2.eLbhX59K[xbU7b.rjljd6i] : mY3jR2.aXYSYCVY[xbU7b.zPJpxWz];
                }
                this.aXYSYCVY.setColor(i11);
                this.eLbhX59K.drawRect(i13, i14, xbU7b.eLbhX59K + i13, xbU7b.zDWsfFRp + i14, this.aXYSYCVY);
            }
            arrayList.add(new ce98vs.AAnYcst.C0786AAnYcst().osx7Pl0E(Bitmap.createBitmap(this.dUI84, i13, i14, xbU7b.eLbhX59K, xbU7b.zDWsfFRp)).qLLw0g(i13 / c1482AAnYcst.eszJ2B0a).q1ORKN(0).oZ7qYn(i14 / c1482AAnYcst.aXYSYCVY, 0).rjljd6i(0).uYRSwDm(xbU7b.eLbhX59K / c1482AAnYcst.eszJ2B0a).dUI84(xbU7b.zDWsfFRp / c1482AAnYcst.aXYSYCVY).eszJ2B0a());
            this.eLbhX59K.drawColor(0, PorterDuff.Mode.CLEAR);
            this.eLbhX59K.restore();
            i12++;
            sparseArray = sparseArray3;
        }
        return Collections.unmodifiableList(arrayList);
    }

    public void jAM6dcNA() {
        this.osx7Pl0E.eszJ2B0a();
    }
}
