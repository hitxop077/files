package jo8yzlz;

import ce98vs.W7Cnq5;
import ce98vs.XbU7b;
import java.util.List;
import t3jmd7k.ZKBAd;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class MY3jR extends XbU7b {
    public final AAnYcst yxejkub;

    public MY3jR(List list) {
        super("DvbDecoder");
        ZKBAd zKBAd = new ZKBAd((byte[]) list.get(0));
        this.yxejkub = new AAnYcst(zKBAd.d3penA(), zKBAd.d3penA());
    }

    @Override // ce98vs.XbU7b
    public W7Cnq5 mK94T(byte[] bArr, int i10, boolean z10) {
        if (z10) {
            this.yxejkub.jAM6dcNA();
        }
        return new RFQ3AA8(this.yxejkub.aXYSYCVY(bArr, i10));
    }
}
