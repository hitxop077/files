package jo8yzlz;

import ce98vs.W7Cnq5;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class RFQ3AA8 implements W7Cnq5 {
    public final List njNibPNp;

    public RFQ3AA8(List list) {
        this.njNibPNp = list;
    }

    @Override // ce98vs.W7Cnq5
    public int dUI84(long j10) {
        return -1;
    }

    @Override // ce98vs.W7Cnq5
    public long eszJ2B0a(int i10) {
        return 0L;
    }

    @Override // ce98vs.W7Cnq5
    public List oZ7qYn(long j10) {
        return this.njNibPNp;
    }

    @Override // ce98vs.W7Cnq5
    public int osx7Pl0E() {
        return 1;
    }
}
