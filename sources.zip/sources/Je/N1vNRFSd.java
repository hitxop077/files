package Je;

import android.content.Context;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public abstract class N1vNRFSd {
    public static final MY3jR eszJ2B0a = new MY3jR(null);

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public /* synthetic */ MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void aXYSYCVY(Context context, String paymentMode, String str) {
            Context applicationContext;
            Intrinsics.checkNotNullParameter(paymentMode, "paymentMode");
            C6.AAnYcst aAnYcstEszJ2B0a = (context == null || (applicationContext = context.getApplicationContext()) == null) ? null : XbU7b.eszJ2B0a.eszJ2B0a(applicationContext);
            if (Intrinsics.areEqual("UPI", paymentMode) && str != null && aAnYcstEszJ2B0a != null) {
                aAnYcstEszJ2B0a.wtGiK9b("p2p-last-used-bank-account-number", str, false);
            }
            if (aAnYcstEszJ2B0a != null) {
                aAnYcstEszJ2B0a.wtGiK9b("p2p-last-used-paymode", paymentMode, true);
            }
        }

        public final void eszJ2B0a(Context context) {
            Context applicationContext;
            C6.AAnYcst aAnYcstEszJ2B0a = (context == null || (applicationContext = context.getApplicationContext()) == null) ? null : XbU7b.eszJ2B0a.eszJ2B0a(applicationContext);
            if (aAnYcstEszJ2B0a != null) {
                aAnYcstEszJ2B0a.oZ7qYn("selected_account_ifsc", false);
            }
            if (aAnYcstEszJ2B0a != null) {
                aAnYcstEszJ2B0a.oZ7qYn("selected_account_number", false);
            }
        }

        public MY3jR() {
        }
    }
}
