package Je;

import kotlin.Pair;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public interface HicDZW {

    /* JADX INFO: compiled from: Obfuscated */
    public interface AAnYcst {
    }

    /* JADX INFO: compiled from: Obfuscated */
    public interface MY3jR {
    }

    /* JADX INFO: compiled from: Obfuscated */
    public interface RFQ3AA8 {
    }

    Pair eszJ2B0a(RFQ3AA8 rfq3aa8, AAnYcst aAnYcst);
}
