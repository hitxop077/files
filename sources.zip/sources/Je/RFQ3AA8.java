package Je;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class RFQ3AA8 {
    public long aXYSYCVY;
    public boolean eLbhX59K;
    public long eszJ2B0a;

    public final void aXYSYCVY() {
        this.eszJ2B0a = 0L;
        this.aXYSYCVY = 0L;
        this.eLbhX59K = false;
    }

    public final void eLbhX59K() {
        if (this.eLbhX59K) {
            return;
        }
        this.eszJ2B0a = System.currentTimeMillis();
        this.eLbhX59K = true;
    }

    public final long eszJ2B0a() {
        return this.eLbhX59K ? this.aXYSYCVY + (System.currentTimeMillis() - this.eszJ2B0a) : this.aXYSYCVY;
    }

    public final void zDWsfFRp() {
        if (this.eLbhX59K) {
            this.aXYSYCVY += System.currentTimeMillis() - this.eszJ2B0a;
            this.eLbhX59K = false;
        }
    }
}
