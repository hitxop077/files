package Je;

import androidx.lifecycle.AfGFIA;
import androidx.lifecycle.RNKsLmd;
import androidx.lifecycle.RkdvoZ;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Function;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class VVpVRy extends AfGFIA {
    public static final MY3jR aXYSYCVY = new MY3jR(null);
    public static final int eLbhX59K = 8;
    public static final String zDWsfFRp = "SingleLiveEvent";
    public final AtomicBoolean eszJ2B0a = new AtomicBoolean(false);

    /* JADX INFO: compiled from: Obfuscated */
    public static final class AAnYcst implements RNKsLmd, FunctionAdapter {
        public final /* synthetic */ Function1 njNibPNp;

        public AAnYcst(Function1 function) {
            Intrinsics.checkNotNullParameter(function, "function");
            this.njNibPNp = function;
        }

        public final boolean equals(Object obj) {
            if ((obj instanceof RNKsLmd) && (obj instanceof FunctionAdapter)) {
                return Intrinsics.areEqual(getFunctionDelegate(), ((FunctionAdapter) obj).getFunctionDelegate());
            }
            return false;
        }

        @Override // kotlin.jvm.internal.FunctionAdapter
        public final Function getFunctionDelegate() {
            return this.njNibPNp;
        }

        public final int hashCode() {
            return getFunctionDelegate().hashCode();
        }

        @Override // androidx.lifecycle.RNKsLmd
        public final /* synthetic */ void onChanged(Object obj) {
            this.njNibPNp.invoke(obj);
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public /* synthetic */ MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public MY3jR() {
        }
    }

    public static final void ivfTYNl(VVpVRy vVpVRy, RNKsLmd rNKsLmd, Object obj) {
        if (vVpVRy.eszJ2B0a.compareAndSet(true, false)) {
            rNKsLmd.onChanged(obj);
        }
    }

    public static final Unit osx7Pl0E(VVpVRy vVpVRy, RNKsLmd rNKsLmd, Object obj) {
        if (vVpVRy.eszJ2B0a.compareAndSet(true, false)) {
            rNKsLmd.onChanged(obj);
        }
        return Unit.INSTANCE;
    }

    @Override // androidx.lifecycle.ZKBAd
    public void observe(RkdvoZ owner, final RNKsLmd observer) {
        Intrinsics.checkNotNullParameter(owner, "owner");
        Intrinsics.checkNotNullParameter(observer, "observer");
        hasActiveObservers();
        super.observe(owner, new RNKsLmd() { // from class: Je.Bv3FS
            @Override // androidx.lifecycle.RNKsLmd
            public final void onChanged(Object obj) {
                VVpVRy.ivfTYNl(this.njNibPNp, observer, obj);
            }
        });
    }

    @Override // androidx.lifecycle.ZKBAd
    public void observeForever(final RNKsLmd observer) {
        Intrinsics.checkNotNullParameter(observer, "observer");
        hasActiveObservers();
        super.observeForever(new AAnYcst(new Function1() { // from class: Je.Lx1jI
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return VVpVRy.osx7Pl0E(this.njNibPNp, observer, obj);
            }
        }));
    }

    @Override // androidx.lifecycle.AfGFIA, androidx.lifecycle.ZKBAd
    public void postValue(Object obj) {
        this.eszJ2B0a.set(true);
        super.postValue(obj);
    }
}
