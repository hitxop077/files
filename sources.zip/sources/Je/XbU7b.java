package Je;

import android.content.Context;
import com.paytm.network.CJRCommonNetworkCall;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public abstract class XbU7b {
    public static final MY3jR eszJ2B0a = new MY3jR(null);
    public static final CJRCommonNetworkCall.VerticalId aXYSYCVY = CJRCommonNetworkCall.VerticalId.TPAP_MONEYTRANSFER;

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public /* synthetic */ MY3jR(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final C6.AAnYcst eszJ2B0a(Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            return C6.AAnYcst.aXYSYCVY.osx7Pl0E(context, XbU7b.aXYSYCVY);
        }

        public MY3jR() {
        }
    }

    public static final C6.AAnYcst aXYSYCVY(Context context) {
        return eszJ2B0a.eszJ2B0a(context);
    }
}
