package Je;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public interface JQAVH {
    int aXYSYCVY(int i10);

    String eszJ2B0a(int i10, Object... objArr);
}
