package Je;

import android.content.Context;
import java.util.ArrayList;
import net.one97.paytm.moneytransfer.base.helper.SvaBAkIt;
import net.one97.paytm.pluginupi.common.utils.ZKBAd;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public abstract class MY3jR {
    public static void aXYSYCVY(Context context, String str, String str2, String str3, String str4, String str5, String str6) {
        if (context == null) {
            return;
        }
        try {
            SvaBAkIt.dUI84().sendNewCustomGTMEvents(context, str, str2, str4, str5, str6, str3, "TPAP_UPI");
        } catch (Exception e10) {
            ZKBAd.zDWsfFRp(e10);
        }
    }

    public static void eLbhX59K(Context context, String str, String str2, String str3, ArrayList arrayList, String str4) {
        if (context == null) {
            return;
        }
        try {
            SvaBAkIt.dUI84().sendNewCustomGTMEventsWithMultipleLabel(context, str, str2, arrayList, str4, str3, "TPAP_UPI");
        } catch (Exception e10) {
            ZKBAd.zDWsfFRp(e10);
        }
    }

    public static void eszJ2B0a(Context context, String str, String str2, String str3, String str4, String str5) {
        if (context == null) {
            return;
        }
        try {
            SvaBAkIt.dUI84().sendNewCustomGTMEvents(context, str, str2, str4, str5, "", str3, "TPAP_UPI");
        } catch (Exception e10) {
            ZKBAd.zDWsfFRp(e10);
        }
    }

    public static void zDWsfFRp(Context context, String str) {
        if (context == null) {
            return;
        }
        try {
            SvaBAkIt.dUI84().sendOpenScreenWithDeviceInfo(str, "TPAP_UPI", context);
        } catch (Exception e10) {
            ZKBAd.zDWsfFRp(e10);
        }
    }
}
