package Kf;

import android.content.Context;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.cllibsdk.analytics.AnalyticsEventBuilder;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public abstract class RFQ3AA8 {
    public static final void eszJ2B0a(Context context, String paymentMode, String sourceCategory, String paymentStatus, String flowType, String errorCode, String str, String screenName) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(paymentMode, "paymentMode");
        Intrinsics.checkNotNullParameter(sourceCategory, "sourceCategory");
        Intrinsics.checkNotNullParameter(paymentStatus, "paymentStatus");
        Intrinsics.checkNotNullParameter(flowType, "flowType");
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        Intrinsics.checkNotNullParameter(screenName, "screenName");
        new AnalyticsEventBuilder("device unlocked").action("pps_device_unlock").category(sourceCategory).verticalId("TPAP_UPI").screenName(screenName).label(1, paymentMode).label(2, sourceCategory).label(3, paymentStatus).label(4, flowType).label(5, errorCode).addEvent(SDKConstants.EVENT_KEY_EVENT_VALUE_3, str).send(context);
    }
}
