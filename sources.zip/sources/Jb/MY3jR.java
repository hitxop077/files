package Jb;

import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.compose.resources.AXWzg4r;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public final class MY3jR {
    public static final MY3jR eszJ2B0a = new MY3jR();

    public final String eszJ2B0a(String path) {
        Intrinsics.checkNotNullParameter(path, "path");
        return AXWzg4r.eLbhX59K("composeResources/moneytransfer_kmm.mt_kmm.generated.resources/" + path);
    }
}
