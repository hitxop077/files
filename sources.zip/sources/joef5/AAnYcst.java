package joef5;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class AAnYcst {
    public static final MY3jR eszJ2B0a(boolean z10) {
        return z10 ? MY3jR.On : MY3jR.Off;
    }
}
