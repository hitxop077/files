package joef5;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public enum MY3jR {
    On,
    Off,
    Indeterminate
}
