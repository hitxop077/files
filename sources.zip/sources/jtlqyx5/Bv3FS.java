package jtlqyx5;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.Property;
import android.view.animation.Interpolator;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;
import java.util.Iterator;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Bv3FS extends GU39Hcg {
    public int dUI84;
    public ObjectAnimator eLbhX59K;
    public final Interpolator[] ivfTYNl;
    public boolean oZ7qYn;
    public final jtlqyx5.AAnYcst osx7Pl0E;
    public float rjljd6i;
    public ObjectAnimator zDWsfFRp;
    public j7p73.AAnYcst zPJpxWz;
    public static final int[] qLLw0g = {533, 567, 850, 750};
    public static final int[] q1ORKN = {1267, 1000, 333, 0};
    public static final Property uTIfLNK0 = new RFQ3AA8(Float.class, "animationFraction");

    /* JADX INFO: compiled from: Obfuscated */
    public class AAnYcst extends AnimatorListenerAdapter {
        public AAnYcst() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            Bv3FS.this.eszJ2B0a();
            Bv3FS bv3FS = Bv3FS.this;
            j7p73.AAnYcst aAnYcst = bv3FS.zPJpxWz;
            if (aAnYcst != null) {
                aAnYcst.aXYSYCVY(bv3FS.eszJ2B0a);
            }
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends AnimatorListenerAdapter {
        public MY3jR() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
            super.onAnimationRepeat(animator);
            Bv3FS bv3FS = Bv3FS.this;
            bv3FS.dUI84 = (bv3FS.dUI84 + 1) % Bv3FS.this.osx7Pl0E.eLbhX59K.length;
            Bv3FS.this.oZ7qYn = true;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class RFQ3AA8 extends Property {
        public RFQ3AA8(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(Bv3FS bv3FS, Float f10) {
            bv3FS.jAM6dcNA(f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(Bv3FS bv3FS) {
            return Float.valueOf(bv3FS.uYRSwDm());
        }
    }

    public Bv3FS(Context context, LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(2);
        this.dUI84 = 0;
        this.zPJpxWz = null;
        this.osx7Pl0E = linearProgressIndicatorSpec;
        this.ivfTYNl = new Interpolator[]{j7p73.LNd998w.eszJ2B0a(context, g13xi.MY3jR.linear_indeterminate_line1_head_interpolator), j7p73.LNd998w.eszJ2B0a(context, g13xi.MY3jR.linear_indeterminate_line1_tail_interpolator), j7p73.LNd998w.eszJ2B0a(context, g13xi.MY3jR.linear_indeterminate_line2_head_interpolator), j7p73.LNd998w.eszJ2B0a(context, g13xi.MY3jR.linear_indeterminate_line2_tail_interpolator)};
    }

    private void mTWLV() {
        if (this.oZ7qYn) {
            Iterator it2 = this.aXYSYCVY.iterator();
            while (it2.hasNext()) {
                ((W7Cnq5.MY3jR) it2.next()).eLbhX59K = this.osx7Pl0E.eLbhX59K[this.dUI84];
            }
            this.oZ7qYn = false;
        }
    }

    private void rtsRj(int i10) {
        for (int i11 = 0; i11 < this.aXYSYCVY.size(); i11++) {
            W7Cnq5.MY3jR mY3jR = (W7Cnq5.MY3jR) this.aXYSYCVY.get(i11);
            int[] iArr = q1ORKN;
            int i12 = i11 * 2;
            int i13 = iArr[i12];
            int[] iArr2 = qLLw0g;
            mY3jR.eszJ2B0a = znp7wap.MY3jR.aXYSYCVY(this.ivfTYNl[i12].getInterpolation(aXYSYCVY(i10, i13, iArr2[i12])), 0.0f, 1.0f);
            int i14 = i12 + 1;
            mY3jR.aXYSYCVY = znp7wap.MY3jR.aXYSYCVY(this.ivfTYNl[i14].getInterpolation(aXYSYCVY(i10, iArr[i14], iArr2[i14])), 0.0f, 1.0f);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float uYRSwDm() {
        return this.rjljd6i;
    }

    private void yxejkub() {
        if (this.eLbhX59K == null) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<Bv3FS, Float>) uTIfLNK0, 0.0f, 1.0f);
            this.eLbhX59K = objectAnimatorOfFloat;
            objectAnimatorOfFloat.setDuration(1800L);
            this.eLbhX59K.setInterpolator(null);
            this.eLbhX59K.setRepeatCount(-1);
            this.eLbhX59K.addListener(new MY3jR());
        }
        if (this.zDWsfFRp == null) {
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, (Property<Bv3FS, Float>) uTIfLNK0, 1.0f);
            this.zDWsfFRp = objectAnimatorOfFloat2;
            objectAnimatorOfFloat2.setDuration(1800L);
            this.zDWsfFRp.setInterpolator(null);
            this.zDWsfFRp.addListener(new AAnYcst());
        }
    }

    @Override // jtlqyx5.GU39Hcg
    public void dUI84() {
        yxejkub();
        rJCQt16();
        this.eLbhX59K.start();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eLbhX59K() {
        rJCQt16();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eszJ2B0a() {
        ObjectAnimator objectAnimator = this.eLbhX59K;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public void jAM6dcNA(float f10) {
        this.rjljd6i = f10;
        rtsRj((int) (f10 * 1800.0f));
        mTWLV();
        this.eszJ2B0a.invalidateSelf();
    }

    @Override // jtlqyx5.GU39Hcg
    public void oZ7qYn() {
        this.zPJpxWz = null;
    }

    @Override // jtlqyx5.GU39Hcg
    public void osx7Pl0E() {
        ObjectAnimator objectAnimator = this.zDWsfFRp;
        if (objectAnimator == null || objectAnimator.isRunning()) {
            return;
        }
        eszJ2B0a();
        if (this.eszJ2B0a.isVisible()) {
            this.zDWsfFRp.setFloatValues(this.rjljd6i, 1.0f);
            this.zDWsfFRp.setDuration((long) ((1.0f - this.rjljd6i) * 1800.0f));
            this.zDWsfFRp.start();
        }
    }

    public void rJCQt16() {
        this.dUI84 = 0;
        Iterator it2 = this.aXYSYCVY.iterator();
        while (it2.hasNext()) {
            ((W7Cnq5.MY3jR) it2.next()).eLbhX59K = this.osx7Pl0E.eLbhX59K[0];
        }
    }

    @Override // jtlqyx5.GU39Hcg
    public void zDWsfFRp(j7p73.AAnYcst aAnYcst) {
        this.zPJpxWz = aAnYcst;
    }
}
