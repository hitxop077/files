package jtlqyx5;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class W7Cnq5 {
    public AAnYcst eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public float aXYSYCVY;
        public int eLbhX59K;
        public float eszJ2B0a;
        public int zDWsfFRp;
    }

    public W7Cnq5(AAnYcst aAnYcst) {
        this.eszJ2B0a = aAnYcst;
    }

    public abstract void aXYSYCVY(Canvas canvas, Paint paint, int i10, int i11);

    public void dUI84(Canvas canvas, Rect rect, float f10, boolean z10, boolean z11) {
        this.eszJ2B0a.ivfTYNl();
        eszJ2B0a(canvas, rect, f10, z10, z11);
    }

    public abstract void eLbhX59K(Canvas canvas, Paint paint, MY3jR mY3jR, int i10);

    public abstract void eszJ2B0a(Canvas canvas, Rect rect, float f10, boolean z10, boolean z11);

    public abstract int ivfTYNl();

    public abstract int osx7Pl0E();

    public abstract void zDWsfFRp(Canvas canvas, Paint paint, float f10, float f11, int i10, int i11, int i12);
}
