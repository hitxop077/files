package jtlqyx5;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class RFQ3AA8 extends W7Cnq5 {
    public float aXYSYCVY;
    public float eLbhX59K;
    public boolean ivfTYNl;
    public float osx7Pl0E;
    public float zDWsfFRp;

    public RFQ3AA8(CircularProgressIndicatorSpec circularProgressIndicatorSpec) {
        super(circularProgressIndicatorSpec);
    }

    @Override // jtlqyx5.W7Cnq5
    public void eLbhX59K(Canvas canvas, Paint paint, W7Cnq5.MY3jR mY3jR, int i10) {
        int iEszJ2B0a = rhrh7l5.MY3jR.eszJ2B0a(mY3jR.eLbhX59K, i10);
        float f10 = mY3jR.eszJ2B0a;
        float f11 = mY3jR.aXYSYCVY;
        int i11 = mY3jR.zDWsfFRp;
        oZ7qYn(canvas, paint, f10, f11, iEszJ2B0a, i11, i11);
    }

    @Override // jtlqyx5.W7Cnq5
    public void eszJ2B0a(Canvas canvas, Rect rect, float f10, boolean z10, boolean z11) {
        float fWidth = rect.width() / osx7Pl0E();
        float fHeight = rect.height() / ivfTYNl();
        AAnYcst aAnYcst = this.eszJ2B0a;
        float f11 = (((CircularProgressIndicatorSpec) aAnYcst).oZ7qYn / 2.0f) + ((CircularProgressIndicatorSpec) aAnYcst).rjljd6i;
        canvas.translate((f11 * fWidth) + rect.left, (f11 * fHeight) + rect.top);
        canvas.rotate(-90.0f);
        canvas.scale(fWidth, fHeight);
        if (((CircularProgressIndicatorSpec) this.eszJ2B0a).zPJpxWz != 0) {
            canvas.scale(1.0f, -1.0f);
        }
        float f12 = -f11;
        canvas.clipRect(f12, f12, f11, f11);
        AAnYcst aAnYcst2 = this.eszJ2B0a;
        this.ivfTYNl = ((CircularProgressIndicatorSpec) aAnYcst2).eszJ2B0a / 2 <= ((CircularProgressIndicatorSpec) aAnYcst2).aXYSYCVY;
        this.aXYSYCVY = ((CircularProgressIndicatorSpec) aAnYcst2).eszJ2B0a * f10;
        this.eLbhX59K = Math.min(((CircularProgressIndicatorSpec) aAnYcst2).eszJ2B0a / 2, ((CircularProgressIndicatorSpec) aAnYcst2).aXYSYCVY) * f10;
        AAnYcst aAnYcst3 = this.eszJ2B0a;
        float f13 = (((CircularProgressIndicatorSpec) aAnYcst3).oZ7qYn - ((CircularProgressIndicatorSpec) aAnYcst3).eszJ2B0a) / 2.0f;
        this.zDWsfFRp = f13;
        if (z10 || z11) {
            if ((z10 && ((CircularProgressIndicatorSpec) aAnYcst3).ivfTYNl == 2) || (z11 && ((CircularProgressIndicatorSpec) aAnYcst3).osx7Pl0E == 1)) {
                this.zDWsfFRp = f13 + (((1.0f - f10) * ((CircularProgressIndicatorSpec) aAnYcst3).eszJ2B0a) / 2.0f);
            } else if ((z10 && ((CircularProgressIndicatorSpec) aAnYcst3).ivfTYNl == 1) || (z11 && ((CircularProgressIndicatorSpec) aAnYcst3).osx7Pl0E == 2)) {
                this.zDWsfFRp = f13 - (((1.0f - f10) * ((CircularProgressIndicatorSpec) aAnYcst3).eszJ2B0a) / 2.0f);
            }
        }
        if (z11 && ((CircularProgressIndicatorSpec) aAnYcst3).osx7Pl0E == 3) {
            this.osx7Pl0E = f10;
        } else {
            this.osx7Pl0E = 1.0f;
        }
    }

    @Override // jtlqyx5.W7Cnq5
    public int ivfTYNl() {
        return qLLw0g();
    }

    public final void oZ7qYn(Canvas canvas, Paint paint, float f10, float f11, int i10, int i11, int i12) {
        float f12 = f11 >= f10 ? f11 - f10 : (f11 + 1.0f) - f10;
        float f13 = f10 % 1.0f;
        if (this.osx7Pl0E < 1.0f) {
            float f14 = f13 + f12;
            if (f14 > 1.0f) {
                oZ7qYn(canvas, paint, f13, 1.0f, i10, i11, 0);
                oZ7qYn(canvas, paint, 1.0f, f14, i10, 0, i12);
                return;
            }
        }
        float degrees = (float) Math.toDegrees(this.eLbhX59K / this.zDWsfFRp);
        if (f13 == 0.0f && f12 >= 0.99f) {
            f12 += ((f12 - 0.99f) * ((degrees * 2.0f) / 360.0f)) / 0.01f;
        }
        float fZDWsfFRp = xthhf.MY3jR.zDWsfFRp(1.0f - this.osx7Pl0E, 1.0f, f13);
        float fZDWsfFRp2 = xthhf.MY3jR.zDWsfFRp(0.0f, this.osx7Pl0E, f12);
        float degrees2 = (float) Math.toDegrees(i11 / this.zDWsfFRp);
        float degrees3 = ((fZDWsfFRp2 * 360.0f) - degrees2) - ((float) Math.toDegrees(i12 / this.zDWsfFRp));
        float f15 = (fZDWsfFRp * 360.0f) + degrees2;
        if (degrees3 <= 0.0f) {
            return;
        }
        paint.setAntiAlias(true);
        paint.setColor(i10);
        paint.setStrokeWidth(this.aXYSYCVY);
        float f16 = degrees * 2.0f;
        if (degrees3 < f16) {
            float f17 = degrees3 / f16;
            paint.setStyle(Paint.Style.FILL);
            zPJpxWz(canvas, paint, f15 + (degrees * f17), this.eLbhX59K * 2.0f, this.aXYSYCVY, f17);
            return;
        }
        float f18 = this.zDWsfFRp;
        RectF rectF = new RectF(-f18, -f18, f18, f18);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(this.ivfTYNl ? Paint.Cap.ROUND : Paint.Cap.BUTT);
        float f19 = f15 + degrees;
        canvas.drawArc(rectF, f19, degrees3 - f16, false, paint);
        if (this.ivfTYNl || this.eLbhX59K <= 0.0f) {
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        rjljd6i(canvas, paint, f19, this.eLbhX59K * 2.0f, this.aXYSYCVY);
        rjljd6i(canvas, paint, (f15 + degrees3) - degrees, this.eLbhX59K * 2.0f, this.aXYSYCVY);
    }

    @Override // jtlqyx5.W7Cnq5
    public int osx7Pl0E() {
        return qLLw0g();
    }

    public final int qLLw0g() {
        AAnYcst aAnYcst = this.eszJ2B0a;
        return ((CircularProgressIndicatorSpec) aAnYcst).oZ7qYn + (((CircularProgressIndicatorSpec) aAnYcst).rjljd6i * 2);
    }

    public final void rjljd6i(Canvas canvas, Paint paint, float f10, float f11, float f12) {
        zPJpxWz(canvas, paint, f10, f11, f12, 1.0f);
    }

    @Override // jtlqyx5.W7Cnq5
    public void zDWsfFRp(Canvas canvas, Paint paint, float f10, float f11, int i10, int i11, int i12) {
        oZ7qYn(canvas, paint, f10, f11, rhrh7l5.MY3jR.eszJ2B0a(i10, i11), i12, i12);
    }

    public final void zPJpxWz(Canvas canvas, Paint paint, float f10, float f11, float f12, float f13) {
        float fMin = (int) Math.min(f12, this.aXYSYCVY);
        float f14 = f11 / 2.0f;
        float fMin2 = Math.min(f14, (this.eLbhX59K * fMin) / this.aXYSYCVY);
        RectF rectF = new RectF((-fMin) / 2.0f, (-f11) / 2.0f, fMin / 2.0f, f14);
        canvas.save();
        double d10 = f10;
        canvas.translate((float) (((double) this.zDWsfFRp) * Math.cos(Math.toRadians(d10))), (float) (((double) this.zDWsfFRp) * Math.sin(Math.toRadians(d10))));
        canvas.rotate(f10);
        canvas.scale(f13, f13);
        canvas.drawRoundRect(rectF, fMin2, fMin2, paint);
        canvas.restore();
    }

    @Override // jtlqyx5.W7Cnq5
    public void aXYSYCVY(Canvas canvas, Paint paint, int i10, int i11) {
    }
}
