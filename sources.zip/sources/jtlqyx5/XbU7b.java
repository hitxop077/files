package jtlqyx5;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.util.Property;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class XbU7b extends Drawable implements Animatable {
    public static final Property cOkM2 = new RFQ3AA8(Float.class, "growFraction");
    public float ca3iT;
    public List dNE3s;
    public boolean fdmP9GD;
    public j7p73.AAnYcst i2VlO;
    public final Context njNibPNp;
    public float pz7TsV;
    public final jtlqyx5.AAnYcst vo5p9AUA;
    public boolean vskcqLTQ;
    public ValueAnimator xINpNt2d;
    public int xnFvJEz;
    public ValueAnimator zYD7SXW6;
    public boolean zigsCJW;
    public final Paint bBHqyf = new Paint();
    public jtlqyx5.MY3jR gmzPK = new jtlqyx5.MY3jR();

    /* JADX INFO: compiled from: Obfuscated */
    public class AAnYcst extends AnimatorListenerAdapter {
        public AAnYcst() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            XbU7b.super.setVisible(false, false);
            XbU7b.this.ivfTYNl();
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends AnimatorListenerAdapter {
        public MY3jR() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            super.onAnimationStart(animator);
            XbU7b.this.osx7Pl0E();
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class RFQ3AA8 extends Property {
        public RFQ3AA8(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(XbU7b xbU7b, Float f10) {
            xbU7b.uYRSwDm(f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(XbU7b xbU7b) {
            return Float.valueOf(xbU7b.oZ7qYn());
        }
    }

    public XbU7b(Context context, jtlqyx5.AAnYcst aAnYcst) {
        this.njNibPNp = context;
        this.vo5p9AUA = aAnYcst;
        setAlpha(255);
    }

    public final void dUI84(ValueAnimator... valueAnimatorArr) {
        boolean z10 = this.zigsCJW;
        this.zigsCJW = true;
        for (ValueAnimator valueAnimator : valueAnimatorArr) {
            valueAnimator.end();
        }
        this.zigsCJW = z10;
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.xnFvJEz;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    public boolean isRunning() {
        return qLLw0g() || zPJpxWz();
    }

    public final void ivfTYNl() {
        j7p73.AAnYcst aAnYcst = this.i2VlO;
        if (aAnYcst != null) {
            aAnYcst.aXYSYCVY(this);
        }
        List list = this.dNE3s;
        if (list == null || this.zigsCJW) {
            return;
        }
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            ((j7p73.AAnYcst) it2.next()).aXYSYCVY(this);
        }
    }

    public boolean jAM6dcNA(boolean z10, boolean z11, boolean z12) {
        q1ORKN();
        if (!isVisible() && !z10) {
            return false;
        }
        ValueAnimator valueAnimator = z10 ? this.zYD7SXW6 : this.xINpNt2d;
        ValueAnimator valueAnimator2 = z10 ? this.xINpNt2d : this.zYD7SXW6;
        if (!z12) {
            if (valueAnimator2.isRunning()) {
                zDWsfFRp(valueAnimator2);
            }
            if (valueAnimator.isRunning()) {
                valueAnimator.end();
            } else {
                dUI84(valueAnimator);
            }
            return super.setVisible(z10, false);
        }
        if (valueAnimator.isRunning()) {
            return false;
        }
        boolean z13 = !z10 || super.setVisible(z10, false);
        if (!(z10 ? this.vo5p9AUA.aXYSYCVY() : this.vo5p9AUA.eszJ2B0a())) {
            dUI84(valueAnimator);
            return z13;
        }
        if (z11 || !valueAnimator.isPaused()) {
            valueAnimator.start();
            return z13;
        }
        valueAnimator.resume();
        return z13;
    }

    public final void mTWLV(ValueAnimator valueAnimator) {
        ValueAnimator valueAnimator2 = this.zYD7SXW6;
        if (valueAnimator2 != null && valueAnimator2.isRunning()) {
            throw new IllegalArgumentException("Cannot set showAnimator while the current showAnimator is running.");
        }
        this.zYD7SXW6 = valueAnimator;
        valueAnimator.addListener(new MY3jR());
    }

    public float oZ7qYn() {
        if (this.vo5p9AUA.aXYSYCVY() || this.vo5p9AUA.eszJ2B0a()) {
            return (this.vskcqLTQ || this.fdmP9GD) ? this.pz7TsV : this.ca3iT;
        }
        return 1.0f;
    }

    public final void osx7Pl0E() {
        j7p73.AAnYcst aAnYcst = this.i2VlO;
        if (aAnYcst != null) {
            aAnYcst.eLbhX59K(this);
        }
        List list = this.dNE3s;
        if (list == null || this.zigsCJW) {
            return;
        }
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            ((j7p73.AAnYcst) it2.next()).eLbhX59K(this);
        }
    }

    public final void q1ORKN() {
        if (this.zYD7SXW6 == null) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<XbU7b, Float>) cOkM2, 0.0f, 1.0f);
            this.zYD7SXW6 = objectAnimatorOfFloat;
            objectAnimatorOfFloat.setDuration(500L);
            this.zYD7SXW6.setInterpolator(dkax3h0.MY3jR.aXYSYCVY);
            mTWLV(this.zYD7SXW6);
        }
        if (this.xINpNt2d == null) {
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, (Property<XbU7b, Float>) cOkM2, 1.0f, 0.0f);
            this.xINpNt2d = objectAnimatorOfFloat2;
            objectAnimatorOfFloat2.setDuration(500L);
            this.xINpNt2d.setInterpolator(dkax3h0.MY3jR.aXYSYCVY);
            yxejkub(this.xINpNt2d);
        }
    }

    public boolean qLLw0g() {
        ValueAnimator valueAnimator = this.zYD7SXW6;
        return (valueAnimator != null && valueAnimator.isRunning()) || this.fdmP9GD;
    }

    public boolean rJCQt16(boolean z10, boolean z11, boolean z12) {
        return jAM6dcNA(z10, z11, z12 && this.gmzPK.eszJ2B0a(this.njNibPNp.getContentResolver()) > 0.0f);
    }

    public boolean rjljd6i() {
        return rJCQt16(false, false, false);
    }

    public boolean rtsRj(j7p73.AAnYcst aAnYcst) {
        List list = this.dNE3s;
        if (list == null || !list.contains(aAnYcst)) {
            return false;
        }
        this.dNE3s.remove(aAnYcst);
        if (!this.dNE3s.isEmpty()) {
            return true;
        }
        this.dNE3s = null;
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i10) {
        this.xnFvJEz = i10;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.bBHqyf.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z10, boolean z11) {
        return rJCQt16(z10, z11, true);
    }

    public void start() {
        jAM6dcNA(true, true, false);
    }

    public void stop() {
        jAM6dcNA(false, true, false);
    }

    public void uTIfLNK0(j7p73.AAnYcst aAnYcst) {
        if (this.dNE3s == null) {
            this.dNE3s = new ArrayList();
        }
        if (this.dNE3s.contains(aAnYcst)) {
            return;
        }
        this.dNE3s.add(aAnYcst);
    }

    public void uYRSwDm(float f10) {
        if (this.ca3iT != f10) {
            this.ca3iT = f10;
            invalidateSelf();
        }
    }

    public final void yxejkub(ValueAnimator valueAnimator) {
        ValueAnimator valueAnimator2 = this.xINpNt2d;
        if (valueAnimator2 != null && valueAnimator2.isRunning()) {
            throw new IllegalArgumentException("Cannot set hideAnimator while the current hideAnimator is running.");
        }
        this.xINpNt2d = valueAnimator;
        valueAnimator.addListener(new AAnYcst());
    }

    public final void zDWsfFRp(ValueAnimator... valueAnimatorArr) {
        boolean z10 = this.zigsCJW;
        this.zigsCJW = true;
        for (ValueAnimator valueAnimator : valueAnimatorArr) {
            valueAnimator.cancel();
        }
        this.zigsCJW = z10;
    }

    public boolean zPJpxWz() {
        ValueAnimator valueAnimator = this.xINpNt2d;
        return (valueAnimator != null && valueAnimator.isRunning()) || this.vskcqLTQ;
    }
}
