package jtlqyx5;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.util.Property;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import net.one97.storefront.utils.ViewHolderFactory;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class LNd998w extends GU39Hcg {
    public int dUI84;
    public ObjectAnimator eLbhX59K;
    public final u59z72tu.AAnYcst ivfTYNl;
    public float oZ7qYn;
    public final jtlqyx5.AAnYcst osx7Pl0E;
    public float rjljd6i;
    public ObjectAnimator zDWsfFRp;
    public j7p73.AAnYcst zPJpxWz;
    public static final int[] qLLw0g = {0, ViewHolderFactory.CAROUSEL_VIDEO_ITEM, 2700, 4050};
    public static final int[] q1ORKN = {667, 2017, 3367, 4717};
    public static final int[] uTIfLNK0 = {1000, 2350, 3700, 5050};
    public static final Property uYRSwDm = new RFQ3AA8(Float.class, "animationFraction");
    public static final Property yxejkub = new C1483LNd998w(Float.class, "completeEndFraction");

    /* JADX INFO: compiled from: Obfuscated */
    public class AAnYcst extends AnimatorListenerAdapter {
        public AAnYcst() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            LNd998w.this.eszJ2B0a();
            LNd998w lNd998w = LNd998w.this;
            j7p73.AAnYcst aAnYcst = lNd998w.zPJpxWz;
            if (aAnYcst != null) {
                aAnYcst.aXYSYCVY(lNd998w.eszJ2B0a);
            }
        }
    }

    /* JADX INFO: renamed from: jtlqyx5.LNd998w$LNd998w, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public class C1483LNd998w extends Property {
        public C1483LNd998w(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(LNd998w lNd998w, Float f10) {
            lNd998w.n84TFkA9(f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(LNd998w lNd998w) {
            return Float.valueOf(lNd998w.mTWLV());
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends AnimatorListenerAdapter {
        public MY3jR() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
            super.onAnimationRepeat(animator);
            LNd998w lNd998w = LNd998w.this;
            lNd998w.dUI84 = (lNd998w.dUI84 + 4) % LNd998w.this.osx7Pl0E.eLbhX59K.length;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class RFQ3AA8 extends Property {
        public RFQ3AA8(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(LNd998w lNd998w, Float f10) {
            lNd998w.oyaOvpOs(f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(LNd998w lNd998w) {
            return Float.valueOf(lNd998w.yxejkub());
        }
    }

    public LNd998w(CircularProgressIndicatorSpec circularProgressIndicatorSpec) {
        super(1);
        this.dUI84 = 0;
        this.zPJpxWz = null;
        this.osx7Pl0E = circularProgressIndicatorSpec;
        this.ivfTYNl = new u59z72tu.AAnYcst();
    }

    public final void bsO5Vo(int i10) {
        W7Cnq5.MY3jR mY3jR = (W7Cnq5.MY3jR) this.aXYSYCVY.get(0);
        float f10 = this.oZ7qYn;
        mY3jR.eszJ2B0a = (f10 * 1520.0f) - 20.0f;
        mY3jR.aXYSYCVY = f10 * 1520.0f;
        for (int i11 = 0; i11 < 4; i11++) {
            mY3jR.aXYSYCVY += this.ivfTYNl.getInterpolation(aXYSYCVY(i10, qLLw0g[i11], 667)) * 250.0f;
            mY3jR.eszJ2B0a += this.ivfTYNl.getInterpolation(aXYSYCVY(i10, q1ORKN[i11], 667)) * 250.0f;
        }
        float f11 = mY3jR.eszJ2B0a;
        float f12 = mY3jR.aXYSYCVY;
        mY3jR.eszJ2B0a = (f11 + ((f12 - f11) * this.rjljd6i)) / 360.0f;
        mY3jR.aXYSYCVY = f12 / 360.0f;
    }

    @Override // jtlqyx5.GU39Hcg
    public void dUI84() {
        rJCQt16();
        rtsRj();
        this.eLbhX59K.start();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eLbhX59K() {
        rtsRj();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eszJ2B0a() {
        ObjectAnimator objectAnimator = this.eLbhX59K;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public final void jAM6dcNA(int i10) {
        for (int i11 = 0; i11 < 4; i11++) {
            float fAXYSYCVY = aXYSYCVY(i10, uTIfLNK0[i11], 333);
            if (fAXYSYCVY >= 0.0f && fAXYSYCVY <= 1.0f) {
                int i12 = i11 + this.dUI84;
                int[] iArr = this.osx7Pl0E.eLbhX59K;
                int length = i12 % iArr.length;
                int length2 = (length + 1) % iArr.length;
                int i13 = iArr[length];
                int i14 = iArr[length2];
                ((W7Cnq5.MY3jR) this.aXYSYCVY.get(0)).eLbhX59K = dkax3h0.RFQ3AA8.aXYSYCVY().evaluate(this.ivfTYNl.getInterpolation(fAXYSYCVY), Integer.valueOf(i13), Integer.valueOf(i14)).intValue();
                return;
            }
        }
    }

    public final float mTWLV() {
        return this.rjljd6i;
    }

    public final void n84TFkA9(float f10) {
        this.rjljd6i = f10;
    }

    @Override // jtlqyx5.GU39Hcg
    public void oZ7qYn() {
        this.zPJpxWz = null;
    }

    @Override // jtlqyx5.GU39Hcg
    public void osx7Pl0E() {
        ObjectAnimator objectAnimator = this.zDWsfFRp;
        if (objectAnimator == null || objectAnimator.isRunning()) {
            return;
        }
        if (this.eszJ2B0a.isVisible()) {
            this.zDWsfFRp.start();
        } else {
            eszJ2B0a();
        }
    }

    public void oyaOvpOs(float f10) {
        this.oZ7qYn = f10;
        int i10 = (int) (f10 * 5400.0f);
        bsO5Vo(i10);
        jAM6dcNA(i10);
        this.eszJ2B0a.invalidateSelf();
    }

    public final void rJCQt16() {
        if (this.eLbhX59K == null) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<LNd998w, Float>) uYRSwDm, 0.0f, 1.0f);
            this.eLbhX59K = objectAnimatorOfFloat;
            objectAnimatorOfFloat.setDuration(5400L);
            this.eLbhX59K.setInterpolator(null);
            this.eLbhX59K.setRepeatCount(-1);
            this.eLbhX59K.addListener(new MY3jR());
        }
        if (this.zDWsfFRp == null) {
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, (Property<LNd998w, Float>) yxejkub, 0.0f, 1.0f);
            this.zDWsfFRp = objectAnimatorOfFloat2;
            objectAnimatorOfFloat2.setDuration(333L);
            this.zDWsfFRp.setInterpolator(this.ivfTYNl);
            this.zDWsfFRp.addListener(new AAnYcst());
        }
    }

    public void rtsRj() {
        this.dUI84 = 0;
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(0)).eLbhX59K = this.osx7Pl0E.eLbhX59K[0];
        this.rjljd6i = 0.0f;
    }

    public final float yxejkub() {
        return this.oZ7qYn;
    }

    @Override // jtlqyx5.GU39Hcg
    public void zDWsfFRp(j7p73.AAnYcst aAnYcst) {
        this.zPJpxWz = aAnYcst;
    }
}
