package jtlqyx5;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.util.Property;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Lx1jI extends GU39Hcg {
    public static final Property rjljd6i = new AAnYcst(Float.class, "animationFraction");
    public boolean dUI84;
    public ObjectAnimator eLbhX59K;
    public final jtlqyx5.AAnYcst ivfTYNl;
    public float oZ7qYn;
    public int osx7Pl0E;
    public u59z72tu.AAnYcst zDWsfFRp;

    /* JADX INFO: compiled from: Obfuscated */
    public class AAnYcst extends Property {
        public AAnYcst(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(Lx1jI lx1jI, Float f10) {
            lx1jI.jAM6dcNA(f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(Lx1jI lx1jI) {
            return Float.valueOf(lx1jI.uYRSwDm());
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends AnimatorListenerAdapter {
        public MY3jR() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
            super.onAnimationRepeat(animator);
            Lx1jI lx1jI = Lx1jI.this;
            lx1jI.osx7Pl0E = (lx1jI.osx7Pl0E + 1) % Lx1jI.this.ivfTYNl.eLbhX59K.length;
            Lx1jI.this.dUI84 = true;
        }
    }

    public Lx1jI(LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(3);
        this.osx7Pl0E = 1;
        this.ivfTYNl = linearProgressIndicatorSpec;
        this.zDWsfFRp = new u59z72tu.AAnYcst();
    }

    private void rtsRj(int i10) {
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(0)).eszJ2B0a = 0.0f;
        float fAXYSYCVY = aXYSYCVY(i10, 0, 667);
        W7Cnq5.MY3jR mY3jR = (W7Cnq5.MY3jR) this.aXYSYCVY.get(0);
        W7Cnq5.MY3jR mY3jR2 = (W7Cnq5.MY3jR) this.aXYSYCVY.get(1);
        float interpolation = this.zDWsfFRp.getInterpolation(fAXYSYCVY);
        mY3jR2.eszJ2B0a = interpolation;
        mY3jR.aXYSYCVY = interpolation;
        W7Cnq5.MY3jR mY3jR3 = (W7Cnq5.MY3jR) this.aXYSYCVY.get(1);
        W7Cnq5.MY3jR mY3jR4 = (W7Cnq5.MY3jR) this.aXYSYCVY.get(2);
        float interpolation2 = this.zDWsfFRp.getInterpolation(fAXYSYCVY + 0.49925038f);
        mY3jR4.eszJ2B0a = interpolation2;
        mY3jR3.aXYSYCVY = interpolation2;
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(2)).aXYSYCVY = 1.0f;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float uYRSwDm() {
        return this.oZ7qYn;
    }

    private void yxejkub() {
        if (this.eLbhX59K == null) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<Lx1jI, Float>) rjljd6i, 0.0f, 1.0f);
            this.eLbhX59K = objectAnimatorOfFloat;
            objectAnimatorOfFloat.setDuration(333L);
            this.eLbhX59K.setInterpolator(null);
            this.eLbhX59K.setRepeatCount(-1);
            this.eLbhX59K.addListener(new MY3jR());
        }
    }

    @Override // jtlqyx5.GU39Hcg
    public void dUI84() {
        yxejkub();
        rJCQt16();
        this.eLbhX59K.start();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eLbhX59K() {
        rJCQt16();
    }

    @Override // jtlqyx5.GU39Hcg
    public void eszJ2B0a() {
        ObjectAnimator objectAnimator = this.eLbhX59K;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    public void jAM6dcNA(float f10) {
        this.oZ7qYn = f10;
        rtsRj((int) (f10 * 333.0f));
        mTWLV();
        this.eszJ2B0a.invalidateSelf();
    }

    public final void mTWLV() {
        if (!this.dUI84 || ((W7Cnq5.MY3jR) this.aXYSYCVY.get(1)).aXYSYCVY >= 1.0f) {
            return;
        }
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(2)).eLbhX59K = ((W7Cnq5.MY3jR) this.aXYSYCVY.get(1)).eLbhX59K;
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(1)).eLbhX59K = ((W7Cnq5.MY3jR) this.aXYSYCVY.get(0)).eLbhX59K;
        ((W7Cnq5.MY3jR) this.aXYSYCVY.get(0)).eLbhX59K = this.ivfTYNl.eLbhX59K[this.osx7Pl0E];
        this.dUI84 = false;
    }

    public void rJCQt16() {
        this.dUI84 = true;
        this.osx7Pl0E = 1;
        for (W7Cnq5.MY3jR mY3jR : this.aXYSYCVY) {
            jtlqyx5.AAnYcst aAnYcst = this.ivfTYNl;
            mY3jR.eLbhX59K = aAnYcst.eLbhX59K[0];
            mY3jR.zDWsfFRp = aAnYcst.dUI84 / 2;
        }
    }

    @Override // jtlqyx5.GU39Hcg
    public void oZ7qYn() {
    }

    @Override // jtlqyx5.GU39Hcg
    public void osx7Pl0E() {
    }

    @Override // jtlqyx5.GU39Hcg
    public void zDWsfFRp(j7p73.AAnYcst aAnYcst) {
    }
}
