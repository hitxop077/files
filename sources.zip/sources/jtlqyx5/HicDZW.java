package jtlqyx5;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import com.google.android.material.progressindicator.CircularProgressIndicatorSpec;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class HicDZW extends XbU7b {
    public Drawable lw3QOa;
    public W7Cnq5 sRtu3PUY;
    public GU39Hcg ytgMq;

    public HicDZW(Context context, AAnYcst aAnYcst, W7Cnq5 w7Cnq5, GU39Hcg gU39Hcg) {
        super(context, aAnYcst);
        mK94T(w7Cnq5);
        eImdmIyv(gU39Hcg);
    }

    public static HicDZW n84TFkA9(Context context, LinearProgressIndicatorSpec linearProgressIndicatorSpec, JQAVH jqavh) {
        return new HicDZW(context, linearProgressIndicatorSpec, jqavh, linearProgressIndicatorSpec.oZ7qYn == 0 ? new Lx1jI(linearProgressIndicatorSpec) : new Bv3FS(context, linearProgressIndicatorSpec));
    }

    public static HicDZW oyaOvpOs(Context context, CircularProgressIndicatorSpec circularProgressIndicatorSpec, RFQ3AA8 rfq3aa8) {
        HicDZW hicDZW = new HicDZW(context, circularProgressIndicatorSpec, rfq3aa8, new LNd998w(circularProgressIndicatorSpec));
        hicDZW.eTQUrp(j7p73.W7Cnq5.aXYSYCVY(context.getResources(), g13xi.XbU7b.indeterminate_static, null));
        return hicDZW;
    }

    public GU39Hcg bsO5Vo() {
        return this.ytgMq;
    }

    public final boolean c1pvtY() {
        MY3jR mY3jR = this.gmzPK;
        return mY3jR != null && mY3jR.eszJ2B0a(this.njNibPNp.getContentResolver()) == 0.0f;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        int i10;
        Drawable drawable;
        Rect rect = new Rect();
        if (!getBounds().isEmpty() && isVisible() && canvas.getClipBounds(rect)) {
            if (c1pvtY() && (drawable = this.lw3QOa) != null) {
                drawable.setBounds(getBounds());
                kvnq9ju.MY3jR.uYRSwDm(this.lw3QOa, this.vo5p9AUA.eLbhX59K[0]);
                this.lw3QOa.draw(canvas);
                return;
            }
            canvas.save();
            this.sRtu3PUY.dUI84(canvas, getBounds(), oZ7qYn(), qLLw0g(), zPJpxWz());
            int i11 = this.vo5p9AUA.dUI84;
            int alpha = getAlpha();
            if (i11 == 0) {
                this.sRtu3PUY.zDWsfFRp(canvas, this.bBHqyf, 0.0f, 1.0f, this.vo5p9AUA.zDWsfFRp, alpha, 0);
                i10 = i11;
            } else {
                W7Cnq5.MY3jR mY3jR = (W7Cnq5.MY3jR) this.ytgMq.aXYSYCVY.get(0);
                List list = this.ytgMq.aXYSYCVY;
                W7Cnq5.MY3jR mY3jR2 = (W7Cnq5.MY3jR) list.get(list.size() - 1);
                W7Cnq5 w7Cnq5 = this.sRtu3PUY;
                if (w7Cnq5 instanceof JQAVH) {
                    i10 = i11;
                    w7Cnq5.zDWsfFRp(canvas, this.bBHqyf, 0.0f, mY3jR.eszJ2B0a, this.vo5p9AUA.zDWsfFRp, alpha, i10);
                    this.sRtu3PUY.zDWsfFRp(canvas, this.bBHqyf, mY3jR2.aXYSYCVY, 1.0f, this.vo5p9AUA.zDWsfFRp, alpha, i10);
                } else {
                    i10 = i11;
                    alpha = 0;
                    w7Cnq5.zDWsfFRp(canvas, this.bBHqyf, mY3jR2.aXYSYCVY, 1.0f + mY3jR.eszJ2B0a, this.vo5p9AUA.zDWsfFRp, 0, i10);
                }
            }
            for (int i12 = 0; i12 < this.ytgMq.aXYSYCVY.size(); i12++) {
                W7Cnq5.MY3jR mY3jR3 = (W7Cnq5.MY3jR) this.ytgMq.aXYSYCVY.get(i12);
                this.sRtu3PUY.eLbhX59K(canvas, this.bBHqyf, mY3jR3, getAlpha());
                if (i12 > 0 && i10 > 0) {
                    this.sRtu3PUY.zDWsfFRp(canvas, this.bBHqyf, ((W7Cnq5.MY3jR) this.ytgMq.aXYSYCVY.get(i12 - 1)).aXYSYCVY, mY3jR3.eszJ2B0a, this.vo5p9AUA.zDWsfFRp, alpha, i10);
                }
            }
            canvas.restore();
        }
    }

    public void eImdmIyv(GU39Hcg gU39Hcg) {
        this.ytgMq = gU39Hcg;
        gU39Hcg.ivfTYNl(this);
    }

    public void eTQUrp(Drawable drawable) {
        this.lw3QOa = drawable;
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getAlpha() {
        return super.getAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return this.sRtu3PUY.ivfTYNl();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return this.sRtu3PUY.osx7Pl0E();
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getOpacity() {
        return super.getOpacity();
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Animatable
    public /* bridge */ /* synthetic */ boolean isRunning() {
        return super.isRunning();
    }

    @Override // jtlqyx5.XbU7b
    public boolean jAM6dcNA(boolean z10, boolean z11, boolean z12) {
        Drawable drawable;
        boolean zJAM6dcNA = super.jAM6dcNA(z10, z11, z12);
        if (c1pvtY() && (drawable = this.lw3QOa) != null) {
            return drawable.setVisible(z10, z11);
        }
        if (!isRunning()) {
            this.ytgMq.eszJ2B0a();
        }
        if (!z10 || !z12) {
            return zJAM6dcNA;
        }
        this.ytgMq.dUI84();
        return zJAM6dcNA;
    }

    public void mK94T(W7Cnq5 w7Cnq5) {
        this.sRtu3PUY = w7Cnq5;
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ boolean qLLw0g() {
        return super.qLLw0g();
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ boolean rJCQt16(boolean z10, boolean z11, boolean z12) {
        return super.rJCQt16(z10, z11, z12);
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ boolean rjljd6i() {
        return super.rjljd6i();
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ boolean rtsRj(j7p73.AAnYcst aAnYcst) {
        return super.rtsRj(aAnYcst);
    }

    public W7Cnq5 sMxPLer() {
        return this.sRtu3PUY;
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setAlpha(int i10) {
        super.setAlpha(i10);
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setColorFilter(ColorFilter colorFilter) {
        super.setColorFilter(colorFilter);
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean setVisible(boolean z10, boolean z11) {
        return super.setVisible(z10, z11);
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Animatable
    public /* bridge */ /* synthetic */ void start() {
        super.start();
    }

    @Override // jtlqyx5.XbU7b, android.graphics.drawable.Animatable
    public /* bridge */ /* synthetic */ void stop() {
        super.stop();
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ void uTIfLNK0(j7p73.AAnYcst aAnYcst) {
        super.uTIfLNK0(aAnYcst);
    }

    @Override // jtlqyx5.XbU7b
    public /* bridge */ /* synthetic */ boolean zPJpxWz() {
        return super.zPJpxWz();
    }
}
