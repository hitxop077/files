package jtlqyx5;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class GU39Hcg {
    public final List aXYSYCVY = new ArrayList();
    public HicDZW eszJ2B0a;

    public GU39Hcg(int i10) {
        for (int i11 = 0; i11 < i10; i11++) {
            this.aXYSYCVY.add(new W7Cnq5.MY3jR());
        }
    }

    public float aXYSYCVY(int i10, int i11, int i12) {
        return (i10 - i11) / i12;
    }

    public abstract void dUI84();

    public abstract void eLbhX59K();

    public abstract void eszJ2B0a();

    public void ivfTYNl(HicDZW hicDZW) {
        this.eszJ2B0a = hicDZW;
    }

    public abstract void oZ7qYn();

    public abstract void osx7Pl0E();

    public abstract void zDWsfFRp(j7p73.AAnYcst aAnYcst);
}
