package jtlqyx5;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import com.google.android.material.internal.IMpOqqn;
import g13xi.VVpVRy;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class AAnYcst {
    public int aXYSYCVY;
    public int dUI84;
    public int[] eLbhX59K = new int[0];
    public int eszJ2B0a;
    public int ivfTYNl;
    public int osx7Pl0E;
    public int zDWsfFRp;

    public AAnYcst(Context context, AttributeSet attributeSet, int i10, int i11) {
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(g13xi.N1vNRFSd.mtrl_progress_track_thickness);
        TypedArray typedArrayRjljd6i = IMpOqqn.rjljd6i(context, attributeSet, VVpVRy.BaseProgressIndicator, i10, i11, new int[0]);
        this.eszJ2B0a = qphrm.RFQ3AA8.zDWsfFRp(context, typedArrayRjljd6i, VVpVRy.BaseProgressIndicator_trackThickness, dimensionPixelSize);
        this.aXYSYCVY = Math.min(qphrm.RFQ3AA8.zDWsfFRp(context, typedArrayRjljd6i, VVpVRy.BaseProgressIndicator_trackCornerRadius, 0), this.eszJ2B0a / 2);
        this.ivfTYNl = typedArrayRjljd6i.getInt(VVpVRy.BaseProgressIndicator_showAnimationBehavior, 0);
        this.osx7Pl0E = typedArrayRjljd6i.getInt(VVpVRy.BaseProgressIndicator_hideAnimationBehavior, 0);
        this.dUI84 = typedArrayRjljd6i.getDimensionPixelSize(VVpVRy.BaseProgressIndicator_indicatorTrackGapSize, 0);
        eLbhX59K(context, typedArrayRjljd6i);
        zDWsfFRp(context, typedArrayRjljd6i);
        typedArrayRjljd6i.recycle();
    }

    public boolean aXYSYCVY() {
        return this.ivfTYNl != 0;
    }

    public final void eLbhX59K(Context context, TypedArray typedArray) {
        int i10 = VVpVRy.BaseProgressIndicator_indicatorColor;
        if (!typedArray.hasValue(i10)) {
            this.eLbhX59K = new int[]{rhrh7l5.MY3jR.aXYSYCVY(context, g13xi.RFQ3AA8.colorPrimary, -1)};
            return;
        }
        if (typedArray.peekValue(i10).type != 1) {
            this.eLbhX59K = new int[]{typedArray.getColor(i10, -1)};
            return;
        }
        int[] intArray = context.getResources().getIntArray(typedArray.getResourceId(i10, -1));
        this.eLbhX59K = intArray;
        if (intArray.length == 0) {
            throw new IllegalArgumentException("indicatorColors cannot be empty when indicatorColor is not used.");
        }
    }

    public boolean eszJ2B0a() {
        return this.osx7Pl0E != 0;
    }

    public void ivfTYNl() {
        if (this.dUI84 < 0) {
            throw new IllegalArgumentException("indicatorTrackGapSize must be >= 0.");
        }
    }

    public final void zDWsfFRp(Context context, TypedArray typedArray) {
        int i10 = VVpVRy.BaseProgressIndicator_trackColor;
        if (typedArray.hasValue(i10)) {
            this.zDWsfFRp = typedArray.getColor(i10, -1);
            return;
        }
        this.zDWsfFRp = this.eLbhX59K[0];
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(new int[]{R.attr.disabledAlpha});
        float f10 = typedArrayObtainStyledAttributes.getFloat(0, 0.2f);
        typedArrayObtainStyledAttributes.recycle();
        this.zDWsfFRp = rhrh7l5.MY3jR.eszJ2B0a(this.zDWsfFRp, (int) (f10 * 255.0f));
    }
}
