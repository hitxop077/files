package jtlqyx5;

import android.content.ContentResolver;
import android.provider.Settings;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class MY3jR {
    public float eszJ2B0a(ContentResolver contentResolver) {
        return Settings.Global.getFloat(contentResolver, "animator_duration_scale", 1.0f);
    }
}
