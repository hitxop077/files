package jtlqyx5;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import com.google.android.material.progressindicator.LinearProgressIndicatorSpec;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class JQAVH extends W7Cnq5 {
    public float aXYSYCVY;
    public float eLbhX59K;
    public boolean ivfTYNl;
    public float osx7Pl0E;
    public float zDWsfFRp;

    public JQAVH(LinearProgressIndicatorSpec linearProgressIndicatorSpec) {
        super(linearProgressIndicatorSpec);
        this.aXYSYCVY = 300.0f;
    }

    @Override // jtlqyx5.W7Cnq5
    public void aXYSYCVY(Canvas canvas, Paint paint, int i10, int i11) {
        int iEszJ2B0a = rhrh7l5.MY3jR.eszJ2B0a(i10, i11);
        if (((LinearProgressIndicatorSpec) this.eszJ2B0a).qLLw0g <= 0 || iEszJ2B0a == 0) {
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(iEszJ2B0a);
        PointF pointF = new PointF((this.aXYSYCVY / 2.0f) - (this.eLbhX59K / 2.0f), 0.0f);
        AAnYcst aAnYcst = this.eszJ2B0a;
        rjljd6i(canvas, paint, pointF, ((LinearProgressIndicatorSpec) aAnYcst).qLLw0g, ((LinearProgressIndicatorSpec) aAnYcst).qLLw0g);
    }

    @Override // jtlqyx5.W7Cnq5
    public void eLbhX59K(Canvas canvas, Paint paint, W7Cnq5.MY3jR mY3jR, int i10) {
        int iEszJ2B0a = rhrh7l5.MY3jR.eszJ2B0a(mY3jR.eLbhX59K, i10);
        float f10 = mY3jR.eszJ2B0a;
        float f11 = mY3jR.aXYSYCVY;
        int i11 = mY3jR.zDWsfFRp;
        oZ7qYn(canvas, paint, f10, f11, iEszJ2B0a, i11, i11);
    }

    @Override // jtlqyx5.W7Cnq5
    public void eszJ2B0a(Canvas canvas, Rect rect, float f10, boolean z10, boolean z11) {
        this.aXYSYCVY = rect.width();
        float f11 = ((LinearProgressIndicatorSpec) this.eszJ2B0a).eszJ2B0a;
        canvas.translate(rect.left + (rect.width() / 2.0f), rect.top + (rect.height() / 2.0f) + Math.max(0.0f, (rect.height() - f11) / 2.0f));
        if (((LinearProgressIndicatorSpec) this.eszJ2B0a).zPJpxWz) {
            canvas.scale(-1.0f, 1.0f);
        }
        float f12 = this.aXYSYCVY / 2.0f;
        float f13 = f11 / 2.0f;
        canvas.clipRect(-f12, -f13, f12, f13);
        AAnYcst aAnYcst = this.eszJ2B0a;
        this.ivfTYNl = ((LinearProgressIndicatorSpec) aAnYcst).eszJ2B0a / 2 == ((LinearProgressIndicatorSpec) aAnYcst).aXYSYCVY;
        this.eLbhX59K = ((LinearProgressIndicatorSpec) aAnYcst).eszJ2B0a * f10;
        this.zDWsfFRp = Math.min(((LinearProgressIndicatorSpec) aAnYcst).eszJ2B0a / 2, ((LinearProgressIndicatorSpec) aAnYcst).aXYSYCVY) * f10;
        if (z10 || z11) {
            if ((z10 && ((LinearProgressIndicatorSpec) this.eszJ2B0a).ivfTYNl == 2) || (z11 && ((LinearProgressIndicatorSpec) this.eszJ2B0a).osx7Pl0E == 1)) {
                canvas.scale(1.0f, -1.0f);
            }
            if (z10 || (z11 && ((LinearProgressIndicatorSpec) this.eszJ2B0a).osx7Pl0E != 3)) {
                canvas.translate(0.0f, (((LinearProgressIndicatorSpec) this.eszJ2B0a).eszJ2B0a * (1.0f - f10)) / 2.0f);
            }
        }
        if (z11 && ((LinearProgressIndicatorSpec) this.eszJ2B0a).osx7Pl0E == 3) {
            this.osx7Pl0E = f10;
        } else {
            this.osx7Pl0E = 1.0f;
        }
    }

    @Override // jtlqyx5.W7Cnq5
    public int ivfTYNl() {
        return ((LinearProgressIndicatorSpec) this.eszJ2B0a).eszJ2B0a;
    }

    public final void oZ7qYn(Canvas canvas, Paint paint, float f10, float f11, int i10, int i11, int i12) {
        float f12;
        float fAXYSYCVY = znp7wap.MY3jR.aXYSYCVY(f10, 0.0f, 1.0f);
        float fAXYSYCVY2 = znp7wap.MY3jR.aXYSYCVY(f11, 0.0f, 1.0f);
        float fZDWsfFRp = xthhf.MY3jR.zDWsfFRp(1.0f - this.osx7Pl0E, 1.0f, fAXYSYCVY);
        float fZDWsfFRp2 = xthhf.MY3jR.zDWsfFRp(1.0f - this.osx7Pl0E, 1.0f, fAXYSYCVY2);
        int iAXYSYCVY = (int) ((i11 * znp7wap.MY3jR.aXYSYCVY(fZDWsfFRp, 0.0f, 0.01f)) / 0.01f);
        int iAXYSYCVY2 = (int) ((i12 * (1.0f - znp7wap.MY3jR.aXYSYCVY(fZDWsfFRp2, 0.99f, 1.0f))) / 0.01f);
        float f13 = this.aXYSYCVY;
        int i13 = (int) ((fZDWsfFRp * f13) + iAXYSYCVY);
        int i14 = (int) ((fZDWsfFRp2 * f13) - iAXYSYCVY2);
        float f14 = (-f13) / 2.0f;
        if (i13 <= i14) {
            float f15 = this.zDWsfFRp;
            float f16 = i13 + f15;
            float f17 = i14 - f15;
            float f18 = f15 * 2.0f;
            paint.setColor(i10);
            paint.setAntiAlias(true);
            paint.setStrokeWidth(this.eLbhX59K);
            if (f16 >= f17) {
                zPJpxWz(canvas, paint, new PointF(f16 + f14, 0.0f), new PointF(f17 + f14, 0.0f), f18, this.eLbhX59K);
                return;
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(this.ivfTYNl ? Paint.Cap.ROUND : Paint.Cap.BUTT);
            float f19 = f16 + f14;
            float f20 = f17 + f14;
            canvas.drawLine(f19, 0.0f, f20, 0.0f, paint);
            if (this.ivfTYNl || this.zDWsfFRp <= 0.0f) {
                return;
            }
            paint.setStyle(Paint.Style.FILL);
            if (f16 > 0.0f) {
                f12 = f18;
                rjljd6i(canvas, paint, new PointF(f19, 0.0f), f12, this.eLbhX59K);
            } else {
                f12 = f18;
            }
            if (f17 < this.aXYSYCVY) {
                rjljd6i(canvas, paint, new PointF(f20, 0.0f), f12, this.eLbhX59K);
            }
        }
    }

    @Override // jtlqyx5.W7Cnq5
    public int osx7Pl0E() {
        return -1;
    }

    public final void rjljd6i(Canvas canvas, Paint paint, PointF pointF, float f10, float f11) {
        zPJpxWz(canvas, paint, pointF, null, f10, f11);
    }

    @Override // jtlqyx5.W7Cnq5
    public void zDWsfFRp(Canvas canvas, Paint paint, float f10, float f11, int i10, int i11, int i12) {
        oZ7qYn(canvas, paint, f10, f11, rhrh7l5.MY3jR.eszJ2B0a(i10, i11), i12, i12);
    }

    public final void zPJpxWz(Canvas canvas, Paint paint, PointF pointF, PointF pointF2, float f10, float f11) {
        float fMin = Math.min(f11, this.eLbhX59K);
        float f12 = f10 / 2.0f;
        float fMin2 = Math.min(f12, (this.zDWsfFRp * fMin) / this.eLbhX59K);
        RectF rectF = new RectF((-f10) / 2.0f, (-fMin) / 2.0f, f12, fMin / 2.0f);
        paint.setStyle(Paint.Style.FILL);
        canvas.save();
        if (pointF2 != null) {
            canvas.translate(pointF2.x, pointF2.y);
            Path path = new Path();
            path.addRoundRect(rectF, fMin2, fMin2, Path.Direction.CCW);
            canvas.clipPath(path);
            canvas.translate(-pointF2.x, -pointF2.y);
        }
        canvas.translate(pointF.x, pointF.y);
        canvas.drawRoundRect(rectF, fMin2, fMin2, paint);
        canvas.restore();
    }
}
