package j55dy3h5;

import android.content.Context;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public interface MY3jR {
    void aXYSYCVY(wodoxfe.MY3jR mY3jR);

    void eszJ2B0a(Context context, Executor executor, wodoxfe.MY3jR mY3jR);
}
