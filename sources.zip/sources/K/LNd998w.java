package K;

import I.GU39Hcg;
import I.W7Cnq5;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import p497q7.SFMiYa;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class LNd998w implements J.AAnYcst {
    public static final I.N1vNRFSd ivfTYNl = new I.N1vNRFSd() { // from class: K.MY3jR
        @Override // I.AAnYcst
        public final void eszJ2B0a(Object obj, Object obj2) {
            LNd998w.eLbhX59K(obj, (I.XbU7b) obj2);
        }
    };
    public static final W7Cnq5 osx7Pl0E = new W7Cnq5() { // from class: K.AAnYcst
        @Override // I.AAnYcst
        public final void eszJ2B0a(Object obj, Object obj2) {
            ((GU39Hcg) obj2).add((String) obj);
        }
    };
    public static final W7Cnq5 dUI84 = new W7Cnq5() { // from class: K.RFQ3AA8
        @Override // I.AAnYcst
        public final void eszJ2B0a(Object obj, Object obj2) {
            ((GU39Hcg) obj2).osx7Pl0E(((Boolean) obj).booleanValue());
        }
    };
    public static final AAnYcst oZ7qYn = new AAnYcst(null);
    public final Map eszJ2B0a = new HashMap();
    public final Map aXYSYCVY = new HashMap();
    public I.N1vNRFSd eLbhX59K = ivfTYNl;
    public boolean zDWsfFRp = false;

    /* JADX INFO: compiled from: Obfuscated */
    public static final class AAnYcst implements W7Cnq5 {
        public static final DateFormat eszJ2B0a;

        static {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            eszJ2B0a = simpleDateFormat;
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(SFMiYa.ORDER_SUMMARY_TIME_ZONE_FORMAT));
        }

        public AAnYcst() {
        }

        @Override // I.AAnYcst
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void eszJ2B0a(Date date, GU39Hcg gU39Hcg) {
            gU39Hcg.add(eszJ2B0a.format(date));
        }

        public /* synthetic */ AAnYcst(MY3jR mY3jR) {
            this();
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR implements I.MY3jR {
        public MY3jR() {
        }

        @Override // I.MY3jR
        public String aXYSYCVY(Object obj) {
            StringWriter stringWriter = new StringWriter();
            try {
                eszJ2B0a(obj, stringWriter);
            } catch (IOException unused) {
            }
            return stringWriter.toString();
        }

        @Override // I.MY3jR
        public void eszJ2B0a(Object obj, Writer writer) {
            N1vNRFSd n1vNRFSd = new N1vNRFSd(writer, LNd998w.this.eszJ2B0a, LNd998w.this.aXYSYCVY, LNd998w.this.eLbhX59K, LNd998w.this.zDWsfFRp);
            n1vNRFSd.zPJpxWz(obj, false);
            n1vNRFSd.oyaOvpOs();
        }
    }

    public LNd998w() {
        uTIfLNK0(String.class, osx7Pl0E);
        uTIfLNK0(Boolean.class, dUI84);
        uTIfLNK0(Date.class, oZ7qYn);
    }

    public static /* synthetic */ void eLbhX59K(Object obj, I.XbU7b xbU7b) {
        throw new I.RFQ3AA8("Couldn't find encoder for type " + obj.getClass().getCanonicalName());
    }

    @Override // J.AAnYcst
    /* JADX INFO: renamed from: q1ORKN, reason: merged with bridge method [inline-methods] */
    public LNd998w eszJ2B0a(Class cls, I.N1vNRFSd n1vNRFSd) {
        this.eszJ2B0a.put(cls, n1vNRFSd);
        this.aXYSYCVY.remove(cls);
        return this;
    }

    public LNd998w qLLw0g(boolean z10) {
        this.zDWsfFRp = z10;
        return this;
    }

    public I.MY3jR rjljd6i() {
        return new MY3jR();
    }

    public LNd998w uTIfLNK0(Class cls, W7Cnq5 w7Cnq5) {
        this.aXYSYCVY.put(cls, w7Cnq5);
        this.eszJ2B0a.remove(cls);
        return this;
    }

    public LNd998w zPJpxWz(J.MY3jR mY3jR) {
        mY3jR.eszJ2B0a(this);
        return this;
    }
}
