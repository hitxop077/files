package K;

import I.GU39Hcg;
import I.W7Cnq5;
import android.util.Base64;
import android.util.JsonWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class N1vNRFSd implements I.XbU7b, GU39Hcg {
    public final boolean dUI84;
    public final JsonWriter eLbhX59K;
    public final Map ivfTYNl;
    public final I.N1vNRFSd osx7Pl0E;
    public final Map zDWsfFRp;
    public N1vNRFSd eszJ2B0a = null;
    public boolean aXYSYCVY = true;

    public N1vNRFSd(Writer writer, Map map, Map map2, I.N1vNRFSd n1vNRFSd, boolean z10) {
        this.eLbhX59K = new JsonWriter(writer);
        this.zDWsfFRp = map;
        this.ivfTYNl = map2;
        this.osx7Pl0E = n1vNRFSd;
        this.dUI84 = z10;
    }

    @Override // I.XbU7b
    public I.XbU7b aXYSYCVY(I.LNd998w lNd998w, boolean z10) {
        return mTWLV(lNd998w.aXYSYCVY(), z10);
    }

    public final N1vNRFSd bsO5Vo(String str, Object obj) throws IOException {
        c1pvtY();
        this.eLbhX59K.name(str);
        if (obj != null) {
            return zPJpxWz(obj, false);
        }
        this.eLbhX59K.nullValue();
        return this;
    }

    public final void c1pvtY() throws IOException {
        if (!this.aXYSYCVY) {
            throw new IllegalStateException("Parent context used since this context was created. Cannot use this context anymore.");
        }
        N1vNRFSd n1vNRFSd = this.eszJ2B0a;
        if (n1vNRFSd != null) {
            n1vNRFSd.c1pvtY();
            this.eszJ2B0a.aXYSYCVY = false;
            this.eszJ2B0a = null;
            this.eLbhX59K.endObject();
        }
    }

    public N1vNRFSd dUI84(double d10) throws IOException {
        c1pvtY();
        this.eLbhX59K.value(d10);
        return this;
    }

    @Override // I.XbU7b
    public I.XbU7b eLbhX59K(I.LNd998w lNd998w, long j10) {
        return uYRSwDm(lNd998w.aXYSYCVY(), j10);
    }

    @Override // I.XbU7b
    public I.XbU7b eszJ2B0a(I.LNd998w lNd998w, Object obj) {
        return yxejkub(lNd998w.aXYSYCVY(), obj);
    }

    @Override // I.XbU7b
    public I.XbU7b ivfTYNl(I.LNd998w lNd998w, double d10) {
        return q1ORKN(lNd998w.aXYSYCVY(), d10);
    }

    public N1vNRFSd jAM6dcNA(byte[] bArr) throws IOException {
        c1pvtY();
        if (bArr == null) {
            this.eLbhX59K.nullValue();
            return this;
        }
        this.eLbhX59K.value(Base64.encodeToString(bArr, 2));
        return this;
    }

    public N1vNRFSd mTWLV(String str, boolean z10) throws IOException {
        c1pvtY();
        this.eLbhX59K.name(str);
        return osx7Pl0E(z10);
    }

    public N1vNRFSd n84TFkA9(I.N1vNRFSd n1vNRFSd, Object obj, boolean z10) throws IOException {
        if (!z10) {
            this.eLbhX59K.beginObject();
        }
        n1vNRFSd.eszJ2B0a(obj, this);
        if (!z10) {
            this.eLbhX59K.endObject();
        }
        return this;
    }

    public N1vNRFSd oZ7qYn(int i10) throws IOException {
        c1pvtY();
        this.eLbhX59K.value(i10);
        return this;
    }

    public void oyaOvpOs() {
        c1pvtY();
        this.eLbhX59K.flush();
    }

    public N1vNRFSd q1ORKN(String str, double d10) throws IOException {
        c1pvtY();
        this.eLbhX59K.name(str);
        return dUI84(d10);
    }

    @Override // I.GU39Hcg
    /* JADX INFO: renamed from: qLLw0g, reason: merged with bridge method [inline-methods] */
    public N1vNRFSd add(String str) throws IOException {
        c1pvtY();
        this.eLbhX59K.value(str);
        return this;
    }

    @Override // I.GU39Hcg
    /* JADX INFO: renamed from: rJCQt16, reason: merged with bridge method [inline-methods] */
    public N1vNRFSd osx7Pl0E(boolean z10) throws IOException {
        c1pvtY();
        this.eLbhX59K.value(z10);
        return this;
    }

    public N1vNRFSd rjljd6i(long j10) throws IOException {
        c1pvtY();
        this.eLbhX59K.value(j10);
        return this;
    }

    public final boolean rtsRj(Object obj) {
        return obj == null || obj.getClass().isArray() || (obj instanceof Collection) || (obj instanceof Date) || (obj instanceof Enum) || (obj instanceof Number);
    }

    public final N1vNRFSd sMxPLer(String str, Object obj) throws IOException {
        if (obj == null) {
            return this;
        }
        c1pvtY();
        this.eLbhX59K.name(str);
        return zPJpxWz(obj, false);
    }

    public N1vNRFSd uTIfLNK0(String str, int i10) throws IOException {
        c1pvtY();
        this.eLbhX59K.name(str);
        return oZ7qYn(i10);
    }

    public N1vNRFSd uYRSwDm(String str, long j10) throws IOException {
        c1pvtY();
        this.eLbhX59K.name(str);
        return rjljd6i(j10);
    }

    public N1vNRFSd yxejkub(String str, Object obj) {
        return this.dUI84 ? sMxPLer(str, obj) : bsO5Vo(str, obj);
    }

    @Override // I.XbU7b
    public I.XbU7b zDWsfFRp(I.LNd998w lNd998w, int i10) {
        return uTIfLNK0(lNd998w.aXYSYCVY(), i10);
    }

    public N1vNRFSd zPJpxWz(Object obj, boolean z10) {
        if (z10 && rtsRj(obj)) {
            throw new I.RFQ3AA8(String.format("%s cannot be encoded inline", obj == null ? null : obj.getClass()));
        }
        if (obj == null) {
            this.eLbhX59K.nullValue();
            return this;
        }
        if (obj instanceof Number) {
            this.eLbhX59K.value((Number) obj);
            return this;
        }
        int i10 = 0;
        if (!obj.getClass().isArray()) {
            if (obj instanceof Collection) {
                this.eLbhX59K.beginArray();
                Iterator it2 = ((Collection) obj).iterator();
                while (it2.hasNext()) {
                    zPJpxWz(it2.next(), false);
                }
                this.eLbhX59K.endArray();
                return this;
            }
            if (obj instanceof Map) {
                this.eLbhX59K.beginObject();
                for (Map.Entry entry : ((Map) obj).entrySet()) {
                    Object key = entry.getKey();
                    try {
                        yxejkub((String) key, entry.getValue());
                    } catch (ClassCastException e10) {
                        throw new I.RFQ3AA8(String.format("Only String keys are currently supported in maps, got %s of type %s instead.", key, key.getClass()), e10);
                    }
                }
                this.eLbhX59K.endObject();
                return this;
            }
            I.N1vNRFSd n1vNRFSd = (I.N1vNRFSd) this.zDWsfFRp.get(obj.getClass());
            if (n1vNRFSd != null) {
                return n84TFkA9(n1vNRFSd, obj, z10);
            }
            W7Cnq5 w7Cnq5 = (W7Cnq5) this.ivfTYNl.get(obj.getClass());
            if (w7Cnq5 != null) {
                w7Cnq5.eszJ2B0a(obj, this);
                return this;
            }
            if (!(obj instanceof Enum)) {
                return n84TFkA9(this.osx7Pl0E, obj, z10);
            }
            if (obj instanceof XbU7b) {
                oZ7qYn(((XbU7b) obj).getNumber());
                return this;
            }
            add(((Enum) obj).name());
            return this;
        }
        if (obj instanceof byte[]) {
            return jAM6dcNA((byte[]) obj);
        }
        this.eLbhX59K.beginArray();
        if (obj instanceof int[]) {
            int[] iArr = (int[]) obj;
            int length = iArr.length;
            while (i10 < length) {
                this.eLbhX59K.value(iArr[i10]);
                i10++;
            }
        } else if (obj instanceof long[]) {
            long[] jArr = (long[]) obj;
            int length2 = jArr.length;
            while (i10 < length2) {
                rjljd6i(jArr[i10]);
                i10++;
            }
        } else if (obj instanceof double[]) {
            double[] dArr = (double[]) obj;
            int length3 = dArr.length;
            while (i10 < length3) {
                this.eLbhX59K.value(dArr[i10]);
                i10++;
            }
        } else if (obj instanceof boolean[]) {
            boolean[] zArr = (boolean[]) obj;
            int length4 = zArr.length;
            while (i10 < length4) {
                this.eLbhX59K.value(zArr[i10]);
                i10++;
            }
        } else if (obj instanceof Number[]) {
            for (Number number : (Number[]) obj) {
                zPJpxWz(number, false);
            }
        } else {
            for (Object obj2 : (Object[]) obj) {
                zPJpxWz(obj2, false);
            }
        }
        this.eLbhX59K.endArray();
        return this;
    }
}
