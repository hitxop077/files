package Jp;

import androidx.lifecycle.AfGFIA;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes4.dex */
public final class MY3jR {
    public AfGFIA eszJ2B0a = new AfGFIA();
    public AfGFIA aXYSYCVY = new AfGFIA();
    public AfGFIA eLbhX59K = new AfGFIA();
    public AfGFIA zDWsfFRp = new AfGFIA();
    public AfGFIA ivfTYNl = new AfGFIA();

    public final AfGFIA aXYSYCVY() {
        return this.ivfTYNl;
    }

    public final AfGFIA eLbhX59K() {
        return this.aXYSYCVY;
    }

    public final AfGFIA eszJ2B0a() {
        return this.zDWsfFRp;
    }

    public final AfGFIA ivfTYNl() {
        return this.eszJ2B0a;
    }

    public final void osx7Pl0E(AfGFIA afGFIA) {
        Intrinsics.checkNotNullParameter(afGFIA, "<set-?>");
        this.ivfTYNl = afGFIA;
    }

    public final AfGFIA zDWsfFRp() {
        return this.eLbhX59K;
    }
}
