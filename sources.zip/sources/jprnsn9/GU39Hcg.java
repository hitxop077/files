package jprnsn9;

import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class GU39Hcg extends SpannableStringBuilder {
    public final Class njNibPNp;
    public final List vo5p9AUA;

    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes7.dex */
    public static class MY3jR implements TextWatcher, SpanWatcher {
        public final Object njNibPNp;
        public final AtomicInteger vo5p9AUA = new AtomicInteger(0);

        public MY3jR(Object obj) {
            this.njNibPNp = obj;
        }

        public final boolean aXYSYCVY(Object obj) {
            return obj instanceof N1vNRFSd;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            ((TextWatcher) this.njNibPNp).afterTextChanged(editable);
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            ((TextWatcher) this.njNibPNp).beforeTextChanged(charSequence, i10, i11, i12);
        }

        public final void eLbhX59K() {
            this.vo5p9AUA.decrementAndGet();
        }

        public final void eszJ2B0a() {
            this.vo5p9AUA.incrementAndGet();
        }

        @Override // android.text.SpanWatcher
        public void onSpanAdded(Spannable spannable, Object obj, int i10, int i11) {
            if (this.vo5p9AUA.get() <= 0 || !aXYSYCVY(obj)) {
                ((SpanWatcher) this.njNibPNp).onSpanAdded(spannable, obj, i10, i11);
            }
        }

        /* JADX WARN: Code duplicated, block: B:14:0x001e A[PHI: r11
  0x001e: PHI (r11v1 int) = (r11v0 int), (r11v3 int) binds: [B:8:0x0013, B:12:0x0019] A[DONT_GENERATE, DONT_INLINE]] */
        @Override // android.text.SpanWatcher
        public void onSpanChanged(Spannable spannable, Object obj, int i10, int i11, int i12, int i13) {
            int i14;
            int i15;
            if (this.vo5p9AUA.get() <= 0 || !aXYSYCVY(obj)) {
                if (Build.VERSION.SDK_INT >= 28) {
                    i14 = i10;
                    i15 = i12;
                } else {
                    if (i10 > i11) {
                        i10 = 0;
                    }
                    if (i12 > i13) {
                        i14 = i10;
                        i15 = 0;
                    } else {
                        i14 = i10;
                        i15 = i12;
                    }
                }
                ((SpanWatcher) this.njNibPNp).onSpanChanged(spannable, obj, i14, i11, i15, i13);
            }
        }

        @Override // android.text.SpanWatcher
        public void onSpanRemoved(Spannable spannable, Object obj, int i10, int i11) {
            if (this.vo5p9AUA.get() <= 0 || !aXYSYCVY(obj)) {
                ((SpanWatcher) this.njNibPNp).onSpanRemoved(spannable, obj, i10, i11);
            }
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
            ((TextWatcher) this.njNibPNp).onTextChanged(charSequence, i10, i11, i12);
        }
    }

    public GU39Hcg(Class cls, CharSequence charSequence) {
        super(charSequence);
        this.vo5p9AUA = new ArrayList();
        wodoxfe.HicDZW.oZ7qYn(cls, "watcherClass cannot be null");
        this.njNibPNp = cls;
    }

    public static GU39Hcg eLbhX59K(Class cls, CharSequence charSequence) {
        return new GU39Hcg(cls, charSequence);
    }

    public final void aXYSYCVY() {
        for (int i10 = 0; i10 < this.vo5p9AUA.size(); i10++) {
            ((MY3jR) this.vo5p9AUA.get(i10)).eszJ2B0a();
        }
    }

    public final boolean dUI84(Class cls) {
        return this.njNibPNp == cls;
    }

    public void eszJ2B0a() {
        aXYSYCVY();
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanEnd(Object obj) {
        MY3jR mY3jROsx7Pl0E;
        if (oZ7qYn(obj) && (mY3jROsx7Pl0E = osx7Pl0E(obj)) != null) {
            obj = mY3jROsx7Pl0E;
        }
        return super.getSpanEnd(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanFlags(Object obj) {
        MY3jR mY3jROsx7Pl0E;
        if (oZ7qYn(obj) && (mY3jROsx7Pl0E = osx7Pl0E(obj)) != null) {
            obj = mY3jROsx7Pl0E;
        }
        return super.getSpanFlags(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanStart(Object obj) {
        MY3jR mY3jROsx7Pl0E;
        if (oZ7qYn(obj) && (mY3jROsx7Pl0E = osx7Pl0E(obj)) != null) {
            obj = mY3jROsx7Pl0E;
        }
        return super.getSpanStart(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public Object[] getSpans(int i10, int i11, Class cls) {
        if (!dUI84(cls)) {
            return super.getSpans(i10, i11, cls);
        }
        MY3jR[] mY3jRArr = (MY3jR[]) super.getSpans(i10, i11, MY3jR.class);
        Object[] objArr = (Object[]) Array.newInstance((Class<?>) cls, mY3jRArr.length);
        for (int i12 = 0; i12 < mY3jRArr.length; i12++) {
            objArr[i12] = mY3jRArr[i12].njNibPNp;
        }
        return objArr;
    }

    public final void ivfTYNl() {
        for (int i10 = 0; i10 < this.vo5p9AUA.size(); i10++) {
            ((MY3jR) this.vo5p9AUA.get(i10)).onTextChanged(this, 0, length(), length());
        }
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int nextSpanTransition(int i10, int i11, Class cls) {
        if (cls == null || dUI84(cls)) {
            cls = MY3jR.class;
        }
        return super.nextSpanTransition(i10, i11, cls);
    }

    public final boolean oZ7qYn(Object obj) {
        return obj != null && dUI84(obj.getClass());
    }

    public final MY3jR osx7Pl0E(Object obj) {
        for (int i10 = 0; i10 < this.vo5p9AUA.size(); i10++) {
            MY3jR mY3jR = (MY3jR) this.vo5p9AUA.get(i10);
            if (mY3jR.njNibPNp == obj) {
                return mY3jR;
            }
        }
        return null;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spannable
    public void removeSpan(Object obj) {
        MY3jR mY3jROsx7Pl0E;
        if (oZ7qYn(obj)) {
            mY3jROsx7Pl0E = osx7Pl0E(obj);
            if (mY3jROsx7Pl0E != null) {
                obj = mY3jROsx7Pl0E;
            }
        } else {
            mY3jROsx7Pl0E = null;
        }
        super.removeSpan(obj);
        if (mY3jROsx7Pl0E != null) {
            this.vo5p9AUA.remove(mY3jROsx7Pl0E);
        }
    }

    public final void rjljd6i() {
        for (int i10 = 0; i10 < this.vo5p9AUA.size(); i10++) {
            ((MY3jR) this.vo5p9AUA.get(i10)).eLbhX59K();
        }
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spannable
    public void setSpan(Object obj, int i10, int i11, int i12) {
        if (oZ7qYn(obj)) {
            MY3jR mY3jR = new MY3jR(obj);
            this.vo5p9AUA.add(mY3jR);
            obj = mY3jR;
        }
        super.setSpan(obj, i10, i11, i12);
    }

    @Override // android.text.SpannableStringBuilder, java.lang.CharSequence
    public CharSequence subSequence(int i10, int i11) {
        return new GU39Hcg(this.njNibPNp, this, i10, i11);
    }

    public void zDWsfFRp() {
        rjljd6i();
        ivfTYNl();
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder delete(int i10, int i11) {
        super.delete(i10, i11);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder insert(int i10, CharSequence charSequence) {
        super.insert(i10, charSequence);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder replace(int i10, int i11, CharSequence charSequence) {
        aXYSYCVY();
        super.replace(i10, i11, charSequence);
        rjljd6i();
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder insert(int i10, CharSequence charSequence, int i11, int i12) {
        super.insert(i10, charSequence, i11, i12);
        return this;
    }

    public GU39Hcg(Class cls, CharSequence charSequence, int i10, int i11) {
        super(charSequence, i10, i11);
        this.vo5p9AUA = new ArrayList();
        wodoxfe.HicDZW.oZ7qYn(cls, "watcherClass cannot be null");
        this.njNibPNp = cls;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder replace(int i10, int i11, CharSequence charSequence, int i12, int i13) {
        aXYSYCVY();
        super.replace(i10, i11, charSequence, i12, i13);
        rjljd6i();
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(CharSequence charSequence) {
        super.append(charSequence);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(char c10) {
        super.append(c10);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(CharSequence charSequence, int i10, int i11) {
        super.append(charSequence, i10, i11);
        return this;
    }

    @Override // android.text.SpannableStringBuilder
    public SpannableStringBuilder append(CharSequence charSequence, Object obj, int i10) {
        super.append(charSequence, obj, i10);
        return this;
    }
}
