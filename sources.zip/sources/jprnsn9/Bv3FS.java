package jprnsn9;

import android.text.PrecomputedText;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class Bv3FS {
    public static /* bridge */ /* synthetic */ boolean eszJ2B0a(Object obj) {
        return obj instanceof PrecomputedText;
    }
}
