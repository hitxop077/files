package jprnsn9;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class AAnYcst {

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static Handler eszJ2B0a(Looper looper) {
            return Handler.createAsync(looper);
        }
    }

    public static ThreadPoolExecutor aXYSYCVY(final String str) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new ThreadFactory() { // from class: jprnsn9.MY3jR
            @Override // java.util.concurrent.ThreadFactory
            public final Thread newThread(Runnable runnable) {
                return AAnYcst.eszJ2B0a(str, runnable);
            }
        });
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    public static Handler eLbhX59K() {
        return Build.VERSION.SDK_INT >= 28 ? MY3jR.eszJ2B0a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper());
    }

    public static /* synthetic */ Thread eszJ2B0a(String str, Runnable runnable) {
        Thread thread = new Thread(runnable, str);
        thread.setPriority(10);
        return thread;
    }
}
