package jprnsn9;

import android.os.Build;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class LNd998w {

    /* JADX INFO: compiled from: Obfuscated */
    public static class AAnYcst {
        public static Set eszJ2B0a() {
            try {
                Object objInvoke = Class.forName("android.text.EmojiConsistency").getMethod("getEmojiConsistencySet", null).invoke(null, null);
                if (objInvoke == null) {
                    return Collections.EMPTY_SET;
                }
                Set set = (Set) objInvoke;
                Iterator it2 = set.iterator();
                while (it2.hasNext()) {
                    if (!(it2.next() instanceof int[])) {
                        return Collections.EMPTY_SET;
                    }
                }
                return set;
            } catch (Throwable unused) {
                return Collections.EMPTY_SET;
            }
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static Set<int[]> eszJ2B0a() {
            return AAnYcst.eszJ2B0a();
        }
    }

    public static Set eszJ2B0a() {
        return Build.VERSION.SDK_INT >= 34 ? MY3jR.eszJ2B0a() : AAnYcst.eszJ2B0a();
    }
}
