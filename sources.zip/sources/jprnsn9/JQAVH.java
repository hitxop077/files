package jprnsn9;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final class JQAVH extends N1vNRFSd {
    public static Paint vskcqLTQ;
    public TextPaint fdmP9GD;

    public JQAVH(HicDZW hicDZW) {
        super(hicDZW);
    }

    public static Paint ivfTYNl() {
        if (vskcqLTQ == null) {
            TextPaint textPaint = new TextPaint();
            vskcqLTQ = textPaint;
            textPaint.setColor(androidx.emoji2.text.RFQ3AA8.eLbhX59K().ivfTYNl());
            vskcqLTQ.setStyle(Paint.Style.FILL);
        }
        return vskcqLTQ;
    }

    @Override // android.text.style.ReplacementSpan
    public void draw(Canvas canvas, CharSequence charSequence, int i10, int i11, float f10, int i12, int i13, int i14, Paint paint) {
        TextPaint textPaintELbhX59K = eLbhX59K(charSequence, i10, i11, paint);
        if (textPaintELbhX59K != null && textPaintELbhX59K.bgColor != 0) {
            zDWsfFRp(canvas, textPaintELbhX59K, f10, f10 + aXYSYCVY(), i12, i14);
        }
        Paint paint2 = textPaintELbhX59K;
        if (androidx.emoji2.text.RFQ3AA8.eLbhX59K().q1ORKN()) {
            canvas.drawRect(f10, i12, f10 + aXYSYCVY(), i14, ivfTYNl());
        }
        HicDZW hicDZWEszJ2B0a = eszJ2B0a();
        float f11 = i13;
        if (paint2 == null) {
            paint2 = paint;
        }
        hicDZWEszJ2B0a.eszJ2B0a(canvas, f10, f11, paint2);
    }

    public final TextPaint eLbhX59K(CharSequence charSequence, int i10, int i11, Paint paint) {
        if (!(charSequence instanceof Spanned)) {
            if (paint instanceof TextPaint) {
                return (TextPaint) paint;
            }
            return null;
        }
        CharacterStyle[] characterStyleArr = (CharacterStyle[]) ((Spanned) charSequence).getSpans(i10, i11, CharacterStyle.class);
        if (characterStyleArr.length != 0) {
            if (characterStyleArr.length != 1 || characterStyleArr[0] != this) {
                TextPaint textPaint = this.fdmP9GD;
                if (textPaint == null) {
                    textPaint = new TextPaint();
                    this.fdmP9GD = textPaint;
                }
                textPaint.set(paint);
                for (CharacterStyle characterStyle : characterStyleArr) {
                    characterStyle.updateDrawState(textPaint);
                }
                return textPaint;
            }
        }
        if (paint instanceof TextPaint) {
            return (TextPaint) paint;
        }
        return null;
    }

    public void zDWsfFRp(Canvas canvas, TextPaint textPaint, float f10, float f11, float f12, float f13) {
        int color = textPaint.getColor();
        Paint.Style style = textPaint.getStyle();
        textPaint.setColor(textPaint.bgColor);
        textPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(f10, f12, f11, f13, textPaint);
        textPaint.setStyle(style);
        textPaint.setColor(color);
    }
}
