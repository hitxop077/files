package jprnsn9;

import android.graphics.Paint;
import android.text.style.ReplacementSpan;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class N1vNRFSd extends ReplacementSpan {
    public final HicDZW vo5p9AUA;
    public final Paint.FontMetricsInt njNibPNp = new Paint.FontMetricsInt();
    public short gmzPK = -1;
    public short zYD7SXW6 = -1;
    public float xINpNt2d = 1.0f;

    public N1vNRFSd(HicDZW hicDZW) {
        wodoxfe.HicDZW.oZ7qYn(hicDZW, "rasterizer cannot be null");
        this.vo5p9AUA = hicDZW;
    }

    public final int aXYSYCVY() {
        return this.gmzPK;
    }

    public final HicDZW eszJ2B0a() {
        return this.vo5p9AUA;
    }

    @Override // android.text.style.ReplacementSpan
    public int getSize(Paint paint, CharSequence charSequence, int i10, int i11, Paint.FontMetricsInt fontMetricsInt) {
        paint.getFontMetricsInt(this.njNibPNp);
        Paint.FontMetricsInt fontMetricsInt2 = this.njNibPNp;
        this.xINpNt2d = (Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f) / this.vo5p9AUA.ivfTYNl();
        this.zYD7SXW6 = (short) (this.vo5p9AUA.ivfTYNl() * this.xINpNt2d);
        short sRjljd6i = (short) (this.vo5p9AUA.rjljd6i() * this.xINpNt2d);
        this.gmzPK = sRjljd6i;
        if (fontMetricsInt != null) {
            Paint.FontMetricsInt fontMetricsInt3 = this.njNibPNp;
            fontMetricsInt.ascent = fontMetricsInt3.ascent;
            fontMetricsInt.descent = fontMetricsInt3.descent;
            fontMetricsInt.top = fontMetricsInt3.top;
            fontMetricsInt.bottom = fontMetricsInt3.bottom;
        }
        return sRjljd6i;
    }
}
