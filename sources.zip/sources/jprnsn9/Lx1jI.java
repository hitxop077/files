package jprnsn9;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;
import wavr5b6k.VVpVRy;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class Lx1jI implements Spannable {
    public boolean njNibPNp = false;
    public Spannable vo5p9AUA;

    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes7.dex */
    public static class AAnYcst {
        public boolean eszJ2B0a(CharSequence charSequence) {
            return charSequence instanceof VVpVRy;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes7.dex */
    public static class MY3jR {
        public static IntStream aXYSYCVY(CharSequence charSequence) {
            return charSequence.codePoints();
        }

        public static IntStream eszJ2B0a(CharSequence charSequence) {
            return charSequence.chars();
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes7.dex */
    public static class RFQ3AA8 extends AAnYcst {
        @Override // jprnsn9.Lx1jI.AAnYcst
        public boolean eszJ2B0a(CharSequence charSequence) {
            return Bv3FS.eszJ2B0a(charSequence) || (charSequence instanceof VVpVRy);
        }
    }

    public Lx1jI(Spannable spannable) {
        this.vo5p9AUA = spannable;
    }

    public static AAnYcst eLbhX59K() {
        return Build.VERSION.SDK_INT < 28 ? new AAnYcst() : new RFQ3AA8();
    }

    public Spannable aXYSYCVY() {
        return this.vo5p9AUA;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i10) {
        return this.vo5p9AUA.charAt(i10);
    }

    @Override // java.lang.CharSequence
    public IntStream chars() {
        return MY3jR.eszJ2B0a(this.vo5p9AUA);
    }

    @Override // java.lang.CharSequence
    public IntStream codePoints() {
        return MY3jR.aXYSYCVY(this.vo5p9AUA);
    }

    public final void eszJ2B0a() {
        Spannable spannable = this.vo5p9AUA;
        if (!this.njNibPNp && eLbhX59K().eszJ2B0a(spannable)) {
            this.vo5p9AUA = new SpannableString(spannable);
        }
        this.njNibPNp = true;
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.vo5p9AUA.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.vo5p9AUA.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.vo5p9AUA.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public Object[] getSpans(int i10, int i11, Class cls) {
        return this.vo5p9AUA.getSpans(i10, i11, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.vo5p9AUA.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i10, int i11, Class cls) {
        return this.vo5p9AUA.nextSpanTransition(i10, i11, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        eszJ2B0a();
        this.vo5p9AUA.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i10, int i11, int i12) {
        eszJ2B0a();
        this.vo5p9AUA.setSpan(obj, i10, i11, i12);
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i10, int i11) {
        return this.vo5p9AUA.subSequence(i10, i11);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.vo5p9AUA.toString();
    }

    public Lx1jI(CharSequence charSequence) {
        this.vo5p9AUA = new SpannableString(charSequence);
    }
}
