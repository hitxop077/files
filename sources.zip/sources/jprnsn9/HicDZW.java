package jprnsn9;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class HicDZW {
    public static final ThreadLocal zDWsfFRp = new ThreadLocal();
    public final androidx.emoji2.text.XbU7b aXYSYCVY;
    public volatile int eLbhX59K = 0;
    public final int eszJ2B0a;

    public HicDZW(androidx.emoji2.text.XbU7b xbU7b, int i10) {
        this.aXYSYCVY = xbU7b;
        this.eszJ2B0a = i10;
    }

    public int aXYSYCVY(int i10) {
        return dUI84().oZ7qYn(i10);
    }

    public final fx39ah.MY3jR dUI84() {
        ThreadLocal threadLocal = zDWsfFRp;
        fx39ah.MY3jR mY3jR = (fx39ah.MY3jR) threadLocal.get();
        if (mY3jR == null) {
            mY3jR = new fx39ah.MY3jR();
            threadLocal.set(mY3jR);
        }
        this.aXYSYCVY.zDWsfFRp().zPJpxWz(mY3jR, this.eszJ2B0a);
        return mY3jR;
    }

    public int eLbhX59K() {
        return dUI84().rjljd6i();
    }

    public void eszJ2B0a(Canvas canvas, float f10, float f11, Paint paint) {
        Typeface typefaceDUI84 = this.aXYSYCVY.dUI84();
        Typeface typeface = paint.getTypeface();
        paint.setTypeface(typefaceDUI84);
        canvas.drawText(this.aXYSYCVY.eLbhX59K(), this.eszJ2B0a * 2, 2, f10, f11, paint);
        paint.setTypeface(typeface);
    }

    public int ivfTYNl() {
        return dUI84().qLLw0g();
    }

    public short oZ7qYn() {
        return dUI84().uTIfLNK0();
    }

    public int osx7Pl0E() {
        return dUI84().q1ORKN();
    }

    public void q1ORKN(boolean z10) {
        int iZDWsfFRp = zDWsfFRp();
        if (z10) {
            this.eLbhX59K = iZDWsfFRp | 4;
        } else {
            this.eLbhX59K = iZDWsfFRp;
        }
    }

    public boolean qLLw0g() {
        return (this.eLbhX59K & 4) > 0;
    }

    public int rjljd6i() {
        return dUI84().uYRSwDm();
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        sb2.append(", id:");
        sb2.append(Integer.toHexString(osx7Pl0E()));
        sb2.append(", codepoints:");
        int iELbhX59K = eLbhX59K();
        for (int i10 = 0; i10 < iELbhX59K; i10++) {
            sb2.append(Integer.toHexString(aXYSYCVY(i10)));
            sb2.append(" ");
        }
        return sb2.toString();
    }

    public void uTIfLNK0(boolean z10) {
        int i10 = this.eLbhX59K & 4;
        this.eLbhX59K = z10 ? i10 | 2 : i10 | 1;
    }

    public int zDWsfFRp() {
        return this.eLbhX59K & 3;
    }

    public boolean zPJpxWz() {
        return dUI84().zPJpxWz();
    }
}
