package jprnsn9;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import kotlin.UShort;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class W7Cnq5 {

    /* JADX INFO: compiled from: Obfuscated */
    public static class AAnYcst {
        public final long aXYSYCVY;
        public final long eszJ2B0a;

        public AAnYcst(long j10, long j11) {
            this.eszJ2B0a = j10;
            this.aXYSYCVY = j11;
        }

        public long eszJ2B0a() {
            return this.eszJ2B0a;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR implements RFQ3AA8 {
        public final ByteBuffer eszJ2B0a;

        public MY3jR(ByteBuffer byteBuffer) {
            this.eszJ2B0a = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // jprnsn9.W7Cnq5.RFQ3AA8
        public int aXYSYCVY() {
            return this.eszJ2B0a.getInt();
        }

        @Override // jprnsn9.W7Cnq5.RFQ3AA8
        public long eLbhX59K() {
            return W7Cnq5.eLbhX59K(this.eszJ2B0a.getInt());
        }

        @Override // jprnsn9.W7Cnq5.RFQ3AA8
        public void eszJ2B0a(int i10) {
            ByteBuffer byteBuffer = this.eszJ2B0a;
            byteBuffer.position(byteBuffer.position() + i10);
        }

        @Override // jprnsn9.W7Cnq5.RFQ3AA8
        public long getPosition() {
            return this.eszJ2B0a.position();
        }

        @Override // jprnsn9.W7Cnq5.RFQ3AA8
        public int readUnsignedShort() {
            return W7Cnq5.zDWsfFRp(this.eszJ2B0a.getShort());
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public interface RFQ3AA8 {
        int aXYSYCVY();

        long eLbhX59K();

        void eszJ2B0a(int i10);

        long getPosition();

        int readUnsignedShort();
    }

    public static fx39ah.AAnYcst aXYSYCVY(ByteBuffer byteBuffer) {
        ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
        byteBufferDuplicate.position((int) eszJ2B0a(new MY3jR(byteBufferDuplicate)).eszJ2B0a());
        return fx39ah.AAnYcst.oZ7qYn(byteBufferDuplicate);
    }

    public static long eLbhX59K(int i10) {
        return ((long) i10) & 4294967295L;
    }

    public static AAnYcst eszJ2B0a(RFQ3AA8 rfq3aa8) throws IOException {
        long jELbhX59K;
        rfq3aa8.eszJ2B0a(4);
        int unsignedShort = rfq3aa8.readUnsignedShort();
        if (unsignedShort > 100) {
            throw new IOException("Cannot read metadata.");
        }
        rfq3aa8.eszJ2B0a(6);
        int i10 = 0;
        while (true) {
            if (i10 >= unsignedShort) {
                jELbhX59K = -1;
                break;
            }
            int iAXYSYCVY = rfq3aa8.aXYSYCVY();
            rfq3aa8.eszJ2B0a(4);
            jELbhX59K = rfq3aa8.eLbhX59K();
            rfq3aa8.eszJ2B0a(4);
            if (1835365473 == iAXYSYCVY) {
                break;
            }
            i10++;
        }
        if (jELbhX59K != -1) {
            rfq3aa8.eszJ2B0a((int) (jELbhX59K - rfq3aa8.getPosition()));
            rfq3aa8.eszJ2B0a(12);
            long jELbhX59K2 = rfq3aa8.eLbhX59K();
            for (int i11 = 0; i11 < jELbhX59K2; i11++) {
                int iAXYSYCVY2 = rfq3aa8.aXYSYCVY();
                long jELbhX59K3 = rfq3aa8.eLbhX59K();
                long jELbhX59K4 = rfq3aa8.eLbhX59K();
                if (1164798569 == iAXYSYCVY2 || 1701669481 == iAXYSYCVY2) {
                    return new AAnYcst(jELbhX59K3 + jELbhX59K, jELbhX59K4);
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static int zDWsfFRp(short s10) {
        return s10 & UShort.MAX_VALUE;
    }
}
