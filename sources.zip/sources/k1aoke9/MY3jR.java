package k1aoke9;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface MY3jR {
    void aXYSYCVY(int i10, int i11);

    void eszJ2B0a(int i10, int i11);
}
