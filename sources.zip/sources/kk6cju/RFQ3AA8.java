package kk6cju;

import aa9a0.SFMiYa;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public interface RFQ3AA8 {
    Object eszJ2B0a(Object obj, SFMiYa sFMiYa);
}
