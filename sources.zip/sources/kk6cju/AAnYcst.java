package kk6cju;

import aa9a0.SFMiYa;
import coil3.EY5bX;
import coil3.Qq2TyU2J;
import java.io.File;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final class AAnYcst implements RFQ3AA8 {
    @Override // kk6cju.RFQ3AA8
    /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
    public EY5bX eszJ2B0a(File file, SFMiYa sFMiYa) {
        return Qq2TyU2J.aXYSYCVY("file", null, file.getPath(), null, null, null, 58, null);
    }
}
