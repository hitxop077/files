package kk6cju;

import aa9a0.SFMiYa;
import android.net.Uri;
import coil3.AfGFIA;
import coil3.EY5bX;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final class MY3jR implements RFQ3AA8 {
    @Override // kk6cju.RFQ3AA8
    /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
    public EY5bX eszJ2B0a(Uri uri, SFMiYa sFMiYa) {
        return AfGFIA.aXYSYCVY(uri);
    }
}
