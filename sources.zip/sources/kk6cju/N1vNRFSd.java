package kk6cju;

import aa9a0.SFMiYa;
import android.content.Context;
import android.content.res.Resources;
import coil3.EY5bX;
import coil3.Qq2TyU2J;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final class N1vNRFSd implements RFQ3AA8 {
    public final boolean aXYSYCVY(int i10, Context context) {
        try {
            return context.getResources().getResourceEntryName(i10) != null;
        } catch (Resources.NotFoundException unused) {
        }
    }

    public EY5bX eLbhX59K(int i10, SFMiYa sFMiYa) {
        if (!aXYSYCVY(i10, sFMiYa.eLbhX59K())) {
            return null;
        }
        return Qq2TyU2J.zPJpxWz("android.resource://" + sFMiYa.eLbhX59K().getPackageName() + '/' + i10, null, 1, null);
    }

    @Override // kk6cju.RFQ3AA8
    public /* bridge */ /* synthetic */ Object eszJ2B0a(Object obj, SFMiYa sFMiYa) {
        return eLbhX59K(((Number) obj).intValue(), sFMiYa);
    }
}
