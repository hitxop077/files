package k5en3m;

import java.util.concurrent.Executor;
import kotlinx.coroutines.UjGBKKw;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface AAnYcst {
    default void aXYSYCVY(Runnable runnable) {
        zDWsfFRp().execute(runnable);
    }

    Executor eLbhX59K();

    UjGBKKw eszJ2B0a();

    MY3jR zDWsfFRp();
}
