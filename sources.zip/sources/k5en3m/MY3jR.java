package k5en3m;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface MY3jR extends Executor {
    boolean fIz14cTt();
}
