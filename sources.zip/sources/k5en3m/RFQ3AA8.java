package k5en3m;

import android.os.Handler;
import android.os.Looper;
import androidx.work.impl.utils.ZKBAd;
import java.util.concurrent.Executor;
import kotlinx.coroutines.Ctz0A;
import kotlinx.coroutines.UjGBKKw;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class RFQ3AA8 implements AAnYcst {
    public final UjGBKKw aXYSYCVY;
    public final ZKBAd eszJ2B0a;
    public final Handler eLbhX59K = new Handler(Looper.getMainLooper());
    public final Executor zDWsfFRp = new MY3jR();

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR implements Executor {
        public MY3jR() {
        }

        @Override // java.util.concurrent.Executor
        public void execute(Runnable runnable) {
            RFQ3AA8.this.eLbhX59K.post(runnable);
        }
    }

    public RFQ3AA8(Executor executor) {
        ZKBAd zKBAd = new ZKBAd(executor);
        this.eszJ2B0a = zKBAd;
        this.aXYSYCVY = Ctz0A.aXYSYCVY(zKBAd);
    }

    @Override // k5en3m.AAnYcst
    public Executor eLbhX59K() {
        return this.zDWsfFRp;
    }

    @Override // k5en3m.AAnYcst
    public UjGBKKw eszJ2B0a() {
        return this.aXYSYCVY;
    }

    @Override // k5en3m.AAnYcst
    /* JADX INFO: renamed from: ivfTYNl, reason: merged with bridge method [inline-methods] */
    public ZKBAd zDWsfFRp() {
        return this.eszJ2B0a;
    }
}
