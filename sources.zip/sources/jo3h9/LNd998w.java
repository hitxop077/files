package jo3h9;

import android.util.Size;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class LNd998w {
    public static final Size eszJ2B0a = new Size(0, 0);
    public static final Size aXYSYCVY = new Size(320, 240);
    public static final Size eLbhX59K = new Size(640, 480);
    public static final Size zDWsfFRp = new Size(720, 480);
    public static final Size ivfTYNl = new Size(1280, 720);
    public static final Size osx7Pl0E = new Size(1920, 1080);
    public static final Size dUI84 = new Size(1920, 1440);
    public static final Size oZ7qYn = new Size(2560, 1440);
    public static final Size rjljd6i = new Size(3840, 2160);

    public static int aXYSYCVY(int i10, int i11) {
        return i10 * i11;
    }

    public static int eLbhX59K(Size size) {
        return aXYSYCVY(size.getWidth(), size.getHeight());
    }

    public static Object eszJ2B0a(Size size, TreeMap treeMap) {
        Map.Entry entryCeilingEntry = treeMap.ceilingEntry(size);
        if (entryCeilingEntry != null) {
            return entryCeilingEntry.getValue();
        }
        Map.Entry entryFloorEntry = treeMap.floorEntry(size);
        if (entryFloorEntry != null) {
            return entryFloorEntry.getValue();
        }
        return null;
    }

    public static boolean zDWsfFRp(Size size, Size size2) {
        return eLbhX59K(size) < eLbhX59K(size2);
    }
}
