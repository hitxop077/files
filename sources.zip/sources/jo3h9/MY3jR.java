package jo3h9;

import java.util.ArrayDeque;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class MY3jR implements RFQ3AA8 {
    public final ArrayDeque aXYSYCVY;
    public final Object eLbhX59K;
    public final int eszJ2B0a;
    public final RFQ3AA8.MY3jR zDWsfFRp;

    public MY3jR(int i10) {
        this(i10, null);
    }

    public void aXYSYCVY(Object obj) {
        Object objEszJ2B0a;
        synchronized (this.eLbhX59K) {
            try {
                objEszJ2B0a = this.aXYSYCVY.size() >= this.eszJ2B0a ? eszJ2B0a() : null;
                this.aXYSYCVY.addFirst(obj);
            } catch (Throwable th2) {
                throw th2;
            }
        }
        RFQ3AA8.MY3jR mY3jR = this.zDWsfFRp;
        if (mY3jR == null || objEszJ2B0a == null) {
            return;
        }
        mY3jR.eszJ2B0a(objEszJ2B0a);
    }

    @Override // jo3h9.RFQ3AA8
    public Object eszJ2B0a() {
        Object objRemoveLast;
        synchronized (this.eLbhX59K) {
            objRemoveLast = this.aXYSYCVY.removeLast();
        }
        return objRemoveLast;
    }

    @Override // jo3h9.RFQ3AA8
    public boolean isEmpty() {
        boolean zIsEmpty;
        synchronized (this.eLbhX59K) {
            zIsEmpty = this.aXYSYCVY.isEmpty();
        }
        return zIsEmpty;
    }

    public MY3jR(int i10, RFQ3AA8.MY3jR mY3jR) {
        this.eLbhX59K = new Object();
        this.eszJ2B0a = i10;
        this.aXYSYCVY = new ArrayDeque(i10);
        this.zDWsfFRp = mY3jR;
    }
}
