package jo3h9;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.util.Rational;
import android.util.Size;
import androidx.camera.core.ImageProcessingUtil;
import irvr1b.GU39Hcg;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import nuw20tz.BcXKTU;
import wodoxfe.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class AAnYcst {
    public static Bitmap aXYSYCVY(androidx.camera.core.LNd998w lNd998w) {
        int format = lNd998w.getFormat();
        if (format == 1) {
            return zDWsfFRp(lNd998w);
        }
        if (format == 35) {
            return ImageProcessingUtil.osx7Pl0E(lNd998w);
        }
        if (format == 256 || format == 4101) {
            return eLbhX59K(lNd998w);
        }
        throw new IllegalArgumentException("Incorrect image format of the input image proxy: " + lNd998w.getFormat() + ", only ImageFormat.YUV_420_888 and PixelFormat.RGBA_8888 are supported");
    }

    public static Rational dUI84(Rational rational) {
        return rational == null ? rational : new Rational(rational.getDenominator(), rational.getNumerator());
    }

    public static Bitmap eLbhX59K(androidx.camera.core.LNd998w lNd998w) {
        byte[] bArrQLLw0g = qLLw0g(lNd998w);
        Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrQLLw0g, 0, bArrQLLw0g.length, null);
        if (bitmapDecodeByteArray != null) {
            return bitmapDecodeByteArray;
        }
        throw new UnsupportedOperationException("Decode jpeg byte array failed");
    }

    public static Rect eszJ2B0a(Size size, Rational rational) {
        int i10;
        if (!oZ7qYn(rational)) {
            BcXKTU.q1ORKN("ImageUtil", "Invalid view ratio.");
            return null;
        }
        int width = size.getWidth();
        int height = size.getHeight();
        float f10 = width;
        float f11 = height;
        float f12 = f10 / f11;
        int numerator = rational.getNumerator();
        int denominator = rational.getDenominator();
        int i11 = 0;
        if (rational.floatValue() > f12) {
            int iRound = Math.round((f10 / numerator) * denominator);
            i10 = (height - iRound) / 2;
            height = iRound;
        } else {
            int iRound2 = Math.round((f11 / denominator) * numerator);
            int i12 = (width - iRound2) / 2;
            width = iRound2;
            i10 = 0;
            i11 = i12;
        }
        return new Rect(i11, i10, width + i11, height + i10);
    }

    public static ByteBuffer ivfTYNl(Bitmap bitmap) {
        HicDZW.aXYSYCVY(bitmap.getConfig() == Bitmap.Config.ARGB_8888, "Only accept Bitmap with ARGB_8888 format for now.");
        ByteBuffer byteBufferAllocateDirect = ByteBuffer.allocateDirect(bitmap.getAllocationByteCount());
        ImageProcessingUtil.rjljd6i(bitmap, byteBufferAllocateDirect, bitmap.getRowBytes());
        byteBufferAllocateDirect.rewind();
        return byteBufferAllocateDirect;
    }

    public static boolean oZ7qYn(Rational rational) {
        return (rational == null || rational.floatValue() <= 0.0f || rational.isNaN()) ? false : true;
    }

    public static Rational osx7Pl0E(int i10, Rational rational) {
        return (i10 == 90 || i10 == 270) ? dUI84(rational) : new Rational(rational.getNumerator(), rational.getDenominator());
    }

    public static Bitmap q1ORKN(Bitmap bitmap, int i10) {
        Matrix matrix = new Matrix();
        matrix.postRotate(i10);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    public static byte[] qLLw0g(androidx.camera.core.LNd998w lNd998w) {
        if (!rjljd6i(lNd998w.getFormat())) {
            throw new IllegalArgumentException("Incorrect image format of the input image proxy: " + lNd998w.getFormat());
        }
        ByteBuffer byteBufferZDWsfFRp = lNd998w.pv6OM()[0].zDWsfFRp();
        byte[] bArr = new byte[byteBufferZDWsfFRp.capacity()];
        byteBufferZDWsfFRp.rewind();
        byteBufferZDWsfFRp.get(bArr);
        return bArr;
    }

    public static boolean rjljd6i(int i10) {
        return i10 == 256 || i10 == 4101;
    }

    public static byte[] uTIfLNK0(androidx.camera.core.LNd998w lNd998w, Rect rect, int i10, int i11) throws MY3jR {
        if (lNd998w.getFormat() != 35) {
            throw new IllegalArgumentException("Incorrect image format of the input image proxy: " + lNd998w.getFormat());
        }
        YuvImage yuvImage = new YuvImage(uYRSwDm(lNd998w), 17, lNd998w.getWidth(), lNd998w.getHeight(), null);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        irvr1b.HicDZW hicDZW = new irvr1b.HicDZW(byteArrayOutputStream, GU39Hcg.eLbhX59K(lNd998w, i11));
        if (rect == null) {
            rect = new Rect(0, 0, lNd998w.getWidth(), lNd998w.getHeight());
        }
        if (yuvImage.compressToJpeg(rect, i10, hicDZW)) {
            return byteArrayOutputStream.toByteArray();
        }
        throw new MY3jR("YuvImage failed to encode jpeg.", MY3jR.EnumC1481MY3jR.ENCODE_FAILED);
    }

    public static byte[] uYRSwDm(androidx.camera.core.LNd998w lNd998w) {
        androidx.camera.core.LNd998w.MY3jR mY3jR = lNd998w.pv6OM()[0];
        androidx.camera.core.LNd998w.MY3jR mY3jR2 = lNd998w.pv6OM()[1];
        androidx.camera.core.LNd998w.MY3jR mY3jR3 = lNd998w.pv6OM()[2];
        ByteBuffer byteBufferZDWsfFRp = mY3jR.zDWsfFRp();
        ByteBuffer byteBufferZDWsfFRp2 = mY3jR2.zDWsfFRp();
        ByteBuffer byteBufferZDWsfFRp3 = mY3jR3.zDWsfFRp();
        byteBufferZDWsfFRp.rewind();
        byteBufferZDWsfFRp2.rewind();
        byteBufferZDWsfFRp3.rewind();
        int iRemaining = byteBufferZDWsfFRp.remaining();
        byte[] bArr = new byte[((lNd998w.getWidth() * lNd998w.getHeight()) / 2) + iRemaining];
        int width = 0;
        for (int i10 = 0; i10 < lNd998w.getHeight(); i10++) {
            byteBufferZDWsfFRp.get(bArr, width, lNd998w.getWidth());
            width += lNd998w.getWidth();
            byteBufferZDWsfFRp.position(Math.min(iRemaining, (byteBufferZDWsfFRp.position() - lNd998w.getWidth()) + mY3jR.ivfTYNl()));
        }
        int height = lNd998w.getHeight() / 2;
        int width2 = lNd998w.getWidth() / 2;
        int iIvfTYNl = mY3jR3.ivfTYNl();
        int iIvfTYNl2 = mY3jR2.ivfTYNl();
        int iOsx7Pl0E = mY3jR3.osx7Pl0E();
        int iOsx7Pl0E2 = mY3jR2.osx7Pl0E();
        byte[] bArr2 = new byte[iIvfTYNl];
        byte[] bArr3 = new byte[iIvfTYNl2];
        for (int i11 = 0; i11 < height; i11++) {
            byteBufferZDWsfFRp3.get(bArr2, 0, Math.min(iIvfTYNl, byteBufferZDWsfFRp3.remaining()));
            byteBufferZDWsfFRp2.get(bArr3, 0, Math.min(iIvfTYNl2, byteBufferZDWsfFRp2.remaining()));
            int i12 = 0;
            int i13 = 0;
            for (int i14 = 0; i14 < width2; i14++) {
                int i15 = width + 1;
                bArr[width] = bArr2[i12];
                width += 2;
                bArr[i15] = bArr3[i13];
                i12 += iOsx7Pl0E;
                i13 += iOsx7Pl0E2;
            }
        }
        return bArr;
    }

    public static Bitmap zDWsfFRp(androidx.camera.core.LNd998w lNd998w) {
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(lNd998w.getWidth(), lNd998w.getHeight(), Bitmap.Config.ARGB_8888);
        lNd998w.pv6OM()[0].zDWsfFRp().rewind();
        ImageProcessingUtil.zPJpxWz(bitmapCreateBitmap, lNd998w.pv6OM()[0].zDWsfFRp(), lNd998w.pv6OM()[0].ivfTYNl());
        return bitmapCreateBitmap;
    }

    public static boolean zPJpxWz(int i10) {
        return i10 == 32;
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR extends Exception {
        private final EnumC1481MY3jR mFailureType;

        /* JADX INFO: renamed from: jo3h9.AAnYcst$MY3jR$MY3jR, reason: collision with other inner class name */
        /* JADX INFO: compiled from: Obfuscated */
        public enum EnumC1481MY3jR {
            ENCODE_FAILED,
            DECODE_FAILED,
            UNKNOWN
        }

        public MY3jR(String str) {
            super(str);
            this.mFailureType = EnumC1481MY3jR.UNKNOWN;
        }

        public EnumC1481MY3jR getFailureType() {
            return this.mFailureType;
        }

        public MY3jR(String str, EnumC1481MY3jR enumC1481MY3jR) {
            super(str);
            this.mFailureType = enumC1481MY3jR;
        }
    }
}
