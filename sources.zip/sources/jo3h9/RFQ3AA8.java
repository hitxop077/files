package jo3h9;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public interface RFQ3AA8 {

    /* JADX INFO: compiled from: Obfuscated */
    public interface MY3jR {
        void eszJ2B0a(Object obj);
    }

    Object eszJ2B0a();

    boolean isEmpty();
}
