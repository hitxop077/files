package jo3h9;

import android.util.Size;
import androidx.camera.core.impl.Ncz6mJ;
import androidx.camera.core.impl.PI2oT3rO;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class N1vNRFSd {
    public static void eszJ2B0a(Ncz6mJ.AAnYcst aAnYcst, int i10) {
        Size sizeWtGiK9b;
        PI2oT3rO pI2oT3rO = (PI2oT3rO) aAnYcst.ivfTYNl();
        int iBsO5Vo = pI2oT3rO.bsO5Vo(-1);
        if (iBsO5Vo == -1 || iBsO5Vo != i10) {
            ((PI2oT3rO.MY3jR) aAnYcst).eszJ2B0a(i10);
        }
        if (iBsO5Vo == -1 || i10 == -1 || iBsO5Vo == i10) {
            return;
        }
        if (Math.abs(irvr1b.RFQ3AA8.aXYSYCVY(i10) - irvr1b.RFQ3AA8.aXYSYCVY(iBsO5Vo)) % 180 != 90 || (sizeWtGiK9b = pI2oT3rO.wtGiK9b(null)) == null) {
            return;
        }
        ((PI2oT3rO.MY3jR) aAnYcst).eLbhX59K(new Size(sizeWtGiK9b.getHeight(), sizeWtGiK9b.getWidth()));
    }
}
