package jo3h9;

import androidx.camera.core.impl.AliKj1I;
import androidx.camera.core.impl.H8UuVVi;
import androidx.camera.core.impl.Jg4Z0Io9;
import androidx.camera.core.impl.PGzD6265;
import androidx.camera.core.impl.RkdvoZ;
import nuw20tz.Q5YIo;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class XbU7b extends MY3jR {
    public XbU7b(int i10, RFQ3AA8.MY3jR mY3jR) {
        super(i10, mY3jR);
    }

    public void eLbhX59K(androidx.camera.core.LNd998w lNd998w) {
        if (zDWsfFRp(lNd998w.nCkWf())) {
            super.aXYSYCVY(lNd998w);
        } else {
            this.zDWsfFRp.eszJ2B0a(lNd998w);
        }
    }

    public final boolean zDWsfFRp(Q5YIo q5YIo) {
        PGzD6265 pGzD6265EszJ2B0a = AliKj1I.eszJ2B0a(q5YIo);
        if (pGzD6265EszJ2B0a == null) {
            return false;
        }
        return (pGzD6265EszJ2B0a.ivfTYNl() == H8UuVVi.LOCKED_FOCUSED || pGzD6265EszJ2B0a.ivfTYNl() == H8UuVVi.PASSIVE_FOCUSED) && pGzD6265EszJ2B0a.oZ7qYn() == Jg4Z0Io9.CONVERGED && pGzD6265EszJ2B0a.osx7Pl0E() == RkdvoZ.CONVERGED;
    }
}
