package j87p84j;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface N1vNRFSd {
}
