package j87p84j;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class LNd998w {
    public float aXYSYCVY;
    public float eszJ2B0a;

    public LNd998w(float f10, float f11) {
        this.eszJ2B0a = f10;
        this.aXYSYCVY = f11;
    }

    public float aXYSYCVY() {
        return this.eszJ2B0a;
    }

    public float eLbhX59K() {
        return this.aXYSYCVY;
    }

    public boolean eszJ2B0a(float f10, float f11) {
        return this.eszJ2B0a == f10 && this.aXYSYCVY == f11;
    }

    public String toString() {
        return aXYSYCVY() + "x" + eLbhX59K();
    }

    public void zDWsfFRp(float f10, float f11) {
        this.eszJ2B0a = f10;
        this.aXYSYCVY = f11;
    }

    public LNd998w() {
        this(1.0f, 1.0f);
    }
}
