package j87p84j;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class RFQ3AA8 {
    public bdf11f7.MY3jR aXYSYCVY;
    public Object eLbhX59K;
    public final AAnYcst eszJ2B0a;

    public RFQ3AA8() {
        this.eszJ2B0a = new AAnYcst();
        this.eLbhX59K = null;
    }

    public final Object aXYSYCVY(float f10, float f11, Object obj, Object obj2, float f12, float f13, float f14) {
        return eszJ2B0a(this.eszJ2B0a.oZ7qYn(f10, f11, obj, obj2, f12, f13, f14));
    }

    public final void eLbhX59K(bdf11f7.MY3jR mY3jR) {
        this.aXYSYCVY = mY3jR;
    }

    public Object eszJ2B0a(AAnYcst aAnYcst) {
        return this.eLbhX59K;
    }

    public RFQ3AA8(Object obj) {
        this.eszJ2B0a = new AAnYcst();
        this.eLbhX59K = obj;
    }
}
