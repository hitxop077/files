package j87p84j;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class AAnYcst {
    public float aXYSYCVY;
    public float dUI84;
    public Object eLbhX59K;
    public float eszJ2B0a;
    public float ivfTYNl;
    public float osx7Pl0E;
    public Object zDWsfFRp;

    public Object aXYSYCVY() {
        return this.zDWsfFRp;
    }

    public Object dUI84() {
        return this.eLbhX59K;
    }

    public float eLbhX59K() {
        return this.osx7Pl0E;
    }

    public float eszJ2B0a() {
        return this.aXYSYCVY;
    }

    public float ivfTYNl() {
        return this.dUI84;
    }

    public AAnYcst oZ7qYn(float f10, float f11, Object obj, Object obj2, float f12, float f13, float f14) {
        this.eszJ2B0a = f10;
        this.aXYSYCVY = f11;
        this.eLbhX59K = obj;
        this.zDWsfFRp = obj2;
        this.ivfTYNl = f12;
        this.osx7Pl0E = f13;
        this.dUI84 = f14;
        return this;
    }

    public float osx7Pl0E() {
        return this.eszJ2B0a;
    }

    public float zDWsfFRp() {
        return this.ivfTYNl;
    }
}
