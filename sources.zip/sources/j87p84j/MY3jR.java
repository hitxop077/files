package j87p84j;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import com.airbnb.lottie.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class MY3jR {
    public final Object aXYSYCVY;
    public final float dUI84;
    public Object eLbhX59K;
    public final HicDZW eszJ2B0a;
    public final Interpolator ivfTYNl;
    public PointF mTWLV;
    public Float oZ7qYn;
    public final Interpolator osx7Pl0E;
    public int q1ORKN;
    public int qLLw0g;
    public float rjljd6i;
    public float uTIfLNK0;
    public float uYRSwDm;
    public PointF yxejkub;
    public final Interpolator zDWsfFRp;
    public float zPJpxWz;

    public MY3jR(HicDZW hicDZW, Object obj, Object obj2, Interpolator interpolator, float f10, Float f11) {
        this.rjljd6i = -3987645.8f;
        this.zPJpxWz = -3987645.8f;
        this.qLLw0g = 784923401;
        this.q1ORKN = 784923401;
        this.uTIfLNK0 = Float.MIN_VALUE;
        this.uYRSwDm = Float.MIN_VALUE;
        this.yxejkub = null;
        this.mTWLV = null;
        this.eszJ2B0a = hicDZW;
        this.aXYSYCVY = obj;
        this.eLbhX59K = obj2;
        this.zDWsfFRp = interpolator;
        this.ivfTYNl = null;
        this.osx7Pl0E = null;
        this.dUI84 = f10;
        this.oZ7qYn = f11;
    }

    public MY3jR aXYSYCVY(Object obj, Object obj2) {
        return new MY3jR(obj, obj2);
    }

    public float dUI84() {
        if (this.rjljd6i == -3987645.8f) {
            this.rjljd6i = ((Float) this.aXYSYCVY).floatValue();
        }
        return this.rjljd6i;
    }

    public float eLbhX59K() {
        if (this.eszJ2B0a == null) {
            return 1.0f;
        }
        if (this.uYRSwDm == Float.MIN_VALUE) {
            if (this.oZ7qYn == null) {
                this.uYRSwDm = 1.0f;
            } else {
                this.uYRSwDm = osx7Pl0E() + ((this.oZ7qYn.floatValue() - this.dUI84) / this.eszJ2B0a.ivfTYNl());
            }
        }
        return this.uYRSwDm;
    }

    public boolean eszJ2B0a(float f10) {
        return f10 >= osx7Pl0E() && f10 < eLbhX59K();
    }

    public int ivfTYNl() {
        if (this.q1ORKN == 784923401) {
            this.q1ORKN = ((Integer) this.eLbhX59K).intValue();
        }
        return this.q1ORKN;
    }

    public int oZ7qYn() {
        if (this.qLLw0g == 784923401) {
            this.qLLw0g = ((Integer) this.aXYSYCVY).intValue();
        }
        return this.qLLw0g;
    }

    public float osx7Pl0E() {
        HicDZW hicDZW = this.eszJ2B0a;
        if (hicDZW == null) {
            return 0.0f;
        }
        if (this.uTIfLNK0 == Float.MIN_VALUE) {
            this.uTIfLNK0 = (this.dUI84 - hicDZW.mTWLV()) / this.eszJ2B0a.ivfTYNl();
        }
        return this.uTIfLNK0;
    }

    public boolean rjljd6i() {
        return this.zDWsfFRp == null && this.ivfTYNl == null && this.osx7Pl0E == null;
    }

    public String toString() {
        return "Keyframe{startValue=" + this.aXYSYCVY + ", endValue=" + this.eLbhX59K + ", startFrame=" + this.dUI84 + ", endFrame=" + this.oZ7qYn + ", interpolator=" + this.zDWsfFRp + '}';
    }

    public float zDWsfFRp() {
        if (this.zPJpxWz == -3987645.8f) {
            this.zPJpxWz = ((Float) this.eLbhX59K).floatValue();
        }
        return this.zPJpxWz;
    }

    public MY3jR(HicDZW hicDZW, Object obj, Object obj2, Interpolator interpolator, Interpolator interpolator2, float f10, Float f11) {
        this.rjljd6i = -3987645.8f;
        this.zPJpxWz = -3987645.8f;
        this.qLLw0g = 784923401;
        this.q1ORKN = 784923401;
        this.uTIfLNK0 = Float.MIN_VALUE;
        this.uYRSwDm = Float.MIN_VALUE;
        this.yxejkub = null;
        this.mTWLV = null;
        this.eszJ2B0a = hicDZW;
        this.aXYSYCVY = obj;
        this.eLbhX59K = obj2;
        this.zDWsfFRp = null;
        this.ivfTYNl = interpolator;
        this.osx7Pl0E = interpolator2;
        this.dUI84 = f10;
        this.oZ7qYn = f11;
    }

    public MY3jR(HicDZW hicDZW, Object obj, Object obj2, Interpolator interpolator, Interpolator interpolator2, Interpolator interpolator3, float f10, Float f11) {
        this.rjljd6i = -3987645.8f;
        this.zPJpxWz = -3987645.8f;
        this.qLLw0g = 784923401;
        this.q1ORKN = 784923401;
        this.uTIfLNK0 = Float.MIN_VALUE;
        this.uYRSwDm = Float.MIN_VALUE;
        this.yxejkub = null;
        this.mTWLV = null;
        this.eszJ2B0a = hicDZW;
        this.aXYSYCVY = obj;
        this.eLbhX59K = obj2;
        this.zDWsfFRp = interpolator;
        this.ivfTYNl = interpolator2;
        this.osx7Pl0E = interpolator3;
        this.dUI84 = f10;
        this.oZ7qYn = f11;
    }

    public MY3jR(Object obj) {
        this.rjljd6i = -3987645.8f;
        this.zPJpxWz = -3987645.8f;
        this.qLLw0g = 784923401;
        this.q1ORKN = 784923401;
        this.uTIfLNK0 = Float.MIN_VALUE;
        this.uYRSwDm = Float.MIN_VALUE;
        this.yxejkub = null;
        this.mTWLV = null;
        this.eszJ2B0a = null;
        this.aXYSYCVY = obj;
        this.eLbhX59K = obj;
        this.zDWsfFRp = null;
        this.ivfTYNl = null;
        this.osx7Pl0E = null;
        this.dUI84 = Float.MIN_VALUE;
        this.oZ7qYn = Float.valueOf(Float.MAX_VALUE);
    }

    public MY3jR(Object obj, Object obj2) {
        this.rjljd6i = -3987645.8f;
        this.zPJpxWz = -3987645.8f;
        this.qLLw0g = 784923401;
        this.q1ORKN = 784923401;
        this.uTIfLNK0 = Float.MIN_VALUE;
        this.uYRSwDm = Float.MIN_VALUE;
        this.yxejkub = null;
        this.mTWLV = null;
        this.eszJ2B0a = null;
        this.aXYSYCVY = obj;
        this.eLbhX59K = obj2;
        this.zDWsfFRp = null;
        this.ivfTYNl = null;
        this.osx7Pl0E = null;
        this.dUI84 = Float.MIN_VALUE;
        this.oZ7qYn = Float.valueOf(Float.MAX_VALUE);
    }
}
