package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.JQAVH, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0013\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\f\b\u0087\b\u0018\u00002\u00020\u0001BC\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\u000b\u0010\fJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\u000eJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u0011\u0010\u0010J\u0012\u0010\u0012\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u0012\u0010\u0013J\u0012\u0010\u0014\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u0014\u0010\u0013J\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u0015\u0010\u0013JX\u0010\u0016\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0007HÆ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u0018\u0010\u0010J\u0010\u0010\u0019\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0019\u0010\u001aJ\u001a\u0010\u001e\u001a\u00020\u001d2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001bHÖ\u0003¢\u0006\u0004\b\u001e\u0010\u001fR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010 \u001a\u0004\b!\u0010\u000eR\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\"\u001a\u0004\b#\u0010\u0010R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010\"\u001a\u0004\b$\u0010\u0010R\u001c\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010%\u001a\u0004\b&\u0010\u0013R\u001c\u0010\t\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010%\u001a\u0004\b'\u0010\u0013R\u001c\u0010\n\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\n\u0010%\u001a\u0004\b(\u0010\u0013¨\u0006)"}, d2 = {"LJg/JQAVH;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "cacheTtl", "", "fromDate", "fromDateFormat", "", "fromDateInEpochMillis", "dateRangeFilterFromDateMillis", "fromDateForUserTagsSummaryInMillis", "<init>", "(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;)V", "component1", "()Ljava/lang/Integer;", "component2", "()Ljava/lang/String;", "component3", "component4", "()Ljava/lang/Long;", "component5", "component6", "copy", "(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;)LJg/JQAVH;", "toString", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/Integer;", "getCacheTtl", "Ljava/lang/String;", "getFromDate", "getFromDateFormat", "Ljava/lang/Long;", "getFromDateInEpochMillis", "getDateRangeFilterFromDateMillis", "getFromDateForUserTagsSummaryInMillis", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UTHMetaInfo extends IJRPaytmDataModel {
    public static final int $stable = 0;

    @SerializedName("cacheTtl")
    private final Integer cacheTtl;

    @SerializedName("dateRangeFilter_fromDate_millis")
    private final Long dateRangeFilterFromDateMillis;

    @SerializedName("fromDate")
    private final String fromDate;

    @SerializedName("fromDateForUserTagsSummaryInMillis")
    private final Long fromDateForUserTagsSummaryInMillis;

    @SerializedName("fromDateFormat")
    private final String fromDateFormat;

    @SerializedName("fromDateInEpochMillis")
    private final Long fromDateInEpochMillis;

    public UTHMetaInfo(Integer num, String str, String str2, Long l10, Long l11, Long l12) {
        this.cacheTtl = num;
        this.fromDate = str;
        this.fromDateFormat = str2;
        this.fromDateInEpochMillis = l10;
        this.dateRangeFilterFromDateMillis = l11;
        this.fromDateForUserTagsSummaryInMillis = l12;
    }

    public static /* synthetic */ UTHMetaInfo copy$default(UTHMetaInfo uTHMetaInfo, Integer num, String str, String str2, Long l10, Long l11, Long l12, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            num = uTHMetaInfo.cacheTtl;
        }
        if ((i10 & 2) != 0) {
            str = uTHMetaInfo.fromDate;
        }
        if ((i10 & 4) != 0) {
            str2 = uTHMetaInfo.fromDateFormat;
        }
        if ((i10 & 8) != 0) {
            l10 = uTHMetaInfo.fromDateInEpochMillis;
        }
        if ((i10 & 16) != 0) {
            l11 = uTHMetaInfo.dateRangeFilterFromDateMillis;
        }
        if ((i10 & 32) != 0) {
            l12 = uTHMetaInfo.fromDateForUserTagsSummaryInMillis;
        }
        Long l13 = l11;
        Long l14 = l12;
        return uTHMetaInfo.copy(num, str, str2, l10, l13, l14);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Integer getCacheTtl() {
        return this.cacheTtl;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getFromDate() {
        return this.fromDate;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getFromDateFormat() {
        return this.fromDateFormat;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final Long getFromDateInEpochMillis() {
        return this.fromDateInEpochMillis;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final Long getDateRangeFilterFromDateMillis() {
        return this.dateRangeFilterFromDateMillis;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final Long getFromDateForUserTagsSummaryInMillis() {
        return this.fromDateForUserTagsSummaryInMillis;
    }

    public final UTHMetaInfo copy(Integer cacheTtl, String fromDate, String fromDateFormat, Long fromDateInEpochMillis, Long dateRangeFilterFromDateMillis, Long fromDateForUserTagsSummaryInMillis) {
        return new UTHMetaInfo(cacheTtl, fromDate, fromDateFormat, fromDateInEpochMillis, dateRangeFilterFromDateMillis, fromDateForUserTagsSummaryInMillis);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UTHMetaInfo)) {
            return false;
        }
        UTHMetaInfo uTHMetaInfo = (UTHMetaInfo) other;
        return Intrinsics.areEqual(this.cacheTtl, uTHMetaInfo.cacheTtl) && Intrinsics.areEqual(this.fromDate, uTHMetaInfo.fromDate) && Intrinsics.areEqual(this.fromDateFormat, uTHMetaInfo.fromDateFormat) && Intrinsics.areEqual(this.fromDateInEpochMillis, uTHMetaInfo.fromDateInEpochMillis) && Intrinsics.areEqual(this.dateRangeFilterFromDateMillis, uTHMetaInfo.dateRangeFilterFromDateMillis) && Intrinsics.areEqual(this.fromDateForUserTagsSummaryInMillis, uTHMetaInfo.fromDateForUserTagsSummaryInMillis);
    }

    public final Integer getCacheTtl() {
        return this.cacheTtl;
    }

    public final Long getDateRangeFilterFromDateMillis() {
        return this.dateRangeFilterFromDateMillis;
    }

    public final String getFromDate() {
        return this.fromDate;
    }

    public final Long getFromDateForUserTagsSummaryInMillis() {
        return this.fromDateForUserTagsSummaryInMillis;
    }

    public final String getFromDateFormat() {
        return this.fromDateFormat;
    }

    public final Long getFromDateInEpochMillis() {
        return this.fromDateInEpochMillis;
    }

    public int hashCode() {
        Integer num = this.cacheTtl;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        String str = this.fromDate;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.fromDateFormat;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Long l10 = this.fromDateInEpochMillis;
        int iHashCode4 = (iHashCode3 + (l10 == null ? 0 : l10.hashCode())) * 31;
        Long l11 = this.dateRangeFilterFromDateMillis;
        int iHashCode5 = (iHashCode4 + (l11 == null ? 0 : l11.hashCode())) * 31;
        Long l12 = this.fromDateForUserTagsSummaryInMillis;
        return iHashCode5 + (l12 != null ? l12.hashCode() : 0);
    }

    public String toString() {
        return "UTHMetaInfo(cacheTtl=" + this.cacheTtl + ", fromDate=" + this.fromDate + ", fromDateFormat=" + this.fromDateFormat + ", fromDateInEpochMillis=" + this.fromDateInEpochMillis + ", dateRangeFilterFromDateMillis=" + this.dateRangeFilterFromDateMillis + ", fromDateForUserTagsSummaryInMillis=" + this.fromDateForUserTagsSummaryInMillis + ")";
    }
}
