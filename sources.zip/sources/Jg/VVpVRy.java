package Jg;

import com.paytmbank.walletnew.passbook.utility.CJRConstants;
import java.util.HashMap;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
public abstract class VVpVRy {
    public static final HashMap aXYSYCVY() {
        return MapsKt.hashMapOf(TuplesKt.to(CJRConstants.PASS_PH_MONEY_PAID, "1"), TuplesKt.to(CJRConstants.PASS_PH_MONEY_RECEIVED, "2"), TuplesKt.to("add_money", "3"), TuplesKt.to("self_transfer", "4"), TuplesKt.to("cashback", "5"), TuplesKt.to("money_refunded", "6"));
    }

    public static final HashMap eszJ2B0a() {
        return MapsKt.hashMapOf(TuplesKt.to("success", "2"), TuplesKt.to("failure", "1"), TuplesKt.to("pending", "3"));
    }
}
