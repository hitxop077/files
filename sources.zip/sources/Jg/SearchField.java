package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.GU39Hcg, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0015\n\u0002\u0010\u0000\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001BC\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\t\u001a\u0004\u0018\u00010\u0002\u0012\b\b\u0002\u0010\n\u001a\u00020\u0006¢\u0006\u0004\b\u000b\u0010\fJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\r\u0010\u000eJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u0010J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0004\b\u0011\u0010\u0012J\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u0013\u0010\u0010J\u0012\u0010\u0014\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0014\u0010\u000eJ\u0010\u0010\u0015\u001a\u00020\u0006HÆ\u0003¢\u0006\u0004\b\u0015\u0010\u0016JV\u0010\u0017\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00022\b\b\u0002\u0010\n\u001a\u00020\u0006HÆ\u0001¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010\u0019\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0019\u0010\u000eJ\u0010\u0010\u001a\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u001a\u0010\u001bJ\u001a\u0010\u001e\u001a\u00020\u00062\b\u0010\u001d\u001a\u0004\u0018\u00010\u001cHÖ\u0003¢\u0006\u0004\b\u001e\u0010\u001fR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010 \u001a\u0004\b!\u0010\u000eR\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\"\u001a\u0004\b#\u0010\u0010R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010$\u001a\u0004\b\u0007\u0010\u0012R\u001c\u0010\b\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010\"\u001a\u0004\b%\u0010\u0010R\u001c\u0010\t\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010 \u001a\u0004\b&\u0010\u000eR\"\u0010\n\u001a\u00020\u00068\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\n\u0010'\u001a\u0004\b(\u0010\u0016\"\u0004\b)\u0010*¨\u0006+"}, d2 = {"LJg/GU39Hcg;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "displayName", "", "displayOrder", "", "isActive", "minLength", "requestParam", SDKConstants.SELECTED, "<init>", "(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/String;Z)V", "component1", "()Ljava/lang/String;", "component2", "()Ljava/lang/Integer;", "component3", "()Ljava/lang/Boolean;", "component4", "component5", "component6", "()Z", "copy", "(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/String;Z)LJg/GU39Hcg;", "toString", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getDisplayName", "Ljava/lang/Integer;", "getDisplayOrder", "Ljava/lang/Boolean;", "getMinLength", "getRequestParam", "Z", "getSelected", "setSelected", "(Z)V", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class SearchField extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("displayName")
    private final String displayName;

    @SerializedName("displayOrder")
    private final Integer displayOrder;

    @SerializedName("isActive")
    private final Boolean isActive;

    @SerializedName("minLength")
    private final Integer minLength;

    @SerializedName("requestParam")
    private final String requestParam;
    private boolean selected;

    public /* synthetic */ SearchField(String str, Integer num, Boolean bool, Integer num2, String str2, boolean z10, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, num, bool, num2, str2, (i10 & 32) != 0 ? false : z10);
    }

    public static /* synthetic */ SearchField copy$default(SearchField searchField, String str, Integer num, Boolean bool, Integer num2, String str2, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = searchField.displayName;
        }
        if ((i10 & 2) != 0) {
            num = searchField.displayOrder;
        }
        if ((i10 & 4) != 0) {
            bool = searchField.isActive;
        }
        if ((i10 & 8) != 0) {
            num2 = searchField.minLength;
        }
        if ((i10 & 16) != 0) {
            str2 = searchField.requestParam;
        }
        if ((i10 & 32) != 0) {
            z10 = searchField.selected;
        }
        String str3 = str2;
        boolean z11 = z10;
        return searchField.copy(str, num, bool, num2, str3, z11);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getDisplayName() {
        return this.displayName;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Integer getDisplayOrder() {
        return this.displayOrder;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Boolean getIsActive() {
        return this.isActive;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final Integer getMinLength() {
        return this.minLength;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getRequestParam() {
        return this.requestParam;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final boolean getSelected() {
        return this.selected;
    }

    public final SearchField copy(String displayName, Integer displayOrder, Boolean isActive, Integer minLength, String requestParam, boolean selected) {
        return new SearchField(displayName, displayOrder, isActive, minLength, requestParam, selected);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SearchField)) {
            return false;
        }
        SearchField searchField = (SearchField) other;
        return Intrinsics.areEqual(this.displayName, searchField.displayName) && Intrinsics.areEqual(this.displayOrder, searchField.displayOrder) && Intrinsics.areEqual(this.isActive, searchField.isActive) && Intrinsics.areEqual(this.minLength, searchField.minLength) && Intrinsics.areEqual(this.requestParam, searchField.requestParam) && this.selected == searchField.selected;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public final Integer getDisplayOrder() {
        return this.displayOrder;
    }

    public final Integer getMinLength() {
        return this.minLength;
    }

    public final String getRequestParam() {
        return this.requestParam;
    }

    public final boolean getSelected() {
        return this.selected;
    }

    public int hashCode() {
        String str = this.displayName;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        Integer num = this.displayOrder;
        int iHashCode2 = (iHashCode + (num == null ? 0 : num.hashCode())) * 31;
        Boolean bool = this.isActive;
        int iHashCode3 = (iHashCode2 + (bool == null ? 0 : bool.hashCode())) * 31;
        Integer num2 = this.minLength;
        int iHashCode4 = (iHashCode3 + (num2 == null ? 0 : num2.hashCode())) * 31;
        String str2 = this.requestParam;
        return ((iHashCode4 + (str2 != null ? str2.hashCode() : 0)) * 31) + Boolean.hashCode(this.selected);
    }

    public final Boolean isActive() {
        return this.isActive;
    }

    public final void setSelected(boolean z10) {
        this.selected = z10;
    }

    public String toString() {
        return "SearchField(displayName=" + this.displayName + ", displayOrder=" + this.displayOrder + ", isActive=" + this.isActive + ", minLength=" + this.minLength + ", requestParam=" + this.requestParam + ", selected=" + this.selected + ")";
    }

    public SearchField(String str, Integer num, Boolean bool, Integer num2, String str2, boolean z10) {
        this.displayName = str;
        this.displayOrder = num;
        this.isActive = bool;
        this.minLength = num2;
        this.requestParam = str2;
        this.selected = z10;
    }
}
