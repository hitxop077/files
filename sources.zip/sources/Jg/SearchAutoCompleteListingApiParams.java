package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import p497q7.SFMiYa;

/* JADX INFO: renamed from: Jg.XbU7b, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u000e\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\n\u0010\u000bJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\u000bJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\r\u0010\u000eJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u000eJ@\u0010\u0010\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u0010\u0010\u0012\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u000bJ\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\u00052\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016HÖ\u0003¢\u0006\u0004\b\u0018\u0010\u0019R$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u001a\u001a\u0004\b\u001b\u0010\u000b\"\u0004\b\u001c\u0010\u001dR\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001a\u001a\u0004\b\u001e\u0010\u000bR$\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0006\u0010\u001f\u001a\u0004\b \u0010\u000e\"\u0004\b!\u0010\"R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010\u001f\u001a\u0004\b#\u0010\u000e¨\u0006$"}, d2 = {"LJg/XbU7b;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", SFMiYa.INTENT_QUERY, "searchFields", "", "filterApplied", "fromAutoComplete", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;)V", "component1", "()Ljava/lang/String;", "component2", "component3", "()Ljava/lang/Boolean;", "component4", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/Boolean;)LJg/XbU7b;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getQuery", "setQuery", "(Ljava/lang/String;)V", "getSearchFields", "Ljava/lang/Boolean;", "getFilterApplied", "setFilterApplied", "(Ljava/lang/Boolean;)V", "getFromAutoComplete", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class SearchAutoCompleteListingApiParams extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("filterApplied")
    private Boolean filterApplied;

    @SerializedName("fromAutoComplete")
    private final Boolean fromAutoComplete;

    @SerializedName(SFMiYa.INTENT_QUERY)
    private String query;

    @SerializedName("searchFields")
    private final String searchFields;

    public SearchAutoCompleteListingApiParams() {
        this(null, null, null, null, 15, null);
    }

    public static /* synthetic */ SearchAutoCompleteListingApiParams copy$default(SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams, String str, String str2, Boolean bool, Boolean bool2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = searchAutoCompleteListingApiParams.query;
        }
        if ((i10 & 2) != 0) {
            str2 = searchAutoCompleteListingApiParams.searchFields;
        }
        if ((i10 & 4) != 0) {
            bool = searchAutoCompleteListingApiParams.filterApplied;
        }
        if ((i10 & 8) != 0) {
            bool2 = searchAutoCompleteListingApiParams.fromAutoComplete;
        }
        return searchAutoCompleteListingApiParams.copy(str, str2, bool, bool2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getQuery() {
        return this.query;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getSearchFields() {
        return this.searchFields;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Boolean getFilterApplied() {
        return this.filterApplied;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final Boolean getFromAutoComplete() {
        return this.fromAutoComplete;
    }

    public final SearchAutoCompleteListingApiParams copy(String query, String searchFields, Boolean filterApplied, Boolean fromAutoComplete) {
        return new SearchAutoCompleteListingApiParams(query, searchFields, filterApplied, fromAutoComplete);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SearchAutoCompleteListingApiParams)) {
            return false;
        }
        SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams = (SearchAutoCompleteListingApiParams) other;
        return Intrinsics.areEqual(this.query, searchAutoCompleteListingApiParams.query) && Intrinsics.areEqual(this.searchFields, searchAutoCompleteListingApiParams.searchFields) && Intrinsics.areEqual(this.filterApplied, searchAutoCompleteListingApiParams.filterApplied) && Intrinsics.areEqual(this.fromAutoComplete, searchAutoCompleteListingApiParams.fromAutoComplete);
    }

    public final Boolean getFilterApplied() {
        return this.filterApplied;
    }

    public final Boolean getFromAutoComplete() {
        return this.fromAutoComplete;
    }

    public final String getQuery() {
        return this.query;
    }

    public final String getSearchFields() {
        return this.searchFields;
    }

    public int hashCode() {
        String str = this.query;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.searchFields;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        Boolean bool = this.filterApplied;
        int iHashCode3 = (iHashCode2 + (bool == null ? 0 : bool.hashCode())) * 31;
        Boolean bool2 = this.fromAutoComplete;
        return iHashCode3 + (bool2 != null ? bool2.hashCode() : 0);
    }

    public final void setFilterApplied(Boolean bool) {
        this.filterApplied = bool;
    }

    public final void setQuery(String str) {
        this.query = str;
    }

    public String toString() {
        return "SearchAutoCompleteListingApiParams(query=" + this.query + ", searchFields=" + this.searchFields + ", filterApplied=" + this.filterApplied + ", fromAutoComplete=" + this.fromAutoComplete + ")";
    }

    public /* synthetic */ SearchAutoCompleteListingApiParams(String str, String str2, Boolean bool, Boolean bool2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? null : str2, (i10 & 4) != 0 ? null : bool, (i10 & 8) != 0 ? null : bool2);
    }

    public SearchAutoCompleteListingApiParams(String str, String str2, Boolean bool, Boolean bool2) {
        this.query = str;
        this.searchFields = str2;
        this.filterApplied = bool;
        this.fromAutoComplete = bool2;
    }
}
