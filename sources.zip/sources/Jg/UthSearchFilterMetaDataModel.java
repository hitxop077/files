package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.io.ConstantsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.passbook.beans.searchFilterV2.PassbookSettingsItem;
import net.one97.paytm.passbook.beans.searchFilterV2.UthFilter;

/* JADX INFO: renamed from: Jg.Bv3FS, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u001b\b\u0087\b\u0018\u00002\u00020\u0001B¡\u0002\u0012\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\t\u0012(\b\u0002\u0010\u000e\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r\u0012(\b\u0002\u0010\u000f\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r\u0012\u0010\b\u0002\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0002\u0012(\b\u0002\u0010\u0012\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r\u0012(\b\u0002\u0010\u0013\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r\u0012(\b\u0002\u0010\u0014\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r¢\u0006\u0004\b\u0015\u0010\u0016J\r\u0010\u0017\u001a\u00020\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u0018\u0010\u0019\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0019\u0010\u001aJ\u0012\u0010\u001b\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\u001b\u0010\u001cJ\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u001d\u0010\u001eJ\u0012\u0010\u001f\u001a\u0004\u0018\u00010\tHÆ\u0003¢\u0006\u0004\b\u001f\u0010 J0\u0010!\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0003¢\u0006\u0004\b!\u0010\"J0\u0010#\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0003¢\u0006\u0004\b#\u0010\"J\u0018\u0010$\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b$\u0010\u001aJ0\u0010%\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0003¢\u0006\u0004\b%\u0010\"J0\u0010&\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0003¢\u0006\u0004\b&\u0010\"J0\u0010'\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0003¢\u0006\u0004\b'\u0010\"Jª\u0002\u0010(\u001a\u00020\u00002\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\t2(\b\u0002\u0010\u000e\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r2(\b\u0002\u0010\u000f\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r2\u0010\b\u0002\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u00022(\b\u0002\u0010\u0012\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r2(\b\u0002\u0010\u0013\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r2(\b\u0002\u0010\u0014\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\rHÆ\u0001¢\u0006\u0004\b(\u0010)J\u0010\u0010*\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b*\u0010+J\u0010\u0010-\u001a\u00020,HÖ\u0001¢\u0006\u0004\b-\u0010.J\u001a\u00102\u001a\u0002012\b\u00100\u001a\u0004\u0018\u00010/HÖ\u0003¢\u0006\u0004\b2\u00103R*\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0004\u00104\u001a\u0004\b5\u0010\u001a\"\u0004\b6\u00107R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u00108\u001a\u0004\b9\u0010\u001cR\u001c\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010:\u001a\u0004\b;\u0010\u001eR$\u0010\n\u001a\u0004\u0018\u00010\t8\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\n\u0010<\u001a\u0004\b=\u0010 \"\u0004\b>\u0010?RB\u0010\u000e\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r8\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010@\u001a\u0004\bA\u0010\"\"\u0004\bB\u0010CRB\u0010\u000f\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r8\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u000f\u0010@\u001a\u0004\bD\u0010\"\"\u0004\bE\u0010CR\"\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0011\u00104\u001a\u0004\bF\u0010\u001aR:\u0010\u0012\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0012\u0010@\u001a\u0004\bG\u0010\"RB\u0010\u0013\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0013\u0010@\u001a\u0004\bH\u0010\"\"\u0004\bI\u0010CRB\u0010\u0014\u001a\"\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bj\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0018\u0001`\r8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0014\u0010@\u001a\u0004\bJ\u0010\"\"\u0004\bK\u0010C¨\u0006L"}, d2 = {"LJg/Bv3FS;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "Lnet/one97/paytm/passbook/beans/searchFilterV2/UthFilter;", "filters", "LJg/JQAVH;", "metaInfo", "LJg/N1vNRFSd;", "search", "LJg/MY3jR;", "autoCompleteApiMetaInfo", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "routingInfo", "apiUrlsInfo", "Lnet/one97/paytm/passbook/beans/searchFilterV2/PassbookSettingsItem;", "passbookMenuSections", "txnTypeToAccountLabelMap", "txnCategoryMapping", "statusKeyMapping", "<init>", "(Ljava/util/List;LJg/JQAVH;LJg/N1vNRFSd;LJg/MY3jR;Ljava/util/HashMap;Ljava/util/HashMap;Ljava/util/List;Ljava/util/HashMap;Ljava/util/HashMap;Ljava/util/HashMap;)V", "clone", "()LJg/Bv3FS;", "component1", "()Ljava/util/List;", "component2", "()LJg/JQAVH;", "component3", "()LJg/N1vNRFSd;", "component4", "()LJg/MY3jR;", "component5", "()Ljava/util/HashMap;", "component6", "component7", "component8", "component9", "component10", "copy", "(Ljava/util/List;LJg/JQAVH;LJg/N1vNRFSd;LJg/MY3jR;Ljava/util/HashMap;Ljava/util/HashMap;Ljava/util/List;Ljava/util/HashMap;Ljava/util/HashMap;Ljava/util/HashMap;)LJg/Bv3FS;", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/util/List;", "getFilters", "setFilters", "(Ljava/util/List;)V", "LJg/JQAVH;", "getMetaInfo", "LJg/N1vNRFSd;", "getSearch", "LJg/MY3jR;", "getAutoCompleteApiMetaInfo", "setAutoCompleteApiMetaInfo", "(LJg/MY3jR;)V", "Ljava/util/HashMap;", "getRoutingInfo", "setRoutingInfo", "(Ljava/util/HashMap;)V", "getApiUrlsInfo", "setApiUrlsInfo", "getPassbookMenuSections", "getTxnTypeToAccountLabelMap", "getTxnCategoryMapping", "setTxnCategoryMapping", "getStatusKeyMapping", "setStatusKeyMapping", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UthSearchFilterMetaDataModel extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("apiUrlsInfo")
    private HashMap<String, String> apiUrlsInfo;

    @SerializedName("autoCompleteApiMetaInfo")
    private AutoCompleteApiMetaInfo autoCompleteApiMetaInfo;

    @SerializedName("filters")
    private List<UthFilter> filters;

    @SerializedName("metaInfo")
    private final UTHMetaInfo metaInfo;

    @SerializedName("passbookMenuSections")
    private final List<PassbookSettingsItem> passbookMenuSections;

    @SerializedName("routingInfo")
    private HashMap<String, String> routingInfo;

    @SerializedName("search")
    private final Search search;
    private HashMap<String, String> statusKeyMapping;
    private HashMap<String, String> txnCategoryMapping;

    @SerializedName("txnTypeToAccountLabelMap")
    private final HashMap<String, String> txnTypeToAccountLabelMap;

    public UthSearchFilterMetaDataModel() {
        this(null, null, null, null, null, null, null, null, null, null, 1023, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ UthSearchFilterMetaDataModel copy$default(UthSearchFilterMetaDataModel uthSearchFilterMetaDataModel, List list, UTHMetaInfo jqavh, Search n1vNRFSd, AutoCompleteApiMetaInfo mY3jR, HashMap map, HashMap map2, List list2, HashMap map3, HashMap map4, HashMap map5, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            list = uthSearchFilterMetaDataModel.filters;
        }
        if ((i10 & 2) != 0) {
            jqavh = uthSearchFilterMetaDataModel.metaInfo;
        }
        if ((i10 & 4) != 0) {
            n1vNRFSd = uthSearchFilterMetaDataModel.search;
        }
        if ((i10 & 8) != 0) {
            mY3jR = uthSearchFilterMetaDataModel.autoCompleteApiMetaInfo;
        }
        if ((i10 & 16) != 0) {
            map = uthSearchFilterMetaDataModel.routingInfo;
        }
        if ((i10 & 32) != 0) {
            map2 = uthSearchFilterMetaDataModel.apiUrlsInfo;
        }
        if ((i10 & 64) != 0) {
            list2 = uthSearchFilterMetaDataModel.passbookMenuSections;
        }
        if ((i10 & 128) != 0) {
            map3 = uthSearchFilterMetaDataModel.txnTypeToAccountLabelMap;
        }
        if ((i10 & 256) != 0) {
            map4 = uthSearchFilterMetaDataModel.txnCategoryMapping;
        }
        if ((i10 & ConstantsKt.MINIMUM_BLOCK_SIZE) != 0) {
            map5 = uthSearchFilterMetaDataModel.statusKeyMapping;
        }
        HashMap map6 = map4;
        HashMap map7 = map5;
        List list3 = list2;
        HashMap map8 = map3;
        HashMap map9 = map;
        HashMap map10 = map2;
        return uthSearchFilterMetaDataModel.copy(list, jqavh, n1vNRFSd, mY3jR, map9, map10, list3, map8, map6, map7);
    }

    public final UthSearchFilterMetaDataModel clone() {
        ArrayList arrayList;
        List<UthFilter> list = this.filters;
        if (list != null) {
            List<UthFilter> list2 = list;
            arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
            Iterator<T> it2 = list2.iterator();
            while (it2.hasNext()) {
                arrayList.add(((UthFilter) it2.next()).clone());
            }
        } else {
            arrayList = null;
        }
        return copy$default(this, arrayList, null, null, null, null, null, null, null, null, null, 1022, null);
    }

    public final List<UthFilter> component1() {
        return this.filters;
    }

    public final HashMap<String, String> component10() {
        return this.statusKeyMapping;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final UTHMetaInfo getMetaInfo() {
        return this.metaInfo;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Search getSearch() {
        return this.search;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final AutoCompleteApiMetaInfo getAutoCompleteApiMetaInfo() {
        return this.autoCompleteApiMetaInfo;
    }

    public final HashMap<String, String> component5() {
        return this.routingInfo;
    }

    public final HashMap<String, String> component6() {
        return this.apiUrlsInfo;
    }

    public final List<PassbookSettingsItem> component7() {
        return this.passbookMenuSections;
    }

    public final HashMap<String, String> component8() {
        return this.txnTypeToAccountLabelMap;
    }

    public final HashMap<String, String> component9() {
        return this.txnCategoryMapping;
    }

    public final UthSearchFilterMetaDataModel copy(List<UthFilter> filters, UTHMetaInfo metaInfo, Search search, AutoCompleteApiMetaInfo autoCompleteApiMetaInfo, HashMap<String, String> routingInfo, HashMap<String, String> apiUrlsInfo, List<PassbookSettingsItem> passbookMenuSections, HashMap<String, String> txnTypeToAccountLabelMap, HashMap<String, String> txnCategoryMapping, HashMap<String, String> statusKeyMapping) {
        return new UthSearchFilterMetaDataModel(filters, metaInfo, search, autoCompleteApiMetaInfo, routingInfo, apiUrlsInfo, passbookMenuSections, txnTypeToAccountLabelMap, txnCategoryMapping, statusKeyMapping);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UthSearchFilterMetaDataModel)) {
            return false;
        }
        UthSearchFilterMetaDataModel uthSearchFilterMetaDataModel = (UthSearchFilterMetaDataModel) other;
        return Intrinsics.areEqual(this.filters, uthSearchFilterMetaDataModel.filters) && Intrinsics.areEqual(this.metaInfo, uthSearchFilterMetaDataModel.metaInfo) && Intrinsics.areEqual(this.search, uthSearchFilterMetaDataModel.search) && Intrinsics.areEqual(this.autoCompleteApiMetaInfo, uthSearchFilterMetaDataModel.autoCompleteApiMetaInfo) && Intrinsics.areEqual(this.routingInfo, uthSearchFilterMetaDataModel.routingInfo) && Intrinsics.areEqual(this.apiUrlsInfo, uthSearchFilterMetaDataModel.apiUrlsInfo) && Intrinsics.areEqual(this.passbookMenuSections, uthSearchFilterMetaDataModel.passbookMenuSections) && Intrinsics.areEqual(this.txnTypeToAccountLabelMap, uthSearchFilterMetaDataModel.txnTypeToAccountLabelMap) && Intrinsics.areEqual(this.txnCategoryMapping, uthSearchFilterMetaDataModel.txnCategoryMapping) && Intrinsics.areEqual(this.statusKeyMapping, uthSearchFilterMetaDataModel.statusKeyMapping);
    }

    public final HashMap<String, String> getApiUrlsInfo() {
        return this.apiUrlsInfo;
    }

    public final AutoCompleteApiMetaInfo getAutoCompleteApiMetaInfo() {
        return this.autoCompleteApiMetaInfo;
    }

    public final List<UthFilter> getFilters() {
        return this.filters;
    }

    public final UTHMetaInfo getMetaInfo() {
        return this.metaInfo;
    }

    public final List<PassbookSettingsItem> getPassbookMenuSections() {
        return this.passbookMenuSections;
    }

    public final HashMap<String, String> getRoutingInfo() {
        return this.routingInfo;
    }

    public final Search getSearch() {
        return this.search;
    }

    public final HashMap<String, String> getStatusKeyMapping() {
        return this.statusKeyMapping;
    }

    public final HashMap<String, String> getTxnCategoryMapping() {
        return this.txnCategoryMapping;
    }

    public final HashMap<String, String> getTxnTypeToAccountLabelMap() {
        return this.txnTypeToAccountLabelMap;
    }

    public int hashCode() {
        List<UthFilter> list = this.filters;
        int iHashCode = (list == null ? 0 : list.hashCode()) * 31;
        UTHMetaInfo jqavh = this.metaInfo;
        int iHashCode2 = (iHashCode + (jqavh == null ? 0 : jqavh.hashCode())) * 31;
        Search n1vNRFSd = this.search;
        int iHashCode3 = (iHashCode2 + (n1vNRFSd == null ? 0 : n1vNRFSd.hashCode())) * 31;
        AutoCompleteApiMetaInfo mY3jR = this.autoCompleteApiMetaInfo;
        int iHashCode4 = (iHashCode3 + (mY3jR == null ? 0 : mY3jR.hashCode())) * 31;
        HashMap<String, String> map = this.routingInfo;
        int iHashCode5 = (iHashCode4 + (map == null ? 0 : map.hashCode())) * 31;
        HashMap<String, String> map2 = this.apiUrlsInfo;
        int iHashCode6 = (iHashCode5 + (map2 == null ? 0 : map2.hashCode())) * 31;
        List<PassbookSettingsItem> list2 = this.passbookMenuSections;
        int iHashCode7 = (iHashCode6 + (list2 == null ? 0 : list2.hashCode())) * 31;
        HashMap<String, String> map3 = this.txnTypeToAccountLabelMap;
        int iHashCode8 = (iHashCode7 + (map3 == null ? 0 : map3.hashCode())) * 31;
        HashMap<String, String> map4 = this.txnCategoryMapping;
        int iHashCode9 = (iHashCode8 + (map4 == null ? 0 : map4.hashCode())) * 31;
        HashMap<String, String> map5 = this.statusKeyMapping;
        return iHashCode9 + (map5 != null ? map5.hashCode() : 0);
    }

    public final void setApiUrlsInfo(HashMap<String, String> map) {
        this.apiUrlsInfo = map;
    }

    public final void setAutoCompleteApiMetaInfo(AutoCompleteApiMetaInfo mY3jR) {
        this.autoCompleteApiMetaInfo = mY3jR;
    }

    public final void setFilters(List<UthFilter> list) {
        this.filters = list;
    }

    public final void setRoutingInfo(HashMap<String, String> map) {
        this.routingInfo = map;
    }

    public final void setStatusKeyMapping(HashMap<String, String> map) {
        this.statusKeyMapping = map;
    }

    public final void setTxnCategoryMapping(HashMap<String, String> map) {
        this.txnCategoryMapping = map;
    }

    public String toString() {
        return "UthSearchFilterMetaDataModel(filters=" + this.filters + ", metaInfo=" + this.metaInfo + ", search=" + this.search + ", autoCompleteApiMetaInfo=" + this.autoCompleteApiMetaInfo + ", routingInfo=" + this.routingInfo + ", apiUrlsInfo=" + this.apiUrlsInfo + ", passbookMenuSections=" + this.passbookMenuSections + ", txnTypeToAccountLabelMap=" + this.txnTypeToAccountLabelMap + ", txnCategoryMapping=" + this.txnCategoryMapping + ", statusKeyMapping=" + this.statusKeyMapping + ")";
    }

    public /* synthetic */ UthSearchFilterMetaDataModel(List list, UTHMetaInfo jqavh, Search n1vNRFSd, AutoCompleteApiMetaInfo mY3jR, HashMap map, HashMap map2, List list2, HashMap map3, HashMap map4, HashMap map5, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : list, (i10 & 2) != 0 ? null : jqavh, (i10 & 4) != 0 ? null : n1vNRFSd, (i10 & 8) != 0 ? null : mY3jR, (i10 & 16) != 0 ? null : map, (i10 & 32) != 0 ? null : map2, (i10 & 64) != 0 ? null : list2, (i10 & 128) != 0 ? null : map3, (i10 & 256) != 0 ? VVpVRy.aXYSYCVY() : map4, (i10 & ConstantsKt.MINIMUM_BLOCK_SIZE) != 0 ? VVpVRy.eszJ2B0a() : map5);
    }

    public UthSearchFilterMetaDataModel(List<UthFilter> list, UTHMetaInfo jqavh, Search n1vNRFSd, AutoCompleteApiMetaInfo mY3jR, HashMap<String, String> map, HashMap<String, String> map2, List<PassbookSettingsItem> list2, HashMap<String, String> map3, HashMap<String, String> map4, HashMap<String, String> map5) {
        this.filters = list;
        this.metaInfo = jqavh;
        this.search = n1vNRFSd;
        this.autoCompleteApiMetaInfo = mY3jR;
        this.routingInfo = map;
        this.apiUrlsInfo = map2;
        this.passbookMenuSections = list2;
        this.txnTypeToAccountLabelMap = map3;
        this.txnCategoryMapping = map4;
        this.statusKeyMapping = map5;
    }
}
