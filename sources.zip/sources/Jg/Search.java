package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.N1vNRFSd, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\b\u0087\b\u0018\u00002\u00020\u0001B-\u0012\u000e\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\t\u0010\nJ\u0018\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000b\u0010\fJ\u0012\u0010\r\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0004\b\r\u0010\u000eJ\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0004\b\u000f\u0010\u0010J:\u0010\u0011\u001a\u00020\u00002\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00022\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007HÆ\u0001¢\u0006\u0004\b\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0013HÖ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0017\u001a\u00020\u0016HÖ\u0001¢\u0006\u0004\b\u0017\u0010\u0018J\u001a\u0010\u001c\u001a\u00020\u001b2\b\u0010\u001a\u001a\u0004\u0018\u00010\u0019HÖ\u0003¢\u0006\u0004\b\u001c\u0010\u001dR\"\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u001e\u001a\u0004\b\u001f\u0010\fR\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010 \u001a\u0004\b!\u0010\u000eR\u001c\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010\"\u001a\u0004\b#\u0010\u0010¨\u0006$"}, d2 = {"LJg/N1vNRFSd;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "LJg/GU39Hcg;", "searchFields", "LJg/HicDZW;", "searchMetaInfo", "LJg/RFQ3AA8;", "contactBook", "<init>", "(Ljava/util/List;LJg/HicDZW;LJg/RFQ3AA8;)V", "component1", "()Ljava/util/List;", "component2", "()LJg/HicDZW;", "component3", "()LJg/RFQ3AA8;", "copy", "(Ljava/util/List;LJg/HicDZW;LJg/RFQ3AA8;)LJg/N1vNRFSd;", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/util/List;", "getSearchFields", "LJg/HicDZW;", "getSearchMetaInfo", "LJg/RFQ3AA8;", "getContactBook", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class Search extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("contactBook")
    private final ContactBook contactBook;

    @SerializedName("fields")
    private final List<SearchField> searchFields;

    @SerializedName("searchMetaInfo")
    private final SearchMetaInfo searchMetaInfo;

    public /* synthetic */ Search(List list, SearchMetaInfo searchMetaInfo, ContactBook contactBook, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(list, searchMetaInfo, (i10 & 4) != 0 ? null : contactBook);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Search copy$default(Search search, List list, SearchMetaInfo searchMetaInfo, ContactBook contactBook, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            list = search.searchFields;
        }
        if ((i10 & 2) != 0) {
            searchMetaInfo = search.searchMetaInfo;
        }
        if ((i10 & 4) != 0) {
            contactBook = search.contactBook;
        }
        return search.copy(list, searchMetaInfo, contactBook);
    }

    public final List<SearchField> component1() {
        return this.searchFields;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final SearchMetaInfo getSearchMetaInfo() {
        return this.searchMetaInfo;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final ContactBook getContactBook() {
        return this.contactBook;
    }

    public final Search copy(List<SearchField> searchFields, SearchMetaInfo searchMetaInfo, ContactBook contactBook) {
        return new Search(searchFields, searchMetaInfo, contactBook);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Search)) {
            return false;
        }
        Search search = (Search) other;
        return Intrinsics.areEqual(this.searchFields, search.searchFields) && Intrinsics.areEqual(this.searchMetaInfo, search.searchMetaInfo) && Intrinsics.areEqual(this.contactBook, search.contactBook);
    }

    public final ContactBook getContactBook() {
        return this.contactBook;
    }

    public final List<SearchField> getSearchFields() {
        return this.searchFields;
    }

    public final SearchMetaInfo getSearchMetaInfo() {
        return this.searchMetaInfo;
    }

    public int hashCode() {
        List<SearchField> list = this.searchFields;
        int iHashCode = (list == null ? 0 : list.hashCode()) * 31;
        SearchMetaInfo searchMetaInfo = this.searchMetaInfo;
        int iHashCode2 = (iHashCode + (searchMetaInfo == null ? 0 : searchMetaInfo.hashCode())) * 31;
        ContactBook contactBook = this.contactBook;
        return iHashCode2 + (contactBook != null ? contactBook.hashCode() : 0);
    }

    public String toString() {
        return "Search(searchFields=" + this.searchFields + ", searchMetaInfo=" + this.searchMetaInfo + ", contactBook=" + this.contactBook + ")";
    }

    public Search(List<SearchField> list, SearchMetaInfo searchMetaInfo, ContactBook contactBook) {
        this.searchFields = list;
        this.searchMetaInfo = searchMetaInfo;
        this.contactBook = contactBook;
    }
}
