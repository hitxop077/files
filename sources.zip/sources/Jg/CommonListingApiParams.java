package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.AAnYcst, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0007\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u0012\u0010\u0007\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0007\u0010\bJ\u0012\u0010\t\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\t\u0010\bJ(\u0010\n\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\n\u0010\u000bJ\u0010\u0010\r\u001a\u00020\fHÖ\u0001¢\u0006\u0004\b\r\u0010\u000eJ\u0010\u0010\u0010\u001a\u00020\u000fHÖ\u0001¢\u0006\u0004\b\u0010\u0010\u0011J\u001a\u0010\u0014\u001a\u00020\u00022\b\u0010\u0013\u001a\u0004\u0018\u00010\u0012HÖ\u0003¢\u0006\u0004\b\u0014\u0010\u0015R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u0016\u001a\u0004\b\u0017\u0010\bR\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0004\u0010\u0016\u001a\u0004\b\u0018\u0010\b¨\u0006\u0019"}, d2 = {"LJg/AAnYcst;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "filterApplied", "fromAutoComplete", "<init>", "(Ljava/lang/Boolean;Ljava/lang/Boolean;)V", "component1", "()Ljava/lang/Boolean;", "component2", "copy", "(Ljava/lang/Boolean;Ljava/lang/Boolean;)LJg/AAnYcst;", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/Boolean;", "getFilterApplied", "getFromAutoComplete", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class CommonListingApiParams extends IJRPaytmDataModel {
    public static final int $stable = 0;

    @SerializedName("filterApplied")
    private final Boolean filterApplied;

    @SerializedName("fromAutoComplete")
    private final Boolean fromAutoComplete;

    public CommonListingApiParams() {
        this(null, 0 == true ? 1 : 0, 3, 0 == true ? 1 : 0);
    }

    public static /* synthetic */ CommonListingApiParams copy$default(CommonListingApiParams commonListingApiParams, Boolean bool, Boolean bool2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            bool = commonListingApiParams.filterApplied;
        }
        if ((i10 & 2) != 0) {
            bool2 = commonListingApiParams.fromAutoComplete;
        }
        return commonListingApiParams.copy(bool, bool2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Boolean getFilterApplied() {
        return this.filterApplied;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Boolean getFromAutoComplete() {
        return this.fromAutoComplete;
    }

    public final CommonListingApiParams copy(Boolean filterApplied, Boolean fromAutoComplete) {
        return new CommonListingApiParams(filterApplied, fromAutoComplete);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CommonListingApiParams)) {
            return false;
        }
        CommonListingApiParams commonListingApiParams = (CommonListingApiParams) other;
        return Intrinsics.areEqual(this.filterApplied, commonListingApiParams.filterApplied) && Intrinsics.areEqual(this.fromAutoComplete, commonListingApiParams.fromAutoComplete);
    }

    public final Boolean getFilterApplied() {
        return this.filterApplied;
    }

    public final Boolean getFromAutoComplete() {
        return this.fromAutoComplete;
    }

    public int hashCode() {
        Boolean bool = this.filterApplied;
        int iHashCode = (bool == null ? 0 : bool.hashCode()) * 31;
        Boolean bool2 = this.fromAutoComplete;
        return iHashCode + (bool2 != null ? bool2.hashCode() : 0);
    }

    public String toString() {
        return "CommonListingApiParams(filterApplied=" + this.filterApplied + ", fromAutoComplete=" + this.fromAutoComplete + ")";
    }

    public /* synthetic */ CommonListingApiParams(Boolean bool, Boolean bool2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : bool, (i10 & 2) != 0 ? null : bool2);
    }

    public CommonListingApiParams(Boolean bool, Boolean bool2) {
        this.filterApplied = bool;
        this.fromAutoComplete = bool2;
    }
}
