package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.RFQ3AA8, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u0000\n\u0002\b\u000f\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\t\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b\n\u0010\u000bJ\u0012\u0010\f\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\f\u0010\rJ\u0012\u0010\u000e\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u000e\u0010\u000fJ\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0004\b\u0010\u0010\u0011J\u0012\u0010\u0012\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0004\b\u0012\u0010\u0013J@\u0010\u0014\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\bHÆ\u0001¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\bHÖ\u0001¢\u0006\u0004\b\u0016\u0010\u0013J\u0010\u0010\u0017\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u0017\u0010\u0018J\u001a\u0010\u001b\u001a\u00020\u00042\b\u0010\u001a\u001a\u0004\u0018\u00010\u0019HÖ\u0003¢\u0006\u0004\b\u001b\u0010\u001cR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u001d\u001a\u0004\b\u001e\u0010\rR$\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u001f\u001a\u0004\b\u0005\u0010\u000f\"\u0004\b \u0010!R$\u0010\u0007\u001a\u0004\u0018\u00010\u00068\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0007\u0010\"\u001a\u0004\b#\u0010\u0011\"\u0004\b$\u0010%R\u001c\u0010\t\u001a\u0004\u0018\u00010\b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010&\u001a\u0004\b'\u0010\u0013¨\u0006("}, d2 = {"LJg/RFQ3AA8;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "numOfContacts", "", "isActive", "LJg/LNd998w;", "contactBookListingApiParams", "", "requestParam", "<init>", "(Ljava/lang/Integer;Ljava/lang/Boolean;LJg/LNd998w;Ljava/lang/String;)V", "component1", "()Ljava/lang/Integer;", "component2", "()Ljava/lang/Boolean;", "component3", "()LJg/LNd998w;", "component4", "()Ljava/lang/String;", "copy", "(Ljava/lang/Integer;Ljava/lang/Boolean;LJg/LNd998w;Ljava/lang/String;)LJg/RFQ3AA8;", "toString", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/Integer;", "getNumOfContacts", "Ljava/lang/Boolean;", "setActive", "(Ljava/lang/Boolean;)V", "LJg/LNd998w;", "getContactBookListingApiParams", "setContactBookListingApiParams", "(LJg/LNd998w;)V", "Ljava/lang/String;", "getRequestParam", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class ContactBook extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("contactBookListingApiParams")
    private ContactBookListingApiParams contactBookListingApiParams;

    @SerializedName("isActive")
    private Boolean isActive;

    @SerializedName("maxNumOfContactBookNumbers")
    private final Integer numOfContacts;

    @SerializedName("requestParam")
    private final String requestParam;

    public ContactBook(Integer num, Boolean bool, ContactBookListingApiParams contactBookListingApiParams, String str) {
        this.numOfContacts = num;
        this.isActive = bool;
        this.contactBookListingApiParams = contactBookListingApiParams;
        this.requestParam = str;
    }

    public static /* synthetic */ ContactBook copy$default(ContactBook contactBook, Integer num, Boolean bool, ContactBookListingApiParams contactBookListingApiParams, String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            num = contactBook.numOfContacts;
        }
        if ((i10 & 2) != 0) {
            bool = contactBook.isActive;
        }
        if ((i10 & 4) != 0) {
            contactBookListingApiParams = contactBook.contactBookListingApiParams;
        }
        if ((i10 & 8) != 0) {
            str = contactBook.requestParam;
        }
        return contactBook.copy(num, bool, contactBookListingApiParams, str);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final Integer getNumOfContacts() {
        return this.numOfContacts;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Boolean getIsActive() {
        return this.isActive;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final ContactBookListingApiParams getContactBookListingApiParams() {
        return this.contactBookListingApiParams;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getRequestParam() {
        return this.requestParam;
    }

    public final ContactBook copy(Integer numOfContacts, Boolean isActive, ContactBookListingApiParams contactBookListingApiParams, String requestParam) {
        return new ContactBook(numOfContacts, isActive, contactBookListingApiParams, requestParam);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ContactBook)) {
            return false;
        }
        ContactBook contactBook = (ContactBook) other;
        return Intrinsics.areEqual(this.numOfContacts, contactBook.numOfContacts) && Intrinsics.areEqual(this.isActive, contactBook.isActive) && Intrinsics.areEqual(this.contactBookListingApiParams, contactBook.contactBookListingApiParams) && Intrinsics.areEqual(this.requestParam, contactBook.requestParam);
    }

    public final ContactBookListingApiParams getContactBookListingApiParams() {
        return this.contactBookListingApiParams;
    }

    public final Integer getNumOfContacts() {
        return this.numOfContacts;
    }

    public final String getRequestParam() {
        return this.requestParam;
    }

    public int hashCode() {
        Integer num = this.numOfContacts;
        int iHashCode = (num == null ? 0 : num.hashCode()) * 31;
        Boolean bool = this.isActive;
        int iHashCode2 = (iHashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        ContactBookListingApiParams contactBookListingApiParams = this.contactBookListingApiParams;
        int iHashCode3 = (iHashCode2 + (contactBookListingApiParams == null ? 0 : contactBookListingApiParams.hashCode())) * 31;
        String str = this.requestParam;
        return iHashCode3 + (str != null ? str.hashCode() : 0);
    }

    public final Boolean isActive() {
        return this.isActive;
    }

    public final void setActive(Boolean bool) {
        this.isActive = bool;
    }

    public final void setContactBookListingApiParams(ContactBookListingApiParams contactBookListingApiParams) {
        this.contactBookListingApiParams = contactBookListingApiParams;
    }

    public String toString() {
        return "ContactBook(numOfContacts=" + this.numOfContacts + ", isActive=" + this.isActive + ", contactBookListingApiParams=" + this.contactBookListingApiParams + ", requestParam=" + this.requestParam + ")";
    }
}
