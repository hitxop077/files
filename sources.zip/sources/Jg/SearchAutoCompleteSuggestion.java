package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.W7Cnq5, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0012\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0011\b\u0087\b\u0018\u00002\u00020\u0001BU\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\n\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\b¢\u0006\u0004\b\f\u0010\rJ\u0012\u0010\u000e\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u000e\u0010\u000fJ\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u0010\u0010\u0011J\u0012\u0010\u0012\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u0012\u0010\u0011J\u0012\u0010\u0013\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\u0013\u0010\u0011J\u0010\u0010\u0014\u001a\u00020\bHÆ\u0003¢\u0006\u0004\b\u0014\u0010\u0015J\u0010\u0010\u0016\u001a\u00020\bHÆ\u0003¢\u0006\u0004\b\u0016\u0010\u0015J\u0010\u0010\u0017\u001a\u00020\bHÆ\u0003¢\u0006\u0004\b\u0017\u0010\u0015J^\u0010\u0018\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00042\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\bHÆ\u0001¢\u0006\u0004\b\u0018\u0010\u0019J\u0010\u0010\u001a\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u001a\u0010\u0011J\u0010\u0010\u001c\u001a\u00020\u001bHÖ\u0001¢\u0006\u0004\b\u001c\u0010\u001dJ\u001a\u0010 \u001a\u00020\b2\b\u0010\u001f\u001a\u0004\u0018\u00010\u001eHÖ\u0003¢\u0006\u0004\b \u0010!R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\"\u001a\u0004\b#\u0010\u000fR$\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010$\u001a\u0004\b%\u0010\u0011\"\u0004\b&\u0010'R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0006\u0010$\u001a\u0004\b(\u0010\u0011R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0007\u0010$\u001a\u0004\b)\u0010\u0011R\u0017\u0010\t\u001a\u00020\b8\u0006¢\u0006\f\n\u0004\b\t\u0010*\u001a\u0004\b+\u0010\u0015R\"\u0010\n\u001a\u00020\b8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\n\u0010*\u001a\u0004\b,\u0010\u0015\"\u0004\b-\u0010.R\u0017\u0010\u000b\u001a\u00020\b8\u0006¢\u0006\f\n\u0004\b\u000b\u0010*\u001a\u0004\b\u000b\u0010\u0015¨\u0006/"}, d2 = {"LJg/W7Cnq5;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "LJg/XbU7b;", "listingApiParams", "", "value", "displayString", "fieldDisplayName", "", "flagAllResults", "flagAmount", "isHeader", "<init>", "(LJg/XbU7b;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)V", "component1", "()LJg/XbU7b;", "component2", "()Ljava/lang/String;", "component3", "component4", "component5", "()Z", "component6", "component7", "copy", "(LJg/XbU7b;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZ)LJg/W7Cnq5;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "LJg/XbU7b;", "getListingApiParams", "Ljava/lang/String;", "getValue", "setValue", "(Ljava/lang/String;)V", "getDisplayString", "getFieldDisplayName", "Z", "getFlagAllResults", "getFlagAmount", "setFlagAmount", "(Z)V", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class SearchAutoCompleteSuggestion extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("displayString")
    private final String displayString;

    @SerializedName("fieldDisplayName")
    private final String fieldDisplayName;
    private final boolean flagAllResults;
    private boolean flagAmount;
    private final boolean isHeader;

    @SerializedName("listingApiParams")
    private final SearchAutoCompleteListingApiParams listingApiParams;

    @SerializedName("value")
    private String value;

    public SearchAutoCompleteSuggestion() {
        this(null, null, null, null, false, false, false, 127, null);
    }

    public static /* synthetic */ SearchAutoCompleteSuggestion copy$default(SearchAutoCompleteSuggestion searchAutoCompleteSuggestion, SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams, String str, String str2, String str3, boolean z10, boolean z11, boolean z12, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            searchAutoCompleteListingApiParams = searchAutoCompleteSuggestion.listingApiParams;
        }
        if ((i10 & 2) != 0) {
            str = searchAutoCompleteSuggestion.value;
        }
        if ((i10 & 4) != 0) {
            str2 = searchAutoCompleteSuggestion.displayString;
        }
        if ((i10 & 8) != 0) {
            str3 = searchAutoCompleteSuggestion.fieldDisplayName;
        }
        if ((i10 & 16) != 0) {
            z10 = searchAutoCompleteSuggestion.flagAllResults;
        }
        if ((i10 & 32) != 0) {
            z11 = searchAutoCompleteSuggestion.flagAmount;
        }
        if ((i10 & 64) != 0) {
            z12 = searchAutoCompleteSuggestion.isHeader;
        }
        boolean z13 = z11;
        boolean z14 = z12;
        boolean z15 = z10;
        String str4 = str2;
        return searchAutoCompleteSuggestion.copy(searchAutoCompleteListingApiParams, str, str4, str3, z15, z13, z14);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final SearchAutoCompleteListingApiParams getListingApiParams() {
        return this.listingApiParams;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getValue() {
        return this.value;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getDisplayString() {
        return this.displayString;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getFieldDisplayName() {
        return this.fieldDisplayName;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final boolean getFlagAllResults() {
        return this.flagAllResults;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final boolean getFlagAmount() {
        return this.flagAmount;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final boolean getIsHeader() {
        return this.isHeader;
    }

    public final SearchAutoCompleteSuggestion copy(SearchAutoCompleteListingApiParams listingApiParams, String value, String displayString, String fieldDisplayName, boolean flagAllResults, boolean flagAmount, boolean isHeader) {
        return new SearchAutoCompleteSuggestion(listingApiParams, value, displayString, fieldDisplayName, flagAllResults, flagAmount, isHeader);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SearchAutoCompleteSuggestion)) {
            return false;
        }
        SearchAutoCompleteSuggestion searchAutoCompleteSuggestion = (SearchAutoCompleteSuggestion) other;
        return Intrinsics.areEqual(this.listingApiParams, searchAutoCompleteSuggestion.listingApiParams) && Intrinsics.areEqual(this.value, searchAutoCompleteSuggestion.value) && Intrinsics.areEqual(this.displayString, searchAutoCompleteSuggestion.displayString) && Intrinsics.areEqual(this.fieldDisplayName, searchAutoCompleteSuggestion.fieldDisplayName) && this.flagAllResults == searchAutoCompleteSuggestion.flagAllResults && this.flagAmount == searchAutoCompleteSuggestion.flagAmount && this.isHeader == searchAutoCompleteSuggestion.isHeader;
    }

    public final String getDisplayString() {
        return this.displayString;
    }

    public final String getFieldDisplayName() {
        return this.fieldDisplayName;
    }

    public final boolean getFlagAllResults() {
        return this.flagAllResults;
    }

    public final boolean getFlagAmount() {
        return this.flagAmount;
    }

    public final SearchAutoCompleteListingApiParams getListingApiParams() {
        return this.listingApiParams;
    }

    public final String getValue() {
        return this.value;
    }

    public int hashCode() {
        SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams = this.listingApiParams;
        int iHashCode = (searchAutoCompleteListingApiParams == null ? 0 : searchAutoCompleteListingApiParams.hashCode()) * 31;
        String str = this.value;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.displayString;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.fieldDisplayName;
        return ((((((iHashCode3 + (str3 != null ? str3.hashCode() : 0)) * 31) + Boolean.hashCode(this.flagAllResults)) * 31) + Boolean.hashCode(this.flagAmount)) * 31) + Boolean.hashCode(this.isHeader);
    }

    public final boolean isHeader() {
        return this.isHeader;
    }

    public final void setFlagAmount(boolean z10) {
        this.flagAmount = z10;
    }

    public final void setValue(String str) {
        this.value = str;
    }

    public String toString() {
        return "SearchAutoCompleteSuggestion(listingApiParams=" + this.listingApiParams + ", value=" + this.value + ", displayString=" + this.displayString + ", fieldDisplayName=" + this.fieldDisplayName + ", flagAllResults=" + this.flagAllResults + ", flagAmount=" + this.flagAmount + ", isHeader=" + this.isHeader + ")";
    }

    public /* synthetic */ SearchAutoCompleteSuggestion(SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams, String str, String str2, String str3, boolean z10, boolean z11, boolean z12, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : searchAutoCompleteListingApiParams, (i10 & 2) != 0 ? null : str, (i10 & 4) != 0 ? null : str2, (i10 & 8) != 0 ? null : str3, (i10 & 16) != 0 ? false : z10, (i10 & 32) != 0 ? false : z11, (i10 & 64) != 0 ? false : z12);
    }

    public SearchAutoCompleteSuggestion(SearchAutoCompleteListingApiParams searchAutoCompleteListingApiParams, String str, String str2, String str3, boolean z10, boolean z11, boolean z12) {
        this.listingApiParams = searchAutoCompleteListingApiParams;
        this.value = str;
        this.displayString = str2;
        this.fieldDisplayName = str3;
        this.flagAllResults = z10;
        this.flagAmount = z11;
        this.isHeader = z12;
    }
}
