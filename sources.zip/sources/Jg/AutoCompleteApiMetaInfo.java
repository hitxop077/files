package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.MY3jR, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0087\b\u0018\u00002\u00020\u0001B\u001b\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\b\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\n\u0010\u000bJ(\u0010\f\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004HÆ\u0001¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u000f\u001a\u00020\u000eHÖ\u0001¢\u0006\u0004\b\u000f\u0010\u0010J\u0010\u0010\u0012\u001a\u00020\u0011HÖ\u0001¢\u0006\u0004\b\u0012\u0010\u0013J\u001a\u0010\u0017\u001a\u00020\u00162\b\u0010\u0015\u001a\u0004\u0018\u00010\u0014HÖ\u0003¢\u0006\u0004\b\u0017\u0010\u0018R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u0019\u001a\u0004\b\u001a\u0010\tR\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u001b\u001a\u0004\b\u001c\u0010\u000b¨\u0006\u001d"}, d2 = {"LJg/MY3jR;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "LJg/W7Cnq5;", "amountSearch", "LJg/AAnYcst;", "commonListingApiParams", "<init>", "(LJg/W7Cnq5;LJg/AAnYcst;)V", "component1", "()LJg/W7Cnq5;", "component2", "()LJg/AAnYcst;", "copy", "(LJg/W7Cnq5;LJg/AAnYcst;)LJg/MY3jR;", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "LJg/W7Cnq5;", "getAmountSearch", "LJg/AAnYcst;", "getCommonListingApiParams", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class AutoCompleteApiMetaInfo extends IJRPaytmDataModel {
    public static final int $stable = 8;

    @SerializedName("amountSearch")
    private final SearchAutoCompleteSuggestion amountSearch;

    @SerializedName("commonListingApiParams")
    private final CommonListingApiParams commonListingApiParams;

    public AutoCompleteApiMetaInfo(SearchAutoCompleteSuggestion searchAutoCompleteSuggestion, CommonListingApiParams commonListingApiParams) {
        this.amountSearch = searchAutoCompleteSuggestion;
        this.commonListingApiParams = commonListingApiParams;
    }

    public static /* synthetic */ AutoCompleteApiMetaInfo copy$default(AutoCompleteApiMetaInfo autoCompleteApiMetaInfo, SearchAutoCompleteSuggestion searchAutoCompleteSuggestion, CommonListingApiParams commonListingApiParams, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            searchAutoCompleteSuggestion = autoCompleteApiMetaInfo.amountSearch;
        }
        if ((i10 & 2) != 0) {
            commonListingApiParams = autoCompleteApiMetaInfo.commonListingApiParams;
        }
        return autoCompleteApiMetaInfo.copy(searchAutoCompleteSuggestion, commonListingApiParams);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final SearchAutoCompleteSuggestion getAmountSearch() {
        return this.amountSearch;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final CommonListingApiParams getCommonListingApiParams() {
        return this.commonListingApiParams;
    }

    public final AutoCompleteApiMetaInfo copy(SearchAutoCompleteSuggestion amountSearch, CommonListingApiParams commonListingApiParams) {
        return new AutoCompleteApiMetaInfo(amountSearch, commonListingApiParams);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AutoCompleteApiMetaInfo)) {
            return false;
        }
        AutoCompleteApiMetaInfo autoCompleteApiMetaInfo = (AutoCompleteApiMetaInfo) other;
        return Intrinsics.areEqual(this.amountSearch, autoCompleteApiMetaInfo.amountSearch) && Intrinsics.areEqual(this.commonListingApiParams, autoCompleteApiMetaInfo.commonListingApiParams);
    }

    public final SearchAutoCompleteSuggestion getAmountSearch() {
        return this.amountSearch;
    }

    public final CommonListingApiParams getCommonListingApiParams() {
        return this.commonListingApiParams;
    }

    public int hashCode() {
        SearchAutoCompleteSuggestion searchAutoCompleteSuggestion = this.amountSearch;
        int iHashCode = (searchAutoCompleteSuggestion == null ? 0 : searchAutoCompleteSuggestion.hashCode()) * 31;
        CommonListingApiParams commonListingApiParams = this.commonListingApiParams;
        return iHashCode + (commonListingApiParams != null ? commonListingApiParams.hashCode() : 0);
    }

    public String toString() {
        return "AutoCompleteApiMetaInfo(amountSearch=" + this.amountSearch + ", commonListingApiParams=" + this.commonListingApiParams + ")";
    }
}
