package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.LNd998w, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0087\b\u0018\u00002\u00020\u0001B\u0011\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\u001c\u0010\b\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002HÆ\u0001¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\n\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\n\u0010\u0007J\u0010\u0010\f\u001a\u00020\u000bHÖ\u0001¢\u0006\u0004\b\f\u0010\rJ\u001a\u0010\u0011\u001a\u00020\u00102\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eHÖ\u0003¢\u0006\u0004\b\u0011\u0010\u0012R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u0013\u001a\u0004\b\u0014\u0010\u0007¨\u0006\u0015"}, d2 = {"LJg/LNd998w;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "searchType", "<init>", "(Ljava/lang/String;)V", "component1", "()Ljava/lang/String;", "copy", "(Ljava/lang/String;)LJg/LNd998w;", "toString", "", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getSearchType", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class ContactBookListingApiParams extends IJRPaytmDataModel {
    public static final int $stable = 0;

    @SerializedName("searchType")
    private final String searchType;

    public ContactBookListingApiParams(String str) {
        this.searchType = str;
    }

    public static /* synthetic */ ContactBookListingApiParams copy$default(ContactBookListingApiParams contactBookListingApiParams, String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = contactBookListingApiParams.searchType;
        }
        return contactBookListingApiParams.copy(str);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getSearchType() {
        return this.searchType;
    }

    public final ContactBookListingApiParams copy(String searchType) {
        return new ContactBookListingApiParams(searchType);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof ContactBookListingApiParams) && Intrinsics.areEqual(this.searchType, ((ContactBookListingApiParams) other).searchType);
    }

    public final String getSearchType() {
        return this.searchType;
    }

    public int hashCode() {
        String str = this.searchType;
        if (str == null) {
            return 0;
        }
        return str.hashCode();
    }

    public String toString() {
        return "ContactBookListingApiParams(searchType=" + this.searchType + ")";
    }
}
