package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;

/* JADX INFO: renamed from: Jg.HicDZW, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0087\b\u0018\u00002\u00020\u0001B\u001b\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\b\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\b\u0010\tJ\u0012\u0010\n\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b\n\u0010\u000bJ(\u0010\f\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004HÆ\u0001¢\u0006\u0004\b\f\u0010\rJ\u0010\u0010\u000e\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b\u000e\u0010\tJ\u0010\u0010\u000f\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b\u000f\u0010\u0010J\u001a\u0010\u0014\u001a\u00020\u00132\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011HÖ\u0003¢\u0006\u0004\b\u0014\u0010\u0015R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u0016\u001a\u0004\b\u0017\u0010\tR\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u0018\u001a\u0004\b\u0019\u0010\u000b¨\u0006\u001a"}, d2 = {"LJg/HicDZW;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "defaultRequestParam", "", "minLength", "<init>", "(Ljava/lang/String;Ljava/lang/Integer;)V", "component1", "()Ljava/lang/String;", "component2", "()Ljava/lang/Integer;", "copy", "(Ljava/lang/String;Ljava/lang/Integer;)LJg/HicDZW;", "toString", "hashCode", "()I", "", StateTabSnapshotBuilder.GROUP_OTHER, "", SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getDefaultRequestParam", "Ljava/lang/Integer;", "getMinLength", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class SearchMetaInfo extends IJRPaytmDataModel {
    public static final int $stable = 0;

    @SerializedName("defaultRequestParam")
    private final String defaultRequestParam;

    @SerializedName("minLength")
    private final Integer minLength;

    public SearchMetaInfo(String str, Integer num) {
        this.defaultRequestParam = str;
        this.minLength = num;
    }

    public static /* synthetic */ SearchMetaInfo copy$default(SearchMetaInfo searchMetaInfo, String str, Integer num, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = searchMetaInfo.defaultRequestParam;
        }
        if ((i10 & 2) != 0) {
            num = searchMetaInfo.minLength;
        }
        return searchMetaInfo.copy(str, num);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getDefaultRequestParam() {
        return this.defaultRequestParam;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Integer getMinLength() {
        return this.minLength;
    }

    public final SearchMetaInfo copy(String defaultRequestParam, Integer minLength) {
        return new SearchMetaInfo(defaultRequestParam, minLength);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SearchMetaInfo)) {
            return false;
        }
        SearchMetaInfo searchMetaInfo = (SearchMetaInfo) other;
        return Intrinsics.areEqual(this.defaultRequestParam, searchMetaInfo.defaultRequestParam) && Intrinsics.areEqual(this.minLength, searchMetaInfo.minLength);
    }

    public final String getDefaultRequestParam() {
        return this.defaultRequestParam;
    }

    public final Integer getMinLength() {
        return this.minLength;
    }

    public int hashCode() {
        String str = this.defaultRequestParam;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        Integer num = this.minLength;
        return iHashCode + (num != null ? num.hashCode() : 0);
    }

    public String toString() {
        return "SearchMetaInfo(defaultRequestParam=" + this.defaultRequestParam + ", minLength=" + this.minLength + ")";
    }
}
