package Jg;

import com.google.gson.annotations.SerializedName;
import com.paytm.network.model.IJRPaytmDataModel;
import com.paytm.network.utils.RedirectTrail;
import com.paytm.sprint.sdk.debug.StateTabSnapshotBuilder;
import java.util.Map;
import kotlin.Metadata;
import kotlin.io.ConstantsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.nativesdk.Constants.SDKConstants;
import net.one97.paytm.nativesdk.emiSubvention.utils.EmiUtil;
import net.one97.paytm.passbook.beans.searchFilterV2.FilterValidation;
import p497q7.SFMiYa;

/* JADX INFO: renamed from: Jg.Lx1jI, reason: from toString */
/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes13.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\bK\b\u0087\b\u0018\u00002\u00020\u0001BÌ\u0001\u0012\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\b\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\u0002\u0012\b\b\u0002\u0010\n\u001a\u00020\u0002\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u0002\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0010\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0006\u0012\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u0014\u0012\u001b\b\u0002\u0010\u0019\u001a\u0015\u0012\u0004\u0012\u00020\u0002\u0012\t\u0012\u00070\u0017¢\u0006\u0002\b\u0018\u0018\u00010\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\u0000¢\u0006\u0004\b\u001c\u0010\u001dJ\u0012\u0010\u001e\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b\u001e\u0010\u001fJ\u0012\u0010 \u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b \u0010!J\u0010\u0010\"\u001a\u00020\u0006HÆ\u0003¢\u0006\u0004\b\"\u0010#J\u0010\u0010$\u001a\u00020\u0006HÆ\u0003¢\u0006\u0004\b$\u0010#J\u0010\u0010%\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b%\u0010\u001fJ\u0010\u0010&\u001a\u00020\u0002HÆ\u0003¢\u0006\u0004\b&\u0010\u001fJ\u0012\u0010'\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b'\u0010\u001fJ\u0012\u0010(\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b(\u0010\u001fJ\u0012\u0010)\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b)\u0010\u001fJ\u0012\u0010*\u001a\u0004\u0018\u00010\u0004HÆ\u0003¢\u0006\u0004\b*\u0010!J\u0012\u0010+\u001a\u0004\u0018\u00010\u0002HÆ\u0003¢\u0006\u0004\b+\u0010\u001fJ\u0012\u0010,\u001a\u0004\u0018\u00010\u0010HÆ\u0003¢\u0006\u0004\b,\u0010-J\u0010\u0010.\u001a\u00020\u0006HÆ\u0003¢\u0006\u0004\b.\u0010#J\u0010\u0010/\u001a\u00020\u0006HÆ\u0003¢\u0006\u0004\b/\u0010#J\u0012\u00100\u001a\u0004\u0018\u00010\u0014HÆ\u0003¢\u0006\u0004\b0\u00101J#\u00102\u001a\u0015\u0012\u0004\u0012\u00020\u0002\u0012\t\u0012\u00070\u0017¢\u0006\u0002\b\u0018\u0018\u00010\u0016HÆ\u0003¢\u0006\u0004\b2\u00103JÕ\u0001\u00104\u001a\u00020\u00002\n\b\u0002\u0010\u0003\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00042\b\b\u0002\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\t\u001a\u00020\u00022\b\b\u0002\u0010\n\u001a\u00020\u00022\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u00022\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00102\b\b\u0002\u0010\u0012\u001a\u00020\u00062\b\b\u0002\u0010\u0013\u001a\u00020\u00062\n\b\u0002\u0010\u0015\u001a\u0004\u0018\u00010\u00142\u001b\b\u0002\u0010\u0019\u001a\u0015\u0012\u0004\u0012\u00020\u0002\u0012\t\u0012\u00070\u0017¢\u0006\u0002\b\u0018\u0018\u00010\u0016HÆ\u0001¢\u0006\u0004\b4\u00105J\u0010\u00106\u001a\u00020\u0002HÖ\u0001¢\u0006\u0004\b6\u0010\u001fJ\u0010\u00107\u001a\u00020\u0004HÖ\u0001¢\u0006\u0004\b7\u00108J\u001a\u0010:\u001a\u00020\u00062\b\u00109\u001a\u0004\u0018\u00010\u0017HÖ\u0003¢\u0006\u0004\b:\u0010;R$\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010<\u001a\u0004\b=\u0010\u001f\"\u0004\b>\u0010?R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0005\u0010@\u001a\u0004\bA\u0010!R\"\u0010\u0007\u001a\u00020\u00068\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0007\u0010B\u001a\u0004\b\u0007\u0010#\"\u0004\bC\u0010DR\u001a\u0010\b\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\b\u0010B\u001a\u0004\bE\u0010#R\u001a\u0010\t\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\t\u0010<\u001a\u0004\bF\u0010\u001fR\"\u0010\n\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\n\u0010<\u001a\u0004\bG\u0010\u001f\"\u0004\bH\u0010?R$\u0010\u000b\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u000b\u0010<\u001a\u0004\bI\u0010\u001f\"\u0004\bJ\u0010?R$\u0010\f\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\f\u0010<\u001a\u0004\bK\u0010\u001f\"\u0004\bL\u0010?R$\u0010\r\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\r\u0010<\u001a\u0004\bM\u0010\u001f\"\u0004\bN\u0010?R$\u0010\u000e\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010@\u001a\u0004\bO\u0010!\"\u0004\bP\u0010QR$\u0010\u000f\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u000f\u0010<\u001a\u0004\bR\u0010\u001f\"\u0004\bS\u0010?R$\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0006@\u0006X\u0087\u000e¢\u0006\u0012\n\u0004\b\u0011\u0010T\u001a\u0004\bU\u0010-\"\u0004\bV\u0010WR\"\u0010\u0012\u001a\u00020\u00068\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010B\u001a\u0004\b\u0012\u0010#\"\u0004\bX\u0010DR\"\u0010\u0013\u001a\u00020\u00068\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0013\u0010B\u001a\u0004\bY\u0010#\"\u0004\bZ\u0010DR$\u0010\u0015\u001a\u0004\u0018\u00010\u00148\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0015\u0010[\u001a\u0004\b\\\u00101\"\u0004\b]\u0010^R5\u0010\u0019\u001a\u0015\u0012\u0004\u0012\u00020\u0002\u0012\t\u0012\u00070\u0017¢\u0006\u0002\b\u0018\u0018\u00010\u00168\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0019\u0010_\u001a\u0004\b`\u00103\"\u0004\ba\u0010b¨\u0006c"}, d2 = {"LJg/Lx1jI;", "Lcom/paytm/network/model/IJRPaytmDataModel;", "", "displayName", "", "displayOrder", "", "isActive", "multiValueSelect", "requestParam", "requestParamValue", "type", "identifierKey", "identifierValue", "logoUrlDrawable", "logoUrl", "Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;", "validation", "isDefaultUpiAccount", SDKConstants.SELECTED, "", "amountValue", "", "", "Lkotlin/jvm/JvmSuppressWildcards;", "filterIdentifier", "<init>", "(Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;ZZLjava/lang/Double;Ljava/util/Map;)V", "clone", "()LJg/Lx1jI;", "component1", "()Ljava/lang/String;", "component2", "()Ljava/lang/Integer;", "component3", "()Z", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "()Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;", "component13", "component14", "component15", "()Ljava/lang/Double;", "component16", "()Ljava/util/Map;", "copy", "(Ljava/lang/String;Ljava/lang/Integer;ZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;ZZLjava/lang/Double;Ljava/util/Map;)LJg/Lx1jI;", "toString", "hashCode", "()I", StateTabSnapshotBuilder.GROUP_OTHER, SDKConstants.POSTPAID_VERIFICATION_OPERATOR_EQUALS, "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getDisplayName", "setDisplayName", "(Ljava/lang/String;)V", "Ljava/lang/Integer;", "getDisplayOrder", "Z", "setActive", "(Z)V", "getMultiValueSelect", "getRequestParam", "getRequestParamValue", "setRequestParamValue", "getType", "setType", "getIdentifierKey", "setIdentifierKey", "getIdentifierValue", "setIdentifierValue", "getLogoUrlDrawable", "setLogoUrlDrawable", "(Ljava/lang/Integer;)V", "getLogoUrl", "setLogoUrl", "Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;", "getValidation", "setValidation", "(Lnet/one97/paytm/passbook/beans/searchFilterV2/FilterValidation;)V", "setDefaultUpiAccount", "getSelected", "setSelected", "Ljava/lang/Double;", "getAmountValue", "setAmountValue", "(Ljava/lang/Double;)V", "Ljava/util/Map;", "getFilterIdentifier", "setFilterIdentifier", "(Ljava/util/Map;)V", "passbook_release"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final /* data */ class UthFilterValue extends IJRPaytmDataModel {
    public static final int $stable = 8;
    private Double amountValue;

    @SerializedName("displayName")
    private String displayName;

    @SerializedName("displayOrder")
    private final Integer displayOrder;
    private Map<String, Object> filterIdentifier;

    @SerializedName("identifierKey")
    private String identifierKey;

    @SerializedName("identifierValue")
    private String identifierValue;

    @SerializedName("isActive")
    private boolean isActive;
    private boolean isDefaultUpiAccount;

    @SerializedName("logoUrl")
    private String logoUrl;

    @SerializedName("logoUrlDrawable")
    private Integer logoUrlDrawable;

    @SerializedName("multiValueSelect")
    private final boolean multiValueSelect;

    @SerializedName("requestParam")
    private final String requestParam;

    @SerializedName("requestParamValue")
    private String requestParamValue;
    private boolean selected;

    @SerializedName("type")
    private String type;

    @SerializedName("validation")
    private FilterValidation validation;

    public UthFilterValue() {
        this(null, null, false, false, null, null, null, null, null, null, null, null, false, false, null, null, 65535, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ UthFilterValue copy$default(UthFilterValue uthFilterValue, String str, Integer num, boolean z10, boolean z11, String str2, String str3, String str4, String str5, String str6, Integer num2, String str7, FilterValidation filterValidation, boolean z12, boolean z13, Double d10, Map map, int i10, Object obj) {
        return uthFilterValue.copy((i10 & 1) != 0 ? uthFilterValue.displayName : str, (i10 & 2) != 0 ? uthFilterValue.displayOrder : num, (i10 & 4) != 0 ? uthFilterValue.isActive : z10, (i10 & 8) != 0 ? uthFilterValue.multiValueSelect : z11, (i10 & 16) != 0 ? uthFilterValue.requestParam : str2, (i10 & 32) != 0 ? uthFilterValue.requestParamValue : str3, (i10 & 64) != 0 ? uthFilterValue.type : str4, (i10 & 128) != 0 ? uthFilterValue.identifierKey : str5, (i10 & 256) != 0 ? uthFilterValue.identifierValue : str6, (i10 & ConstantsKt.MINIMUM_BLOCK_SIZE) != 0 ? uthFilterValue.logoUrlDrawable : num2, (i10 & RedirectTrail.MAX_SERIALIZED_LEN) != 0 ? uthFilterValue.logoUrl : str7, (i10 & EmiUtil.EMI_PLAN_REQUEST_CODE) != 0 ? uthFilterValue.validation : filterValidation, (i10 & 4096) != 0 ? uthFilterValue.isDefaultUpiAccount : z12, (i10 & 8192) != 0 ? uthFilterValue.selected : z13, (i10 & SFMiYa.REQUEST_CODE_DIGITAL_CREDIT_VERIFY_PASSCODE) != 0 ? uthFilterValue.amountValue : d10, (i10 & SFMiYa.REQUEST_CODE_DIGITAL_CREDIT_SET_PASSCODE) != 0 ? uthFilterValue.filterIdentifier : map);
    }

    public final UthFilterValue clone() {
        FilterValidation filterValidation = this.validation;
        return copy$default(this, null, null, false, false, null, null, null, null, null, null, null, filterValidation != null ? filterValidation.clone() : null, false, false, null, this.filterIdentifier, 30719, null);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getDisplayName() {
        return this.displayName;
    }

    /* JADX INFO: renamed from: component10, reason: from getter */
    public final Integer getLogoUrlDrawable() {
        return this.logoUrlDrawable;
    }

    /* JADX INFO: renamed from: component11, reason: from getter */
    public final String getLogoUrl() {
        return this.logoUrl;
    }

    /* JADX INFO: renamed from: component12, reason: from getter */
    public final FilterValidation getValidation() {
        return this.validation;
    }

    /* JADX INFO: renamed from: component13, reason: from getter */
    public final boolean getIsDefaultUpiAccount() {
        return this.isDefaultUpiAccount;
    }

    /* JADX INFO: renamed from: component14, reason: from getter */
    public final boolean getSelected() {
        return this.selected;
    }

    /* JADX INFO: renamed from: component15, reason: from getter */
    public final Double getAmountValue() {
        return this.amountValue;
    }

    public final Map<String, Object> component16() {
        return this.filterIdentifier;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Integer getDisplayOrder() {
        return this.displayOrder;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getIsActive() {
        return this.isActive;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final boolean getMultiValueSelect() {
        return this.multiValueSelect;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getRequestParam() {
        return this.requestParam;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getRequestParamValue() {
        return this.requestParamValue;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getType() {
        return this.type;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final String getIdentifierKey() {
        return this.identifierKey;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final String getIdentifierValue() {
        return this.identifierValue;
    }

    public final UthFilterValue copy(String displayName, Integer displayOrder, boolean isActive, boolean multiValueSelect, String requestParam, String requestParamValue, String type, String identifierKey, String identifierValue, Integer logoUrlDrawable, String logoUrl, FilterValidation validation, boolean isDefaultUpiAccount, boolean selected, Double amountValue, Map<String, Object> filterIdentifier) {
        Intrinsics.checkNotNullParameter(requestParam, "requestParam");
        Intrinsics.checkNotNullParameter(requestParamValue, "requestParamValue");
        return new UthFilterValue(displayName, displayOrder, isActive, multiValueSelect, requestParam, requestParamValue, type, identifierKey, identifierValue, logoUrlDrawable, logoUrl, validation, isDefaultUpiAccount, selected, amountValue, filterIdentifier);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UthFilterValue)) {
            return false;
        }
        UthFilterValue uthFilterValue = (UthFilterValue) other;
        return Intrinsics.areEqual(this.displayName, uthFilterValue.displayName) && Intrinsics.areEqual(this.displayOrder, uthFilterValue.displayOrder) && this.isActive == uthFilterValue.isActive && this.multiValueSelect == uthFilterValue.multiValueSelect && Intrinsics.areEqual(this.requestParam, uthFilterValue.requestParam) && Intrinsics.areEqual(this.requestParamValue, uthFilterValue.requestParamValue) && Intrinsics.areEqual(this.type, uthFilterValue.type) && Intrinsics.areEqual(this.identifierKey, uthFilterValue.identifierKey) && Intrinsics.areEqual(this.identifierValue, uthFilterValue.identifierValue) && Intrinsics.areEqual(this.logoUrlDrawable, uthFilterValue.logoUrlDrawable) && Intrinsics.areEqual(this.logoUrl, uthFilterValue.logoUrl) && Intrinsics.areEqual(this.validation, uthFilterValue.validation) && this.isDefaultUpiAccount == uthFilterValue.isDefaultUpiAccount && this.selected == uthFilterValue.selected && Intrinsics.areEqual((Object) this.amountValue, (Object) uthFilterValue.amountValue) && Intrinsics.areEqual(this.filterIdentifier, uthFilterValue.filterIdentifier);
    }

    public final Double getAmountValue() {
        return this.amountValue;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public final Integer getDisplayOrder() {
        return this.displayOrder;
    }

    public final Map<String, Object> getFilterIdentifier() {
        return this.filterIdentifier;
    }

    public final String getIdentifierKey() {
        return this.identifierKey;
    }

    public final String getIdentifierValue() {
        return this.identifierValue;
    }

    public final String getLogoUrl() {
        return this.logoUrl;
    }

    public final Integer getLogoUrlDrawable() {
        return this.logoUrlDrawable;
    }

    public final boolean getMultiValueSelect() {
        return this.multiValueSelect;
    }

    public final String getRequestParam() {
        return this.requestParam;
    }

    public final String getRequestParamValue() {
        return this.requestParamValue;
    }

    public final boolean getSelected() {
        return this.selected;
    }

    public final String getType() {
        return this.type;
    }

    public final FilterValidation getValidation() {
        return this.validation;
    }

    public int hashCode() {
        String str = this.displayName;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        Integer num = this.displayOrder;
        int iHashCode2 = (((((((((iHashCode + (num == null ? 0 : num.hashCode())) * 31) + Boolean.hashCode(this.isActive)) * 31) + Boolean.hashCode(this.multiValueSelect)) * 31) + this.requestParam.hashCode()) * 31) + this.requestParamValue.hashCode()) * 31;
        String str2 = this.type;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.identifierKey;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.identifierValue;
        int iHashCode5 = (iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31;
        Integer num2 = this.logoUrlDrawable;
        int iHashCode6 = (iHashCode5 + (num2 == null ? 0 : num2.hashCode())) * 31;
        String str5 = this.logoUrl;
        int iHashCode7 = (iHashCode6 + (str5 == null ? 0 : str5.hashCode())) * 31;
        FilterValidation filterValidation = this.validation;
        int iHashCode8 = (((((iHashCode7 + (filterValidation == null ? 0 : filterValidation.hashCode())) * 31) + Boolean.hashCode(this.isDefaultUpiAccount)) * 31) + Boolean.hashCode(this.selected)) * 31;
        Double d10 = this.amountValue;
        int iHashCode9 = (iHashCode8 + (d10 == null ? 0 : d10.hashCode())) * 31;
        Map<String, Object> map = this.filterIdentifier;
        return iHashCode9 + (map != null ? map.hashCode() : 0);
    }

    public final boolean isActive() {
        return this.isActive;
    }

    public final boolean isDefaultUpiAccount() {
        return this.isDefaultUpiAccount;
    }

    public final void setActive(boolean z10) {
        this.isActive = z10;
    }

    public final void setAmountValue(Double d10) {
        this.amountValue = d10;
    }

    public final void setDefaultUpiAccount(boolean z10) {
        this.isDefaultUpiAccount = z10;
    }

    public final void setDisplayName(String str) {
        this.displayName = str;
    }

    public final void setFilterIdentifier(Map<String, Object> map) {
        this.filterIdentifier = map;
    }

    public final void setIdentifierKey(String str) {
        this.identifierKey = str;
    }

    public final void setIdentifierValue(String str) {
        this.identifierValue = str;
    }

    public final void setLogoUrl(String str) {
        this.logoUrl = str;
    }

    public final void setLogoUrlDrawable(Integer num) {
        this.logoUrlDrawable = num;
    }

    public final void setRequestParamValue(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.requestParamValue = str;
    }

    public final void setSelected(boolean z10) {
        this.selected = z10;
    }

    public final void setType(String str) {
        this.type = str;
    }

    public final void setValidation(FilterValidation filterValidation) {
        this.validation = filterValidation;
    }

    public String toString() {
        return "UthFilterValue(displayName=" + this.displayName + ", displayOrder=" + this.displayOrder + ", isActive=" + this.isActive + ", multiValueSelect=" + this.multiValueSelect + ", requestParam=" + this.requestParam + ", requestParamValue=" + this.requestParamValue + ", type=" + this.type + ", identifierKey=" + this.identifierKey + ", identifierValue=" + this.identifierValue + ", logoUrlDrawable=" + this.logoUrlDrawable + ", logoUrl=" + this.logoUrl + ", validation=" + this.validation + ", isDefaultUpiAccount=" + this.isDefaultUpiAccount + ", selected=" + this.selected + ", amountValue=" + this.amountValue + ", filterIdentifier=" + this.filterIdentifier + ")";
    }

    public /* synthetic */ UthFilterValue(String str, Integer num, boolean z10, boolean z11, String str2, String str3, String str4, String str5, String str6, Integer num2, String str7, FilterValidation filterValidation, boolean z12, boolean z13, Double d10, Map map, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? 0 : num, (i10 & 4) != 0 ? false : z10, (i10 & 8) != 0 ? false : z11, (i10 & 16) != 0 ? "" : str2, (i10 & 32) == 0 ? str3 : "", (i10 & 64) != 0 ? null : str4, (i10 & 128) != 0 ? null : str5, (i10 & 256) != 0 ? null : str6, (i10 & ConstantsKt.MINIMUM_BLOCK_SIZE) != 0 ? null : num2, (i10 & RedirectTrail.MAX_SERIALIZED_LEN) != 0 ? null : str7, (i10 & EmiUtil.EMI_PLAN_REQUEST_CODE) != 0 ? null : filterValidation, (i10 & 4096) != 0 ? false : z12, (i10 & 8192) == 0 ? z13 : false, (i10 & SFMiYa.REQUEST_CODE_DIGITAL_CREDIT_VERIFY_PASSCODE) != 0 ? null : d10, (i10 & SFMiYa.REQUEST_CODE_DIGITAL_CREDIT_SET_PASSCODE) != 0 ? null : map);
    }

    public UthFilterValue(String str, Integer num, boolean z10, boolean z11, String requestParam, String requestParamValue, String str2, String str3, String str4, Integer num2, String str5, FilterValidation filterValidation, boolean z12, boolean z13, Double d10, Map<String, Object> map) {
        Intrinsics.checkNotNullParameter(requestParam, "requestParam");
        Intrinsics.checkNotNullParameter(requestParamValue, "requestParamValue");
        this.displayName = str;
        this.displayOrder = num;
        this.isActive = z10;
        this.multiValueSelect = z11;
        this.requestParam = requestParam;
        this.requestParamValue = requestParamValue;
        this.type = str2;
        this.identifierKey = str3;
        this.identifierValue = str4;
        this.logoUrlDrawable = num2;
        this.logoUrl = str5;
        this.validation = filterValidation;
        this.isDefaultUpiAccount = z12;
        this.selected = z13;
        this.amountValue = d10;
        this.filterIdentifier = map;
    }
}
