package Jh;

import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.passbook.uthlisting.domain.usercase.JQAVH;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class MY3jR {
    public final net.one97.paytm.passbook.syncmanager.domain.AAnYcst aXYSYCVY(p325ki.MY3jR repository, net.one97.paytm.passbook.caching.db.uthListing.AAnYcst uthListingCacheRules) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        Intrinsics.checkNotNullParameter(uthListingCacheRules, "uthListingCacheRules");
        return new net.one97.paytm.passbook.syncmanager.domain.AAnYcst(repository, uthListingCacheRules);
    }

    public final JQAVH eLbhX59K(p325ki.AAnYcst repository) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        return new JQAVH(repository);
    }

    public final net.one97.paytm.passbook.syncmanager.domain.MY3jR eszJ2B0a(p325ki.MY3jR repository, net.one97.paytm.passbook.caching.db.uthListing.AAnYcst uthListingCacheRules) {
        Intrinsics.checkNotNullParameter(repository, "repository");
        Intrinsics.checkNotNullParameter(uthListingCacheRules, "uthListingCacheRules");
        return new net.one97.paytm.passbook.syncmanager.domain.MY3jR(repository, uthListingCacheRules);
    }
}
