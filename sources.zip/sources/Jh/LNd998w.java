package Jh;

import X9.HicDZW;
import X9.N1vNRFSd;
import net.one97.paytm.passbook.uthlisting.domain.usercase.JQAVH;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes10.dex */
public abstract class LNd998w implements N1vNRFSd {
    public static JQAVH eszJ2B0a(MY3jR mY3jR, p325ki.AAnYcst aAnYcst) {
        return (JQAVH) HicDZW.ivfTYNl(mY3jR.eLbhX59K(aAnYcst));
    }
}
