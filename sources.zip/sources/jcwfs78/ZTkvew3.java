package jcwfs78;

import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class ZTkvew3 extends BcXKTU {
    public final WeakReference eszJ2B0a;

    public ZTkvew3(ZQB7k zQB7k) {
        this.eszJ2B0a = new WeakReference(zQB7k);
    }

    @Override // jcwfs78.BcXKTU
    public final void eszJ2B0a() {
        ZQB7k zQB7k = (ZQB7k) this.eszJ2B0a.get();
        if (zQB7k == null) {
            return;
        }
        ZQB7k.c1pvtY(zQB7k);
    }
}
