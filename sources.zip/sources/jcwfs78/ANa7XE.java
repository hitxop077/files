package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class ANa7XE extends U080F {
    public final /* synthetic */ VI3TfJlk.MY3jR ivfTYNl;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ANa7XE(VI3TfJlk.MY3jR mY3jR, Lx1jI lx1jI, Feature[] featureArr, boolean z10, int i10) {
        super(lx1jI, featureArr, z10, i10);
        this.ivfTYNl = mY3jR;
    }

    @Override // jcwfs78.U080F
    public final void zDWsfFRp(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW) {
        this.ivfTYNl.eszJ2B0a.accept(aAnYcst, hicDZW);
    }
}
