package jcwfs78;

import android.app.Dialog;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Sk4GIh extends BcXKTU {
    public final /* synthetic */ UhFXwfhx aXYSYCVY;
    public final /* synthetic */ Dialog eszJ2B0a;

    public Sk4GIh(UhFXwfhx uhFXwfhx, Dialog dialog) {
        this.aXYSYCVY = uhFXwfhx;
        this.eszJ2B0a = dialog;
    }

    @Override // jcwfs78.BcXKTU
    public final void eszJ2B0a() {
        this.aXYSYCVY.vo5p9AUA.yxejkub();
        if (this.eszJ2B0a.isShowing()) {
            this.eszJ2B0a.dismiss();
        }
    }
}
