package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class HUwff {
    public final XR9Xco aXYSYCVY;
    public final Runnable eLbhX59K;
    public final U080F eszJ2B0a;

    public HUwff(U080F u080f, XR9Xco xR9Xco, Runnable runnable) {
        this.eszJ2B0a = u080f;
        this.aXYSYCVY = xR9Xco;
        this.eLbhX59K = runnable;
    }
}
