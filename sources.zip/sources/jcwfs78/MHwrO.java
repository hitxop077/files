package jcwfs78;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class MHwrO implements com.google.android.gms.common.api.N1vNRFSd.AAnYcst, com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 {
    public DuA2vx gmzPK;
    public final com.google.android.gms.common.api.MY3jR njNibPNp;
    public final boolean vo5p9AUA;

    public MHwrO(com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
        this.njNibPNp = mY3jR;
        this.vo5p9AUA = z10;
    }

    public final DuA2vx aXYSYCVY() {
        f5zilcb.VVpVRy.uYRSwDm(this.gmzPK, "Callbacks must be attached to a ClientConnectionHelper instance before connecting the client.");
        return this.gmzPK;
    }

    public final void eszJ2B0a(DuA2vx duA2vx) {
        this.gmzPK = duA2vx;
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnected(Bundle bundle) {
        aXYSYCVY().onConnected(bundle);
    }

    @Override // jcwfs78.SFMiYa
    public final void onConnectionFailed(ConnectionResult connectionResult) {
        aXYSYCVY().m8rcW6(connectionResult, this.njNibPNp, this.vo5p9AUA);
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnectionSuspended(int i10) {
        aXYSYCVY().onConnectionSuspended(i10);
    }
}
