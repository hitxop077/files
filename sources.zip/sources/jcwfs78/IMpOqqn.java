package jcwfs78;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class IMpOqqn {
    public final Map eszJ2B0a = Collections.synchronizedMap(new WeakHashMap());
    public final Map aXYSYCVY = Collections.synchronizedMap(new WeakHashMap());

    public final boolean dUI84() {
        return (this.eszJ2B0a.isEmpty() && this.aXYSYCVY.isEmpty()) ? false : true;
    }

    public final void eLbhX59K(BasePendingResult basePendingResult, boolean z10) {
        this.eszJ2B0a.put(basePendingResult, Boolean.valueOf(z10));
        basePendingResult.eLbhX59K(new LksRT6(this, basePendingResult));
    }

    public final void ivfTYNl(int i10, String str) {
        StringBuilder sb2 = new StringBuilder("The connection to Google Play services was lost");
        if (i10 == 1) {
            sb2.append(" due to service disconnection.");
        } else if (i10 == 3) {
            sb2.append(" due to dead object exception.");
        }
        if (str != null) {
            sb2.append(" Last reason for disconnect: ");
            sb2.append(str);
        }
        oZ7qYn(true, new Status(20, sb2.toString()));
    }

    public final void oZ7qYn(boolean z10, Status status) {
        HashMap map;
        HashMap map2;
        synchronized (this.eszJ2B0a) {
            map = new HashMap(this.eszJ2B0a);
        }
        synchronized (this.aXYSYCVY) {
            map2 = new HashMap(this.aXYSYCVY);
        }
        for (Map.Entry entry : map.entrySet()) {
            if (z10 || ((Boolean) entry.getValue()).booleanValue()) {
                ((BasePendingResult) entry.getKey()).oZ7qYn(status);
            }
        }
        for (Map.Entry entry2 : map2.entrySet()) {
            if (z10 || ((Boolean) entry2.getValue()).booleanValue()) {
                ((a4dh7ol.HicDZW) entry2.getKey()).zDWsfFRp(new ApiException(status));
            }
        }
    }

    public final void osx7Pl0E() {
        oZ7qYn(false, XbU7b.sRtu3PUY);
    }

    public final void zDWsfFRp(a4dh7ol.HicDZW hicDZW, boolean z10) {
        this.aXYSYCVY.put(hicDZW, Boolean.valueOf(z10));
        hicDZW.eszJ2B0a().addOnCompleteListener(new RkdvoZ(this, hicDZW));
    }
}
