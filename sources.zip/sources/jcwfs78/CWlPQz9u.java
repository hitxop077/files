package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class CWlPQz9u implements Runnable {
    public final /* synthetic */ BgOcqi njNibPNp;

    public abstract void eszJ2B0a();

    @Override // java.lang.Runnable
    public final void run() {
        this.njNibPNp.aXYSYCVY.lock();
        try {
            try {
                if (!Thread.interrupted()) {
                    eszJ2B0a();
                }
            } catch (RuntimeException e10) {
                this.njNibPNp.eszJ2B0a.mTWLV(e10);
            }
        } finally {
            this.njNibPNp.aXYSYCVY.unlock();
        }
    }
}
