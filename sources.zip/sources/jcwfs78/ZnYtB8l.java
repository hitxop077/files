package jcwfs78;

import android.os.Looper;
import android.os.Message;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class ZnYtB8l extends ir9vwy.VVpVRy {
    public final /* synthetic */ DrXCNOo9 aXYSYCVY;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ZnYtB8l(DrXCNOo9 drXCNOo9, Looper looper) {
        super(looper);
        this.aXYSYCVY = drXCNOo9;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 1) {
            ((VX4rr) message.obj).aXYSYCVY(this.aXYSYCVY);
        } else if (i10 == 2) {
            throw ((RuntimeException) message.obj);
        }
    }
}
