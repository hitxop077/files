package jcwfs78;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class RFQ3AA8 implements Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {
    public static final RFQ3AA8 xINpNt2d = new RFQ3AA8();
    public final AtomicBoolean njNibPNp = new AtomicBoolean();
    public final AtomicBoolean vo5p9AUA = new AtomicBoolean();
    public final ArrayList gmzPK = new ArrayList();
    public boolean zYD7SXW6 = false;

    /* JADX INFO: compiled from: Obfuscated */
    public interface MY3jR {
        void eszJ2B0a(boolean z10);
    }

    public static RFQ3AA8 ivfTYNl() {
        return xINpNt2d;
    }

    public static void osx7Pl0E(Application application) {
        RFQ3AA8 rfq3aa8 = xINpNt2d;
        synchronized (rfq3aa8) {
            try {
                if (!rfq3aa8.zYD7SXW6) {
                    application.registerActivityLifecycleCallbacks(rfq3aa8);
                    application.registerComponentCallbacks(rfq3aa8);
                    rfq3aa8.zYD7SXW6 = true;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public boolean dUI84() {
        return this.njNibPNp.get();
    }

    public boolean oZ7qYn(boolean z10) {
        AtomicBoolean atomicBoolean = this.vo5p9AUA;
        if (!atomicBoolean.get()) {
            if (an89d.Gyx10a.aXYSYCVY()) {
                return z10;
            }
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(runningAppProcessInfo);
            if (!atomicBoolean.getAndSet(true) && runningAppProcessInfo.importance > 100) {
                this.njNibPNp.set(true);
            }
        }
        return dUI84();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
        AtomicBoolean atomicBoolean = this.vo5p9AUA;
        boolean zCompareAndSet = this.njNibPNp.compareAndSet(true, false);
        atomicBoolean.set(true);
        if (zCompareAndSet) {
            rjljd6i(false);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
        AtomicBoolean atomicBoolean = this.vo5p9AUA;
        boolean zCompareAndSet = this.njNibPNp.compareAndSet(true, false);
        atomicBoolean.set(true);
        if (zCompareAndSet) {
            rjljd6i(false);
        }
    }

    @Override // android.content.ComponentCallbacks2
    public final void onTrimMemory(int i10) {
        if (i10 == 20 && this.njNibPNp.compareAndSet(false, true)) {
            this.vo5p9AUA.set(true);
            rjljd6i(true);
        }
    }

    public final void rjljd6i(boolean z10) {
        synchronized (xINpNt2d) {
            try {
                Iterator it2 = this.gmzPK.iterator();
                while (it2.hasNext()) {
                    ((MY3jR) it2.next()).eszJ2B0a(z10);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void zDWsfFRp(MY3jR mY3jR) {
        synchronized (xINpNt2d) {
            this.gmzPK.add(mY3jR);
        }
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
