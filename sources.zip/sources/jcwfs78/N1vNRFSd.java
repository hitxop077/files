package jcwfs78;

import android.os.Bundle;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface N1vNRFSd {
    void onConnected(Bundle bundle);

    void onConnectionSuspended(int i10);
}
