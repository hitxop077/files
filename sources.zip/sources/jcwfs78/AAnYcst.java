package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class AAnYcst {
    public final com.google.android.gms.common.api.MY3jR aXYSYCVY;
    public final com.google.android.gms.common.api.MY3jR.LNd998w eLbhX59K;
    public final int eszJ2B0a;
    public final String zDWsfFRp;

    public AAnYcst(com.google.android.gms.common.api.MY3jR mY3jR, com.google.android.gms.common.api.MY3jR.LNd998w lNd998w, String str) {
        this.aXYSYCVY = mY3jR;
        this.eLbhX59K = lNd998w;
        this.zDWsfFRp = str;
        this.eszJ2B0a = f5zilcb.Lx1jI.aXYSYCVY(mY3jR, lNd998w, str);
    }

    public static AAnYcst eszJ2B0a(com.google.android.gms.common.api.MY3jR mY3jR, com.google.android.gms.common.api.MY3jR.LNd998w lNd998w, String str) {
        return new AAnYcst(mY3jR, lNd998w, str);
    }

    public final String aXYSYCVY() {
        return this.aXYSYCVY.zDWsfFRp();
    }

    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof AAnYcst)) {
            return false;
        }
        AAnYcst aAnYcst = (AAnYcst) obj;
        return f5zilcb.Lx1jI.eszJ2B0a(this.aXYSYCVY, aAnYcst.aXYSYCVY) && f5zilcb.Lx1jI.eszJ2B0a(this.eLbhX59K, aAnYcst.eLbhX59K) && f5zilcb.Lx1jI.eszJ2B0a(this.zDWsfFRp, aAnYcst.zDWsfFRp);
    }

    public final int hashCode() {
        return this.eszJ2B0a;
    }
}
