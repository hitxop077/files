package jcwfs78;

import android.os.Looper;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class Bv3FS {
    public final Set eszJ2B0a = Collections.newSetFromMap(new WeakHashMap());

    public static Lx1jI aXYSYCVY(Object obj, Executor executor, String str) {
        f5zilcb.VVpVRy.uYRSwDm(obj, "Listener must not be null");
        f5zilcb.VVpVRy.uYRSwDm(executor, "Executor must not be null");
        f5zilcb.VVpVRy.uYRSwDm(str, "Listener type must not be null");
        return new Lx1jI(executor, obj, str);
    }

    public static Lx1jI.MY3jR eLbhX59K(Object obj, String str) {
        f5zilcb.VVpVRy.uYRSwDm(obj, "Listener must not be null");
        f5zilcb.VVpVRy.uYRSwDm(str, "Listener type must not be null");
        f5zilcb.VVpVRy.oZ7qYn(str, "Listener type must not be empty");
        return new Lx1jI.MY3jR(obj, str);
    }

    public static Lx1jI eszJ2B0a(Object obj, Looper looper, String str) {
        f5zilcb.VVpVRy.uYRSwDm(obj, "Listener must not be null");
        f5zilcb.VVpVRy.uYRSwDm(looper, "Looper must not be null");
        f5zilcb.VVpVRy.uYRSwDm(str, "Listener type must not be null");
        return new Lx1jI(looper, obj, str);
    }

    public final void zDWsfFRp() {
        Iterator it2 = this.eszJ2B0a.iterator();
        while (it2.hasNext()) {
            ((Lx1jI) it2.next()).eszJ2B0a();
        }
        this.eszJ2B0a.clear();
    }
}
