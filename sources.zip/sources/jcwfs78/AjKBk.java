package jcwfs78;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface AjKBk {
    void aXYSYCVY(Bundle bundle);

    void eLbhX59K(ConnectionResult connectionResult);

    void eszJ2B0a(int i10, boolean z10);
}
