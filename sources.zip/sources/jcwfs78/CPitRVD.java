package jcwfs78;

import android.os.Looper;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class CPitRVD extends AliKj1I {
    public final com.google.android.gms.common.api.LNd998w eLbhX59K;

    public CPitRVD(com.google.android.gms.common.api.LNd998w lNd998w) {
        super("Method is not supported by connectionless client. APIs supporting connectionless client must not call this method.");
        this.eLbhX59K = lNd998w;
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final com.google.android.gms.common.api.internal.MY3jR dUI84(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        return this.eLbhX59K.yxejkub(mY3jR);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final com.google.android.gms.common.api.internal.MY3jR oZ7qYn(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        return this.eLbhX59K.rtsRj(mY3jR);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final Looper qLLw0g() {
        return this.eLbhX59K.mK94T();
    }
}
