package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class FOuNY {
    public final /* synthetic */ C7hy1o eszJ2B0a;

    public FOuNY(C7hy1o c7hy1o) {
        this.eszJ2B0a = c7hy1o;
    }
}
