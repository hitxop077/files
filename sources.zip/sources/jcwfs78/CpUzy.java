package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class CpUzy extends XR9Xco {
    public final /* synthetic */ VI3TfJlk.MY3jR aXYSYCVY;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CpUzy(VI3TfJlk.MY3jR mY3jR, Lx1jI.MY3jR mY3jR2) {
        super(mY3jR2);
        this.aXYSYCVY = mY3jR;
    }

    @Override // jcwfs78.XR9Xco
    public final void aXYSYCVY(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW) {
        this.aXYSYCVY.aXYSYCVY.accept(aAnYcst, hicDZW);
    }
}
