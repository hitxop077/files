package jcwfs78;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.zav;
import com.google.android.gms.signin.internal.zak;
import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class HUx1xD extends qkwfhx.RFQ3AA8 implements com.google.android.gms.common.api.N1vNRFSd.AAnYcst, com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 {
    public static final com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR pz7TsV = g0f7s.LNd998w.eLbhX59K;
    public g0f7s.N1vNRFSd fdmP9GD;
    public final com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR gmzPK;
    public final Context njNibPNp;
    public final Handler vo5p9AUA;
    public FtzTzIH2 vskcqLTQ;
    public final f5zilcb.LNd998w xINpNt2d;
    public final Set zYD7SXW6;

    public HUx1xD(Context context, Handler handler, f5zilcb.LNd998w lNd998w) {
        com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR = pz7TsV;
        this.njNibPNp = context;
        this.vo5p9AUA = handler;
        this.xINpNt2d = (f5zilcb.LNd998w) f5zilcb.VVpVRy.uYRSwDm(lNd998w, "ClientSettings must not be null");
        this.zYD7SXW6 = lNd998w.dUI84();
        this.gmzPK = abstractC0848MY3jR;
    }

    public static /* bridge */ /* synthetic */ void ahxwvx7(HUx1xD hUx1xD, zak zakVar) {
        ConnectionResult connectionResultQLLw0g = zakVar.qLLw0g();
        if (connectionResultQLLw0g.zlPyDfl()) {
            zav zavVar = (zav) f5zilcb.VVpVRy.uTIfLNK0(zakVar.q1ORKN());
            ConnectionResult connectionResultQLLw0g2 = zavVar.qLLw0g();
            if (!connectionResultQLLw0g2.zlPyDfl()) {
                String strValueOf = String.valueOf(connectionResultQLLw0g2);
                new Exception();
                "Sign-in succeeded with resolve account failure: ".concat(strValueOf);
                hUx1xD.vskcqLTQ.zDWsfFRp(connectionResultQLLw0g2);
                hUx1xD.fdmP9GD.aXYSYCVY();
                return;
            }
            hUx1xD.vskcqLTQ.aXYSYCVY(zavVar.q1ORKN(), hUx1xD.zYD7SXW6);
        } else {
            hUx1xD.vskcqLTQ.zDWsfFRp(connectionResultQLLw0g);
        }
        hUx1xD.fdmP9GD.aXYSYCVY();
    }

    @Override // qkwfhx.N1vNRFSd
    public final void k85yoboL(zak zakVar) {
        this.vo5p9AUA.post(new IGmZk(this, zakVar));
    }

    public final void mbqfW() {
        g0f7s.N1vNRFSd n1vNRFSd = this.fdmP9GD;
        if (n1vNRFSd != null) {
            n1vNRFSd.aXYSYCVY();
        }
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [com.google.android.gms.common.api.MY3jR$XbU7b, g0f7s.N1vNRFSd] */
    public final void mnnFu(FtzTzIH2 ftzTzIH2) {
        g0f7s.N1vNRFSd n1vNRFSd = this.fdmP9GD;
        if (n1vNRFSd != null) {
            n1vNRFSd.aXYSYCVY();
        }
        this.xINpNt2d.q1ORKN(Integer.valueOf(System.identityHashCode(this)));
        com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR = this.gmzPK;
        Context context = this.njNibPNp;
        Handler handler = this.vo5p9AUA;
        f5zilcb.LNd998w lNd998w = this.xINpNt2d;
        this.fdmP9GD = abstractC0848MY3jR.eLbhX59K(context, handler.getLooper(), lNd998w, lNd998w.oZ7qYn(), this, this);
        this.vskcqLTQ = ftzTzIH2;
        Set set = this.zYD7SXW6;
        if (set == null || set.isEmpty()) {
            this.vo5p9AUA.post(new PI2oT3rO(this));
        } else {
            this.fdmP9GD.oZ7qYn();
        }
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnected(Bundle bundle) {
        this.fdmP9GD.yxejkub(this);
    }

    @Override // jcwfs78.SFMiYa
    public final void onConnectionFailed(ConnectionResult connectionResult) {
        this.vskcqLTQ.zDWsfFRp(connectionResult);
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnectionSuspended(int i10) {
        this.vskcqLTQ.eLbhX59K(i10);
    }
}
