package jcwfs78;

import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class PI2oT3rO implements Runnable {
    public final /* synthetic */ HUx1xD njNibPNp;

    public PI2oT3rO(HUx1xD hUx1xD) {
        this.njNibPNp = hUx1xD;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.njNibPNp.vskcqLTQ.zDWsfFRp(new ConnectionResult(4));
    }
}
