package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class ItX6BnZf extends VX4rr {
    public final /* synthetic */ ZKBAd aXYSYCVY;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ItX6BnZf(ZKBAd zKBAd, AL02fFI aL02fFI) {
        super(aL02fFI);
        this.aXYSYCVY = zKBAd;
    }

    @Override // jcwfs78.VX4rr
    public final void eszJ2B0a() {
        this.aXYSYCVY.eLbhX59K(1);
    }
}
