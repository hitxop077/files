package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class VI3TfJlk {
    public final XR9Xco aXYSYCVY;
    public final Runnable eLbhX59K;
    public final U080F eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public Gyx10a aXYSYCVY;
        public int dUI84;
        public Gyx10a eszJ2B0a;
        public Feature[] ivfTYNl;
        public Lx1jI zDWsfFRp;
        public Runnable eLbhX59K = new Runnable() { // from class: jcwfs78.LzHtV
            @Override // java.lang.Runnable
            public final void run() {
            }
        };
        public boolean osx7Pl0E = true;

        public /* synthetic */ MY3jR(IvVqPzQ ivVqPzQ) {
        }

        public MY3jR aXYSYCVY(Gyx10a gyx10a) {
            this.eszJ2B0a = gyx10a;
            return this;
        }

        public MY3jR dUI84(Lx1jI lx1jI) {
            this.zDWsfFRp = lx1jI;
            return this;
        }

        public MY3jR eLbhX59K(boolean z10) {
            this.osx7Pl0E = z10;
            return this;
        }

        public VI3TfJlk eszJ2B0a() {
            f5zilcb.VVpVRy.aXYSYCVY(this.eszJ2B0a != null, "Must set register function");
            f5zilcb.VVpVRy.aXYSYCVY(this.aXYSYCVY != null, "Must set unregister function");
            f5zilcb.VVpVRy.aXYSYCVY(this.zDWsfFRp != null, "Must set holder");
            return new VI3TfJlk(new ANa7XE(this, this.zDWsfFRp, this.ivfTYNl, this.osx7Pl0E, this.dUI84), new CpUzy(this, (Lx1jI.MY3jR) f5zilcb.VVpVRy.uYRSwDm(this.zDWsfFRp.aXYSYCVY(), "Key must not be null")), this.eLbhX59K, null);
        }

        public MY3jR ivfTYNl(int i10) {
            this.dUI84 = i10;
            return this;
        }

        public MY3jR osx7Pl0E(Gyx10a gyx10a) {
            this.aXYSYCVY = gyx10a;
            return this;
        }

        public MY3jR zDWsfFRp(Feature... featureArr) {
            this.ivfTYNl = featureArr;
            return this;
        }
    }

    public /* synthetic */ VI3TfJlk(U080F u080f, XR9Xco xR9Xco, Runnable runnable, IDClkQ0 iDClkQ0) {
        this.eszJ2B0a = u080f;
        this.aXYSYCVY = xR9Xco;
        this.eLbhX59K = runnable;
    }

    public static MY3jR eszJ2B0a() {
        return new MY3jR(null);
    }
}
