package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class ArqY6z implements Runnable {
    public final /* synthetic */ H8UuVVi njNibPNp;

    public ArqY6z(H8UuVVi h8UuVVi) {
        this.njNibPNp = h8UuVVi;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.njNibPNp.bBHqyf.lock();
        try {
            H8UuVVi.eImdmIyv(this.njNibPNp);
        } finally {
            this.njNibPNp.bBHqyf.unlock();
        }
    }
}
