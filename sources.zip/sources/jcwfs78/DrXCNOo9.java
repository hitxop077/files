package jcwfs78;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class DrXCNOo9 implements ZIAa4n, DuA2vx {
    public int bBHqyf;
    public final AjKBk cOkM2;
    public final Map dNE3s;
    public final Map fdmP9GD;
    public final Context gmzPK;
    public final com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR i2VlO;
    public final Lock njNibPNp;
    public final f5zilcb.LNd998w pz7TsV;
    public final Condition vo5p9AUA;
    public final ZnYtB8l xINpNt2d;
    public final ZQB7k xnFvJEz;
    public final uchv3v.XbU7b zYD7SXW6;
    public volatile AL02fFI zigsCJW;
    public final Map vskcqLTQ = new HashMap();
    public ConnectionResult ca3iT = null;

    public DrXCNOo9(Context context, ZQB7k zQB7k, Lock lock, Looper looper, uchv3v.XbU7b xbU7b, Map map, f5zilcb.LNd998w lNd998w, Map map2, com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR, ArrayList arrayList, AjKBk ajKBk) {
        this.gmzPK = context;
        this.njNibPNp = lock;
        this.zYD7SXW6 = xbU7b;
        this.fdmP9GD = map;
        this.pz7TsV = lNd998w;
        this.dNE3s = map2;
        this.i2VlO = abstractC0848MY3jR;
        this.xnFvJEz = zQB7k;
        this.cOkM2 = ajKBk;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((MHwrO) arrayList.get(i10)).eszJ2B0a(this);
        }
        this.xINpNt2d = new ZnYtB8l(this, looper);
        this.vo5p9AUA = lock.newCondition();
        this.zigsCJW = new FsJiNjAN(this);
    }

    @Override // jcwfs78.ZIAa4n
    public final com.google.android.gms.common.api.internal.MY3jR aXYSYCVY(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        mY3jR.yxejkub();
        return this.zigsCJW.osx7Pl0E(mY3jR);
    }

    @Override // jcwfs78.ZIAa4n
    public final void dUI84(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append((CharSequence) str).append("mState=").println(this.zigsCJW);
        for (com.google.android.gms.common.api.MY3jR mY3jR : this.dNE3s.keySet()) {
            String strValueOf = String.valueOf(str);
            printWriter.append((CharSequence) str).append((CharSequence) mY3jR.zDWsfFRp()).println(p497q7.SFMiYa.COLON);
            ((com.google.android.gms.common.api.MY3jR.XbU7b) f5zilcb.VVpVRy.uTIfLNK0((com.google.android.gms.common.api.MY3jR.XbU7b) this.fdmP9GD.get(mY3jR.aXYSYCVY()))).qLLw0g(strValueOf.concat("  "), fileDescriptor, printWriter, strArr);
        }
    }

    @Override // jcwfs78.ZIAa4n
    public final void eLbhX59K() {
        this.zigsCJW.aXYSYCVY();
    }

    @Override // jcwfs78.ZIAa4n
    public final com.google.android.gms.common.api.internal.MY3jR eszJ2B0a(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        mY3jR.yxejkub();
        this.zigsCJW.zDWsfFRp(mY3jR);
        return mY3jR;
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean ivfTYNl(NUIvmoc nUIvmoc) {
        return false;
    }

    @Override // jcwfs78.DuA2vx
    public final void m8rcW6(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
        this.njNibPNp.lock();
        try {
            this.zigsCJW.oZ7qYn(connectionResult, mY3jR, z10);
        } finally {
            this.njNibPNp.unlock();
        }
    }

    public final void mTWLV(RuntimeException runtimeException) {
        ZnYtB8l znYtB8l = this.xINpNt2d;
        znYtB8l.sendMessage(znYtB8l.obtainMessage(2, runtimeException));
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean oZ7qYn() {
        return this.zigsCJW instanceof BgOcqi;
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnected(Bundle bundle) {
        this.njNibPNp.lock();
        try {
            this.zigsCJW.dUI84(bundle);
        } finally {
            this.njNibPNp.unlock();
        }
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnectionSuspended(int i10) {
        this.njNibPNp.lock();
        try {
            this.zigsCJW.eLbhX59K(i10);
        } finally {
            this.njNibPNp.unlock();
        }
    }

    @Override // jcwfs78.ZIAa4n
    public final void osx7Pl0E() {
        if (this.zigsCJW.ivfTYNl()) {
            this.vskcqLTQ.clear();
        }
    }

    public final void q1ORKN() {
        this.njNibPNp.lock();
        try {
            this.xnFvJEz.mK94T();
            this.zigsCJW = new ZKBAd(this);
            this.zigsCJW.eszJ2B0a();
            this.vo5p9AUA.signalAll();
        } finally {
            this.njNibPNp.unlock();
        }
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean rjljd6i() {
        return this.zigsCJW instanceof ZKBAd;
    }

    public final void uTIfLNK0() throws Throwable {
        DrXCNOo9 drXCNOo9;
        this.njNibPNp.lock();
        try {
            drXCNOo9 = this;
            try {
                drXCNOo9.zigsCJW = new BgOcqi(drXCNOo9, this.pz7TsV, this.dNE3s, this.zYD7SXW6, this.i2VlO, this.njNibPNp, this.gmzPK);
                drXCNOo9.zigsCJW.eszJ2B0a();
                drXCNOo9.vo5p9AUA.signalAll();
                drXCNOo9.njNibPNp.unlock();
            } catch (Throwable th2) {
                th = th2;
                drXCNOo9.njNibPNp.unlock();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            drXCNOo9 = this;
        }
    }

    public final void uYRSwDm(ConnectionResult connectionResult) {
        this.njNibPNp.lock();
        try {
            this.ca3iT = connectionResult;
            this.zigsCJW = new FsJiNjAN(this);
            this.zigsCJW.eszJ2B0a();
            this.vo5p9AUA.signalAll();
        } finally {
            this.njNibPNp.unlock();
        }
    }

    public final void yxejkub(VX4rr vX4rr) {
        ZnYtB8l znYtB8l = this.xINpNt2d;
        znYtB8l.sendMessage(znYtB8l.obtainMessage(1, vX4rr));
    }

    @Override // jcwfs78.ZIAa4n
    public final void zDWsfFRp() {
    }
}
