package jcwfs78;

import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class MY3jR implements O5Z56VT6 {
    @Override // jcwfs78.O5Z56VT6
    public final Exception eszJ2B0a(Status status) {
        return f5zilcb.MY3jR.eszJ2B0a(status);
    }
}
