package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class CuakH3s9 implements Runnable {
    public final /* synthetic */ int njNibPNp;
    public final /* synthetic */ KpPYc30 vo5p9AUA;

    public CuakH3s9(KpPYc30 kpPYc30, int i10) {
        this.vo5p9AUA = kpPYc30;
        this.njNibPNp = i10;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.vo5p9AUA.rjljd6i(this.njNibPNp);
    }
}
