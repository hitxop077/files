package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class Kuh1mAB7 implements f5zilcb.AliKj1I {
    public final /* synthetic */ ZQB7k njNibPNp;

    public Kuh1mAB7(ZQB7k zQB7k) {
        this.njNibPNp = zQB7k;
    }

    @Override // f5zilcb.AliKj1I
    public final boolean eszJ2B0a() {
        return this.njNibPNp.q1ORKN();
    }
}
