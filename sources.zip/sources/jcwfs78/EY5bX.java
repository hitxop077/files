package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class EY5bX implements Runnable {
    public final /* synthetic */ BgOcqi njNibPNp;

    public EY5bX(BgOcqi bgOcqi) {
        this.njNibPNp = bgOcqi;
    }

    @Override // java.lang.Runnable
    public final void run() {
        BgOcqi bgOcqi = this.njNibPNp;
        bgOcqi.zDWsfFRp.eszJ2B0a(bgOcqi.eLbhX59K);
    }
}
