package jcwfs78;

import android.content.ServiceConnection;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class VVpVRy implements com.google.android.gms.common.api.MY3jR.XbU7b, ServiceConnection {
}
