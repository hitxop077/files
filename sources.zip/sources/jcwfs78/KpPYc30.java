package jcwfs78;

import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Status;
import com.paytm.sprint.sdk.SprintConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class KpPYc30 implements com.google.android.gms.common.api.N1vNRFSd.AAnYcst, com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8, DuA2vx {
    public final /* synthetic */ XbU7b bBHqyf;
    public boolean dNE3s;
    public final AAnYcst gmzPK;
    public final HUx1xD pz7TsV;
    public final com.google.android.gms.common.api.MY3jR.XbU7b vo5p9AUA;
    public final int vskcqLTQ;
    public final IMpOqqn zYD7SXW6;
    public final Queue njNibPNp = new LinkedList();
    public final Set xINpNt2d = new HashSet();
    public final Map fdmP9GD = new HashMap();
    public final List i2VlO = new ArrayList();
    public ConnectionResult zigsCJW = null;
    public int ca3iT = 0;

    public KpPYc30(XbU7b xbU7b, com.google.android.gms.common.api.LNd998w lNd998w) {
        this.bBHqyf = xbU7b;
        com.google.android.gms.common.api.MY3jR.XbU7b xbU7bWtGiK9b = lNd998w.wtGiK9b(xbU7b.xnFvJEz.getLooper(), this);
        this.vo5p9AUA = xbU7bWtGiK9b;
        this.gmzPK = lNd998w.bsO5Vo();
        this.zYD7SXW6 = new IMpOqqn();
        this.vskcqLTQ = lNd998w.nyeBEo();
        if (xbU7bWtGiK9b.dUI84()) {
            this.pz7TsV = lNd998w.jdF33N(xbU7b.xINpNt2d, xbU7b.xnFvJEz);
        } else {
            this.pz7TsV = null;
        }
    }

    public static /* bridge */ /* synthetic */ void eImdmIyv(KpPYc30 kpPYc30, PNhZ1c pNhZ1c) {
        if (kpPYc30.i2VlO.contains(pNhZ1c) && !kpPYc30.dNE3s) {
            if (kpPYc30.vo5p9AUA.eszJ2B0a()) {
                kpPYc30.dUI84();
            } else {
                kpPYc30.nyeBEo();
            }
        }
    }

    public static /* bridge */ /* synthetic */ void mK94T(KpPYc30 kpPYc30, PNhZ1c pNhZ1c) {
        Feature[] featureArrDUI84;
        if (kpPYc30.i2VlO.remove(pNhZ1c)) {
            kpPYc30.bBHqyf.xnFvJEz.removeMessages(15, pNhZ1c);
            kpPYc30.bBHqyf.xnFvJEz.removeMessages(16, pNhZ1c);
            Feature feature = pNhZ1c.aXYSYCVY;
            ArrayList arrayList = new ArrayList(kpPYc30.njNibPNp.size());
            for (MkXy0K3 mkXy0K3 : kpPYc30.njNibPNp) {
                if ((mkXy0K3 instanceof Wg91SLQ) && (featureArrDUI84 = ((Wg91SLQ) mkXy0K3).dUI84(kpPYc30)) != null && an89d.AAnYcst.aXYSYCVY(featureArrDUI84, feature)) {
                    arrayList.add(mkXy0K3);
                }
            }
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                MkXy0K3 mkXy0K4 = (MkXy0K3) arrayList.get(i10);
                kpPYc30.njNibPNp.remove(mkXy0K4);
                mkXy0K4.aXYSYCVY(new com.google.android.gms.common.api.SFMiYa(feature));
            }
        }
    }

    public final boolean aXYSYCVY() {
        return yxejkub(true);
    }

    public final void ceTXybVl() {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if (this.dNE3s) {
            q1ORKN();
            XbU7b xbU7b = this.bBHqyf;
            ivfTYNl(xbU7b.fdmP9GD.rjljd6i(xbU7b.xINpNt2d) == 18 ? new Status(21, "Connection timed out waiting for Google Play services update to complete.") : new Status(22, "API failed to connect while resuming due to an unknown error."));
            this.vo5p9AUA.zDWsfFRp("Timing out connection while resuming.");
        }
    }

    public final void dUI84() {
        ArrayList arrayList = new ArrayList(this.njNibPNp);
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            MkXy0K3 mkXy0K3 = (MkXy0K3) arrayList.get(i10);
            if (!this.vo5p9AUA.eszJ2B0a()) {
                return;
            }
            if (uTIfLNK0(mkXy0K3)) {
                this.njNibPNp.remove(mkXy0K3);
            }
        }
    }

    public final Feature eLbhX59K(Feature[] featureArr) {
        if (featureArr != null && featureArr.length != 0) {
            Feature[] featureArrRtsRj = this.vo5p9AUA.rtsRj();
            if (featureArrRtsRj == null) {
                featureArrRtsRj = new Feature[0];
            }
            androidx.collection.MY3jR mY3jR = new androidx.collection.MY3jR(featureArrRtsRj.length);
            for (Feature feature : featureArrRtsRj) {
                mY3jR.put(feature.q1ORKN(), Long.valueOf(feature.yxejkub()));
            }
            for (Feature feature2 : featureArr) {
                Long l10 = (Long) mY3jR.get(feature2.q1ORKN());
                if (l10 == null || l10.longValue() < feature2.yxejkub()) {
                    return feature2;
                }
            }
        }
        return null;
    }

    public final void eTQUrp() {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        this.zigsCJW = null;
    }

    public final void egsKh() {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        ivfTYNl(XbU7b.sRtu3PUY);
        this.zYD7SXW6.osx7Pl0E();
        for (Lx1jI.MY3jR mY3jR : (Lx1jI.MY3jR[]) this.fdmP9GD.keySet().toArray(new Lx1jI.MY3jR[0])) {
            wtGiK9b(new CadWAic(mY3jR, new a4dh7ol.HicDZW()));
        }
        zDWsfFRp(new ConnectionResult(4));
        if (this.vo5p9AUA.eszJ2B0a()) {
            this.vo5p9AUA.rJCQt16(new D4KLUvX(this));
        }
    }

    public final boolean eszJ2B0a() {
        return this.vo5p9AUA.dUI84();
    }

    public final void fk0tr(ConnectionResult connectionResult) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = this.vo5p9AUA;
        xbU7b.zDWsfFRp("onSignInFailed for " + xbU7b.getClass().getName() + " with " + String.valueOf(connectionResult));
        gA0EO(connectionResult, null);
    }

    public final void gA0EO(ConnectionResult connectionResult, Exception exc) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        HUx1xD hUx1xD = this.pz7TsV;
        if (hUx1xD != null) {
            hUx1xD.mbqfW();
        }
        eTQUrp();
        this.bBHqyf.vskcqLTQ.eLbhX59K();
        zDWsfFRp(connectionResult);
        if ((this.vo5p9AUA instanceof q9zeiwup.N1vNRFSd) && connectionResult.q1ORKN() != 24) {
            this.bBHqyf.vo5p9AUA = true;
            XbU7b xbU7b = this.bBHqyf;
            xbU7b.xnFvJEz.sendMessageDelayed(xbU7b.xnFvJEz.obtainMessage(19), 300000L);
        }
        if (connectionResult.q1ORKN() == 4) {
            ivfTYNl(XbU7b.ytgMq);
            return;
        }
        if (this.njNibPNp.isEmpty()) {
            this.zigsCJW = connectionResult;
            return;
        }
        if (exc != null) {
            f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
            osx7Pl0E(null, exc, false);
            return;
        }
        if (!this.bBHqyf.cOkM2) {
            ivfTYNl(XbU7b.dUI84(this.gmzPK, connectionResult));
            return;
        }
        osx7Pl0E(XbU7b.dUI84(this.gmzPK, connectionResult), null, true);
        if (this.njNibPNp.isEmpty() || uYRSwDm(connectionResult) || this.bBHqyf.osx7Pl0E(connectionResult, this.vskcqLTQ)) {
            return;
        }
        if (connectionResult.q1ORKN() == 18) {
            this.dNE3s = true;
        }
        if (!this.dNE3s) {
            ivfTYNl(XbU7b.dUI84(this.gmzPK, connectionResult));
            return;
        }
        XbU7b xbU7b2 = this.bBHqyf;
        xbU7b2.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b2.xnFvJEz, 9, this.gmzPK), SprintConfig.DEFAULT_CACHE_TIMEOUT);
    }

    public final void ivfTYNl(Status status) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        osx7Pl0E(status, null, false);
    }

    public final void jdF33N() {
        this.ca3iT++;
    }

    @Override // jcwfs78.DuA2vx
    public final void m8rcW6(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
        throw null;
    }

    public final int mTWLV() {
        return this.vskcqLTQ;
    }

    public final Map n84TFkA9() {
        return this.fdmP9GD;
    }

    public final void nyeBEo() {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if (this.vo5p9AUA.eszJ2B0a() || this.vo5p9AUA.ivfTYNl()) {
            return;
        }
        try {
            XbU7b xbU7b = this.bBHqyf;
            int iAXYSYCVY = xbU7b.vskcqLTQ.aXYSYCVY(xbU7b.xINpNt2d, this.vo5p9AUA);
            if (iAXYSYCVY != 0) {
                ConnectionResult connectionResult = new ConnectionResult(iAXYSYCVY, null);
                this.vo5p9AUA.getClass();
                connectionResult.toString();
                gA0EO(connectionResult, null);
                return;
            }
            XbU7b xbU7b2 = this.bBHqyf;
            com.google.android.gms.common.api.MY3jR.XbU7b xbU7b3 = this.vo5p9AUA;
            ROakya rOakya = new ROakya(xbU7b2, xbU7b3, this.gmzPK);
            if (xbU7b3.dUI84()) {
                ((HUx1xD) f5zilcb.VVpVRy.uTIfLNK0(this.pz7TsV)).mnnFu(rOakya);
            }
            try {
                this.vo5p9AUA.oyaOvpOs(rOakya);
            } catch (SecurityException e10) {
                gA0EO(new ConnectionResult(10), e10);
            }
        } catch (IllegalStateException e11) {
            gA0EO(new ConnectionResult(10), e11);
        }
    }

    public final void oZ7qYn() {
        eTQUrp();
        zDWsfFRp(ConnectionResult.fdmP9GD);
        q1ORKN();
        Iterator it2 = this.fdmP9GD.values().iterator();
        while (it2.hasNext()) {
            HUwff hUwff = (HUwff) it2.next();
            if (eLbhX59K(hUwff.eszJ2B0a.eLbhX59K()) != null) {
                it2.remove();
            } else {
                try {
                    hUwff.eszJ2B0a.zDWsfFRp(this.vo5p9AUA, new a4dh7ol.HicDZW());
                } catch (DeadObjectException unused) {
                    onConnectionSuspended(3);
                    this.vo5p9AUA.zDWsfFRp("DeadObjectException thrown while calling register listener method.");
                } catch (RemoteException unused2) {
                    it2.remove();
                }
            }
        }
        dUI84();
        zPJpxWz();
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnected(Bundle bundle) {
        if (Looper.myLooper() == this.bBHqyf.xnFvJEz.getLooper()) {
            oZ7qYn();
        } else {
            this.bBHqyf.xnFvJEz.post(new Q5YIo(this));
        }
    }

    @Override // jcwfs78.SFMiYa
    public final void onConnectionFailed(ConnectionResult connectionResult) {
        gA0EO(connectionResult, null);
    }

    @Override // jcwfs78.N1vNRFSd
    public final void onConnectionSuspended(int i10) {
        if (Looper.myLooper() == this.bBHqyf.xnFvJEz.getLooper()) {
            rjljd6i(i10);
        } else {
            this.bBHqyf.xnFvJEz.post(new CuakH3s9(this, i10));
        }
    }

    public final void osx7Pl0E(Status status, Exception exc, boolean z10) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if ((status == null) == (exc == null)) {
            throw new IllegalArgumentException("Status XOR exception should be null");
        }
        Iterator it2 = this.njNibPNp.iterator();
        while (it2.hasNext()) {
            MkXy0K3 mkXy0K3 = (MkXy0K3) it2.next();
            if (!z10 || mkXy0K3.eszJ2B0a == 2) {
                if (status != null) {
                    mkXy0K3.eszJ2B0a(status);
                } else {
                    mkXy0K3.aXYSYCVY(exc);
                }
                it2.remove();
            }
        }
    }

    public final void q1ORKN() {
        if (this.dNE3s) {
            XbU7b xbU7b = this.bBHqyf;
            xbU7b.xnFvJEz.removeMessages(11, this.gmzPK);
            XbU7b xbU7b2 = this.bBHqyf;
            xbU7b2.xnFvJEz.removeMessages(9, this.gmzPK);
            this.dNE3s = false;
        }
    }

    public final void qLLw0g(MkXy0K3 mkXy0K3) {
        mkXy0K3.zDWsfFRp(this.zYD7SXW6, eszJ2B0a());
        try {
            mkXy0K3.eLbhX59K(this);
        } catch (DeadObjectException unused) {
            onConnectionSuspended(1);
            this.vo5p9AUA.zDWsfFRp("DeadObjectException thrown while running ApiCallRunner.");
        }
    }

    public final int rJCQt16() {
        return this.ca3iT;
    }

    public final void rjljd6i(int i10) {
        eTQUrp();
        this.dNE3s = true;
        this.zYD7SXW6.ivfTYNl(i10, this.vo5p9AUA.n84TFkA9());
        AAnYcst aAnYcst = this.gmzPK;
        XbU7b xbU7b = this.bBHqyf;
        xbU7b.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b.xnFvJEz, 9, aAnYcst), SprintConfig.DEFAULT_CACHE_TIMEOUT);
        AAnYcst aAnYcst2 = this.gmzPK;
        XbU7b xbU7b2 = this.bBHqyf;
        xbU7b2.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b2.xnFvJEz, 11, aAnYcst2), 120000L);
        this.bBHqyf.vskcqLTQ.eLbhX59K();
        Iterator it2 = this.fdmP9GD.values().iterator();
        while (it2.hasNext()) {
            ((HUwff) it2.next()).eLbhX59K.run();
        }
    }

    public final com.google.android.gms.common.api.MY3jR.XbU7b rtsRj() {
        return this.vo5p9AUA;
    }

    public final boolean uTIfLNK0(MkXy0K3 mkXy0K3) {
        if (!(mkXy0K3 instanceof Wg91SLQ)) {
            qLLw0g(mkXy0K3);
            return true;
        }
        Wg91SLQ wg91SLQ = (Wg91SLQ) mkXy0K3;
        Feature featureELbhX59K = eLbhX59K(wg91SLQ.dUI84(this));
        if (featureELbhX59K == null) {
            qLLw0g(mkXy0K3);
            return true;
        }
        this.vo5p9AUA.getClass();
        featureELbhX59K.q1ORKN();
        featureELbhX59K.yxejkub();
        if (!this.bBHqyf.cOkM2 || !wg91SLQ.osx7Pl0E(this)) {
            wg91SLQ.aXYSYCVY(new com.google.android.gms.common.api.SFMiYa(featureELbhX59K));
            return true;
        }
        PNhZ1c pNhZ1c = new PNhZ1c(this.gmzPK, featureELbhX59K, null);
        int iIndexOf = this.i2VlO.indexOf(pNhZ1c);
        if (iIndexOf >= 0) {
            PNhZ1c pNhZ1c2 = (PNhZ1c) this.i2VlO.get(iIndexOf);
            this.bBHqyf.xnFvJEz.removeMessages(15, pNhZ1c2);
            XbU7b xbU7b = this.bBHqyf;
            xbU7b.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b.xnFvJEz, 15, pNhZ1c2), SprintConfig.DEFAULT_CACHE_TIMEOUT);
            return false;
        }
        this.i2VlO.add(pNhZ1c);
        XbU7b xbU7b2 = this.bBHqyf;
        xbU7b2.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b2.xnFvJEz, 15, pNhZ1c), SprintConfig.DEFAULT_CACHE_TIMEOUT);
        XbU7b xbU7b3 = this.bBHqyf;
        xbU7b3.xnFvJEz.sendMessageDelayed(Message.obtain(xbU7b3.xnFvJEz, 16, pNhZ1c), 120000L);
        ConnectionResult connectionResult = new ConnectionResult(2, null);
        if (uYRSwDm(connectionResult)) {
            return false;
        }
        this.bBHqyf.osx7Pl0E(connectionResult, this.vskcqLTQ);
        return false;
    }

    public final boolean uYRSwDm(ConnectionResult connectionResult) {
        synchronized (XbU7b.lw3QOa) {
            try {
                XbU7b xbU7b = this.bBHqyf;
                if (xbU7b.zigsCJW == null || !xbU7b.ca3iT.contains(this.gmzPK)) {
                    return false;
                }
                this.bBHqyf.zigsCJW.rtsRj(connectionResult, this.vskcqLTQ);
                return true;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void wtGiK9b(MkXy0K3 mkXy0K3) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if (this.vo5p9AUA.eszJ2B0a()) {
            if (uTIfLNK0(mkXy0K3)) {
                zPJpxWz();
                return;
            } else {
                this.njNibPNp.add(mkXy0K3);
                return;
            }
        }
        this.njNibPNp.add(mkXy0K3);
        ConnectionResult connectionResult = this.zigsCJW;
        if (connectionResult == null || !connectionResult.fIz14cTt()) {
            nyeBEo();
        } else {
            gA0EO(this.zigsCJW, null);
        }
    }

    public final boolean yxejkub(boolean z10) {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if (!this.vo5p9AUA.eszJ2B0a() || !this.fdmP9GD.isEmpty()) {
            return false;
        }
        if (!this.zYD7SXW6.dUI84()) {
            this.vo5p9AUA.zDWsfFRp("Timing out service connection.");
            return true;
        }
        if (!z10) {
            return false;
        }
        zPJpxWz();
        return false;
    }

    public final void z3luKc() {
        f5zilcb.VVpVRy.zDWsfFRp(this.bBHqyf.xnFvJEz);
        if (this.dNE3s) {
            nyeBEo();
        }
    }

    public final void zDWsfFRp(ConnectionResult connectionResult) {
        Iterator it2 = this.xINpNt2d.iterator();
        if (!it2.hasNext()) {
            this.xINpNt2d.clear();
            return;
        }
        android.support.v4.media.MY3jR.eszJ2B0a(it2.next());
        if (f5zilcb.Lx1jI.eszJ2B0a(connectionResult, ConnectionResult.fdmP9GD)) {
            this.vo5p9AUA.mTWLV();
        }
        throw null;
    }

    public final void zPJpxWz() {
        this.bBHqyf.xnFvJEz.removeMessages(12, this.gmzPK);
        AAnYcst aAnYcst = this.gmzPK;
        XbU7b xbU7b = this.bBHqyf;
        xbU7b.xnFvJEz.sendMessageDelayed(xbU7b.xnFvJEz.obtainMessage(12, aAnYcst), this.bBHqyf.njNibPNp);
    }
}
