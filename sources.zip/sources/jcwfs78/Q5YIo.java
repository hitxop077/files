package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Q5YIo implements Runnable {
    public final /* synthetic */ KpPYc30 njNibPNp;

    public Q5YIo(KpPYc30 kpPYc30) {
        this.njNibPNp = kpPYc30;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.njNibPNp.oZ7qYn();
    }
}
