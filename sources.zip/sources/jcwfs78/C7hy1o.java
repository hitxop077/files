package jcwfs78;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class C7hy1o {
    public static final Status eLbhX59K = new Status(8, "The connection to Google Play services was lost");
    public final Set eszJ2B0a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
    public final FOuNY aXYSYCVY = new FOuNY(this);

    public final void aXYSYCVY() {
        for (BasePendingResult basePendingResult : (BasePendingResult[]) this.eszJ2B0a.toArray(new BasePendingResult[0])) {
            basePendingResult.jAM6dcNA(null);
            if (basePendingResult.rJCQt16()) {
                this.eszJ2B0a.remove(basePendingResult);
            }
        }
    }

    public final void eszJ2B0a(BasePendingResult basePendingResult) {
        this.eszJ2B0a.add(basePendingResult);
        basePendingResult.jAM6dcNA(this.aXYSYCVY);
    }
}
