package jcwfs78;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import androidx.compose.foundation.lazy.mVyI.YXAkFhvmrjl;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import com.google.android.gms.common.api.internal.zabx;
import com.paytm.sprint.sdk.SprintConfig;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes2.dex */
public final class ZQB7k extends com.google.android.gms.common.api.N1vNRFSd implements AjKBk {
    public final Lock aXYSYCVY;
    public Integer bsO5Vo;
    public final C7hy1o c1pvtY;
    public final Looper dUI84;
    public final f5zilcb.AliKj1I eImdmIyv;
    public final f5zilcb.ItX6BnZf eLbhX59K;
    public final int ivfTYNl;
    public final Map jAM6dcNA;
    public Set mTWLV;
    public final ArrayList n84TFkA9;
    public final Context osx7Pl0E;
    public final Bv3FS oyaOvpOs;
    public final ECK8f q1ORKN;
    public long qLLw0g;
    public final f5zilcb.LNd998w rJCQt16;
    public volatile boolean rjljd6i;
    public final com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR rtsRj;
    public Set sMxPLer;
    public final uchv3v.N1vNRFSd uTIfLNK0;
    public zabx uYRSwDm;
    public final Map yxejkub;
    public long zPJpxWz;
    public ZIAa4n zDWsfFRp = null;
    public final Queue oZ7qYn = new LinkedList();

    public ZQB7k(Context context, Lock lock, Looper looper, f5zilcb.LNd998w lNd998w, uchv3v.N1vNRFSd n1vNRFSd, com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR, Map map, List list, List list2, Map map2, int i10, int i11, ArrayList arrayList) {
        this.zPJpxWz = true != an89d.N1vNRFSd.aXYSYCVY() ? 120000L : 10000L;
        this.qLLw0g = SprintConfig.DEFAULT_CACHE_TIMEOUT;
        this.mTWLV = new HashSet();
        this.oyaOvpOs = new Bv3FS();
        this.bsO5Vo = null;
        this.sMxPLer = null;
        Kuh1mAB7 kuh1mAB7 = new Kuh1mAB7(this);
        this.eImdmIyv = kuh1mAB7;
        this.osx7Pl0E = context;
        this.aXYSYCVY = lock;
        this.eLbhX59K = new f5zilcb.ItX6BnZf(looper, kuh1mAB7);
        this.dUI84 = looper;
        this.q1ORKN = new ECK8f(this, looper);
        this.uTIfLNK0 = n1vNRFSd;
        this.ivfTYNl = i10;
        if (i10 >= 0) {
            this.bsO5Vo = Integer.valueOf(i11);
        }
        this.jAM6dcNA = map;
        this.yxejkub = map2;
        this.n84TFkA9 = arrayList;
        this.c1pvtY = new C7hy1o();
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            this.eLbhX59K.osx7Pl0E((com.google.android.gms.common.api.N1vNRFSd.AAnYcst) it2.next());
        }
        Iterator it3 = list2.iterator();
        while (it3.hasNext()) {
            this.eLbhX59K.dUI84((com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8) it3.next());
        }
        this.rJCQt16 = lNd998w;
        this.rtsRj = abstractC0848MY3jR;
    }

    public static /* bridge */ /* synthetic */ void c1pvtY(ZQB7k zQB7k) {
        zQB7k.aXYSYCVY.lock();
        try {
            if (zQB7k.rjljd6i) {
                zQB7k.nyeBEo();
            }
        } finally {
            zQB7k.aXYSYCVY.unlock();
        }
    }

    public static /* bridge */ /* synthetic */ void eImdmIyv(ZQB7k zQB7k) {
        zQB7k.aXYSYCVY.lock();
        try {
            if (zQB7k.mK94T()) {
                zQB7k.nyeBEo();
            }
        } finally {
            zQB7k.aXYSYCVY.unlock();
        }
    }

    public static int n84TFkA9(Iterable iterable, boolean z10) {
        Iterator it2 = iterable.iterator();
        boolean zDUI84 = false;
        boolean zELbhX59K = false;
        while (it2.hasNext()) {
            com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = (com.google.android.gms.common.api.MY3jR.XbU7b) it2.next();
            zDUI84 |= xbU7b.dUI84();
            zELbhX59K |= xbU7b.eLbhX59K();
        }
        if (zDUI84) {
            return (zELbhX59K && z10) ? 2 : 1;
        }
        return 3;
    }

    public static String sMxPLer(int i10) {
        if (i10 == 1) {
            return "SIGN_IN_MODE_REQUIRED";
        }
        if (i10 != 2) {
            return i10 != 3 ? "UNKNOWN" : "SIGN_IN_MODE_NONE";
        }
        return "SIGN_IN_MODE_OPTIONAL";
    }

    @Override // jcwfs78.AjKBk
    public final void aXYSYCVY(Bundle bundle) {
        while (!this.oZ7qYn.isEmpty()) {
            oZ7qYn((com.google.android.gms.common.api.internal.MY3jR) this.oZ7qYn.remove());
        }
        this.eLbhX59K.zDWsfFRp(bundle);
    }

    public final String bsO5Vo() {
        StringWriter stringWriter = new StringWriter();
        osx7Pl0E("", null, new PrintWriter(stringWriter), null);
        return stringWriter.toString();
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final com.google.android.gms.common.api.internal.MY3jR dUI84(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        com.google.android.gms.common.api.MY3jR mY3jROyaOvpOs = mY3jR.oyaOvpOs();
        f5zilcb.VVpVRy.aXYSYCVY(this.yxejkub.containsKey(mY3jR.n84TFkA9()), "GoogleApiClient is not configured to use " + (mY3jROyaOvpOs != null ? mY3jROyaOvpOs.zDWsfFRp() : "the API") + " required for this call.");
        this.aXYSYCVY.lock();
        try {
            ZIAa4n zIAa4n = this.zDWsfFRp;
            if (zIAa4n == null) {
                this.oZ7qYn.add(mY3jR);
            } else {
                mY3jR = zIAa4n.eszJ2B0a(mY3jR);
            }
            return mY3jR;
        } finally {
            this.aXYSYCVY.unlock();
        }
    }

    @Override // jcwfs78.AjKBk
    public final void eLbhX59K(ConnectionResult connectionResult) {
        if (!this.uTIfLNK0.qLLw0g(this.osx7Pl0E, connectionResult.q1ORKN())) {
            mK94T();
        }
        if (this.rjljd6i) {
            return;
        }
        this.eLbhX59K.eLbhX59K(connectionResult);
        this.eLbhX59K.eszJ2B0a();
    }

    @Override // jcwfs78.AjKBk
    public final void eszJ2B0a(int i10, boolean z10) {
        if (i10 == 1) {
            if (!z10 && !this.rjljd6i) {
                this.rjljd6i = true;
                if (this.uYRSwDm == null && !an89d.N1vNRFSd.aXYSYCVY()) {
                    try {
                        this.uYRSwDm = this.uTIfLNK0.sMxPLer(this.osx7Pl0E.getApplicationContext(), new ZTkvew3(this));
                    } catch (SecurityException unused) {
                    }
                }
                ECK8f eCK8f = this.q1ORKN;
                eCK8f.sendMessageDelayed(eCK8f.obtainMessage(1), this.zPJpxWz);
                ECK8f eCK8f2 = this.q1ORKN;
                eCK8f2.sendMessageDelayed(eCK8f2.obtainMessage(2), this.qLLw0g);
            }
            i10 = 1;
        }
        for (BasePendingResult basePendingResult : (BasePendingResult[]) this.c1pvtY.eszJ2B0a.toArray(new BasePendingResult[0])) {
            basePendingResult.oZ7qYn(C7hy1o.eLbhX59K);
        }
        this.eLbhX59K.ivfTYNl(i10);
        this.eLbhX59K.eszJ2B0a();
        if (i10 == 2) {
            nyeBEo();
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void ivfTYNl() {
        this.aXYSYCVY.lock();
        try {
            this.c1pvtY.aXYSYCVY();
            ZIAa4n zIAa4n = this.zDWsfFRp;
            if (zIAa4n != null) {
                zIAa4n.osx7Pl0E();
            }
            this.oyaOvpOs.zDWsfFRp();
            for (com.google.android.gms.common.api.internal.MY3jR mY3jR : this.oZ7qYn) {
                mY3jR.jAM6dcNA(null);
                mY3jR.osx7Pl0E();
            }
            this.oZ7qYn.clear();
            if (this.zDWsfFRp != null) {
                mK94T();
                this.eLbhX59K.eszJ2B0a();
            }
        } finally {
            this.aXYSYCVY.unlock();
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void jAM6dcNA(com.google.android.gms.common.api.N1vNRFSd.AAnYcst aAnYcst) {
        this.eLbhX59K.oZ7qYn(aAnYcst);
    }

    public final boolean mK94T() {
        if (!this.rjljd6i) {
            return false;
        }
        this.rjljd6i = false;
        this.q1ORKN.removeMessages(2);
        this.q1ORKN.removeMessages(1);
        zabx zabxVar = this.uYRSwDm;
        if (zabxVar != null) {
            zabxVar.aXYSYCVY();
            this.uYRSwDm = null;
        }
        return true;
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void mTWLV(com.google.android.gms.common.api.N1vNRFSd.AAnYcst aAnYcst) {
        this.eLbhX59K.osx7Pl0E(aAnYcst);
    }

    public final void nyeBEo() {
        this.eLbhX59K.aXYSYCVY();
        ((ZIAa4n) f5zilcb.VVpVRy.uTIfLNK0(this.zDWsfFRp)).eLbhX59K();
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final com.google.android.gms.common.api.internal.MY3jR oZ7qYn(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        Map map = this.yxejkub;
        com.google.android.gms.common.api.MY3jR mY3jROyaOvpOs = mY3jR.oyaOvpOs();
        f5zilcb.VVpVRy.aXYSYCVY(map.containsKey(mY3jR.n84TFkA9()), "GoogleApiClient is not configured to use " + (mY3jROyaOvpOs != null ? mY3jROyaOvpOs.zDWsfFRp() : "the API") + " required for this call.");
        this.aXYSYCVY.lock();
        try {
            ZIAa4n zIAa4n = this.zDWsfFRp;
            if (zIAa4n == null) {
                throw new IllegalStateException("GoogleApiClient is not connected yet.");
            }
            if (this.rjljd6i) {
                this.oZ7qYn.add(mY3jR);
                while (!this.oZ7qYn.isEmpty()) {
                    com.google.android.gms.common.api.internal.MY3jR mY3jR2 = (com.google.android.gms.common.api.internal.MY3jR) this.oZ7qYn.remove();
                    this.c1pvtY.eszJ2B0a(mY3jR2);
                    mY3jR2.aXYSYCVY(Status.pz7TsV);
                }
            } else {
                mY3jR = zIAa4n.aXYSYCVY(mY3jR);
            }
            this.aXYSYCVY.unlock();
            return mY3jR;
        } catch (Throwable th2) {
            this.aXYSYCVY.unlock();
            throw th2;
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void osx7Pl0E(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append((CharSequence) str).append("mContext=").println(this.osx7Pl0E);
        printWriter.append((CharSequence) str).append("mResuming=").print(this.rjljd6i);
        printWriter.append(" mWorkQueue.size()=").print(this.oZ7qYn.size());
        printWriter.append(" mUnconsumedApiCalls.size()=").println(this.c1pvtY.eszJ2B0a.size());
        ZIAa4n zIAa4n = this.zDWsfFRp;
        if (zIAa4n != null) {
            zIAa4n.dUI84(str, fileDescriptor, printWriter, strArr);
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final boolean q1ORKN() {
        ZIAa4n zIAa4n = this.zDWsfFRp;
        return zIAa4n != null && zIAa4n.rjljd6i();
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final Looper qLLw0g() {
        return this.dUI84;
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void rJCQt16(com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 rfq3aa8) {
        this.eLbhX59K.dUI84(rfq3aa8);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void rtsRj(com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 rfq3aa8) {
        this.eLbhX59K.rjljd6i(rfq3aa8);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final boolean uTIfLNK0() {
        ZIAa4n zIAa4n = this.zDWsfFRp;
        return zIAa4n != null && zIAa4n.oZ7qYn();
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final boolean uYRSwDm(NUIvmoc nUIvmoc) {
        ZIAa4n zIAa4n = this.zDWsfFRp;
        return zIAa4n != null && zIAa4n.ivfTYNl(nUIvmoc);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void yxejkub() {
        ZIAa4n zIAa4n = this.zDWsfFRp;
        if (zIAa4n != null) {
            zIAa4n.zDWsfFRp();
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void zDWsfFRp() {
        this.aXYSYCVY.lock();
        try {
            int i10 = 2;
            boolean z10 = false;
            if (this.ivfTYNl >= 0) {
                f5zilcb.VVpVRy.jAM6dcNA(this.bsO5Vo != null, "Sign-in mode should have been set explicitly by auto-manage.");
            } else {
                Integer num = this.bsO5Vo;
                if (num == null) {
                    this.bsO5Vo = Integer.valueOf(n84TFkA9(this.yxejkub.values(), false));
                } else if (num.intValue() == 2) {
                    throw new IllegalStateException("Cannot call connect() when SignInMode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead.");
                }
            }
            int iIntValue = ((Integer) f5zilcb.VVpVRy.uTIfLNK0(this.bsO5Vo)).intValue();
            this.aXYSYCVY.lock();
            try {
                if (iIntValue != 3 && iIntValue != 1) {
                    if (iIntValue != 2) {
                        i10 = iIntValue;
                    }
                    f5zilcb.VVpVRy.aXYSYCVY(z10, "Illegal sign-in mode: " + i10);
                    eTQUrp(i10);
                    nyeBEo();
                    this.aXYSYCVY.unlock();
                    return;
                }
                i10 = iIntValue;
                f5zilcb.VVpVRy.aXYSYCVY(z10, "Illegal sign-in mode: " + i10);
                eTQUrp(i10);
                nyeBEo();
                this.aXYSYCVY.unlock();
                return;
            } finally {
                this.aXYSYCVY.unlock();
            }
            z10 = true;
        } catch (Throwable th2) {
            this.aXYSYCVY.unlock();
            throw th2;
        }
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final com.google.android.gms.common.api.MY3jR.XbU7b zPJpxWz(com.google.android.gms.common.api.MY3jR.RFQ3AA8 rfq3aa8) {
        com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = (com.google.android.gms.common.api.MY3jR.XbU7b) this.yxejkub.get(rfq3aa8);
        f5zilcb.VVpVRy.uYRSwDm(xbU7b, "Appropriate Api was not requested.");
        return xbU7b;
    }

    public final void eTQUrp(int i10) {
        Integer num = this.bsO5Vo;
        if (num == null) {
            this.bsO5Vo = Integer.valueOf(i10);
        } else if (num.intValue() != i10) {
            throw new IllegalStateException("Cannot use sign-in mode: " + sMxPLer(i10) + ". Mode was already set to " + sMxPLer(this.bsO5Vo.intValue()));
        }
        if (this.zDWsfFRp != null) {
            return;
        }
        boolean zDUI84 = false;
        boolean zELbhX59K = false;
        for (com.google.android.gms.common.api.MY3jR.XbU7b xbU7b : this.yxejkub.values()) {
            zDUI84 |= xbU7b.dUI84();
            zELbhX59K |= xbU7b.eLbhX59K();
        }
        int iIntValue = this.bsO5Vo.intValue();
        if (iIntValue != 1) {
            if (iIntValue == 2 && zDUI84) {
                this.zDWsfFRp = H8UuVVi.mTWLV(this.osx7Pl0E, this, this.aXYSYCVY, this.dUI84, this.uTIfLNK0, this.yxejkub, this.rJCQt16, this.jAM6dcNA, this.rtsRj, this.n84TFkA9);
                return;
            }
        } else {
            if (!zDUI84) {
                throw new IllegalStateException("SIGN_IN_MODE_REQUIRED cannot be used on a GoogleApiClient that does not contain any authenticated APIs. Use connect() instead.");
            }
            if (zELbhX59K) {
                throw new IllegalStateException(YXAkFhvmrjl.wXnlhaa);
            }
        }
        this.zDWsfFRp = new DrXCNOo9(this.osx7Pl0E, this, this.aXYSYCVY, this.dUI84, this.uTIfLNK0, this.yxejkub, this.rJCQt16, this.jAM6dcNA, this.rtsRj, this.n84TFkA9, this);
    }
}
