package jcwfs78;

import android.os.Bundle;
import java.util.Objects;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class GAJbYy implements Runnable {
    public final /* synthetic */ PxxW8Q1 gmzPK;
    public final /* synthetic */ HicDZW njNibPNp;
    public final /* synthetic */ String vo5p9AUA;

    public GAJbYy(PxxW8Q1 pxxW8Q1, HicDZW hicDZW, String str) {
        this.njNibPNp = hicDZW;
        this.vo5p9AUA = str;
        Objects.requireNonNull(pxxW8Q1);
        this.gmzPK = pxxW8Q1;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Bundle bundle;
        PxxW8Q1 pxxW8Q1 = this.gmzPK;
        if (pxxW8Q1.qLLw0g() > 0) {
            HicDZW hicDZW = this.njNibPNp;
            if (pxxW8Q1.q1ORKN() != null) {
                bundle = pxxW8Q1.q1ORKN().getBundle(this.vo5p9AUA);
            } else {
                bundle = null;
            }
            hicDZW.osx7Pl0E(bundle);
        }
        if (pxxW8Q1.qLLw0g() >= 2) {
            this.njNibPNp.zPJpxWz();
        }
        if (pxxW8Q1.qLLw0g() >= 3) {
            this.njNibPNp.oZ7qYn();
        }
        if (pxxW8Q1.qLLw0g() >= 4) {
            this.njNibPNp.qLLw0g();
        }
        if (pxxW8Q1.qLLw0g() >= 5) {
            this.njNibPNp.dUI84();
        }
    }
}
