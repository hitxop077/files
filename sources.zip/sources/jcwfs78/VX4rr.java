package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class VX4rr {
    public final AL02fFI eszJ2B0a;

    public VX4rr(AL02fFI aL02fFI) {
        this.eszJ2B0a = aL02fFI;
    }

    public final void aXYSYCVY(DrXCNOo9 drXCNOo9) {
        drXCNOo9.njNibPNp.lock();
        try {
            if (drXCNOo9.zigsCJW == this.eszJ2B0a) {
                eszJ2B0a();
            }
        } finally {
            drXCNOo9.njNibPNp.unlock();
        }
    }

    public abstract void eszJ2B0a();
}
