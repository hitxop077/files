package jcwfs78;

import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Wl27nX2 {
    public final ConnectionResult aXYSYCVY;
    public final int eszJ2B0a;

    public Wl27nX2(ConnectionResult connectionResult, int i10) {
        f5zilcb.VVpVRy.uTIfLNK0(connectionResult);
        this.aXYSYCVY = connectionResult;
        this.eszJ2B0a = i10;
    }

    public final ConnectionResult aXYSYCVY() {
        return this.aXYSYCVY;
    }

    public final int eszJ2B0a() {
        return this.eszJ2B0a;
    }
}
