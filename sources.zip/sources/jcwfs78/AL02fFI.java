package jcwfs78;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface AL02fFI {
    void aXYSYCVY();

    void dUI84(Bundle bundle);

    void eLbhX59K(int i10);

    void eszJ2B0a();

    boolean ivfTYNl();

    void oZ7qYn(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10);

    com.google.android.gms.common.api.internal.MY3jR osx7Pl0E(com.google.android.gms.common.api.internal.MY3jR mY3jR);

    com.google.android.gms.common.api.internal.MY3jR zDWsfFRp(com.google.android.gms.common.api.internal.MY3jR mY3jR);
}
