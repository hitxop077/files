package jcwfs78;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class MkXy0K3 {
    public final int eszJ2B0a;

    public MkXy0K3(int i10) {
        this.eszJ2B0a = i10;
    }

    public static /* bridge */ /* synthetic */ Status ivfTYNl(RemoteException remoteException) {
        return new Status(19, remoteException.getClass().getSimpleName() + ": " + remoteException.getLocalizedMessage());
    }

    public abstract void aXYSYCVY(Exception exc);

    public abstract void eLbhX59K(KpPYc30 kpPYc30);

    public abstract void eszJ2B0a(Status status);

    public abstract void zDWsfFRp(IMpOqqn iMpOqqn, boolean z10);
}
