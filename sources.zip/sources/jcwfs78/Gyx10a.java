package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface Gyx10a {
    void accept(Object obj, Object obj2);
}
