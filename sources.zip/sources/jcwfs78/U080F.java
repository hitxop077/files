package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class U080F {
    public final Feature[] aXYSYCVY;
    public final boolean eLbhX59K;
    public final Lx1jI eszJ2B0a;
    public final int zDWsfFRp;

    public U080F(Lx1jI lx1jI, Feature[] featureArr, boolean z10, int i10) {
        this.eszJ2B0a = lx1jI;
        this.aXYSYCVY = featureArr;
        this.eLbhX59K = z10;
        this.zDWsfFRp = i10;
    }

    public Lx1jI.MY3jR aXYSYCVY() {
        return this.eszJ2B0a.aXYSYCVY();
    }

    public Feature[] eLbhX59K() {
        return this.aXYSYCVY;
    }

    public void eszJ2B0a() {
        this.eszJ2B0a.eszJ2B0a();
    }

    public final int ivfTYNl() {
        return this.zDWsfFRp;
    }

    public final boolean osx7Pl0E() {
        return this.eLbhX59K;
    }

    public abstract void zDWsfFRp(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW);
}
