package jcwfs78;

import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class OTtpwH extends HicDZW implements DialogInterface.OnCancelListener {
    public final AtomicReference gmzPK;
    public volatile boolean vo5p9AUA;
    public final uchv3v.N1vNRFSd xINpNt2d;
    public final Handler zYD7SXW6;

    public OTtpwH(JQAVH jqavh, uchv3v.N1vNRFSd n1vNRFSd) {
        super(jqavh);
        this.gmzPK = new AtomicReference(null);
        this.zYD7SXW6 = new ir9vwy.VVpVRy(Looper.getMainLooper());
        this.xINpNt2d = n1vNRFSd;
    }

    public static final int mTWLV(Wl27nX2 wl27nX2) {
        if (wl27nX2 == null) {
            return -1;
        }
        return wl27nX2.eszJ2B0a();
    }

    @Override // jcwfs78.HicDZW
    public final void ivfTYNl(int i10, int i11, Intent intent) {
        Wl27nX2 wl27nX2 = (Wl27nX2) this.gmzPK.get();
        if (i10 != 1) {
            if (i10 == 2) {
                int iRjljd6i = this.xINpNt2d.rjljd6i(aXYSYCVY());
                if (iRjljd6i == 0) {
                    yxejkub();
                    return;
                } else {
                    if (wl27nX2 == null) {
                        return;
                    }
                    if (wl27nX2.aXYSYCVY().q1ORKN() == 18 && iRjljd6i == 18) {
                        return;
                    }
                }
            }
        } else if (i11 == -1) {
            yxejkub();
            return;
        } else if (i11 == 0) {
            if (wl27nX2 != null) {
                q1ORKN(new ConnectionResult(intent != null ? intent.getIntExtra("<<ResolutionFailureErrorDetail>>", 13) : 13, null, wl27nX2.aXYSYCVY().toString()), mTWLV(wl27nX2));
                return;
            }
            return;
        }
        if (wl27nX2 != null) {
            q1ORKN(wl27nX2.aXYSYCVY(), wl27nX2.eszJ2B0a());
        }
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        q1ORKN(new ConnectionResult(13, null), mTWLV((Wl27nX2) this.gmzPK.get()));
    }

    @Override // jcwfs78.HicDZW
    public final void osx7Pl0E(Bundle bundle) {
        super.osx7Pl0E(bundle);
        if (bundle != null) {
            this.gmzPK.set(bundle.getBoolean("resolving_error", false) ? new Wl27nX2(new ConnectionResult(bundle.getInt("failed_status"), (PendingIntent) bundle.getParcelable("failed_resolution")), bundle.getInt("failed_client_id", -1)) : null);
        }
    }

    public final void q1ORKN(ConnectionResult connectionResult, int i10) {
        this.gmzPK.set(null);
        uTIfLNK0(connectionResult, i10);
    }

    @Override // jcwfs78.HicDZW
    public void qLLw0g() {
        super.qLLw0g();
        this.vo5p9AUA = false;
    }

    @Override // jcwfs78.HicDZW
    public final void rjljd6i(Bundle bundle) {
        super.rjljd6i(bundle);
        Wl27nX2 wl27nX2 = (Wl27nX2) this.gmzPK.get();
        if (wl27nX2 == null) {
            return;
        }
        bundle.putBoolean("resolving_error", true);
        bundle.putInt("failed_client_id", wl27nX2.eszJ2B0a());
        bundle.putInt("failed_status", wl27nX2.aXYSYCVY().q1ORKN());
        bundle.putParcelable("failed_resolution", wl27nX2.aXYSYCVY().egsKh());
    }

    public final void rtsRj(ConnectionResult connectionResult, int i10) {
        AtomicReference atomicReference;
        Wl27nX2 wl27nX2 = new Wl27nX2(connectionResult, i10);
        do {
            atomicReference = this.gmzPK;
            if (androidx.camera.view.H8UuVVi.eszJ2B0a(atomicReference, null, wl27nX2)) {
                this.zYD7SXW6.post(new UhFXwfhx(this, wl27nX2));
                return;
            }
        } while (atomicReference.get() == null);
    }

    public abstract void uTIfLNK0(ConnectionResult connectionResult, int i10);

    public abstract void uYRSwDm();

    public final void yxejkub() {
        this.gmzPK.set(null);
        uYRSwDm();
    }

    @Override // jcwfs78.HicDZW
    public void zPJpxWz() {
        super.zPJpxWz();
        this.vo5p9AUA = true;
    }
}
