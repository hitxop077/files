package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class MCUSO {
    public final int aXYSYCVY;
    public final com.google.android.gms.common.api.LNd998w eLbhX59K;
    public final MkXy0K3 eszJ2B0a;

    public MCUSO(MkXy0K3 mkXy0K3, int i10, com.google.android.gms.common.api.LNd998w lNd998w) {
        this.eszJ2B0a = mkXy0K3;
        this.aXYSYCVY = i10;
        this.eLbhX59K = lNd998w;
    }
}
