package jcwfs78;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class RkdvoZ implements OnCompleteListener {
    public final /* synthetic */ a4dh7ol.HicDZW njNibPNp;
    public final /* synthetic */ IMpOqqn vo5p9AUA;

    public RkdvoZ(IMpOqqn iMpOqqn, a4dh7ol.HicDZW hicDZW) {
        this.vo5p9AUA = iMpOqqn;
        this.njNibPNp = hicDZW;
    }

    @Override // com.google.android.gms.tasks.OnCompleteListener
    public final void onComplete(Task task) {
        this.vo5p9AUA.aXYSYCVY.remove(this.njNibPNp);
    }
}
