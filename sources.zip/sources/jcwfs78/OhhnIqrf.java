package jcwfs78;

import com.google.android.gms.common.internal.MethodInvocation;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class OhhnIqrf {
    public final int aXYSYCVY;
    public final long eLbhX59K;
    public final MethodInvocation eszJ2B0a;
    public final int zDWsfFRp;

    public OhhnIqrf(MethodInvocation methodInvocation, int i10, long j10, int i11) {
        this.eszJ2B0a = methodInvocation;
        this.aXYSYCVY = i10;
        this.eLbhX59K = j10;
        this.zDWsfFRp = i11;
    }
}
