package jcwfs78;

import com.google.android.gms.signin.internal.zak;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class IGmZk implements Runnable {
    public final /* synthetic */ zak njNibPNp;
    public final /* synthetic */ HUx1xD vo5p9AUA;

    public IGmZk(HUx1xD hUx1xD, zak zakVar) {
        this.vo5p9AUA = hUx1xD;
        this.njNibPNp = zakVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        HUx1xD.ahxwvx7(this.vo5p9AUA, this.njNibPNp);
    }
}
