package jcwfs78;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class SiyNFU implements AjKBk {
    public final /* synthetic */ H8UuVVi eszJ2B0a;

    public /* synthetic */ SiyNFU(H8UuVVi h8UuVVi, I8loLBkM i8loLBkM) {
        this.eszJ2B0a = h8UuVVi;
    }

    @Override // jcwfs78.AjKBk
    public final void aXYSYCVY(Bundle bundle) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            this.eszJ2B0a.zigsCJW = ConnectionResult.fdmP9GD;
            H8UuVVi.eImdmIyv(this.eszJ2B0a);
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.AjKBk
    public final void eLbhX59K(ConnectionResult connectionResult) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            this.eszJ2B0a.zigsCJW = connectionResult;
            H8UuVVi.eImdmIyv(this.eszJ2B0a);
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.AjKBk
    public final void eszJ2B0a(int i10, boolean z10) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            H8UuVVi h8UuVVi = this.eszJ2B0a;
            if (h8UuVVi.ca3iT) {
                h8UuVVi.ca3iT = false;
                H8UuVVi.sMxPLer(this.eszJ2B0a, i10, z10);
            } else {
                h8UuVVi.ca3iT = true;
                this.eszJ2B0a.zYD7SXW6.onConnectionSuspended(i10);
            }
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }
}
