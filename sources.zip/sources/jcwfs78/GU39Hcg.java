package jcwfs78;

import android.app.Activity;
import androidx.fragment.app.FragmentActivity;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class GU39Hcg {
    public final Object eszJ2B0a;

    public GU39Hcg(Activity activity) {
        f5zilcb.VVpVRy.uYRSwDm(activity, "Activity must not be null");
        this.eszJ2B0a = activity;
    }

    public final boolean aXYSYCVY() {
        return this.eszJ2B0a instanceof Activity;
    }

    public final Activity eLbhX59K() {
        return (Activity) this.eszJ2B0a;
    }

    public final boolean eszJ2B0a() {
        return this.eszJ2B0a instanceof FragmentActivity;
    }

    public final FragmentActivity zDWsfFRp() {
        return (FragmentActivity) this.eszJ2B0a;
    }
}
