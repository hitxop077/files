package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class XR9Xco {
    public final Lx1jI.MY3jR eszJ2B0a;

    public XR9Xco(Lx1jI.MY3jR mY3jR) {
        this.eszJ2B0a = mY3jR;
    }

    public abstract void aXYSYCVY(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW);

    public Lx1jI.MY3jR eszJ2B0a() {
        return this.eszJ2B0a;
    }
}
