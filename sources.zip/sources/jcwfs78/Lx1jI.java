package jcwfs78;

import android.os.Looper;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Lx1jI {
    public volatile Object aXYSYCVY;
    public volatile MY3jR eLbhX59K;
    public final Executor eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public interface AAnYcst {
        void aXYSYCVY();

        void eszJ2B0a(Object obj);
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR {
        public final String aXYSYCVY;
        public final Object eszJ2B0a;

        public MY3jR(Object obj, String str) {
            this.eszJ2B0a = obj;
            this.aXYSYCVY = str;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof MY3jR)) {
                return false;
            }
            MY3jR mY3jR = (MY3jR) obj;
            return this.eszJ2B0a == mY3jR.eszJ2B0a && this.aXYSYCVY.equals(mY3jR.aXYSYCVY);
        }

        public String eszJ2B0a() {
            return this.aXYSYCVY + "@" + System.identityHashCode(this.eszJ2B0a);
        }

        public int hashCode() {
            return (System.identityHashCode(this.eszJ2B0a) * 31) + this.aXYSYCVY.hashCode();
        }
    }

    public Lx1jI(Looper looper, Object obj, String str) {
        this.eszJ2B0a = new bmb3rm89.MY3jR(looper);
        this.aXYSYCVY = f5zilcb.VVpVRy.uYRSwDm(obj, "Listener must not be null");
        this.eLbhX59K = new MY3jR(obj, f5zilcb.VVpVRy.dUI84(str));
    }

    public MY3jR aXYSYCVY() {
        return this.eLbhX59K;
    }

    public void eLbhX59K(final AAnYcst aAnYcst) {
        f5zilcb.VVpVRy.uYRSwDm(aAnYcst, "Notifier must not be null");
        this.eszJ2B0a.execute(new Runnable() { // from class: jcwfs78.FjjWA4N
            @Override // java.lang.Runnable
            public final void run() {
                this.njNibPNp.zDWsfFRp(aAnYcst);
            }
        });
    }

    public void eszJ2B0a() {
        this.aXYSYCVY = null;
        this.eLbhX59K = null;
    }

    public final void zDWsfFRp(AAnYcst aAnYcst) {
        Object obj = this.aXYSYCVY;
        if (obj == null) {
            aAnYcst.aXYSYCVY();
            return;
        }
        try {
            aAnYcst.eszJ2B0a(obj);
        } catch (RuntimeException e10) {
            aAnYcst.aXYSYCVY();
            throw e10;
        }
    }

    public Lx1jI(Executor executor, Object obj, String str) {
        this.eszJ2B0a = (Executor) f5zilcb.VVpVRy.uYRSwDm(executor, "Executor must not be null");
        this.aXYSYCVY = f5zilcb.VVpVRy.uYRSwDm(obj, "Listener must not be null");
        this.eLbhX59K = new MY3jR(obj, f5zilcb.VVpVRy.dUI84(str));
    }
}
