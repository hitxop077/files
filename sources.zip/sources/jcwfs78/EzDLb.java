package jcwfs78;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class EzDLb implements AjKBk {
    public final /* synthetic */ H8UuVVi eszJ2B0a;

    public /* synthetic */ EzDLb(H8UuVVi h8UuVVi, ANdw3bYe aNdw3bYe) {
        this.eszJ2B0a = h8UuVVi;
    }

    @Override // jcwfs78.AjKBk
    public final void aXYSYCVY(Bundle bundle) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            H8UuVVi.c1pvtY(this.eszJ2B0a, bundle);
            this.eszJ2B0a.i2VlO = ConnectionResult.fdmP9GD;
            H8UuVVi.eImdmIyv(this.eszJ2B0a);
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.AjKBk
    public final void eLbhX59K(ConnectionResult connectionResult) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            this.eszJ2B0a.i2VlO = connectionResult;
            H8UuVVi.eImdmIyv(this.eszJ2B0a);
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.AjKBk
    public final void eszJ2B0a(int i10, boolean z10) {
        this.eszJ2B0a.bBHqyf.lock();
        try {
            H8UuVVi h8UuVVi = this.eszJ2B0a;
            if (h8UuVVi.ca3iT || h8UuVVi.zigsCJW == null || !h8UuVVi.zigsCJW.zlPyDfl()) {
                this.eszJ2B0a.ca3iT = false;
                H8UuVVi.sMxPLer(this.eszJ2B0a, i10, z10);
            } else {
                this.eszJ2B0a.ca3iT = true;
                this.eszJ2B0a.xINpNt2d.onConnectionSuspended(i10);
            }
        } finally {
            this.eszJ2B0a.bBHqyf.unlock();
        }
    }
}
