package jcwfs78;

import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class Jg4Z0Io9 {
    public static void aXYSYCVY(Status status, Object obj, a4dh7ol.HicDZW hicDZW) {
        if (status.zlPyDfl()) {
            hicDZW.eLbhX59K(obj);
        } else {
            hicDZW.aXYSYCVY(f5zilcb.MY3jR.eszJ2B0a(status));
        }
    }

    public static boolean eLbhX59K(Status status, Object obj, a4dh7ol.HicDZW hicDZW) {
        return status.zlPyDfl() ? hicDZW.ivfTYNl(obj) : hicDZW.zDWsfFRp(f5zilcb.MY3jR.eszJ2B0a(status));
    }

    public static void eszJ2B0a(Status status, a4dh7ol.HicDZW hicDZW) {
        aXYSYCVY(status, null, hicDZW);
    }
}
