package jcwfs78;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class LksRT6 implements com.google.android.gms.common.api.W7Cnq5.MY3jR {
    public final /* synthetic */ IMpOqqn aXYSYCVY;
    public final /* synthetic */ BasePendingResult eszJ2B0a;

    public LksRT6(IMpOqqn iMpOqqn, BasePendingResult basePendingResult) {
        this.aXYSYCVY = iMpOqqn;
        this.eszJ2B0a = basePendingResult;
    }

    @Override // com.google.android.gms.common.api.W7Cnq5.MY3jR
    public final void eszJ2B0a(Status status) {
        this.aXYSYCVY.eszJ2B0a.remove(this.eszJ2B0a);
    }
}
