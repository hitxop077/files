package jcwfs78;

import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface ZIAa4n {
    com.google.android.gms.common.api.internal.MY3jR aXYSYCVY(com.google.android.gms.common.api.internal.MY3jR mY3jR);

    void dUI84(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    void eLbhX59K();

    com.google.android.gms.common.api.internal.MY3jR eszJ2B0a(com.google.android.gms.common.api.internal.MY3jR mY3jR);

    boolean ivfTYNl(NUIvmoc nUIvmoc);

    boolean oZ7qYn();

    void osx7Pl0E();

    boolean rjljd6i();

    void zDWsfFRp();
}
