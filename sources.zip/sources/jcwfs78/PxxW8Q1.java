package jcwfs78;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class PxxW8Q1 {
    public Bundle eLbhX59K;
    public final Map eszJ2B0a = Collections.synchronizedMap(new androidx.collection.MY3jR());
    public int aXYSYCVY = 0;

    public final void aXYSYCVY(String str, HicDZW hicDZW) {
        Map map = this.eszJ2B0a;
        if (map.containsKey(str)) {
            StringBuilder sb2 = new StringBuilder(String.valueOf(str).length() + 59);
            sb2.append("LifecycleCallback with tag ");
            sb2.append(str);
            sb2.append(" already added to this fragment.");
            throw new IllegalArgumentException(sb2.toString());
        }
        map.put(str, hicDZW);
        if (this.aXYSYCVY > 0) {
            new com.google.android.gms.internal.common.VI3TfJlk(Looper.getMainLooper()).post(new GAJbYy(this, hicDZW, str));
        }
    }

    public final void dUI84(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        for (Map.Entry entry : this.eszJ2B0a.entrySet()) {
            Bundle bundle2 = new Bundle();
            ((HicDZW) entry.getValue()).rjljd6i(bundle2);
            bundle.putBundle((String) entry.getKey(), bundle2);
        }
    }

    public final void eLbhX59K(Bundle bundle) {
        this.aXYSYCVY = 1;
        this.eLbhX59K = bundle;
        for (Map.Entry entry : this.eszJ2B0a.entrySet()) {
            ((HicDZW) entry.getValue()).osx7Pl0E(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public final HicDZW eszJ2B0a(String str, Class cls) {
        return (HicDZW) cls.cast(this.eszJ2B0a.get(str));
    }

    public final void ivfTYNl() {
        this.aXYSYCVY = 3;
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).oZ7qYn();
        }
    }

    public final void oZ7qYn() {
        this.aXYSYCVY = 4;
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).qLLw0g();
        }
    }

    public final void osx7Pl0E(int i10, int i11, Intent intent) {
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).ivfTYNl(i10, i11, intent);
        }
    }

    public final /* synthetic */ Bundle q1ORKN() {
        return this.eLbhX59K;
    }

    public final /* synthetic */ int qLLw0g() {
        return this.aXYSYCVY;
    }

    public final void rjljd6i() {
        this.aXYSYCVY = 5;
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).dUI84();
        }
    }

    public final void zDWsfFRp() {
        this.aXYSYCVY = 2;
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).zPJpxWz();
        }
    }

    public final void zPJpxWz(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        Iterator it2 = this.eszJ2B0a.values().iterator();
        while (it2.hasNext()) {
            ((HicDZW) it2.next()).eszJ2B0a(str, fileDescriptor, printWriter, strArr);
        }
    }
}
