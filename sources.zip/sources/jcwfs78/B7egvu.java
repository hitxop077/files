package jcwfs78;

import java.util.concurrent.ExecutorService;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class B7egvu {
    public static final ExecutorService eszJ2B0a = ir9vwy.Bv3FS.eszJ2B0a().eszJ2B0a(2, new bmb3rm89.RFQ3AA8("GAC_Executor"), 2);

    public static ExecutorService eszJ2B0a() {
        return eszJ2B0a;
    }
}
