package jcwfs78;

import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.zav;
import com.google.android.gms.signin.internal.zak;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class BgOcqi implements AL02fFI {
    public final Lock aXYSYCVY;
    public final Context eLbhX59K;
    public final DrXCNOo9 eszJ2B0a;
    public ConnectionResult ivfTYNl;
    public final f5zilcb.LNd998w jAM6dcNA;
    public boolean mTWLV;
    public int oZ7qYn;
    public int osx7Pl0E;
    public final com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR oyaOvpOs;
    public boolean q1ORKN;
    public g0f7s.N1vNRFSd qLLw0g;
    public boolean rJCQt16;
    public final Map rtsRj;
    public boolean uTIfLNK0;
    public boolean uYRSwDm;
    public com.google.android.gms.common.internal.AAnYcst yxejkub;
    public final uchv3v.XbU7b zDWsfFRp;
    public int dUI84 = 0;
    public final Bundle rjljd6i = new Bundle();
    public final Set zPJpxWz = new HashSet();
    public final ArrayList n84TFkA9 = new ArrayList();

    public BgOcqi(DrXCNOo9 drXCNOo9, f5zilcb.LNd998w lNd998w, Map map, uchv3v.XbU7b xbU7b, com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR, Lock lock, Context context) {
        this.eszJ2B0a = drXCNOo9;
        this.jAM6dcNA = lNd998w;
        this.rtsRj = map;
        this.zDWsfFRp = xbU7b;
        this.oyaOvpOs = abstractC0848MY3jR;
        this.aXYSYCVY = lock;
        this.eLbhX59K = context;
    }

    public static /* bridge */ /* synthetic */ Set eImdmIyv(BgOcqi bgOcqi) {
        f5zilcb.LNd998w lNd998w = bgOcqi.jAM6dcNA;
        if (lNd998w == null) {
            return Collections.EMPTY_SET;
        }
        HashSet hashSet = new HashSet(lNd998w.dUI84());
        Map mapQLLw0g = bgOcqi.jAM6dcNA.qLLw0g();
        for (com.google.android.gms.common.api.MY3jR mY3jR : mapQLLw0g.keySet()) {
            DrXCNOo9 drXCNOo9 = bgOcqi.eszJ2B0a;
            if (!drXCNOo9.vskcqLTQ.containsKey(mY3jR.aXYSYCVY())) {
                android.support.v4.media.MY3jR.eszJ2B0a(mapQLLw0g.get(mY3jR));
                throw null;
            }
        }
        return hashSet;
    }

    public static final String jAM6dcNA(int i10) {
        return i10 != 0 ? "STEP_GETTING_REMOTE_SERVICE" : "STEP_SERVICE_BINDINGS_AND_SIGN_IN";
    }

    public static /* bridge */ /* synthetic */ void nyeBEo(BgOcqi bgOcqi, zak zakVar) {
        if (bgOcqi.yxejkub(0)) {
            ConnectionResult connectionResultQLLw0g = zakVar.qLLw0g();
            if (!connectionResultQLLw0g.zlPyDfl()) {
                if (!bgOcqi.rJCQt16(connectionResultQLLw0g)) {
                    bgOcqi.q1ORKN(connectionResultQLLw0g);
                    return;
                } else {
                    bgOcqi.rjljd6i();
                    bgOcqi.uYRSwDm();
                    return;
                }
            }
            zav zavVar = (zav) f5zilcb.VVpVRy.uTIfLNK0(zakVar.q1ORKN());
            ConnectionResult connectionResultQLLw0g2 = zavVar.qLLw0g();
            if (!connectionResultQLLw0g2.zlPyDfl()) {
                String strValueOf = String.valueOf(connectionResultQLLw0g2);
                new Exception();
                "Sign-in succeeded with resolve account failure: ".concat(strValueOf);
                bgOcqi.q1ORKN(connectionResultQLLw0g2);
                return;
            }
            bgOcqi.uYRSwDm = true;
            bgOcqi.yxejkub = (com.google.android.gms.common.internal.AAnYcst) f5zilcb.VVpVRy.uTIfLNK0(zavVar.q1ORKN());
            bgOcqi.mTWLV = zavVar.yxejkub();
            bgOcqi.rJCQt16 = zavVar.egsKh();
            bgOcqi.uYRSwDm();
        }
    }

    public final void d3penA() {
        ArrayList arrayList = this.n84TFkA9;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((Future) arrayList.get(i10)).cancel(true);
        }
        this.n84TFkA9.clear();
    }

    @Override // jcwfs78.AL02fFI
    public final void dUI84(Bundle bundle) {
        if (yxejkub(1)) {
            if (bundle != null) {
                this.rjljd6i.putAll(bundle);
            }
            if (mTWLV()) {
                qLLw0g();
            }
        }
    }

    @Override // jcwfs78.AL02fFI
    public final void eLbhX59K(int i10) {
        q1ORKN(new ConnectionResult(8, null));
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [com.google.android.gms.common.api.MY3jR$XbU7b, g0f7s.N1vNRFSd] */
    @Override // jcwfs78.AL02fFI
    public final void eszJ2B0a() {
        this.eszJ2B0a.vskcqLTQ.clear();
        this.uTIfLNK0 = false;
        O0DWnU o0DWnU = null;
        this.ivfTYNl = null;
        this.dUI84 = 0;
        this.q1ORKN = true;
        this.uYRSwDm = false;
        this.mTWLV = false;
        HashMap map = new HashMap();
        boolean z10 = false;
        for (com.google.android.gms.common.api.MY3jR mY3jR : this.rtsRj.keySet()) {
            com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = (com.google.android.gms.common.api.MY3jR.XbU7b) f5zilcb.VVpVRy.uTIfLNK0((com.google.android.gms.common.api.MY3jR.XbU7b) this.eszJ2B0a.fdmP9GD.get(mY3jR.aXYSYCVY()));
            z10 |= mY3jR.eLbhX59K().aXYSYCVY() == 1;
            boolean zBooleanValue = ((Boolean) this.rtsRj.get(mY3jR)).booleanValue();
            if (xbU7b.dUI84()) {
                this.uTIfLNK0 = true;
                if (zBooleanValue) {
                    this.zPJpxWz.add(mY3jR.aXYSYCVY());
                } else {
                    this.q1ORKN = false;
                }
            }
            map.put(xbU7b, new Qq2TyU2J(this, mY3jR, zBooleanValue));
        }
        if (z10) {
            this.uTIfLNK0 = false;
        }
        if (this.uTIfLNK0) {
            f5zilcb.VVpVRy.uTIfLNK0(this.jAM6dcNA);
            f5zilcb.VVpVRy.uTIfLNK0(this.oyaOvpOs);
            this.jAM6dcNA.q1ORKN(Integer.valueOf(System.identityHashCode(this.eszJ2B0a.xnFvJEz)));
            QLaNltKD qLaNltKD = new QLaNltKD(this, o0DWnU);
            com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR = this.oyaOvpOs;
            Context context = this.eLbhX59K;
            DrXCNOo9 drXCNOo9 = this.eszJ2B0a;
            f5zilcb.LNd998w lNd998w = this.jAM6dcNA;
            this.qLLw0g = abstractC0848MY3jR.eLbhX59K(context, drXCNOo9.xnFvJEz.qLLw0g(), lNd998w, lNd998w.oZ7qYn(), qLaNltKD, qLaNltKD);
        }
        this.oZ7qYn = this.eszJ2B0a.fdmP9GD.size();
        this.n84TFkA9.add(B7egvu.eszJ2B0a().submit(new I1KGSb0S(this, map)));
    }

    @Override // jcwfs78.AL02fFI
    public final boolean ivfTYNl() {
        d3penA();
        zPJpxWz(true);
        this.eszJ2B0a.uYRSwDm(null);
        return true;
    }

    public final boolean mTWLV() {
        int i10 = this.oZ7qYn - 1;
        this.oZ7qYn = i10;
        if (i10 > 0) {
            return false;
        }
        if (i10 < 0) {
            this.eszJ2B0a.xnFvJEz.bsO5Vo();
            new Exception();
            q1ORKN(new ConnectionResult(8, null));
            return false;
        }
        ConnectionResult connectionResult = this.ivfTYNl;
        if (connectionResult == null) {
            return true;
        }
        this.eszJ2B0a.bBHqyf = this.osx7Pl0E;
        q1ORKN(connectionResult);
        return false;
    }

    @Override // jcwfs78.AL02fFI
    public final void oZ7qYn(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
        if (yxejkub(1)) {
            uTIfLNK0(connectionResult, mY3jR, z10);
            if (mTWLV()) {
                qLLw0g();
            }
        }
    }

    @Override // jcwfs78.AL02fFI
    public final com.google.android.gms.common.api.internal.MY3jR osx7Pl0E(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }

    public final void q1ORKN(ConnectionResult connectionResult) {
        d3penA();
        zPJpxWz(!connectionResult.fIz14cTt());
        this.eszJ2B0a.uYRSwDm(connectionResult);
        this.eszJ2B0a.cOkM2.eLbhX59K(connectionResult);
    }

    public final void qLLw0g() {
        this.eszJ2B0a.q1ORKN();
        B7egvu.eszJ2B0a().execute(new EY5bX(this));
        g0f7s.N1vNRFSd n1vNRFSd = this.qLLw0g;
        if (n1vNRFSd != null) {
            if (this.mTWLV) {
                n1vNRFSd.uTIfLNK0((com.google.android.gms.common.internal.AAnYcst) f5zilcb.VVpVRy.uTIfLNK0(this.yxejkub), this.rJCQt16);
            }
            zPJpxWz(false);
        }
        Iterator it2 = this.eszJ2B0a.vskcqLTQ.keySet().iterator();
        while (it2.hasNext()) {
            ((com.google.android.gms.common.api.MY3jR.XbU7b) f5zilcb.VVpVRy.uTIfLNK0((com.google.android.gms.common.api.MY3jR.XbU7b) this.eszJ2B0a.fdmP9GD.get((com.google.android.gms.common.api.MY3jR.RFQ3AA8) it2.next()))).aXYSYCVY();
        }
        this.eszJ2B0a.cOkM2.aXYSYCVY(this.rjljd6i.isEmpty() ? null : this.rjljd6i);
    }

    public final boolean rJCQt16(ConnectionResult connectionResult) {
        return this.q1ORKN && !connectionResult.fIz14cTt();
    }

    public final void rjljd6i() {
        this.uTIfLNK0 = false;
        this.eszJ2B0a.xnFvJEz.mTWLV = Collections.EMPTY_SET;
        for (com.google.android.gms.common.api.MY3jR.RFQ3AA8 rfq3aa8 : this.zPJpxWz) {
            if (!this.eszJ2B0a.vskcqLTQ.containsKey(rfq3aa8)) {
                DrXCNOo9 drXCNOo9 = this.eszJ2B0a;
                drXCNOo9.vskcqLTQ.put(rfq3aa8, new ConnectionResult(17, null));
            }
        }
    }

    public final void uTIfLNK0(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
        int iAXYSYCVY = mY3jR.eLbhX59K().aXYSYCVY();
        if ((!z10 || connectionResult.fIz14cTt() || this.zDWsfFRp.eLbhX59K(connectionResult.q1ORKN()) != null) && (this.ivfTYNl == null || iAXYSYCVY < this.osx7Pl0E)) {
            this.ivfTYNl = connectionResult;
            this.osx7Pl0E = iAXYSYCVY;
        }
        DrXCNOo9 drXCNOo9 = this.eszJ2B0a;
        drXCNOo9.vskcqLTQ.put(mY3jR.aXYSYCVY(), connectionResult);
    }

    public final void uYRSwDm() {
        if (this.oZ7qYn != 0) {
            return;
        }
        if (!this.uTIfLNK0 || this.uYRSwDm) {
            ArrayList arrayList = new ArrayList();
            this.dUI84 = 1;
            this.oZ7qYn = this.eszJ2B0a.fdmP9GD.size();
            for (com.google.android.gms.common.api.MY3jR.RFQ3AA8 rfq3aa8 : this.eszJ2B0a.fdmP9GD.keySet()) {
                if (!this.eszJ2B0a.vskcqLTQ.containsKey(rfq3aa8)) {
                    arrayList.add((com.google.android.gms.common.api.MY3jR.XbU7b) this.eszJ2B0a.fdmP9GD.get(rfq3aa8));
                } else if (mTWLV()) {
                    qLLw0g();
                }
            }
            if (arrayList.isEmpty()) {
                return;
            }
            this.n84TFkA9.add(B7egvu.eszJ2B0a().submit(new UjGBKKw(this, arrayList)));
        }
    }

    public final boolean yxejkub(int i10) {
        if (this.dUI84 == i10) {
            return true;
        }
        this.eszJ2B0a.xnFvJEz.bsO5Vo();
        "Unexpected callback in ".concat(toString());
        jAM6dcNA(this.dUI84);
        jAM6dcNA(i10);
        new Exception();
        q1ORKN(new ConnectionResult(8, null));
        return false;
    }

    @Override // jcwfs78.AL02fFI
    public final com.google.android.gms.common.api.internal.MY3jR zDWsfFRp(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        this.eszJ2B0a.xnFvJEz.oZ7qYn.add(mY3jR);
        return mY3jR;
    }

    public final void zPJpxWz(boolean z10) {
        g0f7s.N1vNRFSd n1vNRFSd = this.qLLw0g;
        if (n1vNRFSd != null) {
            if (n1vNRFSd.eszJ2B0a() && z10) {
                n1vNRFSd.osx7Pl0E();
            }
            n1vNRFSd.aXYSYCVY();
            this.yxejkub = null;
        }
    }

    @Override // jcwfs78.AL02fFI
    public final void aXYSYCVY() {
    }
}
