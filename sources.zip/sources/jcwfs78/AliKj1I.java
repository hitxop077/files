package jcwfs78;

import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class AliKj1I extends com.google.android.gms.common.api.N1vNRFSd {
    public final String aXYSYCVY = "Method is not supported by connectionless client. APIs supporting connectionless client must not call this method.";

    public AliKj1I(String str) {
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void ivfTYNl() {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void jAM6dcNA(com.google.android.gms.common.api.N1vNRFSd.AAnYcst aAnYcst) {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void mTWLV(com.google.android.gms.common.api.N1vNRFSd.AAnYcst aAnYcst) {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void osx7Pl0E(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final boolean q1ORKN() {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void rJCQt16(com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 rfq3aa8) {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void rtsRj(com.google.android.gms.common.api.N1vNRFSd.RFQ3AA8 rfq3aa8) {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final boolean uTIfLNK0() {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }

    @Override // com.google.android.gms.common.api.N1vNRFSd
    public final void zDWsfFRp() {
        throw new UnsupportedOperationException(this.aXYSYCVY);
    }
}
