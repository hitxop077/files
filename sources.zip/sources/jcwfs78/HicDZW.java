package jcwfs78;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class HicDZW {
    public final JQAVH njNibPNp;

    public HicDZW(JQAVH jqavh) {
        this.njNibPNp = jqavh;
    }

    public static JQAVH eLbhX59K(Activity activity) {
        return zDWsfFRp(new GU39Hcg(activity));
    }

    public static JQAVH zDWsfFRp(GU39Hcg gU39Hcg) {
        if (gU39Hcg.eszJ2B0a()) {
            return KPH7ZX6.ekiPo(gU39Hcg.zDWsfFRp());
        }
        if (gU39Hcg.aXYSYCVY()) {
            return LV4CzgpJ.eszJ2B0a(gU39Hcg.eLbhX59K());
        }
        throw new IllegalArgumentException("Can't get fragment for unexpected activity.");
    }

    public Activity aXYSYCVY() {
        Activity activityYwA25jds = this.njNibPNp.ywA25jds();
        f5zilcb.VVpVRy.uTIfLNK0(activityYwA25jds);
        return activityYwA25jds;
    }

    public void dUI84() {
    }

    public void oZ7qYn() {
    }

    public void qLLw0g() {
    }

    public void zPJpxWz() {
    }

    public void osx7Pl0E(Bundle bundle) {
    }

    public void rjljd6i(Bundle bundle) {
    }

    public void ivfTYNl(int i10, int i11, Intent intent) {
    }

    public void eszJ2B0a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }
}
