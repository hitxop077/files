package jcwfs78;

import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface O5Z56VT6 {
    Exception eszJ2B0a(Status status);
}
