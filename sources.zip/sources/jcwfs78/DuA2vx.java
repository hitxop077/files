package jcwfs78;

import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface DuA2vx extends com.google.android.gms.common.api.N1vNRFSd.AAnYcst {
    void m8rcW6(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10);
}
