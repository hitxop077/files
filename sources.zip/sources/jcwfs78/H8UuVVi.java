package jcwfs78;

import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class H8UuVVi implements ZIAa4n {
    public final Lock bBHqyf;
    public Bundle dNE3s;
    public final Map fdmP9GD;
    public final Looper gmzPK;
    public final Context njNibPNp;
    public final com.google.android.gms.common.api.MY3jR.XbU7b pz7TsV;
    public final ZQB7k vo5p9AUA;
    public final DrXCNOo9 xINpNt2d;
    public final DrXCNOo9 zYD7SXW6;
    public final Set vskcqLTQ = Collections.newSetFromMap(new WeakHashMap());
    public ConnectionResult i2VlO = null;
    public ConnectionResult zigsCJW = null;
    public boolean ca3iT = false;
    public int xnFvJEz = 0;

    public H8UuVVi(Context context, ZQB7k zQB7k, Lock lock, Looper looper, uchv3v.XbU7b xbU7b, Map map, Map map2, f5zilcb.LNd998w lNd998w, com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR, com.google.android.gms.common.api.MY3jR.XbU7b xbU7b2, ArrayList arrayList, ArrayList arrayList2, Map map3, Map map4) {
        this.njNibPNp = context;
        this.vo5p9AUA = zQB7k;
        this.bBHqyf = lock;
        this.gmzPK = looper;
        this.pz7TsV = xbU7b2;
        this.zYD7SXW6 = new DrXCNOo9(context, zQB7k, lock, looper, xbU7b, map2, null, map4, null, arrayList2, new EzDLb(this, null));
        this.xINpNt2d = new DrXCNOo9(context, zQB7k, lock, looper, xbU7b, map, lNd998w, map3, abstractC0848MY3jR, arrayList, new SiyNFU(this, 0 == true ? 1 : 0));
        androidx.collection.MY3jR mY3jR = new androidx.collection.MY3jR();
        Iterator it2 = map2.keySet().iterator();
        while (it2.hasNext()) {
            mY3jR.put((com.google.android.gms.common.api.MY3jR.RFQ3AA8) it2.next(), this.zYD7SXW6);
        }
        Iterator it3 = map.keySet().iterator();
        while (it3.hasNext()) {
            mY3jR.put((com.google.android.gms.common.api.MY3jR.RFQ3AA8) it3.next(), this.xINpNt2d);
        }
        this.fdmP9GD = Collections.unmodifiableMap(mY3jR);
    }

    public static /* bridge */ /* synthetic */ void c1pvtY(H8UuVVi h8UuVVi, Bundle bundle) {
        Bundle bundle2 = h8UuVVi.dNE3s;
        if (bundle2 == null) {
            h8UuVVi.dNE3s = bundle;
        } else if (bundle != null) {
            bundle2.putAll(bundle);
        }
    }

    public static /* bridge */ /* synthetic */ void eImdmIyv(H8UuVVi h8UuVVi) {
        ConnectionResult connectionResult;
        if (!uYRSwDm(h8UuVVi.i2VlO)) {
            if (h8UuVVi.i2VlO != null && uYRSwDm(h8UuVVi.zigsCJW)) {
                h8UuVVi.xINpNt2d.osx7Pl0E();
                h8UuVVi.zPJpxWz((ConnectionResult) f5zilcb.VVpVRy.uTIfLNK0(h8UuVVi.i2VlO));
                return;
            }
            ConnectionResult connectionResult2 = h8UuVVi.i2VlO;
            if (connectionResult2 == null || (connectionResult = h8UuVVi.zigsCJW) == null) {
                return;
            }
            if (h8UuVVi.xINpNt2d.bBHqyf < h8UuVVi.zYD7SXW6.bBHqyf) {
                connectionResult2 = connectionResult;
            }
            h8UuVVi.zPJpxWz(connectionResult2);
            return;
        }
        if (uYRSwDm(h8UuVVi.zigsCJW) || h8UuVVi.q1ORKN()) {
            int i10 = h8UuVVi.xnFvJEz;
            if (i10 == 1) {
                h8UuVVi.qLLw0g();
            } else if (i10 != 2) {
                new AssertionError();
            } else {
                ((ZQB7k) f5zilcb.VVpVRy.uTIfLNK0(h8UuVVi.vo5p9AUA)).aXYSYCVY(h8UuVVi.dNE3s);
                h8UuVVi.qLLw0g();
            }
            h8UuVVi.xnFvJEz = 0;
            return;
        }
        ConnectionResult connectionResult3 = h8UuVVi.zigsCJW;
        if (connectionResult3 != null) {
            if (h8UuVVi.xnFvJEz == 1) {
                h8UuVVi.qLLw0g();
            } else {
                h8UuVVi.zPJpxWz(connectionResult3);
                h8UuVVi.zYD7SXW6.osx7Pl0E();
            }
        }
    }

    public static H8UuVVi mTWLV(Context context, ZQB7k zQB7k, Lock lock, Looper looper, uchv3v.XbU7b xbU7b, Map map, f5zilcb.LNd998w lNd998w, Map map2, com.google.android.gms.common.api.MY3jR.AbstractC0848MY3jR abstractC0848MY3jR, ArrayList arrayList) {
        androidx.collection.MY3jR mY3jR = new androidx.collection.MY3jR();
        androidx.collection.MY3jR mY3jR2 = new androidx.collection.MY3jR();
        com.google.android.gms.common.api.MY3jR.XbU7b xbU7b2 = null;
        for (Map.Entry entry : map.entrySet()) {
            com.google.android.gms.common.api.MY3jR.XbU7b xbU7b3 = (com.google.android.gms.common.api.MY3jR.XbU7b) entry.getValue();
            if (true == xbU7b3.eLbhX59K()) {
                xbU7b2 = xbU7b3;
            }
            if (xbU7b3.dUI84()) {
                mY3jR.put((com.google.android.gms.common.api.MY3jR.RFQ3AA8) entry.getKey(), xbU7b3);
            } else {
                mY3jR2.put((com.google.android.gms.common.api.MY3jR.RFQ3AA8) entry.getKey(), xbU7b3);
            }
        }
        f5zilcb.VVpVRy.jAM6dcNA(!mY3jR.isEmpty(), "CompositeGoogleApiClient should not be used without any APIs that require sign-in.");
        androidx.collection.MY3jR mY3jR3 = new androidx.collection.MY3jR();
        androidx.collection.MY3jR mY3jR4 = new androidx.collection.MY3jR();
        for (com.google.android.gms.common.api.MY3jR mY3jR5 : map2.keySet()) {
            com.google.android.gms.common.api.MY3jR.RFQ3AA8 rfq3aa8AXYSYCVY = mY3jR5.aXYSYCVY();
            if (mY3jR.containsKey(rfq3aa8AXYSYCVY)) {
                mY3jR3.put(mY3jR5, (Boolean) map2.get(mY3jR5));
            } else {
                if (!mY3jR2.containsKey(rfq3aa8AXYSYCVY)) {
                    throw new IllegalStateException("Each API in the isOptionalMap must have a corresponding client in the clients map.");
                }
                mY3jR4.put(mY3jR5, (Boolean) map2.get(mY3jR5));
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            MHwrO mHwrO = (MHwrO) arrayList.get(i10);
            if (mY3jR3.containsKey(mHwrO.njNibPNp)) {
                arrayList2.add(mHwrO);
            } else {
                if (!mY3jR4.containsKey(mHwrO.njNibPNp)) {
                    throw new IllegalStateException("Each ClientCallbacks must have a corresponding API in the isOptionalMap");
                }
                arrayList3.add(mHwrO);
            }
        }
        return new H8UuVVi(context, zQB7k, lock, looper, xbU7b, mY3jR, mY3jR2, lNd998w, abstractC0848MY3jR, xbU7b2, arrayList2, arrayList3, mY3jR3, mY3jR4);
    }

    public static /* bridge */ /* synthetic */ void sMxPLer(H8UuVVi h8UuVVi, int i10, boolean z10) {
        h8UuVVi.vo5p9AUA.eszJ2B0a(i10, z10);
        h8UuVVi.zigsCJW = null;
        h8UuVVi.i2VlO = null;
    }

    public static boolean uYRSwDm(ConnectionResult connectionResult) {
        return connectionResult != null && connectionResult.zlPyDfl();
    }

    @Override // jcwfs78.ZIAa4n
    public final com.google.android.gms.common.api.internal.MY3jR aXYSYCVY(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        if (!uTIfLNK0(mY3jR)) {
            return this.zYD7SXW6.aXYSYCVY(mY3jR);
        }
        if (!q1ORKN()) {
            return this.xINpNt2d.aXYSYCVY(mY3jR);
        }
        mY3jR.aXYSYCVY(new Status(4, (String) null, eTQUrp()));
        return mY3jR;
    }

    @Override // jcwfs78.ZIAa4n
    public final void dUI84(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append((CharSequence) str).append("authClient").println(p497q7.SFMiYa.COLON);
        this.xINpNt2d.dUI84(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        printWriter.append((CharSequence) str).append("anonClient").println(p497q7.SFMiYa.COLON);
        this.zYD7SXW6.dUI84(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
    }

    @Override // jcwfs78.ZIAa4n
    public final void eLbhX59K() {
        this.xnFvJEz = 2;
        this.ca3iT = false;
        this.zigsCJW = null;
        this.i2VlO = null;
        this.zYD7SXW6.eLbhX59K();
        this.xINpNt2d.eLbhX59K();
    }

    public final PendingIntent eTQUrp() {
        com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = this.pz7TsV;
        if (xbU7b == null) {
            return null;
        }
        return PendingIntent.getActivity(this.njNibPNp, System.identityHashCode(this.vo5p9AUA), xbU7b.uYRSwDm(), ir9vwy.GU39Hcg.eszJ2B0a | 134217728);
    }

    @Override // jcwfs78.ZIAa4n
    public final com.google.android.gms.common.api.internal.MY3jR eszJ2B0a(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        if (!uTIfLNK0(mY3jR)) {
            this.zYD7SXW6.eszJ2B0a(mY3jR);
            return mY3jR;
        }
        if (q1ORKN()) {
            mY3jR.aXYSYCVY(new Status(4, (String) null, eTQUrp()));
            return mY3jR;
        }
        this.xINpNt2d.eszJ2B0a(mY3jR);
        return mY3jR;
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean ivfTYNl(NUIvmoc nUIvmoc) {
        this.bBHqyf.lock();
        try {
            boolean z10 = false;
            if (oZ7qYn() || rjljd6i()) {
                if (!this.xINpNt2d.rjljd6i()) {
                    this.vskcqLTQ.add(nUIvmoc);
                    z10 = true;
                    if (this.xnFvJEz == 0) {
                        this.xnFvJEz = 1;
                    }
                    this.zigsCJW = null;
                    this.xINpNt2d.eLbhX59K();
                }
            }
            return z10;
        } finally {
            this.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean oZ7qYn() {
        this.bBHqyf.lock();
        try {
            return this.xnFvJEz == 2;
        } finally {
            this.bBHqyf.unlock();
        }
    }

    @Override // jcwfs78.ZIAa4n
    public final void osx7Pl0E() {
        this.zigsCJW = null;
        this.i2VlO = null;
        this.xnFvJEz = 0;
        this.zYD7SXW6.osx7Pl0E();
        this.xINpNt2d.osx7Pl0E();
        qLLw0g();
    }

    public final boolean q1ORKN() {
        ConnectionResult connectionResult = this.zigsCJW;
        return connectionResult != null && connectionResult.q1ORKN() == 4;
    }

    public final void qLLw0g() {
        Iterator it2 = this.vskcqLTQ.iterator();
        while (it2.hasNext()) {
            ((NUIvmoc) it2.next()).onComplete();
        }
        this.vskcqLTQ.clear();
    }

    @Override // jcwfs78.ZIAa4n
    public final boolean rjljd6i() {
        this.bBHqyf.lock();
        try {
            boolean z10 = false;
            if (this.zYD7SXW6.rjljd6i() && (this.xINpNt2d.rjljd6i() || q1ORKN() || this.xnFvJEz == 1)) {
                z10 = true;
            }
            return z10;
        } finally {
            this.bBHqyf.unlock();
        }
    }

    public final boolean uTIfLNK0(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        DrXCNOo9 drXCNOo9 = (DrXCNOo9) this.fdmP9GD.get(mY3jR.n84TFkA9());
        f5zilcb.VVpVRy.uYRSwDm(drXCNOo9, "GoogleApiClient is not configured to use the API required for this call.");
        return drXCNOo9.equals(this.xINpNt2d);
    }

    @Override // jcwfs78.ZIAa4n
    public final void zDWsfFRp() {
        this.bBHqyf.lock();
        try {
            boolean zOZ7qYn = oZ7qYn();
            this.xINpNt2d.osx7Pl0E();
            this.zigsCJW = new ConnectionResult(4);
            if (zOZ7qYn) {
                new ir9vwy.VVpVRy(this.gmzPK).post(new ArqY6z(this));
            } else {
                qLLw0g();
            }
        } finally {
            this.bBHqyf.unlock();
        }
    }

    public final void zPJpxWz(ConnectionResult connectionResult) {
        int i10 = this.xnFvJEz;
        if (i10 == 1) {
            qLLw0g();
        } else if (i10 != 2) {
            new Exception();
        } else {
            this.vo5p9AUA.eLbhX59K(connectionResult);
            qLLw0g();
        }
        this.xnFvJEz = 0;
    }
}
