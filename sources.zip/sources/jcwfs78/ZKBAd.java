package jcwfs78;

import android.os.Bundle;
import android.os.DeadObjectException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class ZKBAd implements AL02fFI {
    public boolean aXYSYCVY = false;
    public final DrXCNOo9 eszJ2B0a;

    public ZKBAd(DrXCNOo9 drXCNOo9) {
        this.eszJ2B0a = drXCNOo9;
    }

    @Override // jcwfs78.AL02fFI
    public final void aXYSYCVY() {
        if (this.aXYSYCVY) {
            this.aXYSYCVY = false;
            this.eszJ2B0a.yxejkub(new GMtmhHQ(this, this));
        }
    }

    @Override // jcwfs78.AL02fFI
    public final void eLbhX59K(int i10) {
        this.eszJ2B0a.uYRSwDm(null);
        this.eszJ2B0a.cOkM2.eszJ2B0a(i10, this.aXYSYCVY);
    }

    @Override // jcwfs78.AL02fFI
    public final boolean ivfTYNl() {
        if (this.aXYSYCVY) {
            return false;
        }
        Set set = this.eszJ2B0a.xnFvJEz.sMxPLer;
        if (set == null || set.isEmpty()) {
            this.eszJ2B0a.uYRSwDm(null);
            return true;
        }
        this.aXYSYCVY = true;
        Iterator it2 = set.iterator();
        if (!it2.hasNext()) {
            return false;
        }
        android.support.v4.media.MY3jR.eszJ2B0a(it2.next());
        throw null;
    }

    @Override // jcwfs78.AL02fFI
    public final com.google.android.gms.common.api.internal.MY3jR osx7Pl0E(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        try {
            this.eszJ2B0a.xnFvJEz.c1pvtY.eszJ2B0a(mY3jR);
            ZQB7k zQB7k = this.eszJ2B0a.xnFvJEz;
            com.google.android.gms.common.api.MY3jR.XbU7b xbU7b = (com.google.android.gms.common.api.MY3jR.XbU7b) zQB7k.yxejkub.get(mY3jR.n84TFkA9());
            f5zilcb.VVpVRy.uYRSwDm(xbU7b, "Appropriate Api was not requested.");
            if (xbU7b.eszJ2B0a() || !this.eszJ2B0a.vskcqLTQ.containsKey(mY3jR.n84TFkA9())) {
                mY3jR.sMxPLer(xbU7b);
                return mY3jR;
            }
            mY3jR.aXYSYCVY(new Status(17));
            return mY3jR;
        } catch (DeadObjectException unused) {
            this.eszJ2B0a.yxejkub(new ItX6BnZf(this, this));
            return mY3jR;
        }
    }

    @Override // jcwfs78.AL02fFI
    public final com.google.android.gms.common.api.internal.MY3jR zDWsfFRp(com.google.android.gms.common.api.internal.MY3jR mY3jR) {
        osx7Pl0E(mY3jR);
        return mY3jR;
    }

    @Override // jcwfs78.AL02fFI
    public final void eszJ2B0a() {
    }

    @Override // jcwfs78.AL02fFI
    public final void dUI84(Bundle bundle) {
    }

    @Override // jcwfs78.AL02fFI
    public final void oZ7qYn(ConnectionResult connectionResult, com.google.android.gms.common.api.MY3jR mY3jR, boolean z10) {
    }
}
