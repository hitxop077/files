package jcwfs78;

import android.os.Looper;
import android.os.Message;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class ECK8f extends ir9vwy.VVpVRy {
    public final /* synthetic */ ZQB7k aXYSYCVY;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ECK8f(ZQB7k zQB7k, Looper looper) {
        super(looper);
        this.aXYSYCVY = zQB7k;
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 1) {
            ZQB7k.eImdmIyv(this.aXYSYCVY);
        } else {
            if (i10 != 2) {
                return;
            }
            ZQB7k.c1pvtY(this.aXYSYCVY);
        }
    }
}
