package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class PNhZ1c {
    public final Feature aXYSYCVY;
    public final AAnYcst eszJ2B0a;

    public /* synthetic */ PNhZ1c(AAnYcst aAnYcst, Feature feature, FtRxP0tp ftRxP0tp) {
        this.eszJ2B0a = aAnYcst;
        this.aXYSYCVY = feature;
    }

    public final boolean equals(Object obj) {
        if (obj != null && (obj instanceof PNhZ1c)) {
            PNhZ1c pNhZ1c = (PNhZ1c) obj;
            if (f5zilcb.Lx1jI.eszJ2B0a(this.eszJ2B0a, pNhZ1c.eszJ2B0a) && f5zilcb.Lx1jI.eszJ2B0a(this.aXYSYCVY, pNhZ1c.aXYSYCVY)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return f5zilcb.Lx1jI.aXYSYCVY(this.eszJ2B0a, this.aXYSYCVY);
    }

    public final String toString() {
        return f5zilcb.Lx1jI.eLbhX59K(this).eszJ2B0a("key", this.eszJ2B0a).eszJ2B0a("feature", this.aXYSYCVY).toString();
    }
}
