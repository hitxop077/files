package jcwfs78;

import com.google.android.gms.common.ConnectionResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface SFMiYa {
    void onConnectionFailed(ConnectionResult connectionResult);
}
