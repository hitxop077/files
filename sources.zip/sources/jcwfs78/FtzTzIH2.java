package jcwfs78;

import com.google.android.gms.common.ConnectionResult;
import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface FtzTzIH2 {
    void aXYSYCVY(com.google.android.gms.common.internal.AAnYcst aAnYcst, Set set);

    void eLbhX59K(int i10);

    void zDWsfFRp(ConnectionResult connectionResult);
}
