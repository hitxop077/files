package jcwfs78;

import android.app.Activity;
import android.content.Intent;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface JQAVH {
    HicDZW oZuW0(String str, Class cls);

    void startActivityForResult(Intent intent, int i10);

    void tsE7SX(String str, HicDZW hicDZW);

    Activity ywA25jds();
}
