package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class HTDmd extends JmXmcSi {
    public final /* synthetic */ JmXmcSi.MY3jR zDWsfFRp;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public HTDmd(JmXmcSi.MY3jR mY3jR, Feature[] featureArr, boolean z10, int i10) {
        super(featureArr, z10, i10);
        this.zDWsfFRp = mY3jR;
    }

    @Override // jcwfs78.JmXmcSi
    public final void zDWsfFRp(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW) {
        this.zDWsfFRp.eszJ2B0a.accept(aAnYcst, hicDZW);
    }
}
