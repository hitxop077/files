package jcwfs78;

import com.google.android.gms.common.api.internal.BasePendingResult;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class Xad7syi {
    public final /* synthetic */ BasePendingResult eszJ2B0a;

    public /* synthetic */ Xad7syi(BasePendingResult basePendingResult, S104V s104v) {
        this.eszJ2B0a = basePendingResult;
    }

    public final void finalize() throws Throwable {
        BasePendingResult.mTWLV(this.eszJ2B0a.oZ7qYn);
        super.finalize();
    }
}
