package jcwfs78;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class LV4CzgpJ extends Fragment implements JQAVH {
    public static final WeakHashMap vo5p9AUA = new WeakHashMap();
    public final PxxW8Q1 njNibPNp = new PxxW8Q1();

    public static LV4CzgpJ eszJ2B0a(Activity activity) {
        LV4CzgpJ lV4CzgpJ;
        WeakHashMap weakHashMap = vo5p9AUA;
        WeakReference weakReference = (WeakReference) weakHashMap.get(activity);
        if (weakReference != null && (lV4CzgpJ = (LV4CzgpJ) weakReference.get()) != null) {
            return lV4CzgpJ;
        }
        try {
            LV4CzgpJ lV4CzgpJ2 = (LV4CzgpJ) activity.getFragmentManager().findFragmentByTag("LifecycleFragmentImpl");
            if (lV4CzgpJ2 == null || lV4CzgpJ2.isRemoving()) {
                lV4CzgpJ2 = new LV4CzgpJ();
                activity.getFragmentManager().beginTransaction().add(lV4CzgpJ2, "LifecycleFragmentImpl").commitAllowingStateLoss();
            }
            weakHashMap.put(activity, new WeakReference(lV4CzgpJ2));
            return lV4CzgpJ2;
        } catch (ClassCastException e10) {
            throw new IllegalStateException("Fragment with tag LifecycleFragmentImpl is not a LifecycleFragmentImpl", e10);
        }
    }

    @Override // android.app.Fragment
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        this.njNibPNp.zPJpxWz(str, fileDescriptor, printWriter, strArr);
    }

    @Override // jcwfs78.JQAVH
    public final HicDZW oZuW0(String str, Class cls) {
        return this.njNibPNp.eszJ2B0a(str, cls);
    }

    @Override // android.app.Fragment
    public final void onActivityResult(int i10, int i11, Intent intent) {
        super.onActivityResult(i10, i11, intent);
        this.njNibPNp.osx7Pl0E(i10, i11, intent);
    }

    @Override // android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.njNibPNp.eLbhX59K(bundle);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        this.njNibPNp.rjljd6i();
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        this.njNibPNp.ivfTYNl();
    }

    @Override // android.app.Fragment
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.njNibPNp.dUI84(bundle);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        this.njNibPNp.zDWsfFRp();
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        this.njNibPNp.oZ7qYn();
    }

    @Override // jcwfs78.JQAVH
    public final void tsE7SX(String str, HicDZW hicDZW) {
        this.njNibPNp.aXYSYCVY(str, hicDZW);
    }

    @Override // jcwfs78.JQAVH
    public final Activity ywA25jds() {
        return getActivity();
    }
}
