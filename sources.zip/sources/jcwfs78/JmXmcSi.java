package jcwfs78;

import com.google.android.gms.common.Feature;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class JmXmcSi {
    public final boolean aXYSYCVY;
    public final int eLbhX59K;
    public final Feature[] eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public Feature[] eLbhX59K;
        public Gyx10a eszJ2B0a;
        public boolean aXYSYCVY = true;
        public int zDWsfFRp = 0;

        public /* synthetic */ MY3jR(GJpNs6 gJpNs6) {
        }

        public MY3jR aXYSYCVY(Gyx10a gyx10a) {
            this.eszJ2B0a = gyx10a;
            return this;
        }

        public MY3jR eLbhX59K(boolean z10) {
            this.aXYSYCVY = z10;
            return this;
        }

        public JmXmcSi eszJ2B0a() {
            f5zilcb.VVpVRy.aXYSYCVY(this.eszJ2B0a != null, "execute parameter required");
            return new HTDmd(this, this.eLbhX59K, this.aXYSYCVY, this.zDWsfFRp);
        }

        public MY3jR ivfTYNl(int i10) {
            this.zDWsfFRp = i10;
            return this;
        }

        public MY3jR zDWsfFRp(Feature... featureArr) {
            this.eLbhX59K = featureArr;
            return this;
        }
    }

    public JmXmcSi(Feature[] featureArr, boolean z10, int i10) {
        this.eszJ2B0a = featureArr;
        boolean z11 = false;
        if (featureArr != null && z10) {
            z11 = true;
        }
        this.aXYSYCVY = z11;
        this.eLbhX59K = i10;
    }

    public static MY3jR eLbhX59K() {
        return new MY3jR(null);
    }

    public final Feature[] dUI84() {
        return this.eszJ2B0a;
    }

    public boolean ivfTYNl() {
        return this.aXYSYCVY;
    }

    public final int osx7Pl0E() {
        return this.eLbhX59K;
    }

    public abstract void zDWsfFRp(com.google.android.gms.common.api.MY3jR.AAnYcst aAnYcst, a4dh7ol.HicDZW hicDZW);
}
