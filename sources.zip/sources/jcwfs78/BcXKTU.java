package jcwfs78;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class BcXKTU {
    public abstract void eszJ2B0a();
}
