package jcwfs78;

import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface W7Cnq5 extends IInterface {

    /* JADX INFO: compiled from: Obfuscated */
    public static abstract class MY3jR extends ir9vwy.AAnYcst implements W7Cnq5 {
        public MY3jR() {
            super("com.google.android.gms.common.api.internal.IStatusCallback");
        }

        @Override // ir9vwy.AAnYcst
        public final boolean ouycaSm(int i10, Parcel parcel, Parcel parcel2, int i11) {
            if (i10 != 1) {
                return false;
            }
            Status status = (Status) ir9vwy.RFQ3AA8.eszJ2B0a(parcel, Status.CREATOR);
            ir9vwy.RFQ3AA8.aXYSYCVY(parcel);
            gbFHS2(status);
            return true;
        }
    }

    void gbFHS2(Status status);
}
