package jcwfs78;

import android.app.Dialog;
import android.app.PendingIntent;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiActivity;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class UhFXwfhx implements Runnable {
    public final Wl27nX2 njNibPNp;
    public final /* synthetic */ OTtpwH vo5p9AUA;

    public UhFXwfhx(OTtpwH oTtpwH, Wl27nX2 wl27nX2) {
        this.vo5p9AUA = oTtpwH;
        this.njNibPNp = wl27nX2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.vo5p9AUA.vo5p9AUA) {
            ConnectionResult connectionResultAXYSYCVY = this.njNibPNp.aXYSYCVY();
            if (connectionResultAXYSYCVY.fIz14cTt()) {
                OTtpwH oTtpwH = this.vo5p9AUA;
                oTtpwH.njNibPNp.startActivityForResult(GoogleApiActivity.eszJ2B0a(oTtpwH.aXYSYCVY(), (PendingIntent) f5zilcb.VVpVRy.uTIfLNK0(connectionResultAXYSYCVY.egsKh()), this.njNibPNp.eszJ2B0a(), false), 1);
                return;
            }
            OTtpwH oTtpwH2 = this.vo5p9AUA;
            if (oTtpwH2.xINpNt2d.zDWsfFRp(oTtpwH2.aXYSYCVY(), connectionResultAXYSYCVY.q1ORKN(), null) != null) {
                OTtpwH oTtpwH3 = this.vo5p9AUA;
                oTtpwH3.xINpNt2d.eTQUrp(oTtpwH3.aXYSYCVY(), oTtpwH3.njNibPNp, connectionResultAXYSYCVY.q1ORKN(), 2, this.vo5p9AUA);
                return;
            }
            if (connectionResultAXYSYCVY.q1ORKN() != 18) {
                this.vo5p9AUA.q1ORKN(connectionResultAXYSYCVY, this.njNibPNp.eszJ2B0a());
                return;
            }
            OTtpwH oTtpwH4 = this.vo5p9AUA;
            Dialog dialogBsO5Vo = oTtpwH4.xINpNt2d.bsO5Vo(oTtpwH4.aXYSYCVY(), oTtpwH4);
            OTtpwH oTtpwH5 = this.vo5p9AUA;
            oTtpwH5.xINpNt2d.sMxPLer(oTtpwH5.aXYSYCVY().getApplicationContext(), new Sk4GIh(this, dialogBsO5Vo));
        }
    }
}
