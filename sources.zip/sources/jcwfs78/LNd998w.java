package jcwfs78;

import com.google.android.gms.common.api.Status;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface LNd998w {
    void aXYSYCVY(Status status);

    void eszJ2B0a(Object obj);
}
