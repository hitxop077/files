package jjxrs;

import android.media.RouteDiscoveryPreference;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class HTDmd {
    public static /* synthetic */ RouteDiscoveryPreference.Builder eszJ2B0a(List list, boolean z10) {
        return new RouteDiscoveryPreference.Builder(list, z10);
    }
}
