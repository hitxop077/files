package jjxrs;

import android.media.MediaRoute2Info;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class C7hy1o {
    public static /* synthetic */ MediaRoute2Info.Builder eszJ2B0a(String str, CharSequence charSequence) {
        return new MediaRoute2Info.Builder(str, charSequence);
    }
}
