package jjxrs;

import android.media.MediaRoute2Info;
import java.util.Objects;
import java.util.function.Predicate;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final /* synthetic */ class ZQB7k implements Predicate {
    @Override // java.util.function.Predicate
    public final boolean test(Object obj) {
        return Objects.nonNull((MediaRoute2Info) obj);
    }
}
