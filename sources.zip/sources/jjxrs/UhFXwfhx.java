package jjxrs;

import android.os.Bundle;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class UhFXwfhx {
    public abstract Bundle aXYSYCVY();

    public abstract boolean eLbhX59K();

    public abstract int eszJ2B0a();

    public abstract boolean zDWsfFRp();
}
