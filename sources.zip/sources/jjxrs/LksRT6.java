package jjxrs;

import java.util.Objects;
import java.util.function.Predicate;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final /* synthetic */ class LksRT6 implements Predicate {
    @Override // java.util.function.Predicate
    public final boolean test(Object obj) {
        return Objects.nonNull((androidx.mediarouter.media.RFQ3AA8) obj);
    }
}
