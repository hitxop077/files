package jjxrs;

import android.media.MediaRouter;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class Sk4GIh {
    public static int eszJ2B0a(Object obj) {
        return ((MediaRouter.RouteInfo) obj).getDeviceType();
    }
}
