package jjxrs;

import android.media.RoutingSessionInfo;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class AfGFIA {
    public static /* synthetic */ RoutingSessionInfo.Builder eszJ2B0a(String str, String str2) {
        return new RoutingSessionInfo.Builder(str, str2);
    }
}
