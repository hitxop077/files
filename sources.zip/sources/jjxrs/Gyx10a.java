package jjxrs;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class Gyx10a {
}
