package jjxrs;

import android.media.MediaRoute2Info;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class AAnYcst {
    public static /* bridge */ /* synthetic */ MediaRoute2Info eszJ2B0a(Object obj) {
        return (MediaRoute2Info) obj;
    }
}
