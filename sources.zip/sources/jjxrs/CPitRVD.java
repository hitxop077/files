package jjxrs;

import android.os.Bundle;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final class CPitRVD {
    public androidx.mediarouter.media.XbU7b aXYSYCVY;
    public final Bundle eszJ2B0a;

    public CPitRVD(androidx.mediarouter.media.XbU7b xbU7b, boolean z10) {
        if (xbU7b == null) {
            throw new IllegalArgumentException("selector must not be null");
        }
        Bundle bundle = new Bundle();
        this.eszJ2B0a = bundle;
        this.aXYSYCVY = xbU7b;
        bundle.putBundle("selector", xbU7b.eszJ2B0a());
        bundle.putBoolean("activeScan", z10);
    }

    public static CPitRVD eLbhX59K(Bundle bundle) {
        if (bundle != null) {
            return new CPitRVD(bundle);
        }
        return null;
    }

    public final void aXYSYCVY() {
        if (this.aXYSYCVY == null) {
            androidx.mediarouter.media.XbU7b xbU7bZDWsfFRp = androidx.mediarouter.media.XbU7b.zDWsfFRp(this.eszJ2B0a.getBundle("selector"));
            this.aXYSYCVY = xbU7bZDWsfFRp;
            if (xbU7bZDWsfFRp == null) {
                this.aXYSYCVY = androidx.mediarouter.media.XbU7b.eLbhX59K;
            }
        }
    }

    public boolean equals(Object obj) {
        if (obj instanceof CPitRVD) {
            CPitRVD cPitRVD = (CPitRVD) obj;
            if (zDWsfFRp().equals(cPitRVD.zDWsfFRp()) && ivfTYNl() == cPitRVD.ivfTYNl()) {
                return true;
            }
        }
        return false;
    }

    public Bundle eszJ2B0a() {
        return this.eszJ2B0a;
    }

    public int hashCode() {
        return (zDWsfFRp().hashCode() ^ (ivfTYNl() ? 1 : 0)) == true ? 1 : 0;
    }

    public boolean ivfTYNl() {
        return this.eszJ2B0a.getBoolean("activeScan");
    }

    public boolean osx7Pl0E() {
        aXYSYCVY();
        return this.aXYSYCVY.dUI84();
    }

    public String toString() {
        return "DiscoveryRequest{ selector=" + zDWsfFRp() + ", activeScan=" + ivfTYNl() + ", isValid=" + osx7Pl0E() + " }";
    }

    public androidx.mediarouter.media.XbU7b zDWsfFRp() {
        aXYSYCVY();
        return this.aXYSYCVY;
    }

    public CPitRVD(Bundle bundle) {
        this.eszJ2B0a = bundle;
    }
}
