package jjxrs;

import android.media.RoutingSessionInfo;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class VX4rr {
    public static /* synthetic */ RoutingSessionInfo.Builder eszJ2B0a(RoutingSessionInfo routingSessionInfo) {
        return new RoutingSessionInfo.Builder(routingSessionInfo);
    }
}
