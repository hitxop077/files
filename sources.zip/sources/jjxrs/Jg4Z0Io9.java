package jjxrs;

import android.os.Handler;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public final /* synthetic */ class Jg4Z0Io9 implements Executor {
    public final /* synthetic */ Handler njNibPNp;

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.njNibPNp.post(runnable);
    }
}
