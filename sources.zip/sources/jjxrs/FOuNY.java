package jjxrs;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class FOuNY {
    public static /* synthetic */ void eszJ2B0a() {
    }
}
