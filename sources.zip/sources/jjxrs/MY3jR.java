package jjxrs;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class MY3jR {
}
