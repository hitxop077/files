package K0;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface LNd998w {
    String aXYSYCVY();

    String dUI84();

    String eLbhX59K();

    Executor eszJ2B0a();

    String ivfTYNl();

    int oZ7qYn();

    int osx7Pl0E();

    String rjljd6i();

    boolean zDWsfFRp();
}
