package K0;

import androidx.lifecycle.I1KGSb0S;
import androidx.lifecycle.LksRT6;
import androidx.lifecycle.VI3TfJlk;
import com.google.android.gms.tasks.Task;
import java.io.Closeable;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface RFQ3AA8 extends Closeable, LksRT6, com.google.android.gms.common.api.XbU7b {
    Task bzHsCEa(I0.MY3jR mY3jR);

    @Override // java.io.Closeable, java.lang.AutoCloseable
    @I1KGSb0S(VI3TfJlk.MY3jR.ON_DESTROY)
    void close();
}
