package K0;

import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import com.google.android.gms.internal.mlkit_vision_text_common.T1nRB;
import com.google.android.gms.internal.mlkit_vision_text_common.ZTkvew3;
import com.google.android.gms.internal.mlkit_vision_text_common.zzuz;
import com.google.android.gms.internal.mlkit_vision_text_common.zzvb;
import com.google.android.gms.internal.mlkit_vision_text_common.zzvd;
import com.google.android.gms.internal.mlkit_vision_text_common.zzvf;
import com.google.android.gms.internal.mlkit_vision_text_common.zzvj;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class MY3jR {
    public final String aXYSYCVY;
    public final List eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static class LNd998w {
        public final Rect aXYSYCVY;
        public final Point[] eLbhX59K;
        public final String eszJ2B0a;
        public final String zDWsfFRp;

        public LNd998w(String str, Rect rect, List list, String str2, Matrix matrix) {
            this.eszJ2B0a = str;
            Rect rect2 = new Rect(rect);
            if (matrix != null) {
                J0.AAnYcst.eLbhX59K(rect2, matrix);
            }
            this.aXYSYCVY = rect2;
            Point[] pointArr = new Point[list.size()];
            for (int i10 = 0; i10 < list.size(); i10++) {
                pointArr[i10] = new Point((Point) list.get(i10));
            }
            if (matrix != null) {
                J0.AAnYcst.aXYSYCVY(pointArr, matrix);
            }
            this.eLbhX59K = pointArr;
            this.zDWsfFRp = str2;
        }

        public String aXYSYCVY() {
            return this.zDWsfFRp;
        }

        public final String eLbhX59K() {
            String str = this.eszJ2B0a;
            return str == null ? "" : str;
        }

        public Rect eszJ2B0a() {
            return this.aXYSYCVY;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class RFQ3AA8 extends LNd998w {
        public final float ivfTYNl;
        public final float osx7Pl0E;

        public RFQ3AA8(zzvj zzvjVar, Matrix matrix) {
            super(zzvjVar.egsKh(), zzvjVar.yxejkub(), zzvjVar.fIz14cTt(), "", matrix);
            this.ivfTYNl = zzvjVar.q1ORKN();
            this.osx7Pl0E = zzvjVar.qLLw0g();
        }

        public String ivfTYNl() {
            return eLbhX59K();
        }

        public float zDWsfFRp() {
            return this.ivfTYNl;
        }
    }

    public MY3jR(zzvf zzvfVar, final Matrix matrix) {
        ArrayList arrayList = new ArrayList();
        this.eszJ2B0a = arrayList;
        this.aXYSYCVY = zzvfVar.qLLw0g();
        arrayList.addAll(ZTkvew3.eszJ2B0a(zzvfVar.q1ORKN(), new T1nRB() { // from class: K0.N1vNRFSd
            @Override // com.google.android.gms.internal.mlkit_vision_text_common.T1nRB
            public final Object aXYSYCVY(Object obj) {
                return new MY3jR.N1vNRFSd((zzuz) obj, matrix);
            }
        }));
    }

    public List aXYSYCVY() {
        return Collections.unmodifiableList(this.eszJ2B0a);
    }

    public String eszJ2B0a() {
        return this.aXYSYCVY;
    }

    public MY3jR(String str, List list) {
        ArrayList arrayList = new ArrayList();
        this.eszJ2B0a = arrayList;
        arrayList.addAll(list);
        this.aXYSYCVY = str;
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class AAnYcst extends LNd998w {
        public final float dUI84;
        public final List ivfTYNl;
        public final float osx7Pl0E;

        public AAnYcst(zzvd zzvdVar, final Matrix matrix, float f10, float f11) {
            super(zzvdVar.fIz14cTt(), zzvdVar.yxejkub(), zzvdVar.zlPyDfl(), zzvdVar.egsKh(), matrix);
            this.ivfTYNl = ZTkvew3.eszJ2B0a(zzvdVar.aB0u11(), new T1nRB() { // from class: K0.W7Cnq5
                @Override // com.google.android.gms.internal.mlkit_vision_text_common.T1nRB
                public final Object aXYSYCVY(Object obj) {
                    return new MY3jR.C0102MY3jR((zzvb) obj, matrix);
                }
            });
            this.osx7Pl0E = f10;
            this.dUI84 = f11;
        }

        public synchronized List ivfTYNl() {
            return this.ivfTYNl;
        }

        public String osx7Pl0E() {
            return eLbhX59K();
        }

        public float zDWsfFRp() {
            return this.osx7Pl0E;
        }

        public AAnYcst(String str, Rect rect, List list, String str2, Matrix matrix, List list2, float f10, float f11) {
            super(str, rect, list, str2, matrix);
            this.ivfTYNl = list2;
            this.osx7Pl0E = f10;
            this.dUI84 = f11;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class N1vNRFSd extends LNd998w {
        public final List ivfTYNl;

        public N1vNRFSd(zzuz zzuzVar, final Matrix matrix) {
            super(zzuzVar.yxejkub(), zzuzVar.qLLw0g(), zzuzVar.egsKh(), zzuzVar.q1ORKN(), matrix);
            this.ivfTYNl = ZTkvew3.eszJ2B0a(zzuzVar.fIz14cTt(), new T1nRB() { // from class: K0.GU39Hcg
                @Override // com.google.android.gms.internal.mlkit_vision_text_common.T1nRB
                public final Object aXYSYCVY(Object obj) {
                    zzvd zzvdVar = (zzvd) obj;
                    return new MY3jR.AAnYcst(zzvdVar, matrix, zzvdVar.q1ORKN(), zzvdVar.qLLw0g());
                }
            });
        }

        public String ivfTYNl() {
            return eLbhX59K();
        }

        public synchronized List zDWsfFRp() {
            return this.ivfTYNl;
        }

        public N1vNRFSd(String str, Rect rect, List list, String str2, Matrix matrix, List list2) {
            super(str, rect, list, str2, matrix);
            this.ivfTYNl = list2;
        }
    }

    /* JADX INFO: renamed from: K0.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static class C0102MY3jR extends LNd998w {
        public final float dUI84;
        public final List ivfTYNl;
        public final float osx7Pl0E;

        public C0102MY3jR(zzvb zzvbVar, final Matrix matrix) {
            super(zzvbVar.fIz14cTt(), zzvbVar.yxejkub(), zzvbVar.zlPyDfl(), zzvbVar.egsKh(), matrix);
            this.osx7Pl0E = zzvbVar.q1ORKN();
            this.dUI84 = zzvbVar.qLLw0g();
            List listAB0u11 = zzvbVar.aB0u11();
            this.ivfTYNl = ZTkvew3.eszJ2B0a(listAB0u11 == null ? new ArrayList() : listAB0u11, new T1nRB() { // from class: K0.XbU7b
                @Override // com.google.android.gms.internal.mlkit_vision_text_common.T1nRB
                public final Object aXYSYCVY(Object obj) {
                    return new MY3jR.RFQ3AA8((zzvj) obj, matrix);
                }
            });
        }

        public synchronized List ivfTYNl() {
            return this.ivfTYNl;
        }

        public String osx7Pl0E() {
            return eLbhX59K();
        }

        public float zDWsfFRp() {
            return this.osx7Pl0E;
        }

        public C0102MY3jR(String str, Rect rect, List list, String str2, Matrix matrix, float f10, float f11, List list2) {
            super(str, rect, list, str2, matrix);
            this.osx7Pl0E = f10;
            this.dUI84 = f11;
            this.ivfTYNl = list2;
        }
    }
}
