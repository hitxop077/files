package K0;

import B0.HicDZW;
import L0.Gyx10a;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class AAnYcst {
    public static RFQ3AA8 eszJ2B0a(LNd998w lNd998w) {
        return ((Gyx10a) HicDZW.eLbhX59K().eszJ2B0a(Gyx10a.class)).eszJ2B0a(lNd998w);
    }
}
