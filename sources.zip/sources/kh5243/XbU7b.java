package kh5243;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class XbU7b {
    public static Executor eszJ2B0a() {
        return MY3jR.INSTANCE;
    }
}
