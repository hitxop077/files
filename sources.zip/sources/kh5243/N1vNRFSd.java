package kh5243;

import java.util.concurrent.Executor;
import java.util.concurrent.Future;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface N1vNRFSd extends Future {
    void yxejkub(Runnable runnable, Executor executor);
}
