package kh5243;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface AAnYcst {
    void onFailure(Throwable th2);

    void onSuccess(Object obj);
}
