package kh5243;

import com.google.common.base.Lx1jI;
import com.google.common.base.O5Z56VT6;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract class RFQ3AA8 extends LNd998w {

    /* JADX INFO: compiled from: Obfuscated */
    public static final class MY3jR implements Runnable {
        public final Future njNibPNp;
        public final AAnYcst vo5p9AUA;

        public MY3jR(Future future, AAnYcst aAnYcst) {
            this.njNibPNp = future;
            this.vo5p9AUA = aAnYcst;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.vo5p9AUA.onSuccess(RFQ3AA8.aXYSYCVY(this.njNibPNp));
            } catch (ExecutionException e10) {
                this.vo5p9AUA.onFailure(e10.getCause());
            } catch (Throwable th2) {
                this.vo5p9AUA.onFailure(th2);
            }
        }

        public String toString() {
            return Lx1jI.aXYSYCVY(this).oZ7qYn(this.vo5p9AUA).toString();
        }
    }

    public static Object aXYSYCVY(Future future) {
        O5Z56VT6.bsO5Vo(future.isDone(), "Future was expected to be done: %s", future);
        return W7Cnq5.eszJ2B0a(future);
    }

    public static void eszJ2B0a(N1vNRFSd n1vNRFSd, AAnYcst aAnYcst, Executor executor) {
        O5Z56VT6.uYRSwDm(aAnYcst);
        n1vNRFSd.yxejkub(new MY3jR(n1vNRFSd, aAnYcst), executor);
    }
}
