package Ka;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class U080F extends Bv3FS {
    public static final AtomicLongFieldUpdater xINpNt2d = AtomicLongFieldUpdater.newUpdater(U080F.class, "zYD7SXW6");
    public volatile long zYD7SXW6;

    public U080F(int i10) {
        super(i10);
    }

    @Override // Ja.Lx1jI.MY3jR
    public final long eLbhX59K() {
        return this.zYD7SXW6;
    }

    public final boolean yxejkub(long j10, long j11) {
        return xINpNt2d.compareAndSet(this, j10, j11);
    }
}
