package Ka;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class AAnYcst extends AbstractQueue implements Ja.Lx1jI.MY3jR, Ja.VVpVRy {
    public final AtomicReferenceArray njNibPNp;
    public final int vo5p9AUA;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR implements Iterator {
        public final AtomicReferenceArray gmzPK;
        public final long njNibPNp;
        public final int vo5p9AUA;
        public Object xINpNt2d = eszJ2B0a();
        public long zYD7SXW6;

        public MY3jR(long j10, long j11, int i10, AtomicReferenceArray atomicReferenceArray) {
            this.zYD7SXW6 = j10;
            this.njNibPNp = j11;
            this.vo5p9AUA = i10;
            this.gmzPK = atomicReferenceArray;
        }

        public final Object eszJ2B0a() {
            Object objOZ7qYn;
            int i10 = this.vo5p9AUA;
            AtomicReferenceArray atomicReferenceArray = this.gmzPK;
            do {
                long j10 = this.zYD7SXW6;
                if (j10 >= this.njNibPNp) {
                    return null;
                }
                this.zYD7SXW6 = 1 + j10;
                objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, Ka.MY3jR.eLbhX59K(j10, i10));
            } while (objOZ7qYn == null);
            return objOZ7qYn;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.xINpNt2d != null;
        }

        @Override // java.util.Iterator
        public Object next() {
            Object obj = this.xINpNt2d;
            if (obj == null) {
                throw new NoSuchElementException();
            }
            this.xINpNt2d = eszJ2B0a();
            return obj;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("remove");
        }
    }

    public AAnYcst(int i10) {
        int iELbhX59K = Na.MY3jR.eLbhX59K(i10);
        this.vo5p9AUA = iELbhX59K - 1;
        this.njNibPNp = new AtomicReferenceArray(iELbhX59K);
    }

    @Override // java.util.AbstractQueue, java.util.AbstractCollection, java.util.Collection, Ja.VVpVRy
    public void clear() {
        while (poll() != null) {
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final boolean isEmpty() {
        return Ja.Lx1jI.eszJ2B0a(this);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new MY3jR(dUI84(), eLbhX59K(), this.vo5p9AUA, this.njNibPNp);
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public final int size() {
        return Ja.Lx1jI.eLbhX59K(this, 1);
    }

    @Override // java.util.AbstractCollection
    public String toString() {
        return getClass().getName();
    }

    @Override // Ja.Lx1jI.MY3jR
    public final int zDWsfFRp() {
        return this.vo5p9AUA + 1;
    }
}
