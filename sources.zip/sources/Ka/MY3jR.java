package Ka;

import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class MY3jR {
    public static int aXYSYCVY(long j10, int i10) {
        return (int) (j10 & ((long) i10));
    }

    public static long dUI84(AtomicLongArray atomicLongArray, int i10) {
        return atomicLongArray.get(i10);
    }

    public static int eLbhX59K(long j10, long j11) {
        return (int) (j10 & j11);
    }

    public static AtomicReferenceArray eszJ2B0a(int i10) {
        return new AtomicReferenceArray(i10);
    }

    public static int ivfTYNl(AtomicReferenceArray atomicReferenceArray) {
        return atomicReferenceArray.length();
    }

    public static Object oZ7qYn(AtomicReferenceArray atomicReferenceArray, int i10) {
        return atomicReferenceArray.get(i10);
    }

    public static Object osx7Pl0E(AtomicReferenceArray atomicReferenceArray, int i10) {
        return atomicReferenceArray.get(i10);
    }

    public static void q1ORKN(AtomicReferenceArray atomicReferenceArray, int i10, Object obj) {
        atomicReferenceArray.lazySet(i10, obj);
    }

    public static void qLLw0g(AtomicReferenceArray atomicReferenceArray, int i10, Object obj) {
        atomicReferenceArray.lazySet(i10, obj);
    }

    public static int rjljd6i(long j10, long j11) {
        return ((int) (j10 & j11)) >> 1;
    }

    public static int zDWsfFRp(long j10) {
        return (int) j10;
    }

    public static void zPJpxWz(AtomicLongArray atomicLongArray, int i10, long j10) {
        atomicLongArray.lazySet(i10, j10);
    }
}
