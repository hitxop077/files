package Ka;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Lx1jI extends VVpVRy {
    public static final AtomicLongFieldUpdater vskcqLTQ = AtomicLongFieldUpdater.newUpdater(Lx1jI.class, "fdmP9GD");
    public volatile long fdmP9GD;

    public Lx1jI(int i10) {
        super(i10);
    }

    @Override // Ja.Lx1jI.MY3jR
    public final long dUI84() {
        return this.fdmP9GD;
    }

    public final boolean mTWLV(long j10, long j11) {
        return vskcqLTQ.compareAndSet(this, j10, j11);
    }
}
