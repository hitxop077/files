package Ka;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class N1vNRFSd extends W7Cnq5 {
    public static final AtomicLongFieldUpdater fdmP9GD = AtomicLongFieldUpdater.newUpdater(N1vNRFSd.class, "gmzPK");
    public volatile long gmzPK;
    public AtomicReferenceArray xINpNt2d;
    public long zYD7SXW6;

    @Override // Ja.Lx1jI.MY3jR
    public final long dUI84() {
        return this.gmzPK;
    }

    public final long mTWLV() {
        return this.gmzPK;
    }

    public final void sMxPLer(long j10) {
        fdmP9GD.lazySet(this, j10);
    }
}
