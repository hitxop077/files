package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class W7Cnq5 extends HicDZW {
}
