package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class VVpVRy extends U080F {
    public VVpVRy(int i10) {
        super(i10);
    }
}
