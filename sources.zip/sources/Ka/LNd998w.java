package Ka;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class LNd998w extends GU39Hcg {
    public static final AtomicLongFieldUpdater i2VlO = AtomicLongFieldUpdater.newUpdater(LNd998w.class, "vskcqLTQ");
    public AtomicReferenceArray dNE3s;
    public long pz7TsV;
    public volatile long vskcqLTQ;

    public final boolean c1pvtY(long j10, long j11) {
        return i2VlO.compareAndSet(this, j10, j11);
    }

    public final long eImdmIyv() {
        return this.vskcqLTQ;
    }

    public final void nyeBEo(long j10) {
        i2VlO.lazySet(this, j10);
    }
}
