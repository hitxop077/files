package Ka;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicReferenceArray;
import kotlin.jvm.internal.LongCompanionObject;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class RFQ3AA8 extends LNd998w implements Ja.VVpVRy {
    public static final Object zigsCJW = new Object();
    public static final Object ca3iT = new Object();

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR implements Iterator {
        public Object gmzPK;
        public final long njNibPNp;
        public long vo5p9AUA;
        public int xINpNt2d;
        public AtomicReferenceArray zYD7SXW6;

        public MY3jR(AtomicReferenceArray atomicReferenceArray, long j10, long j11) {
            this.njNibPNp = j11 >> 1;
            this.vo5p9AUA = j10 >> 1;
            aXYSYCVY(atomicReferenceArray);
            this.gmzPK = eszJ2B0a();
        }

        public final void aXYSYCVY(AtomicReferenceArray atomicReferenceArray) {
            this.zYD7SXW6 = atomicReferenceArray;
            this.xINpNt2d = Ka.MY3jR.ivfTYNl(atomicReferenceArray) - 2;
        }

        public final Object eszJ2B0a() {
            while (true) {
                long j10 = this.vo5p9AUA;
                if (j10 >= this.njNibPNp) {
                    break;
                }
                this.vo5p9AUA = 1 + j10;
                Object objOZ7qYn = Ka.MY3jR.oZ7qYn(this.zYD7SXW6, Ka.MY3jR.eLbhX59K(j10, this.xINpNt2d));
                if (objOZ7qYn != null) {
                    if (objOZ7qYn != RFQ3AA8.zigsCJW) {
                        return objOZ7qYn;
                    }
                    Object objOZ7qYn2 = Ka.MY3jR.oZ7qYn(this.zYD7SXW6, Ka.MY3jR.zDWsfFRp(this.xINpNt2d + 1));
                    if (objOZ7qYn2 == RFQ3AA8.ca3iT || objOZ7qYn2 == null) {
                        break;
                    }
                    aXYSYCVY((AtomicReferenceArray) objOZ7qYn2);
                    Object objOZ7qYn3 = Ka.MY3jR.oZ7qYn(this.zYD7SXW6, Ka.MY3jR.eLbhX59K(j10, this.xINpNt2d));
                    if (objOZ7qYn3 != null) {
                        return objOZ7qYn3;
                    }
                }
            }
            return null;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.gmzPK != null;
        }

        @Override // java.util.Iterator
        public Object next() {
            Object obj = this.gmzPK;
            if (obj == null) {
                throw new NoSuchElementException();
            }
            this.gmzPK = eszJ2B0a();
            return obj;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("remove");
        }
    }

    public RFQ3AA8(int i10) {
        Na.AAnYcst.eszJ2B0a(i10, 2, "initialCapacity");
        int iELbhX59K = Na.MY3jR.eLbhX59K(i10);
        long j10 = (iELbhX59K - 1) << 1;
        AtomicReferenceArray atomicReferenceArrayEszJ2B0a = Ka.MY3jR.eszJ2B0a(iELbhX59K + 1);
        this.dNE3s = atomicReferenceArrayEszJ2B0a;
        this.pz7TsV = j10;
        this.xINpNt2d = atomicReferenceArrayEszJ2B0a;
        this.zYD7SXW6 = j10;
        nyeBEo(j10);
    }

    private int fIz14cTt(long j10, long j11, long j12) {
        long jDUI84 = dUI84();
        long jCeTXybVl = ceTXybVl(j10) + jDUI84;
        if (jCeTXybVl > j11) {
            return !c1pvtY(j12, jCeTXybVl) ? 1 : 0;
        }
        if (egsKh(j11, jDUI84) <= 0) {
            return 2;
        }
        return q1ORKN(j11, 1 + j11) ? 3 : 1;
    }

    public static int ydGaB1bU(long j10) {
        return Ka.MY3jR.rjljd6i(j10 + 2, LongCompanionObject.MAX_VALUE);
    }

    public final AtomicReferenceArray aNB31q(AtomicReferenceArray atomicReferenceArray, long j10) {
        int iYdGaB1bU = ydGaB1bU(j10);
        AtomicReferenceArray atomicReferenceArray2 = (AtomicReferenceArray) Ka.MY3jR.oZ7qYn(atomicReferenceArray, iYdGaB1bU);
        this.xINpNt2d = atomicReferenceArray2;
        this.zYD7SXW6 = (Ka.MY3jR.ivfTYNl(atomicReferenceArray2) - 2) << 1;
        Ka.MY3jR.qLLw0g(atomicReferenceArray, iYdGaB1bU, ca3iT);
        return atomicReferenceArray2;
    }

    public Object aXYSYCVY() {
        AtomicReferenceArray atomicReferenceArray = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        int iRjljd6i = Ka.MY3jR.rjljd6i(jMTWLV, j10);
        Object objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
        if (objOZ7qYn == null) {
            return null;
        }
        if (objOZ7qYn == zigsCJW) {
            return sgXstV(aNB31q(atomicReferenceArray, j10), jMTWLV);
        }
        Ka.MY3jR.qLLw0g(atomicReferenceArray, iRjljd6i, null);
        sMxPLer(jMTWLV + 2);
        return objOZ7qYn;
    }

    public abstract long ceTXybVl(long j10);

    public abstract int d3penA(AtomicReferenceArray atomicReferenceArray);

    public abstract long egsKh(long j10, long j11);

    @Override // java.util.AbstractCollection, java.util.Collection
    public boolean isEmpty() {
        return (dUI84() - eLbhX59K()) / 2 == 0;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return new MY3jR(this.xINpNt2d, dUI84(), eLbhX59K());
    }

    public boolean ivfTYNl(Object obj) {
        return offer(obj);
    }

    public final Object myMyVU(AtomicReferenceArray atomicReferenceArray, long j10) {
        Object objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, Ka.MY3jR.rjljd6i(j10, this.zYD7SXW6));
        if (objOZ7qYn != null) {
            return objOZ7qYn;
        }
        throw new IllegalStateException("new buffer must have at least one element");
    }

    public boolean offer(Object obj) {
        if (obj == null) {
            throw null;
        }
        while (true) {
            long jEImdmIyv = eImdmIyv();
            long jELbhX59K = eLbhX59K();
            if ((jELbhX59K & 1) != 1) {
                long j10 = this.pz7TsV;
                AtomicReferenceArray atomicReferenceArray = this.dNE3s;
                if (jEImdmIyv <= jELbhX59K) {
                    int iFIz14cTt = fIz14cTt(j10, jELbhX59K, jEImdmIyv);
                    if (iFIz14cTt == 1) {
                        continue;
                    } else {
                        if (iFIz14cTt == 2) {
                            return false;
                        }
                        if (iFIz14cTt == 3) {
                            sVizei(j10, atomicReferenceArray, jELbhX59K, obj, null);
                            return true;
                        }
                    }
                }
                if (q1ORKN(jELbhX59K, 2 + jELbhX59K)) {
                    Ka.MY3jR.qLLw0g(atomicReferenceArray, Ka.MY3jR.rjljd6i(jELbhX59K, j10), obj);
                    return true;
                }
            }
        }
    }

    public Object peek() {
        AtomicReferenceArray atomicReferenceArray = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        int iRjljd6i = Ka.MY3jR.rjljd6i(jMTWLV, j10);
        Object objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
        if (objOZ7qYn == null) {
            if ((jMTWLV - eLbhX59K()) / 2 == 0) {
                return null;
            }
            do {
                objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
            } while (objOZ7qYn == null);
        }
        return objOZ7qYn == zigsCJW ? myMyVU(aNB31q(atomicReferenceArray, j10), jMTWLV) : objOZ7qYn;
    }

    public Object poll() {
        AtomicReferenceArray atomicReferenceArray = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        int iRjljd6i = Ka.MY3jR.rjljd6i(jMTWLV, j10);
        Object objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
        if (objOZ7qYn == null) {
            if ((jMTWLV - eLbhX59K()) / 2 == 0) {
                return null;
            }
            do {
                objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
            } while (objOZ7qYn == null);
        }
        if (objOZ7qYn == zigsCJW) {
            return sgXstV(aNB31q(atomicReferenceArray, j10), jMTWLV);
        }
        Ka.MY3jR.qLLw0g(atomicReferenceArray, iRjljd6i, null);
        sMxPLer(jMTWLV + 2);
        return objOZ7qYn;
    }

    public int qLLw0g(Ja.VVpVRy.MY3jR mY3jR, int i10) {
        return Ja.SFMiYa.eszJ2B0a(this, mY3jR, i10);
    }

    public final void sVizei(long j10, AtomicReferenceArray atomicReferenceArray, long j11, Object obj, Ja.VVpVRy.AAnYcst aAnYcst) {
        int iD3penA = d3penA(atomicReferenceArray);
        try {
            AtomicReferenceArray atomicReferenceArrayEszJ2B0a = Ka.MY3jR.eszJ2B0a(iD3penA);
            this.dNE3s = atomicReferenceArrayEszJ2B0a;
            long j12 = (iD3penA - 2) << 1;
            this.pz7TsV = j12;
            int iRjljd6i = Ka.MY3jR.rjljd6i(j11, j10);
            int iRjljd6i2 = Ka.MY3jR.rjljd6i(j11, j12);
            if (obj == null) {
                obj = aAnYcst.get();
            }
            Ka.MY3jR.qLLw0g(atomicReferenceArrayEszJ2B0a, iRjljd6i2, obj);
            Ka.MY3jR.qLLw0g(atomicReferenceArray, ydGaB1bU(j10), atomicReferenceArrayEszJ2B0a);
            long jEgsKh = egsKh(j11, dUI84());
            Na.AAnYcst.eLbhX59K(jEgsKh, "availableInQueue");
            nyeBEo(Math.min(j12, jEgsKh) + j11);
            yxejkub(j11 + 2);
            Ka.MY3jR.qLLw0g(atomicReferenceArray, iRjljd6i, zigsCJW);
        } catch (OutOfMemoryError e10) {
            yxejkub(j11);
            throw e10;
        }
    }

    public final Object sgXstV(AtomicReferenceArray atomicReferenceArray, long j10) {
        int iRjljd6i = Ka.MY3jR.rjljd6i(j10, this.zYD7SXW6);
        Object objOZ7qYn = Ka.MY3jR.oZ7qYn(atomicReferenceArray, iRjljd6i);
        if (objOZ7qYn == null) {
            throw new IllegalStateException("new buffer must have at least one element");
        }
        Ka.MY3jR.qLLw0g(atomicReferenceArray, iRjljd6i, null);
        sMxPLer(j10 + 2);
        return objOZ7qYn;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public int size() {
        return Ja.Lx1jI.eLbhX59K(this, 2);
    }

    @Override // java.util.AbstractCollection
    public String toString() {
        return getClass().getName();
    }
}
