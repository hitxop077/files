package Ka;

import java.util.AbstractQueue;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class XbU7b extends AbstractQueue implements Ja.Lx1jI.MY3jR {
}
