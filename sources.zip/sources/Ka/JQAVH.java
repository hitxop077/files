package Ka;

import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public class JQAVH extends SFMiYa {
    public static final int dNE3s = Integer.getInteger("jctools.mpmc.max.lookahead.step", 4096).intValue();
    public final int pz7TsV;

    public JQAVH(int i10) {
        super(Na.AAnYcst.eszJ2B0a(i10, 2, "capacity"));
        this.pz7TsV = Math.max(2, Math.min(zDWsfFRp() / 4, dNE3s));
    }

    private int sMxPLer(Ja.VVpVRy.MY3jR mY3jR, int i10) {
        long jDUI84;
        int iAXYSYCVY;
        AtomicLongArray atomicLongArray = this.gmzPK;
        int i11 = this.vo5p9AUA;
        AtomicReferenceArray atomicReferenceArray = this.njNibPNp;
        for (int i12 = 0; i12 < i10; i12++) {
            while (true) {
                jDUI84 = dUI84();
                iAXYSYCVY = MY3jR.aXYSYCVY(jDUI84, i11);
                long jDUI85 = MY3jR.dUI84(atomicLongArray, iAXYSYCVY);
                long j10 = jDUI84 + 1;
                if (jDUI85 < j10) {
                    return i12;
                }
                if (jDUI85 > j10 || !mTWLV(jDUI84, j10)) {
                }
            }
            long j11 = i11;
            int iELbhX59K = MY3jR.eLbhX59K(jDUI84, j11);
            Object objOsx7Pl0E = MY3jR.osx7Pl0E(atomicReferenceArray, iELbhX59K);
            MY3jR.q1ORKN(atomicReferenceArray, iELbhX59K, null);
            MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, jDUI84 + j11 + 1);
            mY3jR.accept(objOsx7Pl0E);
        }
        return i10;
    }

    @Override // Ja.VVpVRy
    public Object aXYSYCVY() {
        AtomicLongArray atomicLongArray = this.gmzPK;
        int i10 = this.vo5p9AUA;
        while (true) {
            long jDUI84 = dUI84();
            int iAXYSYCVY = MY3jR.aXYSYCVY(jDUI84, i10);
            long jDUI85 = MY3jR.dUI84(atomicLongArray, iAXYSYCVY);
            long j10 = jDUI84 + 1;
            if (jDUI85 < j10) {
                return null;
            }
            if (jDUI85 <= j10 && mTWLV(jDUI84, j10)) {
                long j11 = i10;
                int iELbhX59K = MY3jR.eLbhX59K(jDUI84, j11);
                Object objOsx7Pl0E = MY3jR.osx7Pl0E(this.njNibPNp, iELbhX59K);
                MY3jR.q1ORKN(this.njNibPNp, iELbhX59K, null);
                MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, jDUI84 + j11 + 1);
                return objOsx7Pl0E;
            }
        }
    }

    public final boolean c1pvtY(long j10, int i10, AtomicLongArray atomicLongArray, long j11) {
        return MY3jR.dUI84(atomicLongArray, MY3jR.aXYSYCVY(j10, i10)) < j11;
    }

    @Override // Ja.VVpVRy
    public boolean ivfTYNl(Object obj) {
        if (obj == null) {
            throw null;
        }
        int i10 = this.vo5p9AUA;
        AtomicLongArray atomicLongArray = this.gmzPK;
        while (true) {
            long jELbhX59K = eLbhX59K();
            int iAXYSYCVY = MY3jR.aXYSYCVY(jELbhX59K, i10);
            long jDUI84 = MY3jR.dUI84(atomicLongArray, iAXYSYCVY);
            if (jDUI84 < jELbhX59K) {
                return false;
            }
            if (jDUI84 <= jELbhX59K) {
                long j10 = 1 + jELbhX59K;
                if (yxejkub(jELbhX59K, j10)) {
                    MY3jR.q1ORKN(this.njNibPNp, MY3jR.eLbhX59K(jELbhX59K, i10), obj);
                    MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, j10);
                    return true;
                }
            }
        }
    }

    @Override // java.util.Queue
    public boolean offer(Object obj) {
        if (obj == null) {
            throw null;
        }
        int i10 = this.vo5p9AUA;
        long j10 = i10 + 1;
        AtomicLongArray atomicLongArray = this.gmzPK;
        long jDUI84 = Long.MIN_VALUE;
        while (true) {
            long jELbhX59K = eLbhX59K();
            int iAXYSYCVY = MY3jR.aXYSYCVY(jELbhX59K, i10);
            long jDUI85 = MY3jR.dUI84(atomicLongArray, iAXYSYCVY);
            if (jDUI85 < jELbhX59K) {
                long j11 = jELbhX59K - j10;
                if (j11 >= jDUI84) {
                    jDUI84 = dUI84();
                    if (j11 >= jDUI84) {
                        return false;
                    }
                }
                jDUI85 = jELbhX59K + 1;
            }
            if (jDUI85 <= jELbhX59K) {
                long j12 = 1 + jELbhX59K;
                if (yxejkub(jELbhX59K, j12)) {
                    MY3jR.q1ORKN(this.njNibPNp, MY3jR.eLbhX59K(jELbhX59K, i10), obj);
                    MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, j12);
                    return true;
                }
            }
        }
    }

    @Override // java.util.Queue
    public Object peek() {
        AtomicLongArray atomicLongArray = this.gmzPK;
        int i10 = this.vo5p9AUA;
        long jELbhX59K = -1;
        while (true) {
            long jDUI84 = dUI84();
            long jDUI85 = MY3jR.dUI84(atomicLongArray, MY3jR.aXYSYCVY(jDUI84, i10));
            long j10 = 1 + jDUI84;
            if (jDUI85 < j10) {
                if (jDUI84 >= jELbhX59K) {
                    jELbhX59K = eLbhX59K();
                    if (jDUI84 == jELbhX59K) {
                        return null;
                    }
                } else {
                    continue;
                }
            } else if (jDUI85 == j10) {
                Object objOZ7qYn = MY3jR.oZ7qYn(this.njNibPNp, MY3jR.eLbhX59K(jDUI84, i10));
                if (dUI84() == jDUI84) {
                    return objOZ7qYn;
                }
            } else {
                continue;
            }
        }
    }

    @Override // java.util.Queue, Ja.VVpVRy
    public Object poll() {
        AtomicLongArray atomicLongArray = this.gmzPK;
        int i10 = this.vo5p9AUA;
        long jELbhX59K = -1;
        while (true) {
            long jDUI84 = dUI84();
            int iAXYSYCVY = MY3jR.aXYSYCVY(jDUI84, i10);
            long jDUI85 = MY3jR.dUI84(atomicLongArray, iAXYSYCVY);
            long j10 = jDUI84 + 1;
            if (jDUI85 < j10) {
                if (jDUI84 >= jELbhX59K) {
                    jELbhX59K = eLbhX59K();
                    if (jDUI84 == jELbhX59K) {
                        return null;
                    }
                }
                jDUI85 = 2 + jDUI84;
            }
            if (jDUI85 <= j10 && mTWLV(jDUI84, j10)) {
                long j11 = i10;
                int iELbhX59K = MY3jR.eLbhX59K(jDUI84, j11);
                Object objOsx7Pl0E = MY3jR.osx7Pl0E(this.njNibPNp, iELbhX59K);
                MY3jR.q1ORKN(this.njNibPNp, iELbhX59K, null);
                MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, jDUI84 + j11 + 1);
                return objOsx7Pl0E;
            }
        }
    }

    @Override // Ja.VVpVRy
    public int qLLw0g(Ja.VVpVRy.MY3jR mY3jR, int i10) {
        JQAVH jqavh;
        JQAVH jqavh2 = this;
        int i11 = i10;
        if (mY3jR == null) {
            throw new IllegalArgumentException("c is null");
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("limit is negative: " + i11);
        }
        boolean z10 = false;
        if (i11 == 0) {
            return 0;
        }
        AtomicLongArray atomicLongArray = jqavh2.gmzPK;
        int i12 = jqavh2.vo5p9AUA;
        AtomicReferenceArray atomicReferenceArray = jqavh2.njNibPNp;
        int iMin = Math.min(jqavh2.pz7TsV, i11);
        int i13 = 0;
        while (i13 < i11) {
            int i14 = i11 - i13;
            int iMin2 = Math.min(i14, iMin);
            int i15 = i11;
            long jDUI84 = jqavh2.dUI84();
            long j10 = ((long) iMin2) + jDUI84;
            long j11 = 1;
            long jDUI85 = MY3jR.dUI84(atomicLongArray, MY3jR.aXYSYCVY(j10 - 1, i12));
            if (jDUI85 != j10 || !jqavh2.mTWLV(jDUI84, j10)) {
                if (jDUI85 < j10) {
                    jqavh = this;
                    if (jqavh.c1pvtY(jDUI84, i12, atomicLongArray, jDUI84 + 1)) {
                        return i13;
                    }
                } else {
                    jqavh = this;
                }
                return i13 + jqavh.sMxPLer(mY3jR, i14);
            }
            int i16 = 0;
            while (i16 < iMin2) {
                long j12 = ((long) i16) + jDUI84;
                int iAXYSYCVY = MY3jR.aXYSYCVY(j12, i12);
                long j13 = jDUI84;
                long j14 = i12;
                int iELbhX59K = MY3jR.eLbhX59K(j12, j14);
                while (MY3jR.dUI84(atomicLongArray, iAXYSYCVY) != j12 + j11) {
                }
                long j15 = j11;
                Object objOsx7Pl0E = MY3jR.osx7Pl0E(atomicReferenceArray, iELbhX59K);
                MY3jR.q1ORKN(atomicReferenceArray, iELbhX59K, null);
                MY3jR.zPJpxWz(atomicLongArray, iAXYSYCVY, j12 + j14 + j15);
                mY3jR.accept(objOsx7Pl0E);
                i16++;
                jDUI84 = j13;
                j11 = j15;
            }
            i13 += iMin2;
            jqavh2 = this;
            i11 = i15;
            z10 = false;
        }
        return i11;
    }
}
