package Ka;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public class NUIvmoc extends RFQ3AA8 {
    public NUIvmoc(int i10) {
        super(i10);
    }

    @Override // Ka.RFQ3AA8, Ja.VVpVRy
    public /* bridge */ /* synthetic */ Object aXYSYCVY() {
        return super.aXYSYCVY();
    }

    @Override // Ka.RFQ3AA8
    public int d3penA(AtomicReferenceArray atomicReferenceArray) {
        return MY3jR.ivfTYNl(atomicReferenceArray);
    }

    @Override // Ka.RFQ3AA8
    public long egsKh(long j10, long j11) {
        return 2147483647L;
    }

    @Override // Ka.RFQ3AA8, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ boolean isEmpty() {
        return super.isEmpty();
    }

    @Override // Ka.RFQ3AA8, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public /* bridge */ /* synthetic */ Iterator iterator() {
        return super.iterator();
    }

    @Override // Ka.RFQ3AA8, Ja.VVpVRy
    public /* bridge */ /* synthetic */ boolean ivfTYNl(Object obj) {
        return super.ivfTYNl(obj);
    }

    @Override // Ka.RFQ3AA8, java.util.Queue
    public /* bridge */ /* synthetic */ boolean offer(Object obj) {
        return super.offer(obj);
    }

    @Override // Ka.RFQ3AA8, java.util.Queue
    public /* bridge */ /* synthetic */ Object peek() {
        return super.peek();
    }

    @Override // Ka.RFQ3AA8, java.util.Queue, Ja.VVpVRy
    public /* bridge */ /* synthetic */ Object poll() {
        return super.poll();
    }

    @Override // Ka.RFQ3AA8, Ja.VVpVRy
    public /* bridge */ /* synthetic */ int qLLw0g(Ja.VVpVRy.MY3jR mY3jR, int i10) {
        return super.qLLw0g(mY3jR, i10);
    }

    @Override // Ka.RFQ3AA8, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ int size() {
        return super.size();
    }

    @Override // Ka.RFQ3AA8, java.util.AbstractCollection
    public /* bridge */ /* synthetic */ String toString() {
        return super.toString();
    }

    @Override // Ja.Lx1jI.MY3jR
    public int zDWsfFRp() {
        return -1;
    }

    @Override // Ka.RFQ3AA8
    public long ceTXybVl(long j10) {
        return j10;
    }
}
