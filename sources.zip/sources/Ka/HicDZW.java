package Ka;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class HicDZW extends XbU7b {
    public static final AtomicLongFieldUpdater vo5p9AUA = AtomicLongFieldUpdater.newUpdater(HicDZW.class, "njNibPNp");
    public volatile long njNibPNp;

    @Override // Ja.Lx1jI.MY3jR
    public final long eLbhX59K() {
        return this.njNibPNp;
    }

    public final boolean q1ORKN(long j10, long j11) {
        return vo5p9AUA.compareAndSet(this, j10, j11);
    }

    public final void yxejkub(long j10) {
        vo5p9AUA.lazySet(this, j10);
    }
}
