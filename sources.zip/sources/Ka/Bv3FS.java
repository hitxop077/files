package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Bv3FS extends O5Z56VT6 {
    public Bv3FS(int i10) {
        super(i10);
    }
}
