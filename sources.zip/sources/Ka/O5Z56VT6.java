package Ka;

import java.util.concurrent.atomic.AtomicLongArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class O5Z56VT6 extends AAnYcst {
    public final AtomicLongArray gmzPK;

    public O5Z56VT6(int i10) {
        super(i10);
        int i11 = this.vo5p9AUA + 1;
        this.gmzPK = new AtomicLongArray(i11);
        for (int i12 = 0; i12 < i11; i12++) {
            q1ORKN(this.gmzPK, i12, i12);
        }
    }

    public final void q1ORKN(AtomicLongArray atomicLongArray, int i10, long j10) {
        atomicLongArray.lazySet(i10, j10);
    }
}
