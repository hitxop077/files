package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Gyx10a extends RFQ3AA8 {
    public final long bBHqyf;

    public Gyx10a(int i10, int i11) {
        super(i10);
        Na.AAnYcst.eszJ2B0a(i11, 4, "maxCapacity");
        Na.AAnYcst.aXYSYCVY(Na.MY3jR.eLbhX59K(i10), Na.MY3jR.eLbhX59K(i11), "initialCapacity");
        this.bBHqyf = ((long) Na.MY3jR.eLbhX59K(i11)) << 1;
    }
}
