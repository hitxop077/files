package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class GU39Hcg extends N1vNRFSd {
}
