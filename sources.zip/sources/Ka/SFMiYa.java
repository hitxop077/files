package Ka;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class SFMiYa extends Lx1jI {
    public SFMiYa(int i10) {
        super(i10);
    }
}
