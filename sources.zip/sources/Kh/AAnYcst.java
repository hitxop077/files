package Kh;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes10.dex */
public final class AAnYcst {
    public static final AAnYcst eszJ2B0a = new AAnYcst();

    public final long eszJ2B0a(long j10) {
        return Long.parseLong(String.valueOf(j10)) / ((long) 1048576);
    }
}
