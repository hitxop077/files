package ju9q3;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class LNd998w {
    public int eszJ2B0a;

    public /* synthetic */ LNd998w(RFQ3AA8 rfq3aa8) {
    }
}
