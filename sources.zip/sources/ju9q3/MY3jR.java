package ju9q3;

import an89d.AXWzg4r;
import an89d.HicDZW;
import an89d.NUIvmoc;
import an89d.XbU7b;
import android.content.Context;
import android.os.PowerManager;
import android.os.WorkSource;
import android.text.TextUtils;
import f5zilcb.VVpVRy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.jvm.internal.LongCompanionObject;
import vpdia.GU39Hcg;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public class MY3jR {
    public final PowerManager.WakeLock aXYSYCVY;
    public boolean dUI84;
    public int eLbhX59K;
    public final Object eszJ2B0a;
    public long ivfTYNl;
    public AtomicInteger mTWLV;
    public int oZ7qYn;
    public final Set osx7Pl0E;
    public final String q1ORKN;
    public WorkSource qLLw0g;
    public final ScheduledExecutorService rJCQt16;
    public vpdia.AAnYcst rjljd6i;
    public final String uTIfLNK0;
    public final Context uYRSwDm;
    public final Map yxejkub;
    public Future zDWsfFRp;
    public XbU7b zPJpxWz;
    public static final long jAM6dcNA = TimeUnit.DAYS.toMillis(366);
    public static volatile ScheduledExecutorService rtsRj = null;
    public static final Object oyaOvpOs = new Object();
    public static volatile N1vNRFSd n84TFkA9 = new RFQ3AA8();

    public MY3jR(Context context, int i10, String str) {
        String packageName = context.getPackageName();
        this.eszJ2B0a = new Object();
        this.eLbhX59K = 0;
        this.osx7Pl0E = new HashSet();
        this.dUI84 = true;
        this.zPJpxWz = HicDZW.eLbhX59K();
        this.yxejkub = new HashMap();
        this.mTWLV = new AtomicInteger(0);
        VVpVRy.uYRSwDm(context, "WakeLock: context must not be null");
        VVpVRy.oZ7qYn(str, "WakeLock: wakeLockName must not be empty");
        this.uYRSwDm = context.getApplicationContext();
        this.uTIfLNK0 = str;
        this.rjljd6i = null;
        if ("com.google.android.gms".equals(context.getPackageName())) {
            this.q1ORKN = str;
        } else {
            String strValueOf = String.valueOf(str);
            this.q1ORKN = strValueOf.length() != 0 ? "*gcore*:".concat(strValueOf) : new String("*gcore*:");
        }
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        if (powerManager == null) {
            StringBuilder sb2 = new StringBuilder(29);
            sb2.append((CharSequence) "expected a non-null reference", 0, 29);
            throw new vpdia.HicDZW(sb2.toString());
        }
        PowerManager.WakeLock wakeLockNewWakeLock = powerManager.newWakeLock(i10, str);
        this.aXYSYCVY = wakeLockNewWakeLock;
        if (AXWzg4r.eLbhX59K(context)) {
            WorkSource workSourceAXYSYCVY = AXWzg4r.aXYSYCVY(context, NUIvmoc.eszJ2B0a(packageName) ? context.getPackageName() : packageName);
            this.qLLw0g = workSourceAXYSYCVY;
            if (workSourceAXYSYCVY != null) {
                rjljd6i(wakeLockNewWakeLock, workSourceAXYSYCVY);
            }
        }
        ScheduledExecutorService scheduledExecutorServiceUnconfigurableScheduledExecutorService = rtsRj;
        if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
            synchronized (oyaOvpOs) {
                try {
                    scheduledExecutorServiceUnconfigurableScheduledExecutorService = rtsRj;
                    if (scheduledExecutorServiceUnconfigurableScheduledExecutorService == null) {
                        GU39Hcg.eszJ2B0a();
                        scheduledExecutorServiceUnconfigurableScheduledExecutorService = Executors.unconfigurableScheduledExecutorService(Executors.newScheduledThreadPool(1));
                        rtsRj = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.rJCQt16 = scheduledExecutorServiceUnconfigurableScheduledExecutorService;
    }

    public static /* synthetic */ void ivfTYNl(MY3jR mY3jR) {
        synchronized (mY3jR.eszJ2B0a) {
            try {
                if (mY3jR.aXYSYCVY()) {
                    String.valueOf(mY3jR.q1ORKN).concat(" ** IS FORCE-RELEASED ON TIMEOUT **");
                    mY3jR.dUI84();
                    if (mY3jR.aXYSYCVY()) {
                        mY3jR.eLbhX59K = 1;
                        mY3jR.oZ7qYn(0);
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public static void rjljd6i(PowerManager.WakeLock wakeLock, WorkSource workSource) {
        try {
            wakeLock.setWorkSource(workSource);
        } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException e10) {
            e10.toString();
        }
    }

    public boolean aXYSYCVY() {
        boolean z10;
        synchronized (this.eszJ2B0a) {
            z10 = this.eLbhX59K > 0;
        }
        return z10;
    }

    public final void dUI84() {
        if (this.osx7Pl0E.isEmpty()) {
            return;
        }
        ArrayList arrayList = new ArrayList(this.osx7Pl0E);
        this.osx7Pl0E.clear();
        if (arrayList.size() <= 0) {
            return;
        }
        android.support.v4.media.MY3jR.eszJ2B0a(arrayList.get(0));
        throw null;
    }

    public void eLbhX59K() {
        if (this.mTWLV.decrementAndGet() < 0) {
            String.valueOf(this.q1ORKN).concat(" release without a matched acquire!");
        }
        synchronized (this.eszJ2B0a) {
            try {
                osx7Pl0E(null);
                if (this.yxejkub.containsKey(null)) {
                    LNd998w lNd998w = (LNd998w) this.yxejkub.get(null);
                    if (lNd998w != null) {
                        int i10 = lNd998w.eszJ2B0a - 1;
                        lNd998w.eszJ2B0a = i10;
                        if (i10 == 0) {
                            this.yxejkub.remove(null);
                        }
                    }
                } else {
                    String.valueOf(this.q1ORKN).concat(" counter does not exist");
                }
                oZ7qYn(0);
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void eszJ2B0a(long j10) {
        this.mTWLV.incrementAndGet();
        long j11 = jAM6dcNA;
        long j12 = LongCompanionObject.MAX_VALUE;
        long jMax = Math.max(Math.min(LongCompanionObject.MAX_VALUE, j11), 1L);
        if (j10 > 0) {
            jMax = Math.min(j10, jMax);
        }
        synchronized (this.eszJ2B0a) {
            try {
                if (!aXYSYCVY()) {
                    this.rjljd6i = vpdia.AAnYcst.eszJ2B0a(false, null);
                    this.aXYSYCVY.acquire();
                    this.zPJpxWz.eszJ2B0a();
                }
                this.eLbhX59K++;
                this.oZ7qYn++;
                osx7Pl0E(null);
                LNd998w lNd998w = (LNd998w) this.yxejkub.get(null);
                if (lNd998w == null) {
                    lNd998w = new LNd998w(null);
                    this.yxejkub.put(null, lNd998w);
                }
                lNd998w.eszJ2B0a++;
                long jEszJ2B0a = this.zPJpxWz.eszJ2B0a();
                if (LongCompanionObject.MAX_VALUE - jEszJ2B0a > jMax) {
                    j12 = jEszJ2B0a + jMax;
                }
                if (j12 > this.ivfTYNl) {
                    this.ivfTYNl = j12;
                    Future future = this.zDWsfFRp;
                    if (future != null) {
                        future.cancel(false);
                    }
                    this.zDWsfFRp = this.rJCQt16.schedule(new Runnable() { // from class: ju9q3.AAnYcst
                        @Override // java.lang.Runnable
                        public final void run() {
                            MY3jR.ivfTYNl(this.njNibPNp);
                        }
                    }, jMax, TimeUnit.MILLISECONDS);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void oZ7qYn(int i10) {
        synchronized (this.eszJ2B0a) {
            try {
                if (aXYSYCVY()) {
                    if (this.dUI84) {
                        int i11 = this.eLbhX59K - 1;
                        this.eLbhX59K = i11;
                        if (i11 > 0) {
                            return;
                        }
                    } else {
                        this.eLbhX59K = 0;
                    }
                    dUI84();
                    Iterator it2 = this.yxejkub.values().iterator();
                    while (it2.hasNext()) {
                        ((LNd998w) it2.next()).eszJ2B0a = 0;
                    }
                    this.yxejkub.clear();
                    Future future = this.zDWsfFRp;
                    if (future != null) {
                        future.cancel(false);
                        this.zDWsfFRp = null;
                        this.ivfTYNl = 0L;
                    }
                    this.oZ7qYn = 0;
                    if (this.aXYSYCVY.isHeld()) {
                        try {
                            try {
                                this.aXYSYCVY.release();
                                if (this.rjljd6i != null) {
                                    this.rjljd6i = null;
                                }
                            } catch (RuntimeException e10) {
                                if (!e10.getClass().equals(RuntimeException.class)) {
                                    throw e10;
                                }
                                String.valueOf(this.q1ORKN).concat(" failed to release!");
                                if (this.rjljd6i != null) {
                                    this.rjljd6i = null;
                                }
                            }
                        } catch (Throwable th2) {
                            if (this.rjljd6i != null) {
                                this.rjljd6i = null;
                            }
                            throw th2;
                        }
                    } else {
                        String.valueOf(this.q1ORKN).concat(" should be held!");
                    }
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }

    public final String osx7Pl0E(String str) {
        if (this.dUI84) {
            TextUtils.isEmpty(null);
        }
        return null;
    }

    public void zDWsfFRp(boolean z10) {
        synchronized (this.eszJ2B0a) {
            this.dUI84 = z10;
        }
    }
}
