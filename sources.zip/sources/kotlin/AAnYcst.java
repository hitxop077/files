package kotlin;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract /* synthetic */ class AAnYcst {
    public static /* synthetic */ int eszJ2B0a(int i10, int i11) {
        return (int) ((((long) i10) & 4294967295L) % (((long) i11) & 4294967295L));
    }
}
