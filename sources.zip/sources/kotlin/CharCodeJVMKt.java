package kotlin;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0087\b¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Char", "", "code", "Lkotlin/UShort;", "Char-xj2QHRw", "(S)C", "kotlin-stdlib"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class CharCodeJVMKt {
    /* JADX INFO: renamed from: Char-xj2QHRw, reason: not valid java name */
    private static final char m425Charxj2QHRw(short s10) {
        return (char) (s10 & UShort.MAX_VALUE);
    }
}
