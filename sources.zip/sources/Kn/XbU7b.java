package Kn;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class XbU7b {
    public static final XbU7b eszJ2B0a = new XbU7b();

    public static /* synthetic */ void eLbhX59K(XbU7b xbU7b, String str, String str2, String str3, Throwable th2, int i10, Object obj) {
        if ((i10 & 8) != 0) {
            th2 = null;
        }
        xbU7b.aXYSYCVY(str, str2, str3, th2);
    }

    public static /* synthetic */ void osx7Pl0E(XbU7b xbU7b, String str, String str2, String str3, Throwable th2, int i10, Object obj) {
        if ((i10 & 8) != 0) {
            th2 = null;
        }
        xbU7b.ivfTYNl(str, str2, str3, th2);
    }

    public final void aXYSYCVY(String className, String methodName, String message, Throwable th2) {
        Intrinsics.checkNotNullParameter(className, "className");
        Intrinsics.checkNotNullParameter(methodName, "methodName");
        Intrinsics.checkNotNullParameter(message, "message");
    }

    public final void eszJ2B0a(String className, String methodName, String message) {
        Intrinsics.checkNotNullParameter(className, "className");
        Intrinsics.checkNotNullParameter(methodName, "methodName");
        Intrinsics.checkNotNullParameter(message, "message");
    }

    public final void ivfTYNl(String className, String methodName, String message, Throwable th2) {
        Intrinsics.checkNotNullParameter(className, "className");
        Intrinsics.checkNotNullParameter(methodName, "methodName");
        Intrinsics.checkNotNullParameter(message, "message");
    }

    public final void zDWsfFRp(String className, String methodName, String message) {
        Intrinsics.checkNotNullParameter(className, "className");
        Intrinsics.checkNotNullParameter(methodName, "methodName");
        Intrinsics.checkNotNullParameter(message, "message");
    }
}
