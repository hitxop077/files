package Kn;

import android.content.Context;
import android.os.Bundle;
import android.widget.ImageView;
import java.util.Map;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface N1vNRFSd {
    void loadImage(Context context, ImageView imageView, String str);

    void logHEEvent(Map map, Map map2);

    void logSigEvent(Context context, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, Map map);

    void openDeeplink(Context context, String str, Bundle bundle);
}
