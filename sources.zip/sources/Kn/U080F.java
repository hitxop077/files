package Kn;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public abstract /* synthetic */ class U080F {
}
