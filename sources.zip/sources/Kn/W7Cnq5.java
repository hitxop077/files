package Kn;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class W7Cnq5 {
    public static N1vNRFSd aXYSYCVY;
    public static final W7Cnq5 eszJ2B0a = new W7Cnq5();

    public final void aXYSYCVY(N1vNRFSd interfaceImpl) {
        Intrinsics.checkNotNullParameter(interfaceImpl, "interfaceImpl");
        aXYSYCVY = interfaceImpl;
    }

    public final N1vNRFSd eszJ2B0a() {
        return aXYSYCVY;
    }
}
