package Ja;

import java.util.Iterator;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class JQAVH extends GU39Hcg {
    public final long[] gmzPK;

    public JQAVH(int i10) {
        super(i10);
        int i11 = (int) (this.njNibPNp + 1);
        this.gmzPK = Na.LNd998w.eszJ2B0a(i11);
        for (long j10 = 0; j10 < i11; j10++) {
            Na.LNd998w.zDWsfFRp(this.gmzPK, Na.LNd998w.aXYSYCVY(j10, this.njNibPNp), j10);
        }
    }

    @Override // Ja.GU39Hcg, java.util.AbstractQueue, java.util.AbstractCollection, java.util.Collection, Ja.VVpVRy
    public /* bridge */ /* synthetic */ void clear() {
        super.clear();
    }

    @Override // Ja.GU39Hcg, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ boolean isEmpty() {
        return super.isEmpty();
    }

    @Override // Ja.GU39Hcg, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public /* bridge */ /* synthetic */ Iterator iterator() {
        return super.iterator();
    }

    @Override // Ja.GU39Hcg, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ int size() {
        return super.size();
    }

    @Override // Ja.GU39Hcg, java.util.AbstractCollection
    public /* bridge */ /* synthetic */ String toString() {
        return super.toString();
    }

    @Override // Ja.GU39Hcg, Ja.Lx1jI.MY3jR
    public /* bridge */ /* synthetic */ int zDWsfFRp() {
        return super.zDWsfFRp();
    }
}
