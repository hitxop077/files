package Ja;

import kotlin.jvm.internal.IntCompanionObject;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Lx1jI {

    /* JADX INFO: compiled from: Obfuscated */
    public interface MY3jR {
        long dUI84();

        long eLbhX59K();

        int zDWsfFRp();
    }

    public static int aXYSYCVY(int i10, long j10) {
        if (j10 < 0) {
            return 0;
        }
        if (i10 == -1 || j10 <= i10) {
            return j10 > 2147483647L ? IntCompanionObject.MAX_VALUE : (int) j10;
        }
        return i10;
    }

    public static int eLbhX59K(MY3jR mY3jR, int i10) {
        long jDUI84 = mY3jR.dUI84();
        while (true) {
            long jELbhX59K = mY3jR.eLbhX59K();
            long jDUI85 = mY3jR.dUI84();
            if (jDUI84 == jDUI85) {
                return aXYSYCVY(mY3jR.zDWsfFRp(), (jELbhX59K - jDUI85) / ((long) i10));
            }
            jDUI84 = jDUI85;
        }
    }

    public static boolean eszJ2B0a(MY3jR mY3jR) {
        return mY3jR.dUI84() >= mY3jR.eLbhX59K();
    }
}
