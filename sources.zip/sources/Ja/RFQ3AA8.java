package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class RFQ3AA8 extends N1vNRFSd {
    public static final long fdmP9GD = Na.RFQ3AA8.eszJ2B0a(RFQ3AA8.class, "consumerIndex");
    public volatile long gmzPK;
    public Object[] xINpNt2d;
    public long zYD7SXW6;

    @Override // Ja.Lx1jI.MY3jR
    public final long dUI84() {
        return this.gmzPK;
    }

    public final long mTWLV() {
        return Na.RFQ3AA8.eLbhX59K.getLong(this, fdmP9GD);
    }

    public final void sMxPLer(long j10) {
        Na.RFQ3AA8.eLbhX59K.putOrderedLong(this, fdmP9GD, j10);
    }
}
