package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class W7Cnq5 extends LNd998w {
    public static final long vo5p9AUA = Na.RFQ3AA8.eszJ2B0a(W7Cnq5.class, "producerIndex");
    public volatile long njNibPNp;

    @Override // Ja.Lx1jI.MY3jR
    public final long eLbhX59K() {
        return this.njNibPNp;
    }

    public final boolean q1ORKN(long j10, long j11) {
        return Na.RFQ3AA8.eLbhX59K.compareAndSwapLong(this, vo5p9AUA, j10, j11);
    }

    public final void yxejkub(long j10) {
        Na.RFQ3AA8.eLbhX59K.putOrderedLong(this, vo5p9AUA, j10);
    }
}
