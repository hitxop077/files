package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class SFMiYa {
    public static int eszJ2B0a(VVpVRy vVpVRy, VVpVRy.MY3jR mY3jR, int i10) {
        if (mY3jR == null) {
            throw new IllegalArgumentException("c is null");
        }
        if (i10 < 0) {
            throw new IllegalArgumentException("limit is negative: " + i10);
        }
        int i11 = 0;
        if (i10 == 0) {
            return 0;
        }
        while (i11 < i10) {
            Object objAXYSYCVY = vVpVRy.aXYSYCVY();
            if (objAXYSYCVY == null) {
                break;
            }
            mY3jR.accept(objAXYSYCVY);
            i11++;
        }
        return i11;
    }
}
