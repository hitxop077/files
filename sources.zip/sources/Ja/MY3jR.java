package Ja;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.LongCompanionObject;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class MY3jR extends AAnYcst implements VVpVRy {
    public static final Object zigsCJW = new Object();
    public static final Object ca3iT = new Object();

    /* JADX INFO: renamed from: Ja.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static class C0090MY3jR implements Iterator {
        public Object gmzPK;
        public final long njNibPNp;
        public long vo5p9AUA;
        public int xINpNt2d;
        public Object[] zYD7SXW6;

        public C0090MY3jR(Object[] objArr, long j10, long j11) {
            this.njNibPNp = j11 >> 1;
            this.vo5p9AUA = j10 >> 1;
            aXYSYCVY(objArr);
            this.gmzPK = eszJ2B0a();
        }

        public final void aXYSYCVY(Object[] objArr) {
            this.zYD7SXW6 = objArr;
            this.xINpNt2d = Bv3FS.eszJ2B0a(objArr) - 2;
        }

        public final Object eszJ2B0a() {
            while (true) {
                long j10 = this.vo5p9AUA;
                if (j10 >= this.njNibPNp) {
                    break;
                }
                this.vo5p9AUA = 1 + j10;
                Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(this.zYD7SXW6, Na.N1vNRFSd.aXYSYCVY(j10, this.xINpNt2d));
                if (objIvfTYNl != null) {
                    if (objIvfTYNl != MY3jR.zigsCJW) {
                        return objIvfTYNl;
                    }
                    Object objIvfTYNl2 = Na.N1vNRFSd.ivfTYNl(this.zYD7SXW6, Na.N1vNRFSd.eLbhX59K(this.xINpNt2d + 1));
                    if (objIvfTYNl2 == MY3jR.ca3iT || objIvfTYNl2 == null) {
                        break;
                    }
                    aXYSYCVY((Object[]) objIvfTYNl2);
                    Object objIvfTYNl3 = Na.N1vNRFSd.ivfTYNl(this.zYD7SXW6, Na.N1vNRFSd.aXYSYCVY(j10, this.xINpNt2d));
                    if (objIvfTYNl3 != null) {
                        return objIvfTYNl3;
                    }
                }
            }
            return null;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.gmzPK != null;
        }

        @Override // java.util.Iterator
        public Object next() {
            Object obj = this.gmzPK;
            if (obj == null) {
                throw new NoSuchElementException();
            }
            this.gmzPK = eszJ2B0a();
            return obj;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("remove");
        }
    }

    public MY3jR(int i10) {
        Na.AAnYcst.eszJ2B0a(i10, 2, "initialCapacity");
        int iELbhX59K = Na.MY3jR.eLbhX59K(i10);
        long j10 = (iELbhX59K - 1) << 1;
        Object[] objArrEszJ2B0a = Na.N1vNRFSd.eszJ2B0a(iELbhX59K + 1);
        this.dNE3s = objArrEszJ2B0a;
        this.pz7TsV = j10;
        this.xINpNt2d = objArrEszJ2B0a;
        this.zYD7SXW6 = j10;
        nyeBEo(j10);
    }

    public static long ydGaB1bU(long j10) {
        return Bv3FS.aXYSYCVY(j10 + 2, LongCompanionObject.MAX_VALUE);
    }

    public final Object[] aNB31q(Object[] objArr, long j10) {
        long jYdGaB1bU = ydGaB1bU(j10);
        Object[] objArr2 = (Object[]) Na.N1vNRFSd.ivfTYNl(objArr, jYdGaB1bU);
        this.xINpNt2d = objArr2;
        this.zYD7SXW6 = (Bv3FS.eszJ2B0a(objArr2) - 2) << 1;
        Na.N1vNRFSd.osx7Pl0E(objArr, jYdGaB1bU, ca3iT);
        return objArr2;
    }

    public Object aXYSYCVY() {
        Object[] objArr = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        long jAXYSYCVY = Bv3FS.aXYSYCVY(jMTWLV, j10);
        Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
        if (objIvfTYNl == null) {
            return null;
        }
        if (objIvfTYNl == zigsCJW) {
            return sgXstV(aNB31q(objArr, j10), jMTWLV);
        }
        Na.N1vNRFSd.osx7Pl0E(objArr, jAXYSYCVY, null);
        sMxPLer(jMTWLV + 2);
        return objIvfTYNl;
    }

    public abstract long ceTXybVl(long j10);

    public abstract int d3penA(Object[] objArr);

    public abstract long egsKh(long j10, long j11);

    public final int fIz14cTt(long j10, long j11, long j12) {
        long jDUI84 = dUI84();
        long jCeTXybVl = ceTXybVl(j10) + jDUI84;
        if (jCeTXybVl > j11) {
            return !c1pvtY(j12, jCeTXybVl) ? 1 : 0;
        }
        if (egsKh(j11, jDUI84) <= 0) {
            return 2;
        }
        return q1ORKN(j11, 1 + j11) ? 3 : 1;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public boolean isEmpty() {
        return (dUI84() - eLbhX59K()) / 2 == 0;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return new C0090MY3jR(this.xINpNt2d, dUI84(), eLbhX59K());
    }

    public boolean ivfTYNl(Object obj) {
        return offer(obj);
    }

    public final Object myMyVU(Object[] objArr, long j10) {
        Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, Bv3FS.aXYSYCVY(j10, this.zYD7SXW6));
        if (objIvfTYNl != null) {
            return objIvfTYNl;
        }
        throw new IllegalStateException("new buffer must have at least one element");
    }

    public boolean offer(Object obj) {
        if (obj == null) {
            throw null;
        }
        while (true) {
            long jEImdmIyv = eImdmIyv();
            long jELbhX59K = eLbhX59K();
            if ((jELbhX59K & 1) != 1) {
                long j10 = this.pz7TsV;
                Object[] objArr = this.dNE3s;
                if (jEImdmIyv <= jELbhX59K) {
                    int iFIz14cTt = fIz14cTt(j10, jELbhX59K, jEImdmIyv);
                    if (iFIz14cTt == 1) {
                        continue;
                    } else {
                        if (iFIz14cTt == 2) {
                            return false;
                        }
                        if (iFIz14cTt == 3) {
                            sVizei(j10, objArr, jELbhX59K, obj, null);
                            return true;
                        }
                    }
                }
                if (q1ORKN(jELbhX59K, 2 + jELbhX59K)) {
                    Na.N1vNRFSd.osx7Pl0E(objArr, Bv3FS.aXYSYCVY(jELbhX59K, j10), obj);
                    return true;
                }
            }
        }
    }

    public Object peek() {
        Object[] objArr = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        long jAXYSYCVY = Bv3FS.aXYSYCVY(jMTWLV, j10);
        Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
        if (objIvfTYNl == null) {
            if ((jMTWLV - eLbhX59K()) / 2 == 0) {
                return null;
            }
            do {
                objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
            } while (objIvfTYNl == null);
        }
        return objIvfTYNl == zigsCJW ? myMyVU(aNB31q(objArr, j10), jMTWLV) : objIvfTYNl;
    }

    public Object poll() {
        Object[] objArr = this.xINpNt2d;
        long jMTWLV = mTWLV();
        long j10 = this.zYD7SXW6;
        long jAXYSYCVY = Bv3FS.aXYSYCVY(jMTWLV, j10);
        Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
        if (objIvfTYNl == null) {
            if ((jMTWLV - eLbhX59K()) / 2 == 0) {
                return null;
            }
            do {
                objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
            } while (objIvfTYNl == null);
        }
        if (objIvfTYNl == zigsCJW) {
            return sgXstV(aNB31q(objArr, j10), jMTWLV);
        }
        Na.N1vNRFSd.osx7Pl0E(objArr, jAXYSYCVY, null);
        sMxPLer(jMTWLV + 2);
        return objIvfTYNl;
    }

    public int qLLw0g(VVpVRy.MY3jR mY3jR, int i10) {
        return SFMiYa.eszJ2B0a(this, mY3jR, i10);
    }

    public final void sVizei(long j10, Object[] objArr, long j11, Object obj, VVpVRy.AAnYcst aAnYcst) {
        int iD3penA = d3penA(objArr);
        try {
            Object[] objArrEszJ2B0a = Na.N1vNRFSd.eszJ2B0a(iD3penA);
            this.dNE3s = objArrEszJ2B0a;
            long j12 = (iD3penA - 2) << 1;
            this.pz7TsV = j12;
            long jAXYSYCVY = Bv3FS.aXYSYCVY(j11, j10);
            long jAXYSYCVY2 = Bv3FS.aXYSYCVY(j11, j12);
            if (obj == null) {
                obj = aAnYcst.get();
            }
            Na.N1vNRFSd.osx7Pl0E(objArrEszJ2B0a, jAXYSYCVY2, obj);
            Na.N1vNRFSd.osx7Pl0E(objArr, ydGaB1bU(j10), objArrEszJ2B0a);
            long jEgsKh = egsKh(j11, dUI84());
            Na.AAnYcst.eLbhX59K(jEgsKh, "availableInQueue");
            nyeBEo(Math.min(j12, jEgsKh) + j11);
            yxejkub(j11 + 2);
            Na.N1vNRFSd.osx7Pl0E(objArr, jAXYSYCVY, zigsCJW);
        } catch (OutOfMemoryError e10) {
            yxejkub(j11);
            throw e10;
        }
    }

    public final Object sgXstV(Object[] objArr, long j10) {
        long jAXYSYCVY = Bv3FS.aXYSYCVY(j10, this.zYD7SXW6);
        Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(objArr, jAXYSYCVY);
        if (objIvfTYNl == null) {
            throw new IllegalStateException("new buffer must have at least one element");
        }
        Na.N1vNRFSd.osx7Pl0E(objArr, jAXYSYCVY, null);
        sMxPLer(j10 + 2);
        return objIvfTYNl;
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public int size() {
        return Lx1jI.eLbhX59K(this, 2);
    }

    @Override // java.util.AbstractCollection
    public String toString() {
        return getClass().getName();
    }
}
