package Ja;

import java.util.AbstractQueue;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class LNd998w extends AbstractQueue implements Lx1jI.MY3jR {
}
