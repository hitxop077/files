package Ja;

import java.util.AbstractQueue;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class HicDZW extends AbstractQueue {
}
