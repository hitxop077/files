package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class XbU7b extends RFQ3AA8 {
}
