package Ja;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class GU39Hcg extends HicDZW implements VVpVRy, Lx1jI.MY3jR {
    public final long njNibPNp;
    public final Object[] vo5p9AUA;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR implements Iterator {
        public final Object[] gmzPK;
        public final long njNibPNp;
        public final long vo5p9AUA;
        public Object xINpNt2d = eszJ2B0a();
        public long zYD7SXW6;

        public MY3jR(long j10, long j11, long j12, Object[] objArr) {
            this.zYD7SXW6 = j10;
            this.njNibPNp = j11;
            this.vo5p9AUA = j12;
            this.gmzPK = objArr;
        }

        public final Object eszJ2B0a() {
            Object objIvfTYNl;
            do {
                long j10 = this.zYD7SXW6;
                if (j10 >= this.njNibPNp) {
                    return null;
                }
                this.zYD7SXW6 = 1 + j10;
                objIvfTYNl = Na.N1vNRFSd.ivfTYNl(this.gmzPK, Na.N1vNRFSd.aXYSYCVY(j10, this.vo5p9AUA));
            } while (objIvfTYNl == null);
            return objIvfTYNl;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.xINpNt2d != null;
        }

        @Override // java.util.Iterator
        public Object next() {
            Object obj = this.xINpNt2d;
            if (obj == null) {
                throw new NoSuchElementException();
            }
            this.xINpNt2d = eszJ2B0a();
            return obj;
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("remove");
        }
    }

    public GU39Hcg(int i10) {
        int iELbhX59K = Na.MY3jR.eLbhX59K(i10);
        this.njNibPNp = iELbhX59K - 1;
        this.vo5p9AUA = Na.N1vNRFSd.eszJ2B0a(iELbhX59K);
    }

    @Override // java.util.AbstractQueue, java.util.AbstractCollection, java.util.Collection, Ja.VVpVRy
    public void clear() {
        while (poll() != null) {
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public boolean isEmpty() {
        return Lx1jI.eszJ2B0a(this);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public Iterator iterator() {
        return new MY3jR(dUI84(), eLbhX59K(), this.njNibPNp, this.vo5p9AUA);
    }

    @Override // java.util.AbstractCollection, java.util.Collection
    public int size() {
        return Lx1jI.eLbhX59K(this, 1);
    }

    @Override // java.util.AbstractCollection
    public String toString() {
        return getClass().getName();
    }

    @Override // Ja.Lx1jI.MY3jR
    public int zDWsfFRp() {
        return (int) (this.njNibPNp + 1);
    }
}
