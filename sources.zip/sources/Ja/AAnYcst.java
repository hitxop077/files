package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class AAnYcst extends XbU7b {
    public static final long i2VlO = Na.RFQ3AA8.eszJ2B0a(AAnYcst.class, "producerLimit");
    public Object[] dNE3s;
    public long pz7TsV;
    public volatile long vskcqLTQ;

    public final boolean c1pvtY(long j10, long j11) {
        return Na.RFQ3AA8.eLbhX59K.compareAndSwapLong(this, i2VlO, j10, j11);
    }

    public final long eImdmIyv() {
        return this.vskcqLTQ;
    }

    public final void nyeBEo(long j10) {
        Na.RFQ3AA8.eLbhX59K.putOrderedLong(this, i2VlO, j10);
    }
}
