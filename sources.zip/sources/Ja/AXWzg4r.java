package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class AXWzg4r extends Gyx10a {
    public static final long xINpNt2d = Na.RFQ3AA8.eszJ2B0a(AXWzg4r.class, "producerIndex");
    public volatile long zYD7SXW6;

    public AXWzg4r(int i10) {
        super(i10);
    }

    @Override // Ja.Lx1jI.MY3jR
    public final long eLbhX59K() {
        return this.zYD7SXW6;
    }

    public final boolean q1ORKN(long j10, long j11) {
        return Na.RFQ3AA8.eLbhX59K.compareAndSwapLong(this, xINpNt2d, j10, j11);
    }
}
