package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class O5Z56VT6 extends VI3TfJlk {
    public O5Z56VT6(int i10) {
        super(i10);
    }
}
