package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class VI3TfJlk extends NUIvmoc {
    public static final long vskcqLTQ = Na.RFQ3AA8.eszJ2B0a(VI3TfJlk.class, "consumerIndex");
    public volatile long fdmP9GD;

    public VI3TfJlk(int i10) {
        super(i10);
    }

    @Override // Ja.Lx1jI.MY3jR
    public final long dUI84() {
        return this.fdmP9GD;
    }

    public final boolean yxejkub(long j10, long j11) {
        return Na.RFQ3AA8.eLbhX59K.compareAndSwapLong(this, vskcqLTQ, j10, j11);
    }
}
