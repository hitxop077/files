package Ja;

import java.util.Iterator;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public class XR9Xco extends MY3jR {
    public XR9Xco(int i10) {
        super(i10);
    }

    @Override // Ja.MY3jR, Ja.VVpVRy
    public /* bridge */ /* synthetic */ Object aXYSYCVY() {
        return super.aXYSYCVY();
    }

    @Override // Ja.MY3jR
    public int d3penA(Object[] objArr) {
        return Bv3FS.eszJ2B0a(objArr);
    }

    @Override // Ja.MY3jR
    public long egsKh(long j10, long j11) {
        return 2147483647L;
    }

    @Override // Ja.MY3jR, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ boolean isEmpty() {
        return super.isEmpty();
    }

    @Override // Ja.MY3jR, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
    public /* bridge */ /* synthetic */ Iterator iterator() {
        return super.iterator();
    }

    @Override // Ja.MY3jR, Ja.VVpVRy
    public /* bridge */ /* synthetic */ boolean ivfTYNl(Object obj) {
        return super.ivfTYNl(obj);
    }

    @Override // Ja.MY3jR, java.util.Queue
    public /* bridge */ /* synthetic */ boolean offer(Object obj) {
        return super.offer(obj);
    }

    @Override // Ja.MY3jR, java.util.Queue
    public /* bridge */ /* synthetic */ Object peek() {
        return super.peek();
    }

    @Override // Ja.MY3jR, java.util.Queue, Ja.VVpVRy
    public /* bridge */ /* synthetic */ Object poll() {
        return super.poll();
    }

    @Override // Ja.MY3jR, Ja.VVpVRy
    public /* bridge */ /* synthetic */ int qLLw0g(VVpVRy.MY3jR mY3jR, int i10) {
        return super.qLLw0g(mY3jR, i10);
    }

    @Override // Ja.MY3jR, java.util.AbstractCollection, java.util.Collection
    public /* bridge */ /* synthetic */ int size() {
        return super.size();
    }

    @Override // Ja.MY3jR, java.util.AbstractCollection
    public /* bridge */ /* synthetic */ String toString() {
        return super.toString();
    }

    @Override // Ja.Lx1jI.MY3jR
    public int zDWsfFRp() {
        return -1;
    }

    @Override // Ja.MY3jR
    public long ceTXybVl(long j10) {
        return j10;
    }
}
