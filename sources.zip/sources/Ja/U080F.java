package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public class U080F extends O5Z56VT6 {
    public static final int dNE3s = Integer.getInteger("jctools.mpmc.max.lookahead.step", 4096).intValue();
    public final int pz7TsV;

    public U080F(int i10) {
        super(Na.AAnYcst.eszJ2B0a(i10, 2, "capacity"));
        this.pz7TsV = Math.max(2, Math.min(zDWsfFRp() / 4, dNE3s));
    }

    @Override // Ja.VVpVRy
    public Object aXYSYCVY() {
        long[] jArr = this.gmzPK;
        long j10 = this.njNibPNp;
        while (true) {
            long jDUI84 = dUI84();
            long jAXYSYCVY = Na.LNd998w.aXYSYCVY(jDUI84, j10);
            long jELbhX59K = Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY);
            long j11 = jDUI84 + 1;
            if (jELbhX59K < j11) {
                return null;
            }
            if (jELbhX59K <= j11 && yxejkub(jDUI84, j11)) {
                long jAXYSYCVY2 = Na.N1vNRFSd.aXYSYCVY(jDUI84, j10);
                Object objZDWsfFRp = Na.N1vNRFSd.zDWsfFRp(this.vo5p9AUA, jAXYSYCVY2);
                Na.N1vNRFSd.dUI84(this.vo5p9AUA, jAXYSYCVY2, null);
                Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, jDUI84 + j10 + 1);
                return objZDWsfFRp;
            }
        }
    }

    @Override // Ja.VVpVRy
    public boolean ivfTYNl(Object obj) {
        if (obj == null) {
            throw null;
        }
        long j10 = this.njNibPNp;
        long[] jArr = this.gmzPK;
        while (true) {
            long jELbhX59K = eLbhX59K();
            long jAXYSYCVY = Na.LNd998w.aXYSYCVY(jELbhX59K, j10);
            long jELbhX59K2 = Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY);
            if (jELbhX59K2 < jELbhX59K) {
                return false;
            }
            if (jELbhX59K2 <= jELbhX59K) {
                long j11 = 1 + jELbhX59K;
                if (q1ORKN(jELbhX59K, j11)) {
                    Na.N1vNRFSd.dUI84(this.vo5p9AUA, Na.N1vNRFSd.aXYSYCVY(jELbhX59K, j10), obj);
                    Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, j11);
                    return true;
                }
            }
        }
    }

    public final int mTWLV(VVpVRy.MY3jR mY3jR, int i10) {
        long jDUI84;
        long jAXYSYCVY;
        long[] jArr = this.gmzPK;
        long j10 = this.njNibPNp;
        Object[] objArr = this.vo5p9AUA;
        for (int i11 = 0; i11 < i10; i11++) {
            while (true) {
                jDUI84 = dUI84();
                jAXYSYCVY = Na.LNd998w.aXYSYCVY(jDUI84, j10);
                long jELbhX59K = Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY);
                long j11 = jDUI84 + 1;
                if (jELbhX59K < j11) {
                    return i11;
                }
                if (jELbhX59K > j11 || !yxejkub(jDUI84, j11)) {
                }
            }
            long jAXYSYCVY2 = Na.N1vNRFSd.aXYSYCVY(jDUI84, j10);
            Object objZDWsfFRp = Na.N1vNRFSd.zDWsfFRp(objArr, jAXYSYCVY2);
            Na.N1vNRFSd.dUI84(objArr, jAXYSYCVY2, null);
            Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, jDUI84 + j10 + 1);
            mY3jR.accept(objZDWsfFRp);
        }
        return i10;
    }

    @Override // java.util.Queue
    public boolean offer(Object obj) {
        long j10;
        if (obj == null) {
            throw null;
        }
        long j11 = this.njNibPNp;
        long j12 = 1;
        long j13 = j11 + 1;
        long[] jArr = this.gmzPK;
        long jDUI84 = Long.MIN_VALUE;
        while (true) {
            long jELbhX59K = eLbhX59K();
            long jAXYSYCVY = Na.LNd998w.aXYSYCVY(jELbhX59K, j11);
            long jELbhX59K2 = Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY);
            if (jELbhX59K2 < jELbhX59K) {
                long j14 = jELbhX59K - j13;
                if (j14 >= jDUI84) {
                    jDUI84 = dUI84();
                    if (j14 >= jDUI84) {
                        return false;
                    }
                }
                jELbhX59K2 = jELbhX59K + j12;
            }
            if (jELbhX59K2 <= jELbhX59K) {
                j10 = j12;
                long j15 = jELbhX59K + j10;
                if (q1ORKN(jELbhX59K, j15)) {
                    Na.N1vNRFSd.dUI84(this.vo5p9AUA, Na.N1vNRFSd.aXYSYCVY(jELbhX59K, j11), obj);
                    Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, j15);
                    return true;
                }
            } else {
                j10 = j12;
            }
            j12 = j10;
        }
    }

    @Override // java.util.Queue
    public Object peek() {
        long[] jArr = this.gmzPK;
        long j10 = this.njNibPNp;
        long jELbhX59K = -1;
        while (true) {
            long jDUI84 = dUI84();
            long jELbhX59K2 = Na.LNd998w.eLbhX59K(jArr, Na.LNd998w.aXYSYCVY(jDUI84, j10));
            long j11 = 1 + jDUI84;
            if (jELbhX59K2 < j11) {
                if (jDUI84 >= jELbhX59K) {
                    jELbhX59K = eLbhX59K();
                    if (jDUI84 == jELbhX59K) {
                        return null;
                    }
                } else {
                    continue;
                }
            } else if (jELbhX59K2 == j11) {
                Object objIvfTYNl = Na.N1vNRFSd.ivfTYNl(this.vo5p9AUA, Na.N1vNRFSd.aXYSYCVY(jDUI84, j10));
                if (dUI84() == jDUI84) {
                    return objIvfTYNl;
                }
            } else {
                continue;
            }
        }
    }

    @Override // java.util.Queue, Ja.VVpVRy
    public Object poll() {
        long[] jArr = this.gmzPK;
        long j10 = this.njNibPNp;
        long jELbhX59K = -1;
        while (true) {
            long jDUI84 = dUI84();
            long jAXYSYCVY = Na.LNd998w.aXYSYCVY(jDUI84, j10);
            long jELbhX59K2 = Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY);
            long j11 = jDUI84 + 1;
            if (jELbhX59K2 < j11) {
                if (jDUI84 >= jELbhX59K) {
                    jELbhX59K = eLbhX59K();
                    if (jDUI84 == jELbhX59K) {
                        return null;
                    }
                }
                jELbhX59K2 = 2 + jDUI84;
            }
            if (jELbhX59K2 <= j11 && yxejkub(jDUI84, j11)) {
                long jAXYSYCVY2 = Na.N1vNRFSd.aXYSYCVY(jDUI84, j10);
                Object objZDWsfFRp = Na.N1vNRFSd.zDWsfFRp(this.vo5p9AUA, jAXYSYCVY2);
                Na.N1vNRFSd.dUI84(this.vo5p9AUA, jAXYSYCVY2, null);
                Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, jDUI84 + j10 + 1);
                return objZDWsfFRp;
            }
        }
    }

    @Override // Ja.VVpVRy
    public int qLLw0g(VVpVRy.MY3jR mY3jR, int i10) {
        U080F u080f;
        U080F u080f2 = this;
        int i11 = i10;
        if (mY3jR == null) {
            throw new IllegalArgumentException("c is null");
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("limit is negative: " + i11);
        }
        boolean z10 = false;
        if (i11 == 0) {
            return 0;
        }
        long[] jArr = u080f2.gmzPK;
        long j10 = u080f2.njNibPNp;
        Object[] objArr = u080f2.vo5p9AUA;
        int iMin = Math.min(u080f2.pz7TsV, i11);
        int i12 = 0;
        while (i12 < i11) {
            int i13 = i11 - i12;
            int iMin2 = Math.min(i13, iMin);
            int i14 = i11;
            long jDUI84 = u080f2.dUI84();
            long j11 = ((long) iMin2) + jDUI84;
            long jELbhX59K = Na.LNd998w.eLbhX59K(jArr, Na.LNd998w.aXYSYCVY(j11 - 1, j10));
            if (jELbhX59K != j11 || !u080f2.yxejkub(jDUI84, j11)) {
                long j12 = j10;
                int i15 = i12;
                if (jELbhX59K < j11) {
                    u080f = this;
                    if (u080f.sMxPLer(jDUI84, j12, jArr, jDUI84 + 1)) {
                        return i15;
                    }
                } else {
                    u080f = this;
                }
                return i15 + u080f.mTWLV(mY3jR, i13);
            }
            int i16 = 0;
            while (i16 < iMin2) {
                long j13 = ((long) i16) + jDUI84;
                long j14 = jDUI84;
                long jAXYSYCVY = Na.LNd998w.aXYSYCVY(j13, j10);
                int i17 = i12;
                int i18 = i16;
                long jAXYSYCVY2 = Na.N1vNRFSd.aXYSYCVY(j13, j10);
                while (Na.LNd998w.eLbhX59K(jArr, jAXYSYCVY) != j13 + 1) {
                }
                Object objZDWsfFRp = Na.N1vNRFSd.zDWsfFRp(objArr, jAXYSYCVY2);
                long j15 = j10;
                Na.N1vNRFSd.dUI84(objArr, jAXYSYCVY2, null);
                Na.LNd998w.zDWsfFRp(jArr, jAXYSYCVY, j13 + j15 + 1);
                mY3jR.accept(objZDWsfFRp);
                i16 = i18 + 1;
                i12 = i17;
                jDUI84 = j14;
                j10 = j15;
            }
            i12 += iMin2;
            u080f2 = this;
            i11 = i14;
            j10 = j10;
            z10 = false;
        }
        return i11;
    }

    public final boolean sMxPLer(long j10, long j11, long[] jArr, long j12) {
        return Na.LNd998w.eLbhX59K(jArr, Na.LNd998w.aXYSYCVY(j10, j11)) < j12;
    }
}
