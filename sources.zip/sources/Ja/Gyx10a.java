package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Gyx10a extends JQAVH {
    public Gyx10a(int i10) {
        super(i10);
    }
}
