package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class Bv3FS {
    public static long aXYSYCVY(long j10, long j11) {
        return Na.N1vNRFSd.eszJ2B0a + ((j10 & j11) << (Na.N1vNRFSd.aXYSYCVY - 1));
    }

    public static int eszJ2B0a(Object[] objArr) {
        return objArr.length;
    }
}
