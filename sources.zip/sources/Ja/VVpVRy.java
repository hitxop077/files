package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public interface VVpVRy {

    /* JADX INFO: compiled from: Obfuscated */
    public interface AAnYcst {
        Object get();
    }

    /* JADX INFO: compiled from: Obfuscated */
    public interface MY3jR {
        void accept(Object obj);
    }

    Object aXYSYCVY();

    void clear();

    boolean ivfTYNl(Object obj);

    Object poll();

    int qLLw0g(MY3jR mY3jR, int i10);
}
