package Ja;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class NUIvmoc extends AXWzg4r {
    public NUIvmoc(int i10) {
        super(i10);
    }
}
