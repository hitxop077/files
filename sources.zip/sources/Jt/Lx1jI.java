package Jt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface Lx1jI {
    Long aXYSYCVY();

    Long eLbhX59K();

    void eszJ2B0a(int i10);

    void zDWsfFRp(int i10);
}
