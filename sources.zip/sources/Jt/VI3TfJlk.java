package Jt;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import javax.net.SocketFactory;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public class VI3TfJlk implements Bv3FS {
    public static final String dUI84 = "Jt.VI3TfJlk";
    public Socket aXYSYCVY;
    public SocketFactory eLbhX59K;
    public Kt.MY3jR eszJ2B0a;
    public int ivfTYNl;
    public int osx7Pl0E;
    public String zDWsfFRp;

    public VI3TfJlk(SocketFactory socketFactory, String str, int i10, String str2) {
        Kt.MY3jR mY3jREszJ2B0a = Kt.AAnYcst.eszJ2B0a("org.eclipse.paho.mqttv5.client.internal.nls.logcat", dUI84);
        this.eszJ2B0a = mY3jREszJ2B0a;
        mY3jREszJ2B0a.setResourceName(str2);
        this.eLbhX59K = socketFactory;
        this.zDWsfFRp = str;
        this.ivfTYNl = i10;
    }

    @Override // Jt.Bv3FS
    public String aXYSYCVY() {
        return "tcp://" + this.zDWsfFRp + p497q7.SFMiYa.COLON + this.ivfTYNl;
    }

    @Override // Jt.Bv3FS
    public InputStream eLbhX59K() {
        return this.aXYSYCVY.getInputStream();
    }

    @Override // Jt.Bv3FS
    public OutputStream eszJ2B0a() {
        return this.aXYSYCVY.getOutputStream();
    }

    @Override // Jt.Bv3FS
    public void start() throws IOException, Rt.AAnYcst {
        try {
            this.eszJ2B0a.fine(dUI84, "start", "252", new Object[]{this.zDWsfFRp, Integer.valueOf(this.ivfTYNl), Long.valueOf(this.osx7Pl0E * 1000)});
            InetSocketAddress inetSocketAddress = new InetSocketAddress(this.zDWsfFRp, this.ivfTYNl);
            Socket socketCreateSocket = this.eLbhX59K.createSocket();
            this.aXYSYCVY = socketCreateSocket;
            socketCreateSocket.connect(inetSocketAddress, this.osx7Pl0E * 1000);
            this.aXYSYCVY.setSoTimeout(1000);
        } catch (ConnectException e10) {
            this.eszJ2B0a.fine(dUI84, "start", "250", null, e10);
            throw new Rt.AAnYcst(32103, e10);
        }
    }

    @Override // Jt.Bv3FS
    public void stop() throws IOException {
        Socket socket = this.aXYSYCVY;
        if (socket != null) {
            socket.shutdownInput();
            this.aXYSYCVY.close();
        }
    }

    public void zDWsfFRp(int i10) {
        this.osx7Pl0E = i10;
    }
}
