package Jt;

import java.io.InputStream;
import java.io.OutputStream;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface Bv3FS {
    String aXYSYCVY();

    InputStream eLbhX59K();

    OutputStream eszJ2B0a();

    void start();

    void stop();
}
