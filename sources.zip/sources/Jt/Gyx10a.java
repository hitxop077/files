package Jt;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public class Gyx10a implements Nt.MY3jR {
    @Override // Nt.MY3jR
    public Set aXYSYCVY() {
        return Collections.unmodifiableSet(new HashSet(Arrays.asList("tcp")));
    }

    @Override // Nt.MY3jR
    public Bv3FS eLbhX59K(URI uri, It.HicDZW hicDZW, String str) throws Rt.AAnYcst {
        String host = uri.getHost();
        int port = uri.getPort();
        if (port == -1) {
            port = 1883;
        }
        String path = uri.getPath();
        if (path != null && !path.isEmpty()) {
            throw new IllegalArgumentException(uri.toString());
        }
        SocketFactory socketFactoryUTIfLNK0 = hicDZW.uTIfLNK0();
        if (socketFactoryUTIfLNK0 == null) {
            socketFactoryUTIfLNK0 = SocketFactory.getDefault();
        } else if (socketFactoryUTIfLNK0 instanceof SSLSocketFactory) {
            throw GU39Hcg.eszJ2B0a(32105);
        }
        VI3TfJlk vI3TfJlk = new VI3TfJlk(socketFactoryUTIfLNK0, host, port, str);
        vI3TfJlk.zDWsfFRp(hicDZW.aXYSYCVY());
        return vI3TfJlk;
    }

    @Override // Nt.MY3jR
    public void eszJ2B0a(URI uri) {
        String path = uri.getPath();
        if (path == null || path.isEmpty()) {
            return;
        }
        throw new IllegalArgumentException("URI path must be empty \"" + uri.toString() + "\"");
    }
}
