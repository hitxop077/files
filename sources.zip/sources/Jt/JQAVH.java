package Jt;

import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public class JQAVH {
    public String aXYSYCVY;
    public AtomicInteger eszJ2B0a = new AtomicInteger(1);

    public String aXYSYCVY() {
        return this.aXYSYCVY;
    }

    public void eLbhX59K(String str) {
        this.aXYSYCVY = str;
    }

    public void eszJ2B0a() {
        this.eszJ2B0a.set(1);
    }
}
