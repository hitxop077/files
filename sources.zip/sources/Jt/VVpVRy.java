package Jt;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ServiceLoader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public abstract class VVpVRy {
    public static Kt.MY3jR eszJ2B0a = Kt.AAnYcst.eszJ2B0a("org.eclipse.paho.mqttv5.client.internal.nls.logcat", VVpVRy.class.getSimpleName());
    public static final ServiceLoader aXYSYCVY = ServiceLoader.load(Nt.MY3jR.class, VVpVRy.class.getClassLoader());
    public static final Pattern eLbhX59K = Pattern.compile("((.+)@)?([^:]*)(:(\\d+))?");

    public static Bv3FS aXYSYCVY(String str, It.HicDZW hicDZW, String str2) {
        try {
            URI uri = new URI(str);
            eszJ2B0a(uri);
            String lowerCase = uri.getScheme().toLowerCase();
            ServiceLoader<Nt.MY3jR> serviceLoader = aXYSYCVY;
            synchronized (serviceLoader) {
                try {
                    for (Nt.MY3jR mY3jR : serviceLoader) {
                        if (mY3jR.aXYSYCVY().contains(lowerCase)) {
                            return mY3jR.eLbhX59K(uri, hicDZW, str2);
                        }
                    }
                    throw new IllegalArgumentException(uri.toString());
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        } catch (URISyntaxException e10) {
            throw new IllegalArgumentException(str, e10);
        }
    }

    public static void eLbhX59K(URI uri, String str, Object obj) {
        try {
            Field declaredField = URI.class.getDeclaredField(str);
            declaredField.setAccessible(true);
            declaredField.set(uri, obj);
        } catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException | SecurityException e10) {
            eszJ2B0a.warning(VVpVRy.class.getName(), "setURIField", "115", new Object[]{uri.toString()}, e10);
        }
    }

    public static void eszJ2B0a(URI uri) {
        if (uri == null || uri.getHost() != null || uri.getAuthority() == null || uri.getAuthority().isEmpty()) {
            return;
        }
        Matcher matcher = eLbhX59K.matcher(uri.getAuthority());
        if (matcher.find()) {
            eLbhX59K(uri, "userInfo", matcher.group(2));
            eLbhX59K(uri, "host", matcher.group(3));
            String strGroup = matcher.group(5);
            eLbhX59K(uri, "port", Integer.valueOf(strGroup != null ? Integer.parseInt(strGroup) : -1));
        }
    }

    public static void zDWsfFRp(String str) {
        try {
            URI uri = new URI(str);
            String scheme = uri.getScheme();
            if (scheme == null || scheme.isEmpty()) {
                throw new IllegalArgumentException("missing scheme in broker URI: " + str);
            }
            String lowerCase = scheme.toLowerCase();
            ServiceLoader<Nt.MY3jR> serviceLoader = aXYSYCVY;
            synchronized (serviceLoader) {
                try {
                    for (Nt.MY3jR mY3jR : serviceLoader) {
                        if (mY3jR.aXYSYCVY().contains(lowerCase)) {
                            mY3jR.eszJ2B0a(uri);
                            return;
                        }
                    }
                    throw new IllegalArgumentException("no NetworkModule installed for scheme \"" + lowerCase + "\" of URI \"" + str + "\"");
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        } catch (URISyntaxException e10) {
            throw new IllegalArgumentException("Can't parse string to URI \"" + str + "\"", e10);
        }
    }
}
