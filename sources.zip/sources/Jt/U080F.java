package Jt;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public class U080F implements Nt.MY3jR {
    @Override // Nt.MY3jR
    public Set aXYSYCVY() {
        return Collections.unmodifiableSet(new HashSet(Arrays.asList("ssl")));
    }

    @Override // Nt.MY3jR
    public Bv3FS eLbhX59K(URI uri, It.HicDZW hicDZW, String str) throws Rt.AAnYcst {
        Mt.MY3jR mY3jR;
        String[] strArrIvfTYNl;
        String host = uri.getHost();
        int port = uri.getPort();
        if (port == -1) {
            port = 8883;
        }
        String path = uri.getPath();
        if (path != null && !path.isEmpty()) {
            throw new IllegalArgumentException(uri.toString());
        }
        SocketFactory socketFactoryUTIfLNK0 = hicDZW.uTIfLNK0();
        if (socketFactoryUTIfLNK0 == null) {
            Mt.MY3jR mY3jR2 = new Mt.MY3jR();
            Properties propertiesQLLw0g = hicDZW.qLLw0g();
            if (propertiesQLLw0g != null) {
                mY3jR2.oyaOvpOs(propertiesQLLw0g, null);
            }
            mY3jR = mY3jR2;
            socketFactoryUTIfLNK0 = mY3jR2.eLbhX59K(null);
        } else {
            if (!(socketFactoryUTIfLNK0 instanceof SSLSocketFactory)) {
                throw GU39Hcg.eszJ2B0a(32105);
            }
            mY3jR = null;
        }
        SFMiYa sFMiYa = new SFMiYa((SSLSocketFactory) socketFactoryUTIfLNK0, host, port, str);
        sFMiYa.oZ7qYn(hicDZW.aXYSYCVY());
        sFMiYa.dUI84(hicDZW.zPJpxWz());
        sFMiYa.osx7Pl0E(hicDZW.n84TFkA9());
        if (mY3jR != null && (strArrIvfTYNl = mY3jR.ivfTYNl(null)) != null) {
            sFMiYa.ivfTYNl(strArrIvfTYNl);
        }
        return sFMiYa;
    }

    @Override // Nt.MY3jR
    public void eszJ2B0a(URI uri) {
        String path = uri.getPath();
        if (path != null && !path.isEmpty()) {
            throw new IllegalArgumentException(uri.toString());
        }
    }
}
