package Jt;

import java.io.IOException;
import java.util.ArrayList;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public class SFMiYa extends VI3TfJlk {
    public static final String yxejkub = "Jt.SFMiYa";
    public Kt.MY3jR oZ7qYn;
    public boolean q1ORKN;
    public HostnameVerifier qLLw0g;
    public String[] rjljd6i;
    public String uTIfLNK0;
    public int uYRSwDm;
    public int zPJpxWz;

    public SFMiYa(SSLSocketFactory sSLSocketFactory, String str, int i10, String str2) {
        super(sSLSocketFactory, str, i10, str2);
        Kt.MY3jR mY3jREszJ2B0a = Kt.AAnYcst.eszJ2B0a("org.eclipse.paho.mqttv5.client.internal.nls.logcat", yxejkub);
        this.oZ7qYn = mY3jREszJ2B0a;
        this.q1ORKN = true;
        this.uTIfLNK0 = str;
        this.uYRSwDm = i10;
        mY3jREszJ2B0a.setResourceName(str2);
    }

    @Override // Jt.VI3TfJlk, Jt.Bv3FS
    public String aXYSYCVY() {
        return "ssl://" + this.uTIfLNK0 + p497q7.SFMiYa.COLON + this.uYRSwDm;
    }

    public void dUI84(HostnameVerifier hostnameVerifier) {
        this.qLLw0g = hostnameVerifier;
    }

    public void ivfTYNl(String[] strArr) {
        this.rjljd6i = strArr;
        if (this.aXYSYCVY == null || strArr == null) {
            return;
        }
        if (this.oZ7qYn.isLoggable(5)) {
            String str = "";
            for (int i10 = 0; i10 < strArr.length; i10++) {
                if (i10 > 0) {
                    str = String.valueOf(str) + ",";
                }
                str = String.valueOf(str) + strArr[i10];
            }
            this.oZ7qYn.fine(yxejkub, "setEnabledCiphers", "260", new Object[]{str});
        }
        ((SSLSocket) this.aXYSYCVY).setEnabledCipherSuites(strArr);
    }

    public void oZ7qYn(int i10) {
        super.zDWsfFRp(i10);
        this.zPJpxWz = i10;
    }

    public void osx7Pl0E(boolean z10) {
        this.q1ORKN = z10;
    }

    @Override // Jt.VI3TfJlk, Jt.Bv3FS
    public void start() throws IOException, Rt.AAnYcst {
        super.start();
        ivfTYNl(this.rjljd6i);
        int soTimeout = this.aXYSYCVY.getSoTimeout();
        this.aXYSYCVY.setSoTimeout(this.zPJpxWz * 1000);
        SSLParameters sSLParameters = new SSLParameters();
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(new SNIHostName(this.uTIfLNK0));
        sSLParameters.setServerNames(arrayList);
        ((SSLSocket) this.aXYSYCVY).setSSLParameters(sSLParameters);
        if (this.q1ORKN) {
            SSLParameters sSLParameters2 = new SSLParameters();
            sSLParameters2.setEndpointIdentificationAlgorithm("HTTPS");
            ((SSLSocket) this.aXYSYCVY).setSSLParameters(sSLParameters2);
        }
        ((SSLSocket) this.aXYSYCVY).startHandshake();
        if (this.qLLw0g != null) {
            SSLSession session = ((SSLSocket) this.aXYSYCVY).getSession();
            if (!this.qLLw0g.verify(this.uTIfLNK0, session)) {
                session.invalidate();
                this.aXYSYCVY.close();
                throw new SSLPeerUnverifiedException("Host: " + this.uTIfLNK0 + ", Peer Host: " + session.getPeerHost());
            }
        }
        this.aXYSYCVY.setSoTimeout(soTimeout);
    }
}
