package Jt;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public abstract class GU39Hcg {
    public static Rt.AAnYcst aXYSYCVY(Throwable th2) {
        return th2.getClass().getName().equals("java.security.GeneralSecurityException") ? new Rt.XbU7b(th2) : new Rt.AAnYcst(th2);
    }

    public static Rt.AAnYcst eszJ2B0a(int i10) {
        return (i10 == 4 || i10 == 5) ? new Rt.XbU7b(i10) : new Rt.AAnYcst(i10);
    }
}
