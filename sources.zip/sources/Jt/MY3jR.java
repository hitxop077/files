package Jt;

import St.JmXmcSi;
import java.util.Enumeration;
import java.util.concurrent.ExecutorService;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public class MY3jR {
    public static final String oyaOvpOs = "Jt.MY3jR";
    public It.W7Cnq5 aXYSYCVY;
    public RFQ3AA8 dUI84;
    public int eLbhX59K;
    public LNd998w ivfTYNl;
    public ExecutorService jAM6dcNA;
    public Jt.AAnYcst oZ7qYn;
    public N1vNRFSd osx7Pl0E;
    public XbU7b q1ORKN;
    public It.Lx1jI qLLw0g;
    public It.HicDZW rjljd6i;
    public HicDZW rtsRj;
    public Bv3FS[] zDWsfFRp;
    public It.GU39Hcg zPJpxWz;
    public Kt.MY3jR eszJ2B0a = Kt.AAnYcst.eszJ2B0a("org.eclipse.paho.mqttv5.client.internal.nls.logcat", oyaOvpOs);
    public boolean uTIfLNK0 = false;
    public final Object yxejkub = new Object();
    public boolean mTWLV = false;
    public boolean rJCQt16 = false;
    public byte uYRSwDm = 3;

    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes5.dex */
    public class AAnYcst implements Runnable {
        public It.Bv3FS gmzPK;
        public St.XbU7b njNibPNp;
        public long vo5p9AUA;
        public String zYD7SXW6;

        public AAnYcst(St.XbU7b xbU7b, long j10, It.Bv3FS bv3FS, ExecutorService executorService) {
            this.njNibPNp = xbU7b;
            this.vo5p9AUA = j10;
            this.gmzPK = bv3FS;
        }

        public void eszJ2B0a() {
            this.zYD7SXW6 = "MQTT Disc: " + MY3jR.this.rtsRj().getClientId();
            if (MY3jR.this.jAM6dcNA == null) {
                new Thread(this).start();
            } else {
                MY3jR.this.jAM6dcNA.execute(this);
            }
        }

        /* JADX WARN: Code duplicated, block: B:15:0x0068 A[DONT_GENERATE] */
        /* JADX WARN: Code duplicated, block: B:29:0x00bc A[DONT_GENERATE] */
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // java.lang.Runnable
        public void run() {
            Thread.currentThread().setName(this.zYD7SXW6);
            MY3jR.this.eszJ2B0a.fine(MY3jR.oyaOvpOs, "disconnectBG:run", "221");
            MY3jR.this.oZ7qYn.wtGiK9b(this.vo5p9AUA);
            try {
                MY3jR.this.eImdmIyv(this.njNibPNp, this.gmzPK);
                if (MY3jR.this.osx7Pl0E != null && MY3jR.this.osx7Pl0E.aXYSYCVY()) {
                    this.gmzPK.aXYSYCVY.jdF33N();
                }
            } catch (Rt.AAnYcst unused) {
            } finally {
                this.gmzPK.aXYSYCVY.uYRSwDm(null, null);
                if (MY3jR.this.osx7Pl0E == null || !MY3jR.this.osx7Pl0E.aXYSYCVY()) {
                    this.gmzPK.aXYSYCVY.yxejkub();
                }
                MY3jR.this.sgXstV(this.gmzPK, null, null);
            }
        }
    }

    /* JADX INFO: renamed from: Jt.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    /* JADX INFO: loaded from: classes5.dex */
    public class RunnableC0101MY3jR implements Runnable {
        public St.LNd998w gmzPK;
        public MY3jR njNibPNp;
        public It.Bv3FS vo5p9AUA;
        public String zYD7SXW6;

        public RunnableC0101MY3jR(MY3jR mY3jR, It.Bv3FS bv3FS, St.LNd998w lNd998w, ExecutorService executorService) {
            this.njNibPNp = mY3jR;
            this.vo5p9AUA = bv3FS;
            this.gmzPK = lNd998w;
            this.zYD7SXW6 = "MQTT Con: " + MY3jR.this.rtsRj().getClientId();
        }

        public void eszJ2B0a() {
            if (MY3jR.this.jAM6dcNA == null) {
                new Thread(this).start();
            } else {
                MY3jR.this.jAM6dcNA.execute(this);
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            Rt.AAnYcst aAnYcstAXYSYCVY;
            Thread.currentThread().setName(this.zYD7SXW6);
            MY3jR.this.eszJ2B0a.fine(MY3jR.oyaOvpOs, "connectBG:run", "220");
            try {
                for (It.Bv3FS bv3FS : MY3jR.this.q1ORKN.eLbhX59K()) {
                    bv3FS.aXYSYCVY.oyaOvpOs(null);
                }
                MY3jR.this.q1ORKN.q1ORKN(this.vo5p9AUA, this.gmzPK);
                Bv3FS bv3FS2 = MY3jR.this.zDWsfFRp[MY3jR.this.eLbhX59K];
                bv3FS2.start();
                MY3jR.this.ivfTYNl = new LNd998w(this.njNibPNp, MY3jR.this.oZ7qYn, MY3jR.this.q1ORKN, bv3FS2.eLbhX59K());
                MY3jR.this.ivfTYNl.aXYSYCVY("MQTT Rec: " + MY3jR.this.rtsRj().getClientId(), MY3jR.this.jAM6dcNA);
                MY3jR.this.osx7Pl0E = new N1vNRFSd(this.njNibPNp, MY3jR.this.oZ7qYn, MY3jR.this.q1ORKN, bv3FS2.eszJ2B0a());
                MY3jR.this.osx7Pl0E.eLbhX59K("MQTT Snd: " + MY3jR.this.rtsRj().getClientId(), MY3jR.this.jAM6dcNA);
                MY3jR.this.dUI84.n84TFkA9("MQTT Call: " + MY3jR.this.rtsRj().getClientId(), MY3jR.this.jAM6dcNA);
                MY3jR.this.eImdmIyv(this.gmzPK, this.vo5p9AUA);
                aAnYcstAXYSYCVY = null;
            } catch (Rt.AAnYcst e10) {
                MY3jR.this.eszJ2B0a.fine(MY3jR.oyaOvpOs, "connectBG:run", "212", null, e10);
                aAnYcstAXYSYCVY = e10;
            } catch (Exception e11) {
                MY3jR.this.eszJ2B0a.fine(MY3jR.oyaOvpOs, "connectBG:run", "209", null, e11);
                aAnYcstAXYSYCVY = GU39Hcg.aXYSYCVY(e11);
            }
            if (aAnYcstAXYSYCVY != null) {
                MY3jR.this.sgXstV(this.vo5p9AUA, aAnYcstAXYSYCVY, null);
            }
        }
    }

    public MY3jR(It.W7Cnq5 w7Cnq5, It.GU39Hcg gU39Hcg, It.Lx1jI lx1jI, ExecutorService executorService, JQAVH jqavh, HicDZW hicDZW) {
        this.aXYSYCVY = w7Cnq5;
        this.zPJpxWz = gU39Hcg;
        this.qLLw0g = lx1jI;
        lx1jI.eszJ2B0a(this);
        this.jAM6dcNA = executorService;
        this.rtsRj = hicDZW;
        this.q1ORKN = new XbU7b(rtsRj().getClientId());
        this.dUI84 = new RFQ3AA8(this);
        Jt.AAnYcst aAnYcst = new Jt.AAnYcst(gU39Hcg, this.q1ORKN, this.dUI84, this, lx1jI, this.rtsRj);
        this.oZ7qYn = aAnYcst;
        this.dUI84.rtsRj(aAnYcst);
        this.eszJ2B0a.setResourceName(rtsRj().getClientId());
    }

    public Bv3FS[] bsO5Vo() {
        return this.zDWsfFRp;
    }

    public final void c1pvtY(Exception exc) {
        this.eszJ2B0a.fine(oyaOvpOs, "handleRunException", "804", null, exc);
        sgXstV(null, !(exc instanceof Rt.AAnYcst) ? new Rt.AAnYcst(32109, exc) : (Rt.AAnYcst) exc, null);
    }

    public void ceTXybVl(int i10) {
        this.eLbhX59K = i10;
    }

    public void d3penA(Bv3FS[] bv3FSArr) {
        this.zDWsfFRp = bv3FSArr;
    }

    public void eImdmIyv(JmXmcSi jmXmcSi, It.Bv3FS bv3FS) throws Rt.AAnYcst {
        Kt.MY3jR mY3jR = this.eszJ2B0a;
        String str = oyaOvpOs;
        mY3jR.fine(str, "internalSend", "200", new Object[]{jmXmcSi.q1ORKN(), jmXmcSi, bv3FS});
        if (bv3FS.getClient() != null) {
            this.eszJ2B0a.fine(str, "internalSend", "213", new Object[]{jmXmcSi.q1ORKN(), jmXmcSi, bv3FS});
            throw new Rt.AAnYcst(32201);
        }
        bv3FS.aXYSYCVY.jAM6dcNA(rtsRj());
        try {
            this.oZ7qYn.d3penA(jmXmcSi, bv3FS);
        } catch (Rt.AAnYcst e10) {
            bv3FS.aXYSYCVY.jAM6dcNA(null);
            if (jmXmcSi instanceof St.VI3TfJlk) {
                this.oZ7qYn.myMyVU((St.VI3TfJlk) jmXmcSi);
            }
            throw e10;
        }
    }

    public boolean eTQUrp() {
        boolean z10;
        synchronized (this.yxejkub) {
            z10 = this.uYRSwDm == 0;
        }
        return z10;
    }

    public void egsKh(It.N1vNRFSd n1vNRFSd) {
        this.dUI84.jAM6dcNA(n1vNRFSd);
    }

    public void f4bPf(It.N1vNRFSd n1vNRFSd) {
        this.dUI84.oyaOvpOs(n1vNRFSd);
    }

    public void fk0tr(String str) {
        this.dUI84.mTWLV(str);
    }

    public void jAM6dcNA(St.XbU7b xbU7b, long j10, It.Bv3FS bv3FS) throws Throwable {
        synchronized (this.yxejkub) {
            try {
                try {
                    if (mK94T()) {
                        this.eszJ2B0a.fine(oyaOvpOs, "disconnect", "223");
                        throw GU39Hcg.eszJ2B0a(32111);
                    }
                    if (wtGiK9b()) {
                        this.eszJ2B0a.fine(oyaOvpOs, "disconnect", "211");
                        throw GU39Hcg.eszJ2B0a(32101);
                    }
                    if (jdF33N()) {
                        this.eszJ2B0a.fine(oyaOvpOs, "disconnect", "219");
                        throw GU39Hcg.eszJ2B0a(32102);
                    }
                    if (Thread.currentThread() == this.dUI84.dUI84()) {
                        this.eszJ2B0a.fine(oyaOvpOs, "disconnect", "210");
                        throw GU39Hcg.eszJ2B0a(32107);
                    }
                    this.eszJ2B0a.fine(oyaOvpOs, "disconnect", "218");
                    this.uYRSwDm = (byte) 2;
                    new AAnYcst(xbU7b, j10, bv3FS, this.jAM6dcNA).eszJ2B0a();
                } catch (Throwable th2) {
                    th = th2;
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
            }
        }
    }

    public boolean jdF33N() {
        boolean z10;
        synchronized (this.yxejkub) {
            z10 = this.uYRSwDm == 2;
        }
        return z10;
    }

    public boolean mK94T() {
        boolean z10;
        synchronized (this.yxejkub) {
            z10 = this.uYRSwDm == 4;
        }
        return z10;
    }

    public void mTWLV(It.HicDZW hicDZW, It.Bv3FS bv3FS) throws Throwable {
        Throwable th2;
        synchronized (this.yxejkub) {
            try {
                try {
                    if (!wtGiK9b() || this.mTWLV) {
                        this.eszJ2B0a.fine(oyaOvpOs, "connect", "207", new Object[]{Byte.valueOf(this.uYRSwDm)});
                        if (mK94T() || this.mTWLV) {
                            throw new Rt.AAnYcst(32111);
                        }
                        if (nyeBEo()) {
                            throw new Rt.AAnYcst(32110);
                        }
                        if (!jdF33N()) {
                            throw GU39Hcg.eszJ2B0a(32100);
                        }
                        throw new Rt.AAnYcst(32102);
                    }
                    this.eszJ2B0a.fine(oyaOvpOs, "connect", "214");
                    this.uYRSwDm = (byte) 1;
                    this.rjljd6i = hicDZW;
                    St.LNd998w lNd998w = new St.LNd998w(this.aXYSYCVY.getClientId(), this.rjljd6i.oZ7qYn(), this.rjljd6i.oyaOvpOs(), this.rjljd6i.ivfTYNl(), this.rjljd6i.eszJ2B0a(), this.rjljd6i.jAM6dcNA());
                    if (this.rjljd6i.mTWLV() != null) {
                        try {
                            lNd998w.eTQUrp(this.rjljd6i.mTWLV());
                        } catch (Throwable th3) {
                            th2 = th3;
                        }
                    }
                    if (this.rjljd6i.rJCQt16() != null) {
                        lNd998w.nyeBEo(this.rjljd6i.rJCQt16());
                    }
                    if (this.rjljd6i.yxejkub() != null) {
                        lNd998w.mK94T(this.rjljd6i.yxejkub());
                    }
                    if (this.rjljd6i.rjljd6i() != null) {
                        lNd998w.eImdmIyv(this.rjljd6i.rjljd6i());
                    }
                    this.rtsRj.mTWLV(this.rjljd6i.ivfTYNl());
                    this.oZ7qYn.f4bPf(this.rjljd6i.oyaOvpOs());
                    this.q1ORKN.dUI84();
                    new RunnableC0101MY3jR(this, bv3FS, lNd998w, this.jAM6dcNA).eszJ2B0a();
                    return;
                } catch (Throwable th4) {
                    th = th4;
                    th2 = th;
                }
            } catch (Throwable th5) {
                th = th5;
                th2 = th;
            }
            throw th2;
        }
    }

    public void myMyVU(boolean z10) {
        this.rJCQt16 = z10;
    }

    public int n84TFkA9() {
        return this.eLbhX59K;
    }

    public boolean nyeBEo() {
        boolean z10;
        synchronized (this.yxejkub) {
            z10 = true;
            if (this.uYRSwDm != 1) {
                z10 = false;
            }
        }
        return z10;
    }

    public long oyaOvpOs() {
        return this.rtsRj.zDWsfFRp();
    }

    public void rJCQt16(St.RFQ3AA8 rfq3aa8, Rt.AAnYcst aAnYcst) throws Rt.AAnYcst {
        int iEImdmIyv = rfq3aa8.eImdmIyv();
        synchronized (this.yxejkub) {
            try {
                if (iEImdmIyv != 0) {
                    this.eszJ2B0a.fine(oyaOvpOs, "connectComplete", "204", new Object[]{Integer.valueOf(iEImdmIyv)});
                    throw aAnYcst;
                }
                this.eszJ2B0a.fine(oyaOvpOs, "connectComplete", "215");
                this.uYRSwDm = (byte) 0;
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public It.W7Cnq5 rtsRj() {
        return this.aXYSYCVY;
    }

    public final It.Bv3FS sMxPLer(It.Bv3FS bv3FS, Rt.AAnYcst aAnYcst) {
        this.eszJ2B0a.fine(oyaOvpOs, "handleOldTokens", "222");
        It.Bv3FS bv3FS2 = null;
        if (bv3FS != null) {
            try {
                if (this.q1ORKN.osx7Pl0E(bv3FS.aXYSYCVY.ivfTYNl()) == null) {
                    this.q1ORKN.uTIfLNK0(bv3FS, bv3FS.aXYSYCVY.ivfTYNl());
                }
            } catch (Exception unused) {
                return bv3FS2;
            }
        }
        Enumeration enumerationElements = this.oZ7qYn.fk0tr(aAnYcst).elements();
        while (enumerationElements.hasMoreElements()) {
            It.Bv3FS bv3FS3 = (It.Bv3FS) enumerationElements.nextElement();
            if (bv3FS3.aXYSYCVY.ivfTYNl().equals("Disc") || bv3FS3.aXYSYCVY.ivfTYNl().equals("Con")) {
                bv3FS2 = bv3FS3;
            } else {
                this.dUI84.aXYSYCVY(bv3FS3);
            }
        }
        return bv3FS2;
    }

    public void sgXstV(It.Bv3FS bv3FS, Rt.AAnYcst aAnYcst, St.XbU7b xbU7b) {
        RFQ3AA8 rfq3aa8;
        RFQ3AA8 rfq3aa9;
        Bv3FS bv3FS2;
        synchronized (this.yxejkub) {
            try {
                if (!this.uTIfLNK0 && !this.mTWLV && !mK94T()) {
                    this.uTIfLNK0 = true;
                    this.eszJ2B0a.fine(oyaOvpOs, "shutdownConnection", "216");
                    boolean z10 = eTQUrp() || jdF33N();
                    this.uYRSwDm = (byte) 2;
                    if (bv3FS != null && !bv3FS.dUI84()) {
                        bv3FS.aXYSYCVY.oyaOvpOs(aAnYcst);
                    }
                    RFQ3AA8 rfq3aa10 = this.dUI84;
                    if (rfq3aa10 != null) {
                        rfq3aa10.bsO5Vo();
                    }
                    LNd998w lNd998w = this.ivfTYNl;
                    if (lNd998w != null) {
                        lNd998w.eLbhX59K();
                    }
                    try {
                        Bv3FS[] bv3FSArr = this.zDWsfFRp;
                        if (bv3FSArr != null && (bv3FS2 = bv3FSArr[this.eLbhX59K]) != null) {
                            bv3FS2.stop();
                        }
                    } catch (Exception unused) {
                    }
                    this.q1ORKN.oZ7qYn(new Rt.AAnYcst(32102));
                    It.Bv3FS bv3FSSMxPLer = sMxPLer(bv3FS, aAnYcst);
                    try {
                        this.oZ7qYn.q1ORKN(aAnYcst);
                        if (this.oZ7qYn.uYRSwDm()) {
                            this.dUI84.rJCQt16();
                        }
                    } catch (Exception unused2) {
                    }
                    N1vNRFSd n1vNRFSd = this.osx7Pl0E;
                    if (n1vNRFSd != null) {
                        n1vNRFSd.zDWsfFRp();
                    }
                    It.Lx1jI lx1jI = this.qLLw0g;
                    if (lx1jI != null) {
                        lx1jI.stop();
                    }
                    try {
                        It.GU39Hcg gU39Hcg = this.zPJpxWz;
                        if (gU39Hcg != null) {
                            gU39Hcg.close();
                        }
                    } catch (Exception unused3) {
                    }
                    synchronized (this.yxejkub) {
                        this.eszJ2B0a.fine(oyaOvpOs, "shutdownConnection", "217");
                        this.uYRSwDm = (byte) 3;
                        this.uTIfLNK0 = false;
                    }
                    if (bv3FSSMxPLer != null && (rfq3aa9 = this.dUI84) != null) {
                        rfq3aa9.aXYSYCVY(bv3FSSMxPLer);
                    }
                    if (z10 && (rfq3aa8 = this.dUI84) != null) {
                        rfq3aa8.zDWsfFRp(aAnYcst, xbU7b);
                    }
                    synchronized (this.yxejkub) {
                        if (this.mTWLV) {
                            try {
                                yxejkub(true);
                            } catch (Exception unused4) {
                            }
                        }
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public It.Bv3FS uTIfLNK0() {
        return uYRSwDm(null);
    }

    public It.Bv3FS uYRSwDm(It.RFQ3AA8 rfq3aa8) {
        try {
            return this.oZ7qYn.ivfTYNl(rfq3aa8);
        } catch (Rt.AAnYcst e10) {
            c1pvtY(e10);
            return null;
        } catch (Exception e11) {
            c1pvtY(e11);
            return null;
        }
    }

    public boolean wtGiK9b() {
        boolean z10;
        synchronized (this.yxejkub) {
            z10 = this.uYRSwDm == 3;
        }
        return z10;
    }

    public void yxejkub(boolean z10) {
        synchronized (this.yxejkub) {
            try {
                if (!mK94T()) {
                    if (!wtGiK9b() || z10) {
                        this.eszJ2B0a.fine(oyaOvpOs, p497q7.SFMiYa.CLOSE_ACTION, "224");
                        if (nyeBEo()) {
                            throw new Rt.AAnYcst(32110);
                        }
                        if (eTQUrp()) {
                            throw GU39Hcg.eszJ2B0a(32100);
                        }
                        if (jdF33N()) {
                            this.mTWLV = true;
                            return;
                        }
                    }
                    this.uYRSwDm = (byte) 4;
                    this.oZ7qYn.rjljd6i();
                    this.oZ7qYn = null;
                    this.dUI84 = null;
                    this.zPJpxWz = null;
                    this.osx7Pl0E = null;
                    this.qLLw0g = null;
                    this.ivfTYNl = null;
                    this.zDWsfFRp = null;
                    this.rjljd6i = null;
                    this.q1ORKN = null;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public void z3luKc(JmXmcSi jmXmcSi, It.Bv3FS bv3FS) throws Rt.AAnYcst {
        if (!eTQUrp() && ((eTQUrp() || !(jmXmcSi instanceof St.LNd998w)) && (!jdF33N() || !(jmXmcSi instanceof St.XbU7b)))) {
            this.eszJ2B0a.fine(oyaOvpOs, "sendNoWait", "208");
            throw GU39Hcg.eszJ2B0a(32104);
        }
        if (jmXmcSi instanceof St.VI3TfJlk) {
            if (this.rtsRj.ivfTYNl() != null) {
                St.VI3TfJlk vI3TfJlk = (St.VI3TfJlk) jmXmcSi;
                if (vI3TfJlk.eImdmIyv().zDWsfFRp() > this.rtsRj.ivfTYNl().intValue()) {
                    Rt.RFQ3AA8 rfq3aa8EImdmIyv = vI3TfJlk.eImdmIyv();
                    rfq3aa8EImdmIyv.zPJpxWz(this.rtsRj.ivfTYNl().intValue());
                    vI3TfJlk.eTQUrp(rfq3aa8EImdmIyv);
                }
            }
            if (this.rtsRj.zPJpxWz() != null) {
                St.VI3TfJlk vI3TfJlk2 = (St.VI3TfJlk) jmXmcSi;
                if (vI3TfJlk2.eImdmIyv().osx7Pl0E() && !this.rtsRj.zPJpxWz().booleanValue()) {
                    Rt.RFQ3AA8 rfq3aa8EImdmIyv2 = vI3TfJlk2.eImdmIyv();
                    rfq3aa8EImdmIyv2.qLLw0g(false);
                    vI3TfJlk2.eTQUrp(rfq3aa8EImdmIyv2);
                }
            }
        }
        eImdmIyv(jmXmcSi, bv3FS);
    }

    public void gA0EO() {
    }
}
