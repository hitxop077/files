package Jt;

import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public class HicDZW {
    public Integer dUI84;
    public Boolean eLbhX59K;
    public Long ivfTYNl;
    public Boolean oZ7qYn;
    public Integer osx7Pl0E;
    public long q1ORKN;
    public boolean qLLw0g;
    public Boolean rjljd6i;
    public String uTIfLNK0;
    public AtomicInteger uYRSwDm;
    public Long zDWsfFRp;
    public Boolean zPJpxWz;
    public Integer eszJ2B0a = 65535;
    public Integer aXYSYCVY = 2;

    public HicDZW(String str) {
        Boolean bool = Boolean.TRUE;
        this.eLbhX59K = bool;
        this.zDWsfFRp = null;
        this.ivfTYNl = null;
        this.osx7Pl0E = 0;
        this.dUI84 = 0;
        this.oZ7qYn = bool;
        this.rjljd6i = bool;
        this.zPJpxWz = bool;
        this.qLLw0g = false;
        this.q1ORKN = 60L;
        this.uTIfLNK0 = "";
        this.uYRSwDm = new AtomicInteger(1);
        this.uTIfLNK0 = str;
    }

    public Long aXYSYCVY() {
        return this.ivfTYNl;
    }

    public void bsO5Vo(boolean z10) {
        this.qLLw0g = z10;
    }

    public void c1pvtY(Boolean bool) {
        if (bool != null) {
            this.rjljd6i = bool;
        }
    }

    public Long dUI84() {
        return this.zDWsfFRp;
    }

    public void eImdmIyv(Boolean bool) {
        if (bool != null) {
            this.oZ7qYn = bool;
        }
    }

    public Integer eLbhX59K() {
        return this.dUI84;
    }

    public void eszJ2B0a() {
        this.uYRSwDm.set(1);
    }

    public Integer ivfTYNl() {
        return this.aXYSYCVY;
    }

    public void jAM6dcNA(Long l10) {
        if (l10 != null) {
            this.zDWsfFRp = l10;
        }
    }

    public void mTWLV(long j10) {
        this.q1ORKN = j10 * 1000;
    }

    public void n84TFkA9(Boolean bool) {
        if (bool != null) {
            this.eLbhX59K = bool;
        }
    }

    public Integer oZ7qYn() {
        return this.osx7Pl0E;
    }

    public Integer osx7Pl0E() {
        return Integer.valueOf(this.uYRSwDm.getAndIncrement());
    }

    public void oyaOvpOs(Integer num) {
        if (num != null) {
            this.eszJ2B0a = num;
        }
    }

    public Boolean q1ORKN() {
        return this.zPJpxWz;
    }

    public boolean qLLw0g() {
        return this.qLLw0g;
    }

    public void rJCQt16(Integer num) {
        if (num != null) {
            this.aXYSYCVY = num;
        }
    }

    public Integer rjljd6i() {
        Integer num = this.eszJ2B0a;
        if (num == null) {
            return 65535;
        }
        return num;
    }

    public void rtsRj(Integer num) {
        if (num != null) {
            this.osx7Pl0E = num;
        }
    }

    public void sMxPLer(Boolean bool) {
        if (bool != null) {
            this.zPJpxWz = bool;
        }
    }

    public Boolean uTIfLNK0() {
        return this.oZ7qYn;
    }

    public void uYRSwDm(Long l10) {
        if (l10 != null) {
            this.ivfTYNl = l10;
        }
    }

    public void yxejkub(Integer num) {
        if (num != null) {
            this.dUI84 = num;
        }
    }

    public long zDWsfFRp() {
        return this.q1ORKN;
    }

    public Boolean zPJpxWz() {
        return this.eLbhX59K;
    }
}
