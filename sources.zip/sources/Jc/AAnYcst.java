package Jc;

import android.content.Context;
import android.net.Uri;
import android.widget.Toast;
import java.util.List;
import java.util.Objects;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.MockUrlActivity;
import net.one97.paytm.dynamic.module.mall.communicator.util.CJRConstants;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public final class AAnYcst {
    public static final AAnYcst eszJ2B0a = new AAnYcst();

    public final void eszJ2B0a(String str, Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        JSONArray jSONArrayI2VlO = MockUrlActivity.i2VlO(context);
        try {
            Uri uri = Uri.parse(str);
            List<String> queryParameters = uri.getQueryParameters("key");
            List<String> queryParameters2 = uri.getQueryParameters("value");
            Objects.toString(queryParameters);
            Objects.toString(queryParameters2);
            if (queryParameters.size() != 0 && queryParameters2.size() != 0) {
                int size = queryParameters.size();
                for (int i10 = 0; i10 < size; i10++) {
                    String str2 = queryParameters.get(i10);
                    String str3 = queryParameters2.get(i10);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("rule_type", "GTM Override");
                    jSONObject.put(CJRConstants.SEARCH_PATTERN_TAG, str2);
                    jSONObject.put(CJRConstants.REPLACEMENT_PATTERN_TAG, str3);
                    jSONObject.put(CJRConstants.IS_FULL_REPLACEMENT_TAG, true);
                    jSONObject.put("is_muted", false);
                    jSONArrayI2VlO.put(jSONObject);
                }
                MockUrlActivity.nhkrxQ(context, jSONArrayI2VlO);
                Toast.makeText(context, "Rule added successfully \n " + str, 0).show();
                return;
            }
            Toast.makeText(context, "Nothing to add Please check deeplink", 0).show();
        } catch (JSONException e10) {
            e10.getMessage();
            Toast.makeText(context, "JSONException in  Rule add", 0).show();
        }
    }
}
