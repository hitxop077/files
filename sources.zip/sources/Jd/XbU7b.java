package Jd;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.UjGBKKw;
import java.util.ArrayList;
import java.util.Objects;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.common.entity.home.ITabFragment;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes12.dex */
public abstract class XbU7b extends UjGBKKw {
    public final ArrayList njNibPNp;
    public final ArrayList vo5p9AUA;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public XbU7b(FragmentManager fm2, ArrayList homeTabs) {
        super(fm2, 1);
        Intrinsics.checkNotNullParameter(fm2, "fm");
        Intrinsics.checkNotNullParameter(homeTabs, "homeTabs");
        this.njNibPNp = homeTabs;
        this.vo5p9AUA = new ArrayList();
    }

    public final ITabFragment dUI84(int i10) {
        if (((ITabFragment) CollectionsKt.getOrNull(this.vo5p9AUA, i10)) == null) {
            getItem(i10);
        }
        Object obj = this.vo5p9AUA.get(i10);
        Intrinsics.checkNotNullExpressionValue(obj, "get(...)");
        return (ITabFragment) obj;
    }

    @Override // androidx.viewpager.widget.MY3jR
    public final int getCount() {
        return this.njNibPNp.size();
    }

    @Override // androidx.fragment.app.UjGBKKw
    public final Fragment getItem(int i10) {
        ITabFragment iTabFragmentIvfTYNl = (ITabFragment) CollectionsKt.getOrNull(this.vo5p9AUA, i10);
        if (iTabFragmentIvfTYNl != null) {
            iTabFragmentIvfTYNl.toString();
        } else {
            Object obj = this.njNibPNp.get(i10);
            Intrinsics.checkNotNullExpressionValue(obj, "get(...)");
            iTabFragmentIvfTYNl = ivfTYNl((Nd.N1vNRFSd) obj, i10);
            this.vo5p9AUA.add(iTabFragmentIvfTYNl);
            Objects.toString(iTabFragmentIvfTYNl);
        }
        return iTabFragmentIvfTYNl.getFragment();
    }

    @Override // androidx.viewpager.widget.MY3jR
    public final int getItemPosition(Object object) {
        Intrinsics.checkNotNullParameter(object, "object");
        return -2;
    }

    public abstract ITabFragment ivfTYNl(Nd.N1vNRFSd n1vNRFSd, int i10);

    public final ArrayList osx7Pl0E() {
        return this.vo5p9AUA;
    }
}
