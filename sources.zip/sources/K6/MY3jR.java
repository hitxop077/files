package K6;

import M6.LNd998w;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes9.dex */
public interface MY3jR {
    D0.MY3jR eszJ2B0a(LNd998w.RFQ3AA8 rfq3aa8);
}
