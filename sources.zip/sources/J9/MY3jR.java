package J9;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes11.dex */
public abstract class MY3jR {
    public static void eszJ2B0a(String str, String str2) {
    }
}
