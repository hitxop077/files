package k09j3zn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class VI3TfJlk {
    public int aXYSYCVY = -1;
    public ViewGroup eLbhX59K;
    public Context eszJ2B0a;
    public Runnable ivfTYNl;
    public Runnable osx7Pl0E;
    public View zDWsfFRp;

    public VI3TfJlk(ViewGroup viewGroup, View view) {
        this.eLbhX59K = viewGroup;
        this.zDWsfFRp = view;
    }

    public static VI3TfJlk eLbhX59K(ViewGroup viewGroup) {
        return (VI3TfJlk) viewGroup.getTag(SFMiYa.transition_current_scene);
    }

    public static void osx7Pl0E(ViewGroup viewGroup, VI3TfJlk vI3TfJlk) {
        viewGroup.setTag(SFMiYa.transition_current_scene, vI3TfJlk);
    }

    public void aXYSYCVY() {
        Runnable runnable;
        if (eLbhX59K(this.eLbhX59K) != this || (runnable = this.osx7Pl0E) == null) {
            return;
        }
        runnable.run();
    }

    public void eszJ2B0a() {
        if (this.aXYSYCVY > 0 || this.zDWsfFRp != null) {
            zDWsfFRp().removeAllViews();
            if (this.aXYSYCVY > 0) {
                LayoutInflater.from(this.eszJ2B0a).inflate(this.aXYSYCVY, this.eLbhX59K);
            } else {
                this.eLbhX59K.addView(this.zDWsfFRp);
            }
        }
        Runnable runnable = this.ivfTYNl;
        if (runnable != null) {
            runnable.run();
        }
        osx7Pl0E(this.eLbhX59K, this);
    }

    public boolean ivfTYNl() {
        return this.aXYSYCVY > 0;
    }

    public ViewGroup zDWsfFRp() {
        return this.eLbhX59K;
    }
}
