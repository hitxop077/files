package k09j3zn;

import android.view.View;
import n6gcj6.sMYe.vCeOCsg;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class BgOcqi extends IMpOqqn {
    public static final String[] eszJ2B0a = {"android:visibilityPropagation:visibility", "android:visibilityPropagation:center"};

    public static int zDWsfFRp(AliKj1I aliKj1I, int i10) {
        int[] iArr;
        if (aliKj1I == null || (iArr = (int[]) aliKj1I.eszJ2B0a.get(vCeOCsg.PDrfraUx)) == null) {
            return -1;
        }
        return iArr[i10];
    }

    @Override // k09j3zn.IMpOqqn
    public String[] aXYSYCVY() {
        return eszJ2B0a;
    }

    public int dUI84(AliKj1I aliKj1I) {
        return zDWsfFRp(aliKj1I, 1);
    }

    @Override // k09j3zn.IMpOqqn
    public void eszJ2B0a(AliKj1I aliKj1I) {
        View view = aliKj1I.aXYSYCVY;
        Integer numValueOf = (Integer) aliKj1I.eszJ2B0a.get("android:visibility:visibility");
        if (numValueOf == null) {
            numValueOf = Integer.valueOf(view.getVisibility());
        }
        aliKj1I.eszJ2B0a.put("android:visibilityPropagation:visibility", numValueOf);
        int[] iArr = {iRound, 0};
        view.getLocationOnScreen(iArr);
        int iRound = iArr[0] + Math.round(view.getTranslationX());
        iArr[0] = iRound + (view.getWidth() / 2);
        int iRound2 = iArr[1] + Math.round(view.getTranslationY());
        iArr[1] = iRound2;
        iArr[1] = iRound2 + (view.getHeight() / 2);
        aliKj1I.eszJ2B0a.put("android:visibilityPropagation:center", iArr);
    }

    public int ivfTYNl(AliKj1I aliKj1I) {
        Integer num;
        if (aliKj1I == null || (num = (Integer) aliKj1I.eszJ2B0a.get("android:visibilityPropagation:visibility")) == null) {
            return 8;
        }
        return num.intValue();
    }

    public int osx7Pl0E(AliKj1I aliKj1I) {
        return zDWsfFRp(aliKj1I, 0);
    }
}
