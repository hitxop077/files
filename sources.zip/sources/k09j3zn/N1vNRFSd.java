package k09j3zn;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public interface N1vNRFSd {
    void eszJ2B0a(ViewGroup viewGroup, View view);

    void setVisibility(int i10);
}
