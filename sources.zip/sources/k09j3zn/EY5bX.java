package k09j3zn;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Build;
import android.util.Property;
import android.view.View;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class EY5bX {
    public static final Property aXYSYCVY;
    public static final Property eLbhX59K;
    public static final RNKsLmd eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public class AAnYcst extends Property {
        public AAnYcst(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(View view, Rect rect) {
            view.setClipBounds(rect);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Rect get(View view) {
            return view.getClipBounds();
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends Property {
        public MY3jR(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f10) {
            EY5bX.osx7Pl0E(view, f10.floatValue());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(EY5bX.aXYSYCVY(view));
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 29) {
            eszJ2B0a = new CWlPQz9u();
        } else {
            eszJ2B0a = new YcaGN();
        }
        aXYSYCVY = new MY3jR(Float.class, "translationAlpha");
        eLbhX59K = new AAnYcst(Rect.class, "clipBounds");
    }

    public static float aXYSYCVY(View view) {
        return eszJ2B0a.aXYSYCVY(view);
    }

    public static void dUI84(View view, int i10) {
        eszJ2B0a.dUI84(view, i10);
    }

    public static void eLbhX59K(View view) {
        eszJ2B0a.eLbhX59K(view);
    }

    public static void eszJ2B0a(View view) {
        eszJ2B0a.eszJ2B0a(view);
    }

    public static void ivfTYNl(View view, int i10, int i11, int i12, int i13) {
        eszJ2B0a.ivfTYNl(view, i10, i11, i12, i13);
    }

    public static void oZ7qYn(View view, Matrix matrix) {
        eszJ2B0a.oZ7qYn(view, matrix);
    }

    public static void osx7Pl0E(View view, float f10) {
        eszJ2B0a.osx7Pl0E(view, f10);
    }

    public static void rjljd6i(View view, Matrix matrix) {
        eszJ2B0a.rjljd6i(view, matrix);
    }

    public static void zDWsfFRp(View view, Matrix matrix) {
        eszJ2B0a.zDWsfFRp(view, matrix);
    }
}
