package k09j3zn;

import android.graphics.Rect;
import android.view.ViewGroup;
import androidx.transition.Transition;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class AAnYcst extends BgOcqi {
    public float aXYSYCVY = 3.0f;

    public static float oZ7qYn(float f10, float f11, float f12, float f13) {
        float f14 = f12 - f10;
        float f15 = f13 - f11;
        return (float) Math.sqrt((f14 * f14) + (f15 * f15));
    }

    @Override // k09j3zn.IMpOqqn
    public long eLbhX59K(ViewGroup viewGroup, Transition transition, AliKj1I aliKj1I, AliKj1I aliKj1I2) {
        int i10;
        int iRound;
        int iCenterX;
        if (aliKj1I == null && aliKj1I2 == null) {
            return 0L;
        }
        if (aliKj1I2 == null || ivfTYNl(aliKj1I) == 0) {
            i10 = -1;
        } else {
            aliKj1I = aliKj1I2;
            i10 = 1;
        }
        int iOsx7Pl0E = osx7Pl0E(aliKj1I);
        int iDUI84 = dUI84(aliKj1I);
        Rect rectF4bPf = transition.f4bPf();
        if (rectF4bPf != null) {
            iCenterX = rectF4bPf.centerX();
            iRound = rectF4bPf.centerY();
        } else {
            int[] iArr = new int[2];
            viewGroup.getLocationOnScreen(iArr);
            int iRound2 = Math.round(iArr[0] + (viewGroup.getWidth() / 2) + viewGroup.getTranslationX());
            iRound = Math.round(iArr[1] + (viewGroup.getHeight() / 2) + viewGroup.getTranslationY());
            iCenterX = iRound2;
        }
        float fOZ7qYn = oZ7qYn(iOsx7Pl0E, iDUI84, iCenterX, iRound) / oZ7qYn(0.0f, 0.0f, viewGroup.getWidth(), viewGroup.getHeight());
        long jD3penA = transition.d3penA();
        if (jD3penA < 0) {
            jD3penA = 300;
        }
        return Math.round(((jD3penA * ((long) i10)) / this.aXYSYCVY) * fOZ7qYn);
    }
}
