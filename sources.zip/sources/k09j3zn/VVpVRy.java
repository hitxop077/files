package k09j3zn;

import android.animation.PropertyValuesHolder;
import android.animation.TypeConverter;
import android.graphics.Path;
import android.util.Property;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class VVpVRy {

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static <V> PropertyValuesHolder eszJ2B0a(Property<?, V> property, Path path) {
            return PropertyValuesHolder.ofObject(property, (TypeConverter) null, path);
        }
    }

    public static PropertyValuesHolder eszJ2B0a(Property property, Path path) {
        return MY3jR.eszJ2B0a(property, path);
    }
}
