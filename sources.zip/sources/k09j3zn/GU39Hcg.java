package k09j3zn;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class GU39Hcg extends ViewGroup implements N1vNRFSd {
    public final ViewTreeObserver.OnPreDrawListener fdmP9GD;
    public final View gmzPK;
    public ViewGroup njNibPNp;
    public View vo5p9AUA;
    public Matrix xINpNt2d;
    public int zYD7SXW6;

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR implements ViewTreeObserver.OnPreDrawListener {
        public MY3jR() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            View view;
            GU39Hcg.this.postInvalidateOnAnimation();
            GU39Hcg gU39Hcg = GU39Hcg.this;
            ViewGroup viewGroup = gU39Hcg.njNibPNp;
            if (viewGroup == null || (view = gU39Hcg.vo5p9AUA) == null) {
                return true;
            }
            viewGroup.endViewTransition(view);
            GU39Hcg.this.njNibPNp.postInvalidateOnAnimation();
            GU39Hcg gU39Hcg2 = GU39Hcg.this;
            gU39Hcg2.njNibPNp = null;
            gU39Hcg2.vo5p9AUA = null;
            return true;
        }
    }

    public GU39Hcg(View view) {
        super(view.getContext());
        this.fdmP9GD = new MY3jR();
        this.gmzPK = view;
        setWillNotDraw(false);
        setClipChildren(false);
        setLayerType(2, null);
    }

    public static GU39Hcg aXYSYCVY(View view, ViewGroup viewGroup, Matrix matrix) {
        int i10;
        XbU7b xbU7b;
        if (!(view.getParent() instanceof ViewGroup)) {
            throw new IllegalArgumentException("Ghosted views must be parented by a ViewGroup");
        }
        XbU7b xbU7bAXYSYCVY = XbU7b.aXYSYCVY(viewGroup);
        GU39Hcg gU39HcgIvfTYNl = ivfTYNl(view);
        if (gU39HcgIvfTYNl == null || (xbU7b = (XbU7b) gU39HcgIvfTYNl.getParent()) == xbU7bAXYSYCVY) {
            i10 = 0;
        } else {
            i10 = gU39HcgIvfTYNl.zYD7SXW6;
            xbU7b.removeView(gU39HcgIvfTYNl);
            gU39HcgIvfTYNl = null;
        }
        if (gU39HcgIvfTYNl == null) {
            if (matrix == null) {
                matrix = new Matrix();
                eLbhX59K(view, viewGroup, matrix);
            }
            gU39HcgIvfTYNl = new GU39Hcg(view);
            gU39HcgIvfTYNl.oZ7qYn(matrix);
            if (xbU7bAXYSYCVY == null) {
                xbU7bAXYSYCVY = new XbU7b(viewGroup);
            } else {
                xbU7bAXYSYCVY.dUI84();
            }
            zDWsfFRp(viewGroup, xbU7bAXYSYCVY);
            zDWsfFRp(viewGroup, gU39HcgIvfTYNl);
            xbU7bAXYSYCVY.eszJ2B0a(gU39HcgIvfTYNl);
            gU39HcgIvfTYNl.zYD7SXW6 = i10;
        } else if (matrix != null) {
            gU39HcgIvfTYNl.oZ7qYn(matrix);
        }
        gU39HcgIvfTYNl.zYD7SXW6++;
        return gU39HcgIvfTYNl;
    }

    public static void dUI84(View view, GU39Hcg gU39Hcg) {
        view.setTag(SFMiYa.ghost_view, gU39Hcg);
    }

    public static void eLbhX59K(View view, ViewGroup viewGroup, Matrix matrix) {
        ViewGroup viewGroup2 = (ViewGroup) view.getParent();
        matrix.reset();
        EY5bX.oZ7qYn(viewGroup2, matrix);
        matrix.preTranslate(-viewGroup2.getScrollX(), -viewGroup2.getScrollY());
        EY5bX.rjljd6i(viewGroup, matrix);
    }

    public static GU39Hcg ivfTYNl(View view) {
        return (GU39Hcg) view.getTag(SFMiYa.ghost_view);
    }

    public static void osx7Pl0E(View view) {
        GU39Hcg gU39HcgIvfTYNl = ivfTYNl(view);
        if (gU39HcgIvfTYNl != null) {
            int i10 = gU39HcgIvfTYNl.zYD7SXW6 - 1;
            gU39HcgIvfTYNl.zYD7SXW6 = i10;
            if (i10 <= 0) {
                ((XbU7b) gU39HcgIvfTYNl.getParent()).removeView(gU39HcgIvfTYNl);
            }
        }
    }

    public static void zDWsfFRp(View view, View view2) {
        EY5bX.ivfTYNl(view2, view2.getLeft(), view2.getTop(), view2.getLeft() + view.getWidth(), view2.getTop() + view.getHeight());
    }

    @Override // k09j3zn.N1vNRFSd
    public void eszJ2B0a(ViewGroup viewGroup, View view) {
        this.njNibPNp = viewGroup;
        this.vo5p9AUA = view;
    }

    public void oZ7qYn(Matrix matrix) {
        this.xINpNt2d = matrix;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        dUI84(this.gmzPK, this);
        this.gmzPK.getViewTreeObserver().addOnPreDrawListener(this.fdmP9GD);
        EY5bX.dUI84(this.gmzPK, 4);
        if (this.gmzPK.getParent() != null) {
            ((View) this.gmzPK.getParent()).invalidate();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        this.gmzPK.getViewTreeObserver().removeOnPreDrawListener(this.fdmP9GD);
        EY5bX.dUI84(this.gmzPK, 0);
        dUI84(this.gmzPK, null);
        if (this.gmzPK.getParent() != null) {
            ((View) this.gmzPK.getParent()).invalidate();
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        k09j3zn.MY3jR.eszJ2B0a(canvas, true);
        canvas.setMatrix(this.xINpNt2d);
        EY5bX.dUI84(this.gmzPK, 0);
        this.gmzPK.invalidate();
        EY5bX.dUI84(this.gmzPK, 4);
        drawChild(canvas, this.gmzPK, getDrawingTime());
        k09j3zn.MY3jR.eszJ2B0a(canvas, false);
    }

    @Override // android.view.View, k09j3zn.N1vNRFSd
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        if (ivfTYNl(this.gmzPK) == this) {
            EY5bX.dUI84(this.gmzPK, i10 == 0 ? 4 : 0);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
    }
}
