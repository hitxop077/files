package k09j3zn;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import androidx.transition.Transition;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class Gyx10a extends BgOcqi {
    public float aXYSYCVY = 3.0f;
    public int eLbhX59K = 80;

    @Override // k09j3zn.IMpOqqn
    public long eLbhX59K(ViewGroup viewGroup, Transition transition, AliKj1I aliKj1I, AliKj1I aliKj1I2) {
        int i10;
        int i11;
        int iCenterY;
        int i12;
        AliKj1I aliKj1I3 = aliKj1I;
        if (aliKj1I3 == null && aliKj1I2 == null) {
            return 0L;
        }
        Rect rectF4bPf = transition.f4bPf();
        if (aliKj1I2 == null || ivfTYNl(aliKj1I3) == 0) {
            i10 = -1;
        } else {
            aliKj1I3 = aliKj1I2;
            i10 = 1;
        }
        int iOsx7Pl0E = osx7Pl0E(aliKj1I3);
        int iDUI84 = dUI84(aliKj1I3);
        int[] iArr = new int[2];
        viewGroup.getLocationOnScreen(iArr);
        int iRound = iArr[0] + Math.round(viewGroup.getTranslationX());
        int iRound2 = iArr[1] + Math.round(viewGroup.getTranslationY());
        int width = viewGroup.getWidth() + iRound;
        int height = viewGroup.getHeight() + iRound2;
        if (rectF4bPf != null) {
            int iCenterX = rectF4bPf.centerX();
            i12 = iRound2;
            iCenterY = rectF4bPf.centerY();
            i11 = iCenterX;
        } else {
            i11 = (iRound + width) / 2;
            iCenterY = (iRound2 + height) / 2;
            i12 = iRound2;
        }
        float fOZ7qYn = oZ7qYn(viewGroup, iOsx7Pl0E, iDUI84, i11, iCenterY, iRound, i12, width, height) / rjljd6i(viewGroup);
        long jD3penA = transition.d3penA();
        if (jD3penA < 0) {
            jD3penA = 300;
        }
        return Math.round(((jD3penA * ((long) i10)) / this.aXYSYCVY) * fOZ7qYn);
    }

    /* JADX WARN: Code duplicated, block: B:6:0x0010  */
    /* JADX WARN: Code duplicated, block: B:7:0x0012  */
    public final int oZ7qYn(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
        int i18 = this.eLbhX59K;
        if (i18 == 8388611) {
            if (view.getLayoutDirection() == 1) {
                i18 = 5;
            } else {
                i18 = 3;
            }
        } else if (i18 == 8388613) {
            if (view.getLayoutDirection() == 1) {
                i18 = 3;
            } else {
                i18 = 5;
            }
        }
        if (i18 == 3) {
            return (i16 - i10) + Math.abs(i13 - i11);
        }
        if (i18 == 5) {
            return (i10 - i14) + Math.abs(i13 - i11);
        }
        if (i18 == 48) {
            return (i17 - i11) + Math.abs(i12 - i10);
        }
        if (i18 != 80) {
            return 0;
        }
        return (i11 - i15) + Math.abs(i12 - i10);
    }

    public final int rjljd6i(ViewGroup viewGroup) {
        int i10 = this.eLbhX59K;
        return (i10 == 3 || i10 == 5 || i10 == 8388611 || i10 == 8388613) ? viewGroup.getWidth() : viewGroup.getHeight();
    }

    public void zPJpxWz(int i10) {
        this.eLbhX59K = i10;
    }
}
