package k09j3zn;

import android.view.View;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class O0DWnU extends QChIE25g {
    public static boolean dUI84 = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void eszJ2B0a(View view, int i10, int i11, int i12, int i13) {
            view.setLeftTopRightBottom(i10, i11, i12, i13);
        }
    }

    @Override // k09j3zn.RNKsLmd
    public void ivfTYNl(View view, int i10, int i11, int i12, int i13) {
        if (dUI84) {
            try {
                MY3jR.eszJ2B0a(view, i10, i11, i12, i13);
            } catch (NoSuchMethodError unused) {
                dUI84 = false;
            }
        }
    }
}
