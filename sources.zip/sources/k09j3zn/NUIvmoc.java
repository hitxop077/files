package k09j3zn;

import android.R;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class NUIvmoc {
    public static final int[] eszJ2B0a = {R.attr.targetClass, R.attr.targetId, R.attr.excludeId, R.attr.excludeClass, R.attr.targetName, R.attr.excludeName};
    public static final int[] aXYSYCVY = {R.attr.fromScene, R.attr.toScene, R.attr.transition};
    public static final int[] eLbhX59K = {R.attr.interpolator, R.attr.duration, R.attr.startDelay, R.attr.matchOrder};
    public static final int[] zDWsfFRp = {R.attr.resizeClip};
    public static final int[] ivfTYNl = {R.attr.transitionVisibilityMode};
    public static final int[] osx7Pl0E = {R.attr.fadingMode};
    public static final int[] dUI84 = {R.attr.reparent, R.attr.reparentWithOverlay};
    public static final int[] oZ7qYn = {R.attr.slideEdge};
    public static final int[] rjljd6i = {R.attr.transitionOrdering};
    public static final int[] zPJpxWz = {R.attr.minimumHorizontalAngle, R.attr.minimumVerticalAngle, R.attr.maximumAngle};
    public static final int[] qLLw0g = {R.attr.patternPathData};
}
