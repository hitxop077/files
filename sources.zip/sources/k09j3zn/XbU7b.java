package k09j3zn;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.ArrayList;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class XbU7b extends FrameLayout {
    public ViewGroup njNibPNp;
    public boolean vo5p9AUA;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static float eszJ2B0a(View view) {
            return view.getZ();
        }
    }

    public XbU7b(ViewGroup viewGroup) {
        super(viewGroup.getContext());
        setClipChildren(false);
        this.njNibPNp = viewGroup;
        viewGroup.setTag(SFMiYa.ghost_view_holder, this);
        this.njNibPNp.getOverlay().add(this);
        this.vo5p9AUA = true;
    }

    public static XbU7b aXYSYCVY(ViewGroup viewGroup) {
        return (XbU7b) viewGroup.getTag(SFMiYa.ghost_view_holder);
    }

    public static boolean ivfTYNl(View view, View view2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        int childCount = viewGroup.getChildCount();
        if (MY3jR.eszJ2B0a(view) != MY3jR.eszJ2B0a(view2)) {
            return MY3jR.eszJ2B0a(view) > MY3jR.eszJ2B0a(view2);
        }
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = viewGroup.getChildAt(ZKBAd.eszJ2B0a(viewGroup, i10));
            if (childAt == view) {
                return false;
            }
            if (childAt == view2) {
                return true;
            }
        }
        return true;
    }

    public static boolean osx7Pl0E(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty() || arrayList2.isEmpty() || arrayList.get(0) != arrayList2.get(0)) {
            return true;
        }
        int iMin = Math.min(arrayList.size(), arrayList2.size());
        for (int i10 = 1; i10 < iMin; i10++) {
            View view = (View) arrayList.get(i10);
            View view2 = (View) arrayList2.get(i10);
            if (view != view2) {
                return ivfTYNl(view, view2);
            }
        }
        return arrayList2.size() == iMin;
    }

    public static void zDWsfFRp(View view, ArrayList arrayList) {
        Object parent = view.getParent();
        if (parent instanceof ViewGroup) {
            zDWsfFRp((View) parent, arrayList);
        }
        arrayList.add(view);
    }

    public void dUI84() {
        if (!this.vo5p9AUA) {
            throw new IllegalStateException("This GhostViewHolder is detached!");
        }
        this.njNibPNp.getOverlay().remove(this);
        this.njNibPNp.getOverlay().add(this);
    }

    public final int eLbhX59K(ArrayList arrayList) {
        ArrayList arrayList2 = new ArrayList();
        int childCount = getChildCount() - 1;
        int i10 = 0;
        while (i10 <= childCount) {
            int i11 = (i10 + childCount) / 2;
            zDWsfFRp(((GU39Hcg) getChildAt(i11)).gmzPK, arrayList2);
            if (osx7Pl0E(arrayList, arrayList2)) {
                i10 = i11 + 1;
            } else {
                childCount = i11 - 1;
            }
            arrayList2.clear();
        }
        return i10;
    }

    public void eszJ2B0a(GU39Hcg gU39Hcg) {
        ArrayList arrayList = new ArrayList();
        zDWsfFRp(gU39Hcg.gmzPK, arrayList);
        int iELbhX59K = eLbhX59K(arrayList);
        if (iELbhX59K < 0 || iELbhX59K >= getChildCount()) {
            addView(gU39Hcg);
        } else {
            addView(gU39Hcg, iELbhX59K);
        }
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        if (!this.vo5p9AUA) {
            throw new IllegalStateException("This GhostViewHolder is detached!");
        }
        super.onViewAdded(view);
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        if ((getChildCount() == 1 && getChildAt(0) == view) || getChildCount() == 0) {
            this.njNibPNp.setTag(SFMiYa.ghost_view_holder, null);
            this.njNibPNp.getOverlay().remove(this);
            this.vo5p9AUA = false;
        }
    }
}
