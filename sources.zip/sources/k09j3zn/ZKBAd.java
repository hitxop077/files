package k09j3zn;

import android.os.Build;
import android.view.ViewGroup;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class ZKBAd {
    public static Method aXYSYCVY = null;
    public static boolean eLbhX59K = false;
    public static boolean eszJ2B0a = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void aXYSYCVY(ViewGroup viewGroup, boolean z10) {
            viewGroup.suppressLayout(z10);
        }

        public static int eszJ2B0a(ViewGroup viewGroup, int i10) {
            return viewGroup.getChildDrawingOrder(i10);
        }
    }

    public static void aXYSYCVY(ViewGroup viewGroup, boolean z10) {
        if (eszJ2B0a) {
            try {
                MY3jR.aXYSYCVY(viewGroup, z10);
            } catch (NoSuchMethodError unused) {
                eszJ2B0a = false;
            }
        }
    }

    public static void eLbhX59K(ViewGroup viewGroup, boolean z10) {
        if (Build.VERSION.SDK_INT >= 29) {
            MY3jR.aXYSYCVY(viewGroup, z10);
        } else {
            aXYSYCVY(viewGroup, z10);
        }
    }

    public static int eszJ2B0a(ViewGroup viewGroup, int i10) {
        if (Build.VERSION.SDK_INT >= 29) {
            return MY3jR.eszJ2B0a(viewGroup, i10);
        }
        if (!eLbhX59K) {
            try {
                Class cls = Integer.TYPE;
                Method declaredMethod = ViewGroup.class.getDeclaredMethod("getChildDrawingOrder", cls, cls);
                aXYSYCVY = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            eLbhX59K = true;
        }
        Method method = aXYSYCVY;
        if (method != null) {
            try {
                return ((Integer) method.invoke(viewGroup, Integer.valueOf(viewGroup.getChildCount()), Integer.valueOf(i10))).intValue();
            } catch (IllegalAccessException | InvocationTargetException unused2) {
            }
        }
        return i10;
    }
}
