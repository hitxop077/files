package k09j3zn;

/* JADX INFO: loaded from: classes7.dex */
public abstract class SFMiYa {
    public static final int ghost_view = 2131365009;
    public static final int ghost_view_holder = 2131365010;
    public static final int parent_matrix = 2131368111;
    public static final int save_non_transition_alpha = 2131369565;
    public static final int save_overlay_view = 2131369566;
    public static final int transition_clip = 2131370967;
    public static final int transition_current_scene = 2131370968;
    public static final int transition_image_transform = 2131370969;
    public static final int transition_layout_save = 2131370970;
    public static final int transition_pause_alpha = 2131370971;
    public static final int transition_position = 2131370972;
    public static final int transition_scene_layoutid_cache = 2131370973;
    public static final int transition_transform = 2131370974;
}
