package k09j3zn;

import android.graphics.Canvas;
import android.os.Build;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class MY3jR {
    public static Method aXYSYCVY;
    public static boolean eLbhX59K;
    public static Method eszJ2B0a;

    /* JADX INFO: renamed from: k09j3zn.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static class C1488MY3jR {
        public static void aXYSYCVY(Canvas canvas) {
            canvas.enableZ();
        }

        public static void eszJ2B0a(Canvas canvas) {
            canvas.disableZ();
        }
    }

    public static void eszJ2B0a(Canvas canvas, boolean z10) {
        Method method;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 29) {
            if (z10) {
                C1488MY3jR.aXYSYCVY(canvas);
                return;
            } else {
                C1488MY3jR.eszJ2B0a(canvas);
                return;
            }
        }
        if (i10 == 28) {
            throw new IllegalStateException("This method doesn't work on Pie!");
        }
        if (!eLbhX59K) {
            try {
                Method declaredMethod = Canvas.class.getDeclaredMethod("insertReorderBarrier", null);
                eszJ2B0a = declaredMethod;
                declaredMethod.setAccessible(true);
                Method declaredMethod2 = Canvas.class.getDeclaredMethod("insertInorderBarrier", null);
                aXYSYCVY = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            eLbhX59K = true;
        }
        if (z10) {
            try {
                Method method2 = eszJ2B0a;
                if (method2 != null) {
                    method2.invoke(canvas, null);
                }
            } catch (IllegalAccessException unused2) {
                return;
            } catch (InvocationTargetException e10) {
                throw new RuntimeException(e10.getCause());
            }
        }
        if (z10 || (method = aXYSYCVY) == null) {
            return;
        }
        method.invoke(canvas, null);
    }
}
