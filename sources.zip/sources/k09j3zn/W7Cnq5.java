package k09j3zn;

import android.graphics.Matrix;
import android.view.View;
import android.view.ViewGroup;
import com.paytm.android.pd.common.activities.Gje.fhlIYZ;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class W7Cnq5 implements N1vNRFSd {
    public static Method fdmP9GD;
    public static boolean gmzPK;
    public static Class vo5p9AUA;
    public static boolean vskcqLTQ;
    public static boolean xINpNt2d;
    public static Method zYD7SXW6;
    public final View njNibPNp;

    public W7Cnq5(View view) {
        this.njNibPNp = view;
    }

    public static N1vNRFSd aXYSYCVY(View view, ViewGroup viewGroup, Matrix matrix) {
        eLbhX59K();
        Method method = zYD7SXW6;
        if (method != null) {
            try {
                return new W7Cnq5((View) method.invoke(null, view, viewGroup, matrix));
            } catch (IllegalAccessException unused) {
            } catch (InvocationTargetException e10) {
                throw new RuntimeException(e10.getCause());
            }
        }
        return null;
    }

    public static void eLbhX59K() {
        if (xINpNt2d) {
            return;
        }
        try {
            zDWsfFRp();
            Method declaredMethod = vo5p9AUA.getDeclaredMethod("addGhost", View.class, ViewGroup.class, Matrix.class);
            zYD7SXW6 = declaredMethod;
            declaredMethod.setAccessible(true);
        } catch (NoSuchMethodException unused) {
        }
        xINpNt2d = true;
    }

    public static void ivfTYNl() {
        if (vskcqLTQ) {
            return;
        }
        try {
            zDWsfFRp();
            Method declaredMethod = vo5p9AUA.getDeclaredMethod("removeGhost", View.class);
            fdmP9GD = declaredMethod;
            declaredMethod.setAccessible(true);
        } catch (NoSuchMethodException unused) {
        }
        vskcqLTQ = true;
    }

    public static void osx7Pl0E(View view) {
        ivfTYNl();
        Method method = fdmP9GD;
        if (method != null) {
            try {
                method.invoke(null, view);
            } catch (IllegalAccessException unused) {
            } catch (InvocationTargetException e10) {
                throw new RuntimeException(e10.getCause());
            }
        }
    }

    @Override // k09j3zn.N1vNRFSd
    public void setVisibility(int i10) {
        this.njNibPNp.setVisibility(i10);
    }

    public static void zDWsfFRp() {
        if (gmzPK) {
            return;
        }
        try {
            vo5p9AUA = Class.forName(fhlIYZ.drrvJHZTTF);
        } catch (ClassNotFoundException unused) {
        }
        gmzPK = true;
    }

    @Override // k09j3zn.N1vNRFSd
    public void eszJ2B0a(ViewGroup viewGroup, View view) {
    }
}
