package k09j3zn;

import android.graphics.Matrix;
import android.view.View;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class CWlPQz9u extends YcaGN {
    @Override // k09j3zn.RNKsLmd
    public float aXYSYCVY(View view) {
        return view.getTransitionAlpha();
    }

    @Override // k09j3zn.YcaGN, k09j3zn.RNKsLmd
    public void dUI84(View view, int i10) {
        view.setTransitionVisibility(i10);
    }

    @Override // k09j3zn.O0DWnU, k09j3zn.RNKsLmd
    public void ivfTYNl(View view, int i10, int i11, int i12, int i13) {
        view.setLeftTopRightBottom(i10, i11, i12, i13);
    }

    @Override // k09j3zn.QChIE25g, k09j3zn.RNKsLmd
    public void oZ7qYn(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }

    @Override // k09j3zn.RNKsLmd
    public void osx7Pl0E(View view, float f10) {
        view.setTransitionAlpha(f10);
    }

    @Override // k09j3zn.QChIE25g, k09j3zn.RNKsLmd
    public void rjljd6i(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }

    @Override // k09j3zn.QChIE25g, k09j3zn.RNKsLmd
    public void zDWsfFRp(View view, Matrix matrix) {
        view.setAnimationMatrix(matrix);
    }
}
