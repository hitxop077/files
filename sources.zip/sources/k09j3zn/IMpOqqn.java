package k09j3zn;

import android.view.ViewGroup;
import androidx.transition.Transition;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class IMpOqqn {
    public abstract String[] aXYSYCVY();

    public abstract long eLbhX59K(ViewGroup viewGroup, Transition transition, AliKj1I aliKj1I, AliKj1I aliKj1I2);

    public abstract void eszJ2B0a(AliKj1I aliKj1I);
}
