package k09j3zn;

import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class AliKj1I {
    public View aXYSYCVY;
    public final Map eszJ2B0a = new HashMap();
    public final ArrayList eLbhX59K = new ArrayList();

    public AliKj1I(View view) {
        this.aXYSYCVY = view;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof AliKj1I)) {
            return false;
        }
        AliKj1I aliKj1I = (AliKj1I) obj;
        return this.aXYSYCVY == aliKj1I.aXYSYCVY && this.eszJ2B0a.equals(aliKj1I.eszJ2B0a);
    }

    public int hashCode() {
        return (this.aXYSYCVY.hashCode() * 31) + this.eszJ2B0a.hashCode();
    }

    public String toString() {
        String str = (("TransitionValues@" + Integer.toHexString(hashCode()) + ":\n") + "    view = " + this.aXYSYCVY + "\n") + "    values:";
        for (String str2 : this.eszJ2B0a.keySet()) {
            str = str + "    " + str2 + ": " + this.eszJ2B0a.get(str2) + "\n";
        }
        return str;
    }
}
