package k09j3zn;

import android.animation.TypeEvaluator;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class RFQ3AA8 implements TypeEvaluator {
    public float[] eszJ2B0a;

    public RFQ3AA8(float[] fArr) {
        this.eszJ2B0a = fArr;
    }

    @Override // android.animation.TypeEvaluator
    /* JADX INFO: renamed from: eszJ2B0a, reason: merged with bridge method [inline-methods] */
    public float[] evaluate(float f10, float[] fArr, float[] fArr2) {
        float[] fArr3 = this.eszJ2B0a;
        if (fArr3 == null) {
            fArr3 = new float[fArr.length];
        }
        for (int i10 = 0; i10 < fArr3.length; i10++) {
            float f11 = fArr[i10];
            fArr3[i10] = f11 + ((fArr2[i10] - f11) * f10);
        }
        return fArr3;
    }
}
