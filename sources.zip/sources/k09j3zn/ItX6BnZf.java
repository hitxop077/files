package k09j3zn;

import android.util.SparseArray;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class ItX6BnZf {
    public final androidx.collection.MY3jR eszJ2B0a = new androidx.collection.MY3jR();
    public final SparseArray aXYSYCVY = new SparseArray();
    public final androidx.collection.Jg4Z0Io9 eLbhX59K = new androidx.collection.Jg4Z0Io9();
    public final androidx.collection.MY3jR zDWsfFRp = new androidx.collection.MY3jR();
}
