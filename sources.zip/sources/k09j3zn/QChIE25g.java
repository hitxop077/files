package k09j3zn;

import android.graphics.Matrix;
import android.view.View;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class QChIE25g extends RNKsLmd {
    public static boolean ivfTYNl = true;
    public static boolean osx7Pl0E = true;
    public static boolean zDWsfFRp = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void aXYSYCVY(View view, Matrix matrix) {
            view.transformMatrixToGlobal(matrix);
        }

        public static void eLbhX59K(View view, Matrix matrix) {
            view.transformMatrixToLocal(matrix);
        }

        public static void eszJ2B0a(View view, Matrix matrix) {
            view.setAnimationMatrix(matrix);
        }
    }

    @Override // k09j3zn.RNKsLmd
    public void oZ7qYn(View view, Matrix matrix) {
        if (ivfTYNl) {
            try {
                MY3jR.aXYSYCVY(view, matrix);
            } catch (NoSuchMethodError unused) {
                ivfTYNl = false;
            }
        }
    }

    @Override // k09j3zn.RNKsLmd
    public void rjljd6i(View view, Matrix matrix) {
        if (osx7Pl0E) {
            try {
                MY3jR.eLbhX59K(view, matrix);
            } catch (NoSuchMethodError unused) {
                osx7Pl0E = false;
            }
        }
    }

    @Override // k09j3zn.RNKsLmd
    public void zDWsfFRp(View view, Matrix matrix) {
        if (zDWsfFRp) {
            try {
                MY3jR.eszJ2B0a(view, matrix);
            } catch (NoSuchMethodError unused) {
                zDWsfFRp = false;
            }
        }
    }
}
