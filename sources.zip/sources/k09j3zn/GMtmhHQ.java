package k09j3zn;

import java.util.Arrays;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class GMtmhHQ {
    public float[] aXYSYCVY = new float[20];
    public int eLbhX59K = 0;
    public long[] eszJ2B0a;

    public GMtmhHQ() {
        long[] jArr = new long[20];
        this.eszJ2B0a = jArr;
        Arrays.fill(jArr, Long.MIN_VALUE);
    }

    public float aXYSYCVY() {
        float fELbhX59K;
        int i10 = this.eLbhX59K;
        if (i10 == 0 && this.eszJ2B0a[i10] == Long.MIN_VALUE) {
            return 0.0f;
        }
        long j10 = this.eszJ2B0a[i10];
        int i11 = 0;
        long j11 = j10;
        while (true) {
            long j12 = this.eszJ2B0a[i10];
            if (j12 == Long.MIN_VALUE) {
                break;
            }
            float f10 = j10 - j12;
            float fAbs = Math.abs(j12 - j11);
            if (f10 > 100.0f || fAbs > 40.0f) {
                break;
            }
            if (i10 == 0) {
                i10 = 20;
            }
            i10--;
            i11++;
            if (i11 >= 20) {
                break;
            }
            j11 = j12;
        }
        if (i11 < 2) {
            return 0.0f;
        }
        if (i11 == 2) {
            int i12 = this.eLbhX59K;
            int i13 = i12 == 0 ? 19 : i12 - 1;
            long[] jArr = this.eszJ2B0a;
            float f11 = jArr[i12] - jArr[i13];
            if (f11 == 0.0f) {
                return 0.0f;
            }
            float[] fArr = this.aXYSYCVY;
            fELbhX59K = (fArr[i12] - fArr[i13]) / f11;
        } else {
            int i14 = this.eLbhX59K;
            int i15 = ((i14 - i11) + 21) % 20;
            int i16 = (i14 + 21) % 20;
            long j13 = this.eszJ2B0a[i15];
            float f12 = this.aXYSYCVY[i15];
            int i17 = i15 + 1;
            float fELbhX59K2 = 0.0f;
            for (int i18 = i17 % 20; i18 != i16; i18 = (i18 + 1) % 20) {
                long j14 = this.eszJ2B0a[i18];
                float f13 = j14 - j13;
                if (f13 != 0.0f) {
                    float f14 = this.aXYSYCVY[i18];
                    float f15 = (f14 - f12) / f13;
                    fELbhX59K2 += (f15 - eLbhX59K(fELbhX59K2)) * Math.abs(f15);
                    if (i18 == i17) {
                        fELbhX59K2 *= 0.5f;
                    }
                    f12 = f14;
                    j13 = j14;
                }
            }
            fELbhX59K = eLbhX59K(fELbhX59K2);
        }
        return fELbhX59K * 1000.0f;
    }

    public final float eLbhX59K(float f10) {
        return (float) (((double) Math.signum(f10)) * Math.sqrt(Math.abs(f10) * 2.0f));
    }

    public void eszJ2B0a(long j10, float f10) {
        int i10 = (this.eLbhX59K + 1) % 20;
        this.eLbhX59K = i10;
        this.eszJ2B0a[i10] = j10;
        this.aXYSYCVY[i10] = f10;
    }
}
