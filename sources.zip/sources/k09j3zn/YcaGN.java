package k09j3zn;

import android.os.Build;
import android.view.View;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class YcaGN extends O0DWnU {
    public static boolean oZ7qYn = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void eszJ2B0a(View view, int i10) {
            view.setTransitionVisibility(i10);
        }
    }

    @Override // k09j3zn.RNKsLmd
    public void dUI84(View view, int i10) {
        if (Build.VERSION.SDK_INT == 28) {
            super.dUI84(view, i10);
        } else if (oZ7qYn) {
            try {
                MY3jR.eszJ2B0a(view, i10);
            } catch (NoSuchMethodError unused) {
                oZ7qYn = false;
            }
        }
    }
}
