package k09j3zn;

import android.graphics.Matrix;
import android.view.View;
import java.lang.reflect.Field;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class RNKsLmd {
    public static Field aXYSYCVY = null;
    public static boolean eLbhX59K = false;
    public static boolean eszJ2B0a = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void aXYSYCVY(View view, float f10) {
            view.setTransitionAlpha(f10);
        }

        public static float eszJ2B0a(View view) {
            return view.getTransitionAlpha();
        }
    }

    public float aXYSYCVY(View view) {
        if (eszJ2B0a) {
            try {
                return MY3jR.eszJ2B0a(view);
            } catch (NoSuchMethodError unused) {
                eszJ2B0a = false;
            }
        }
        return view.getAlpha();
    }

    public void dUI84(View view, int i10) {
        if (!eLbhX59K) {
            try {
                Field declaredField = View.class.getDeclaredField("mViewFlags");
                aXYSYCVY = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException unused) {
            }
            eLbhX59K = true;
        }
        Field field = aXYSYCVY;
        if (field != null) {
            try {
                aXYSYCVY.setInt(view, i10 | (field.getInt(view) & (-13)));
            } catch (IllegalAccessException unused2) {
            }
        }
    }

    public abstract void ivfTYNl(View view, int i10, int i11, int i12, int i13);

    public abstract void oZ7qYn(View view, Matrix matrix);

    public void osx7Pl0E(View view, float f10) {
        if (eszJ2B0a) {
            try {
                MY3jR.aXYSYCVY(view, f10);
                return;
            } catch (NoSuchMethodError unused) {
                eszJ2B0a = false;
            }
        }
        view.setAlpha(f10);
    }

    public abstract void rjljd6i(View view, Matrix matrix);

    public abstract void zDWsfFRp(View view, Matrix matrix);

    public void eLbhX59K(View view) {
    }

    public void eszJ2B0a(View view) {
    }
}
