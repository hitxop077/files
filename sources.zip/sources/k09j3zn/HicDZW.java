package k09j3zn;

import android.graphics.Matrix;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class HicDZW {
    public static void aXYSYCVY(View view) {
        if (Build.VERSION.SDK_INT == 28) {
            W7Cnq5.osx7Pl0E(view);
        } else {
            GU39Hcg.osx7Pl0E(view);
        }
    }

    public static N1vNRFSd eszJ2B0a(View view, ViewGroup viewGroup, Matrix matrix) {
        return Build.VERSION.SDK_INT == 28 ? W7Cnq5.aXYSYCVY(view, viewGroup, matrix) : GU39Hcg.aXYSYCVY(view, viewGroup, matrix);
    }
}
