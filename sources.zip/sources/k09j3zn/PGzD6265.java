package k09j3zn;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public interface PGzD6265 {
    void dUI84(long j10);

    long eLbhX59K();

    boolean eszJ2B0a();

    void qLLw0g(Runnable runnable);

    void zDWsfFRp();
}
