package k09j3zn;

import android.graphics.Matrix;
import android.graphics.RectF;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class Lx1jI {
    public static final Matrix eszJ2B0a = new MY3jR();

    /* JADX INFO: compiled from: Obfuscated */
    public class MY3jR extends Matrix {
        public void eszJ2B0a() {
            throw new IllegalStateException("Matrix can not be modified");
        }

        @Override // android.graphics.Matrix
        public boolean postConcat(Matrix matrix) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postRotate(float f10, float f11, float f12) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postScale(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postSkew(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postTranslate(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preConcat(Matrix matrix) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preRotate(float f10, float f11, float f12) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preScale(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preSkew(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preTranslate(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public void reset() {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void set(Matrix matrix) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public boolean setConcat(Matrix matrix, Matrix matrix2) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean setPolyToPoly(float[] fArr, int i10, float[] fArr2, int i11, int i12) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean setRectToRect(RectF rectF, RectF rectF2, Matrix.ScaleToFit scaleToFit) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public void setRotate(float f10, float f11, float f12) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setScale(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setSinCos(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setSkew(float f10, float f11, float f12, float f13) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setTranslate(float f10, float f11) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setValues(float[] fArr) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public boolean postRotate(float f10) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postScale(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean postSkew(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preRotate(float f10) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preScale(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public boolean preSkew(float f10, float f11) {
            eszJ2B0a();
            return false;
        }

        @Override // android.graphics.Matrix
        public void setRotate(float f10) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setScale(float f10, float f11) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setSinCos(float f10, float f11) {
            eszJ2B0a();
        }

        @Override // android.graphics.Matrix
        public void setSkew(float f10, float f11) {
            eszJ2B0a();
        }
    }
}
