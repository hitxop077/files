package k09j3zn;

import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class JQAVH {
    public static boolean eszJ2B0a = true;

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void eszJ2B0a(ImageView imageView, Matrix matrix) {
            imageView.animateTransform(matrix);
        }
    }

    public static void aXYSYCVY(ImageView imageView, Matrix matrix) {
        if (eszJ2B0a) {
            try {
                MY3jR.eszJ2B0a(imageView, matrix);
            } catch (NoSuchMethodError unused) {
                eszJ2B0a = false;
            }
        }
    }

    public static void eszJ2B0a(ImageView imageView, Matrix matrix) {
        if (Build.VERSION.SDK_INT >= 29) {
            MY3jR.eszJ2B0a(imageView, matrix);
            return;
        }
        if (matrix != null) {
            aXYSYCVY(imageView, matrix);
            return;
        }
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setBounds(0, 0, (imageView.getWidth() - imageView.getPaddingLeft()) - imageView.getPaddingRight(), (imageView.getHeight() - imageView.getPaddingTop()) - imageView.getPaddingBottom());
            imageView.invalidate();
        }
    }
}
