package k09j3zn;

import android.animation.ObjectAnimator;
import android.animation.TypeConverter;
import android.graphics.Path;
import android.util.Property;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract class Bv3FS {

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static <T, V> ObjectAnimator eszJ2B0a(T t10, Property<T, V> property, Path path) {
            return ObjectAnimator.ofObject(t10, property, (TypeConverter) null, path);
        }
    }

    public static ObjectAnimator eszJ2B0a(Object obj, Property property, Path path) {
        return MY3jR.eszJ2B0a(obj, property, path);
    }
}
