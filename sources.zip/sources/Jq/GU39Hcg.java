package Jq;

import java.io.EOFException;
import java.io.IOException;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import p090cr.FsJiNjAN;
import p090cr.SFMiYa;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public class GU39Hcg extends SFMiYa {
    public final Function1 njNibPNp;
    public boolean vo5p9AUA;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public GU39Hcg(FsJiNjAN delegate, Function1 onException) {
        super(delegate);
        Intrinsics.checkNotNullParameter(delegate, "delegate");
        Intrinsics.checkNotNullParameter(onException, "onException");
        this.njNibPNp = onException;
    }

    @Override // p090cr.SFMiYa, p090cr.FsJiNjAN, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        try {
            super.close();
        } catch (IOException e10) {
            this.vo5p9AUA = true;
            this.njNibPNp.invoke(e10);
        }
    }

    @Override // p090cr.SFMiYa, p090cr.FsJiNjAN, java.io.Flushable
    public void flush() {
        if (this.vo5p9AUA) {
            return;
        }
        try {
            super.flush();
        } catch (IOException e10) {
            this.vo5p9AUA = true;
            this.njNibPNp.invoke(e10);
        }
    }

    @Override // p090cr.SFMiYa, p090cr.FsJiNjAN
    public void write(p090cr.N1vNRFSd source, long j10) throws EOFException {
        Intrinsics.checkNotNullParameter(source, "source");
        if (this.vo5p9AUA) {
            source.skip(j10);
            return;
        }
        try {
            super.write(source, j10);
        } catch (IOException e10) {
            this.vo5p9AUA = true;
            this.njNibPNp.invoke(e10);
        }
    }
}
