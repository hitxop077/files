package Jq;

import p090cr.FsJiNjAN;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes5.dex */
public interface RFQ3AA8 {
    void abort();

    FsJiNjAN body();
}
