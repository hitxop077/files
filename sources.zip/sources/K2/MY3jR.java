package K2;

import androidx.paging.ECK8f;
import java.util.List;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.HicDZW;
import p672w2.U080F;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes9.dex */
public interface MY3jR {
    HicDZW ajI4U(String str);

    Object c1pvtY(String str, Continuation continuation);

    Object ceTXybVl(long j10, int i10, Continuation continuation);

    Object d3penA(long j10, boolean z10, Continuation continuation);

    Object dhljW(long j10, boolean z10, Continuation continuation);

    Object fk0tr(long j10, Continuation continuation);

    Object gOqrBax(long j10, boolean z10, Continuation continuation);

    ECK8f gbFHS2(String str, String str2);

    Object htsFy(List list, Continuation continuation);

    Object m7KrVcu(long j10, Continuation continuation);

    Object myMyVU(List list, Continuation continuation);

    Object nZaGFW(p552s2.MY3jR mY3jR, Continuation continuation);

    HicDZW oFBLnx7(U080F u080f, String str);

    Object oqgjooY(List list, Continuation continuation);

    Object pGHyP(String str, U080F u080f, Continuation continuation);

    Object sMxPLer(Continuation continuation);

    Object sVizei(long j10, Long l10, Continuation continuation);

    HicDZW supclA(String str, int i10);

    Object yiLiUsMh(long j10, String str, Continuation continuation);
}
