package k6vab;

import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class XR9Xco implements wz8j2kn.AAnYcst {
    public final p134eb.MY3jR aXYSYCVY;
    public final p134eb.MY3jR eLbhX59K;
    public final p134eb.MY3jR ivfTYNl;
    public final p134eb.MY3jR zDWsfFRp;

    public XR9Xco(p134eb.MY3jR mY3jR, p134eb.MY3jR mY3jR2, p134eb.MY3jR mY3jR3, p134eb.MY3jR mY3jR4) {
        this.aXYSYCVY = mY3jR;
        this.eLbhX59K = mY3jR2;
        this.zDWsfFRp = mY3jR3;
        this.ivfTYNl = mY3jR4;
    }

    public static Jg4Z0Io9 eLbhX59K(Executor executor, cjh72uj.LNd998w lNd998w, H8UuVVi h8UuVVi, n78gzh.AAnYcst aAnYcst) {
        return new Jg4Z0Io9(executor, lNd998w, h8UuVVi, aAnYcst);
    }

    public static XR9Xco eszJ2B0a(p134eb.MY3jR mY3jR, p134eb.MY3jR mY3jR2, p134eb.MY3jR mY3jR3, p134eb.MY3jR mY3jR4) {
        return new XR9Xco(mY3jR, mY3jR2, mY3jR3, mY3jR4);
    }

    @Override // p134eb.MY3jR
    /* JADX INFO: renamed from: aXYSYCVY, reason: merged with bridge method [inline-methods] */
    public Jg4Z0Io9 get() {
        return eLbhX59K((Executor) this.aXYSYCVY.get(), (cjh72uj.LNd998w) this.eLbhX59K.get(), (H8UuVVi) this.zDWsfFRp.get(), (n78gzh.AAnYcst) this.ivfTYNl.get());
    }
}
