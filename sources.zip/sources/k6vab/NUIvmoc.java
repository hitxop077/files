package k6vab;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class NUIvmoc {
    public final a3q01h.N1vNRFSd aXYSYCVY;
    public final ksex6.MY3jR dUI84;
    public final cjh72uj.LNd998w eLbhX59K;
    public final Context eszJ2B0a;
    public final Executor ivfTYNl;
    public final ksex6.MY3jR oZ7qYn;
    public final n78gzh.AAnYcst osx7Pl0E;
    public final cjh72uj.RFQ3AA8 rjljd6i;
    public final H8UuVVi zDWsfFRp;

    public NUIvmoc(Context context, a3q01h.N1vNRFSd n1vNRFSd, cjh72uj.LNd998w lNd998w, H8UuVVi h8UuVVi, Executor executor, n78gzh.AAnYcst aAnYcst, ksex6.MY3jR mY3jR, ksex6.MY3jR mY3jR2, cjh72uj.RFQ3AA8 rfq3aa8) {
        this.eszJ2B0a = context;
        this.aXYSYCVY = n1vNRFSd;
        this.eLbhX59K = lNd998w;
        this.zDWsfFRp = h8UuVVi;
        this.ivfTYNl = executor;
        this.osx7Pl0E = aAnYcst;
        this.dUI84 = mY3jR;
        this.oZ7qYn = mY3jR2;
        this.rjljd6i = rfq3aa8;
    }

    public static /* synthetic */ Object aXYSYCVY(NUIvmoc nUIvmoc, Iterable iterable, hd07qwtb.VI3TfJlk vI3TfJlk, long j10) {
        nUIvmoc.eLbhX59K.vtWRdB6(iterable);
        nUIvmoc.eLbhX59K.kOOHmYh(vI3TfJlk, nUIvmoc.dUI84.eszJ2B0a() + j10);
        return null;
    }

    public static /* synthetic */ Object dUI84(NUIvmoc nUIvmoc, hd07qwtb.VI3TfJlk vI3TfJlk, long j10) {
        nUIvmoc.eLbhX59K.kOOHmYh(vI3TfJlk, nUIvmoc.dUI84.eszJ2B0a() + j10);
        return null;
    }

    public static /* synthetic */ Object eLbhX59K(NUIvmoc nUIvmoc) {
        nUIvmoc.rjljd6i.eszJ2B0a();
        return null;
    }

    public static /* synthetic */ Object ivfTYNl(NUIvmoc nUIvmoc, Iterable iterable) {
        nUIvmoc.eLbhX59K.yRR2N(iterable);
        return null;
    }

    public static /* synthetic */ Object oZ7qYn(NUIvmoc nUIvmoc, Map map) {
        nUIvmoc.getClass();
        for (Map.Entry entry : map.entrySet()) {
            nUIvmoc.rjljd6i.osx7Pl0E(((Integer) entry.getValue()).intValue(), tl6r9inj.RFQ3AA8.AAnYcst.INVALID_PAYLOD, (String) entry.getKey());
        }
        return null;
    }

    public static /* synthetic */ Object osx7Pl0E(NUIvmoc nUIvmoc, hd07qwtb.VI3TfJlk vI3TfJlk, int i10) {
        nUIvmoc.zDWsfFRp.eszJ2B0a(vI3TfJlk, i10 + 1);
        return null;
    }

    public static /* synthetic */ void rjljd6i(final NUIvmoc nUIvmoc, final hd07qwtb.VI3TfJlk vI3TfJlk, final int i10, Runnable runnable) {
        nUIvmoc.getClass();
        try {
            n78gzh.AAnYcst aAnYcst = nUIvmoc.osx7Pl0E;
            final cjh72uj.LNd998w lNd998w = nUIvmoc.eLbhX59K;
            Objects.requireNonNull(lNd998w);
            aAnYcst.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.HicDZW
                @Override // n78gzh.AAnYcst.MY3jR
                public final Object execute() {
                    return Integer.valueOf(lNd998w.aNB31q());
                }
            });
            if (nUIvmoc.qLLw0g()) {
                nUIvmoc.q1ORKN(vI3TfJlk, i10);
            } else {
                nUIvmoc.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.JQAVH
                    @Override // n78gzh.AAnYcst.MY3jR
                    public final Object execute() {
                        return NUIvmoc.osx7Pl0E(this.eszJ2B0a, vI3TfJlk, i10);
                    }
                });
            }
        } catch (n78gzh.MY3jR unused) {
            nUIvmoc.zDWsfFRp.eszJ2B0a(vI3TfJlk, i10 + 1);
        } finally {
            runnable.run();
        }
    }

    public a3q01h.W7Cnq5 q1ORKN(final hd07qwtb.VI3TfJlk vI3TfJlk, int i10) {
        a3q01h.W7Cnq5 w7Cnq5EszJ2B0a;
        a3q01h.VVpVRy vVpVRy = this.aXYSYCVY.get(vI3TfJlk.aXYSYCVY());
        a3q01h.W7Cnq5 w7Cnq5IvfTYNl = a3q01h.W7Cnq5.ivfTYNl(0L);
        final long j10 = 0;
        while (((Boolean) this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.Lx1jI
            @Override // n78gzh.AAnYcst.MY3jR
            public final Object execute() {
                return Boolean.valueOf(this.eszJ2B0a.eLbhX59K.akPTh9t(vI3TfJlk));
            }
        })).booleanValue()) {
            final Iterable iterable = (Iterable) this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.Bv3FS
                @Override // n78gzh.AAnYcst.MY3jR
                public final Object execute() {
                    return this.eszJ2B0a.eLbhX59K.baBvqf(vI3TfJlk);
                }
            });
            if (!iterable.iterator().hasNext()) {
                return w7Cnq5IvfTYNl;
            }
            if (vVpVRy == null) {
                ofx4z1.MY3jR.aXYSYCVY("Uploader", "Unknown backend for %s, deleting event batch for it...", vI3TfJlk);
                w7Cnq5EszJ2B0a = a3q01h.W7Cnq5.eszJ2B0a();
            } else {
                ArrayList arrayList = new ArrayList();
                Iterator it2 = iterable.iterator();
                while (it2.hasNext()) {
                    arrayList.add(((cjh72uj.Lx1jI) it2.next()).aXYSYCVY());
                }
                if (vI3TfJlk.ivfTYNl()) {
                    arrayList.add(zPJpxWz(vVpVRy));
                }
                w7Cnq5EszJ2B0a = vVpVRy.eszJ2B0a(a3q01h.XbU7b.eszJ2B0a().aXYSYCVY(arrayList).eLbhX59K(vI3TfJlk.eLbhX59K()).eszJ2B0a());
            }
            w7Cnq5IvfTYNl = w7Cnq5EszJ2B0a;
            if (w7Cnq5IvfTYNl.eLbhX59K() == a3q01h.W7Cnq5.MY3jR.TRANSIENT_ERROR) {
                final hd07qwtb.VI3TfJlk vI3TfJlk2 = vI3TfJlk;
                this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.VVpVRy
                    @Override // n78gzh.AAnYcst.MY3jR
                    public final Object execute() {
                        return NUIvmoc.aXYSYCVY(this.eszJ2B0a, iterable, vI3TfJlk2, j10);
                    }
                });
                this.zDWsfFRp.aXYSYCVY(vI3TfJlk2, i10 + 1, true);
                return w7Cnq5IvfTYNl;
            }
            hd07qwtb.VI3TfJlk vI3TfJlk3 = vI3TfJlk;
            this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.SFMiYa
                @Override // n78gzh.AAnYcst.MY3jR
                public final Object execute() {
                    return NUIvmoc.ivfTYNl(this.eszJ2B0a, iterable);
                }
            });
            if (w7Cnq5IvfTYNl.eLbhX59K() == a3q01h.W7Cnq5.MY3jR.OK) {
                long jMax = Math.max(j10, w7Cnq5IvfTYNl.aXYSYCVY());
                if (vI3TfJlk3.ivfTYNl()) {
                    this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.U080F
                        @Override // n78gzh.AAnYcst.MY3jR
                        public final Object execute() {
                            return NUIvmoc.eLbhX59K(this.eszJ2B0a);
                        }
                    });
                }
                j10 = jMax;
            } else if (w7Cnq5IvfTYNl.eLbhX59K() == a3q01h.W7Cnq5.MY3jR.INVALID_PAYLOAD) {
                final HashMap map = new HashMap();
                Iterator it3 = iterable.iterator();
                while (it3.hasNext()) {
                    String strUYRSwDm = ((cjh72uj.Lx1jI) it3.next()).aXYSYCVY().uYRSwDm();
                    if (map.containsKey(strUYRSwDm)) {
                        map.put(strUYRSwDm, Integer.valueOf(((Integer) map.get(strUYRSwDm)).intValue() + 1));
                    } else {
                        map.put(strUYRSwDm, 1);
                    }
                }
                this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.VI3TfJlk
                    @Override // n78gzh.AAnYcst.MY3jR
                    public final Object execute() {
                        return NUIvmoc.oZ7qYn(this.eszJ2B0a, map);
                    }
                });
            }
            vI3TfJlk = vI3TfJlk3;
        }
        final hd07qwtb.VI3TfJlk vI3TfJlk4 = vI3TfJlk;
        this.osx7Pl0E.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.Gyx10a
            @Override // n78gzh.AAnYcst.MY3jR
            public final Object execute() {
                return NUIvmoc.dUI84(this.eszJ2B0a, vI3TfJlk4, j10);
            }
        });
        return w7Cnq5IvfTYNl;
    }

    public boolean qLLw0g() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.eszJ2B0a.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void uTIfLNK0(final hd07qwtb.VI3TfJlk vI3TfJlk, final int i10, final Runnable runnable) {
        this.ivfTYNl.execute(new Runnable() { // from class: k6vab.W7Cnq5
            @Override // java.lang.Runnable
            public final void run() {
                NUIvmoc.rjljd6i(this.njNibPNp, vI3TfJlk, i10, runnable);
            }
        });
    }

    public hd07qwtb.HicDZW zPJpxWz(a3q01h.VVpVRy vVpVRy) {
        n78gzh.AAnYcst aAnYcst = this.osx7Pl0E;
        final cjh72uj.RFQ3AA8 rfq3aa8 = this.rjljd6i;
        Objects.requireNonNull(rfq3aa8);
        return vVpVRy.aXYSYCVY(hd07qwtb.HicDZW.eszJ2B0a().rjljd6i(this.dUI84.eszJ2B0a()).yxejkub(this.oZ7qYn.eszJ2B0a()).uYRSwDm("GDT_CLIENT_METRICS").oZ7qYn(new hd07qwtb.GU39Hcg(qszy7qz.RFQ3AA8.aXYSYCVY("proto"), ((tl6r9inj.MY3jR) aAnYcst.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.GU39Hcg
            @Override // n78gzh.AAnYcst.MY3jR
            public final Object execute() {
                return rfq3aa8.ivfTYNl();
            }
        })).osx7Pl0E())).zDWsfFRp());
    }
}
