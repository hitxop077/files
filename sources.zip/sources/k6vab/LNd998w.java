package k6vab;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import android.util.Base64;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.zip.Adler32;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class LNd998w implements H8UuVVi {
    public final cjh72uj.LNd998w aXYSYCVY;
    public final XbU7b eLbhX59K;
    public final Context eszJ2B0a;

    public LNd998w(Context context, cjh72uj.LNd998w lNd998w, XbU7b xbU7b) {
        this.eszJ2B0a = context;
        this.aXYSYCVY = lNd998w;
        this.eLbhX59K = xbU7b;
    }

    @Override // k6vab.H8UuVVi
    public void aXYSYCVY(hd07qwtb.VI3TfJlk vI3TfJlk, int i10, boolean z10) {
        ComponentName componentName = new ComponentName(this.eszJ2B0a, (Class<?>) JobInfoSchedulerService.class);
        JobScheduler jobScheduler = (JobScheduler) this.eszJ2B0a.getSystemService("jobscheduler");
        int iELbhX59K = eLbhX59K(vI3TfJlk);
        if (!z10 && zDWsfFRp(jobScheduler, iELbhX59K, i10)) {
            ofx4z1.MY3jR.aXYSYCVY("JobInfoScheduler", "Upload for context %s is already scheduled. Returning...", vI3TfJlk);
            return;
        }
        long jYRhi0ouT = this.aXYSYCVY.yRhi0ouT(vI3TfJlk);
        JobInfo.Builder builderELbhX59K = this.eLbhX59K.eLbhX59K(new JobInfo.Builder(iELbhX59K, componentName), vI3TfJlk.zDWsfFRp(), jYRhi0ouT, i10);
        PersistableBundle persistableBundle = new PersistableBundle();
        persistableBundle.putInt("attemptNumber", i10);
        persistableBundle.putString("backendName", vI3TfJlk.aXYSYCVY());
        persistableBundle.putInt("priority", ry9sq.MY3jR.eszJ2B0a(vI3TfJlk.zDWsfFRp()));
        if (vI3TfJlk.eLbhX59K() != null) {
            persistableBundle.putString(p497q7.SFMiYa.EXTRAS, Base64.encodeToString(vI3TfJlk.eLbhX59K(), 0));
        }
        builderELbhX59K.setExtras(persistableBundle);
        ofx4z1.MY3jR.eLbhX59K("JobInfoScheduler", "Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d", vI3TfJlk, Integer.valueOf(iELbhX59K), Long.valueOf(this.eLbhX59K.dUI84(vI3TfJlk.zDWsfFRp(), jYRhi0ouT, i10)), Long.valueOf(jYRhi0ouT), Integer.valueOf(i10));
        jobScheduler.schedule(builderELbhX59K.build());
    }

    public int eLbhX59K(hd07qwtb.VI3TfJlk vI3TfJlk) {
        Adler32 adler32 = new Adler32();
        adler32.update(this.eszJ2B0a.getPackageName().getBytes(Charset.forName("UTF-8")));
        adler32.update(vI3TfJlk.aXYSYCVY().getBytes(Charset.forName("UTF-8")));
        adler32.update(ByteBuffer.allocate(4).putInt(ry9sq.MY3jR.eszJ2B0a(vI3TfJlk.zDWsfFRp())).array());
        if (vI3TfJlk.eLbhX59K() != null) {
            adler32.update(vI3TfJlk.eLbhX59K());
        }
        return (int) adler32.getValue();
    }

    @Override // k6vab.H8UuVVi
    public void eszJ2B0a(hd07qwtb.VI3TfJlk vI3TfJlk, int i10) {
        aXYSYCVY(vI3TfJlk, i10, false);
    }

    public final boolean zDWsfFRp(JobScheduler jobScheduler, int i10, int i11) {
        for (JobInfo jobInfo : jobScheduler.getAllPendingJobs()) {
            int i12 = jobInfo.getExtras().getInt("attemptNumber");
            if (jobInfo.getId() == i10) {
                if (i12 >= i11) {
                    return true;
                }
            }
        }
        return false;
    }
}
