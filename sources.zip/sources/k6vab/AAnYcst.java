package k6vab;

import java.util.Map;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class AAnYcst extends XbU7b {
    public final Map aXYSYCVY;
    public final ksex6.MY3jR eszJ2B0a;

    public AAnYcst(ksex6.MY3jR mY3jR, Map map) {
        if (mY3jR == null) {
            throw new NullPointerException("Null clock");
        }
        this.eszJ2B0a = mY3jR;
        if (map == null) {
            throw new NullPointerException("Null values");
        }
        this.aXYSYCVY = map;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof XbU7b) {
            XbU7b xbU7b = (XbU7b) obj;
            if (this.eszJ2B0a.equals(xbU7b.ivfTYNl()) && this.aXYSYCVY.equals(xbU7b.oZ7qYn())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((this.eszJ2B0a.hashCode() ^ 1000003) * 1000003) ^ this.aXYSYCVY.hashCode();
    }

    @Override // k6vab.XbU7b
    public ksex6.MY3jR ivfTYNl() {
        return this.eszJ2B0a;
    }

    @Override // k6vab.XbU7b
    public Map oZ7qYn() {
        return this.aXYSYCVY;
    }

    public String toString() {
        return "SchedulerConfig{clock=" + this.eszJ2B0a + ", values=" + this.aXYSYCVY + "}";
    }
}
