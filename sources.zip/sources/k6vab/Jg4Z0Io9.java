package k6vab;

import java.util.Iterator;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public class Jg4Z0Io9 {
    public final cjh72uj.LNd998w aXYSYCVY;
    public final H8UuVVi eLbhX59K;
    public final Executor eszJ2B0a;
    public final n78gzh.AAnYcst zDWsfFRp;

    public Jg4Z0Io9(Executor executor, cjh72uj.LNd998w lNd998w, H8UuVVi h8UuVVi, n78gzh.AAnYcst aAnYcst) {
        this.eszJ2B0a = executor;
        this.aXYSYCVY = lNd998w;
        this.eLbhX59K = h8UuVVi;
        this.zDWsfFRp = aAnYcst;
    }

    public static /* synthetic */ Object eszJ2B0a(Jg4Z0Io9 jg4Z0Io9) {
        Iterator it2 = jg4Z0Io9.aXYSYCVY.hykDcAq().iterator();
        while (it2.hasNext()) {
            jg4Z0Io9.eLbhX59K.eszJ2B0a((hd07qwtb.VI3TfJlk) it2.next(), 1);
        }
        return null;
    }

    public void eLbhX59K() {
        this.eszJ2B0a.execute(new Runnable() { // from class: k6vab.AXWzg4r
            @Override // java.lang.Runnable
            public final void run() {
                Jg4Z0Io9 jg4Z0Io9 = this.njNibPNp;
                jg4Z0Io9.zDWsfFRp.dUI84(new n78gzh.AAnYcst.MY3jR() { // from class: k6vab.JmXmcSi
                    @Override // n78gzh.AAnYcst.MY3jR
                    public final Object execute() {
                        return Jg4Z0Io9.eszJ2B0a(jg4Z0Io9);
                    }
                });
            }
        });
    }
}
