package k6vab;

import java.util.Set;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class RFQ3AA8 extends XbU7b.AAnYcst {
    public final long aXYSYCVY;
    public final Set eLbhX59K;
    public final long eszJ2B0a;

    /* JADX INFO: compiled from: Obfuscated */
    public static final class AAnYcst extends XbU7b.AAnYcst.MY3jR {
        public Long aXYSYCVY;
        public Set eLbhX59K;
        public Long eszJ2B0a;

        @Override // k6vab.XbU7b.AAnYcst.MY3jR
        public XbU7b.AAnYcst.MY3jR aXYSYCVY(long j10) {
            this.eszJ2B0a = Long.valueOf(j10);
            return this;
        }

        @Override // k6vab.XbU7b.AAnYcst.MY3jR
        public XbU7b.AAnYcst.MY3jR eLbhX59K(Set set) {
            if (set == null) {
                throw new NullPointerException("Null flags");
            }
            this.eLbhX59K = set;
            return this;
        }

        @Override // k6vab.XbU7b.AAnYcst.MY3jR
        public XbU7b.AAnYcst eszJ2B0a() {
            String str = "";
            if (this.eszJ2B0a == null) {
                str = " delta";
            }
            if (this.aXYSYCVY == null) {
                str = str + " maxAllowedDelay";
            }
            if (this.eLbhX59K == null) {
                str = str + " flags";
            }
            if (str.isEmpty()) {
                return new RFQ3AA8(this.eszJ2B0a.longValue(), this.aXYSYCVY.longValue(), this.eLbhX59K);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // k6vab.XbU7b.AAnYcst.MY3jR
        public XbU7b.AAnYcst.MY3jR zDWsfFRp(long j10) {
            this.aXYSYCVY = Long.valueOf(j10);
            return this;
        }
    }

    @Override // k6vab.XbU7b.AAnYcst
    public long aXYSYCVY() {
        return this.eszJ2B0a;
    }

    @Override // k6vab.XbU7b.AAnYcst
    public Set eLbhX59K() {
        return this.eLbhX59K;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof XbU7b.AAnYcst) {
            XbU7b.AAnYcst aAnYcst = (XbU7b.AAnYcst) obj;
            if (this.eszJ2B0a == aAnYcst.aXYSYCVY() && this.aXYSYCVY == aAnYcst.zDWsfFRp() && this.eLbhX59K.equals(aAnYcst.eLbhX59K())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        long j10 = this.eszJ2B0a;
        int i10 = (((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003;
        long j11 = this.aXYSYCVY;
        return ((i10 ^ ((int) ((j11 >>> 32) ^ j11))) * 1000003) ^ this.eLbhX59K.hashCode();
    }

    public String toString() {
        return "ConfigValue{delta=" + this.eszJ2B0a + ", maxAllowedDelay=" + this.aXYSYCVY + ", flags=" + this.eLbhX59K + "}";
    }

    @Override // k6vab.XbU7b.AAnYcst
    public long zDWsfFRp() {
        return this.aXYSYCVY;
    }

    public RFQ3AA8(long j10, long j11, Set set) {
        this.eszJ2B0a = j10;
        this.aXYSYCVY = j11;
        this.eLbhX59K = set;
    }
}
