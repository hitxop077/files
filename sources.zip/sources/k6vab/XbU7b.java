package k6vab;

import android.app.job.JobInfo;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.one97.storefront.view.customviews.bonusextension.BonusExtensionDefaults;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class XbU7b {

    /* JADX INFO: compiled from: Obfuscated */
    public static abstract class AAnYcst {

        /* JADX INFO: compiled from: Obfuscated */
        public static abstract class MY3jR {
            public abstract MY3jR aXYSYCVY(long j10);

            public abstract MY3jR eLbhX59K(Set set);

            public abstract AAnYcst eszJ2B0a();

            public abstract MY3jR zDWsfFRp(long j10);
        }

        public static MY3jR eszJ2B0a() {
            return new k6vab.RFQ3AA8.AAnYcst().eLbhX59K(Collections.EMPTY_SET);
        }

        public abstract long aXYSYCVY();

        public abstract Set eLbhX59K();

        public abstract long zDWsfFRp();
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public Map aXYSYCVY = new HashMap();
        public ksex6.MY3jR eszJ2B0a;

        public XbU7b aXYSYCVY() {
            if (this.eszJ2B0a == null) {
                throw new NullPointerException("missing required property: clock");
            }
            if (this.aXYSYCVY.keySet().size() < qszy7qz.XbU7b.values().length) {
                throw new IllegalStateException("Not all priorities have been configured");
            }
            Map map = this.aXYSYCVY;
            this.aXYSYCVY = new HashMap();
            return XbU7b.zDWsfFRp(this.eszJ2B0a, map);
        }

        public MY3jR eLbhX59K(ksex6.MY3jR mY3jR) {
            this.eszJ2B0a = mY3jR;
            return this;
        }

        public MY3jR eszJ2B0a(qszy7qz.XbU7b xbU7b, AAnYcst aAnYcst) {
            this.aXYSYCVY.put(xbU7b, aAnYcst);
            return this;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public enum RFQ3AA8 {
        NETWORK_UNMETERED,
        DEVICE_IDLE,
        DEVICE_CHARGING
    }

    public static MY3jR aXYSYCVY() {
        return new MY3jR();
    }

    public static XbU7b osx7Pl0E(ksex6.MY3jR mY3jR) {
        return aXYSYCVY().eszJ2B0a(qszy7qz.XbU7b.DEFAULT, AAnYcst.eszJ2B0a().aXYSYCVY(30000L).zDWsfFRp(BonusExtensionDefaults.MILLIS_PER_DAY).eszJ2B0a()).eszJ2B0a(qszy7qz.XbU7b.HIGHEST, AAnYcst.eszJ2B0a().aXYSYCVY(1000L).zDWsfFRp(BonusExtensionDefaults.MILLIS_PER_DAY).eszJ2B0a()).eszJ2B0a(qszy7qz.XbU7b.VERY_LOW, AAnYcst.eszJ2B0a().aXYSYCVY(BonusExtensionDefaults.MILLIS_PER_DAY).zDWsfFRp(BonusExtensionDefaults.MILLIS_PER_DAY).eLbhX59K(rjljd6i(RFQ3AA8.DEVICE_IDLE)).eszJ2B0a()).eLbhX59K(mY3jR).aXYSYCVY();
    }

    public static Set rjljd6i(Object... objArr) {
        return Collections.unmodifiableSet(new HashSet(Arrays.asList(objArr)));
    }

    public static XbU7b zDWsfFRp(ksex6.MY3jR mY3jR, Map map) {
        return new k6vab.AAnYcst(mY3jR, map);
    }

    public long dUI84(qszy7qz.XbU7b xbU7b, long j10, int i10) {
        long jEszJ2B0a = j10 - ivfTYNl().eszJ2B0a();
        AAnYcst aAnYcst = (AAnYcst) oZ7qYn().get(xbU7b);
        return Math.min(Math.max(eszJ2B0a(i10, aAnYcst.aXYSYCVY()), jEszJ2B0a), aAnYcst.zDWsfFRp());
    }

    public JobInfo.Builder eLbhX59K(JobInfo.Builder builder, qszy7qz.XbU7b xbU7b, long j10, int i10) {
        builder.setMinimumLatency(dUI84(xbU7b, j10, i10));
        zPJpxWz(builder, ((AAnYcst) oZ7qYn().get(xbU7b)).eLbhX59K());
        return builder;
    }

    public final long eszJ2B0a(int i10, long j10) {
        int i11 = i10 - 1;
        return (long) (Math.pow(3.0d, i11) * j10 * Math.max(1.0d, Math.log(10000.0d) / Math.log((j10 > 1 ? j10 : 2L) * ((long) i11))));
    }

    public abstract ksex6.MY3jR ivfTYNl();

    public abstract Map oZ7qYn();

    public final void zPJpxWz(JobInfo.Builder builder, Set set) {
        if (set.contains(RFQ3AA8.NETWORK_UNMETERED)) {
            builder.setRequiredNetworkType(2);
        } else {
            builder.setRequiredNetworkType(1);
        }
        if (set.contains(RFQ3AA8.DEVICE_CHARGING)) {
            builder.setRequiresCharging(true);
        }
        if (set.contains(RFQ3AA8.DEVICE_IDLE)) {
            builder.setRequiresDeviceIdle(true);
        }
    }
}
