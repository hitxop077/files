package k6vab;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public interface H8UuVVi {
    void aXYSYCVY(hd07qwtb.VI3TfJlk vI3TfJlk, int i10, boolean z10);

    void eszJ2B0a(hd07qwtb.VI3TfJlk vI3TfJlk, int i10);
}
