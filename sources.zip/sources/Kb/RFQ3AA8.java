package Kb;

import kotlin.jvm.internal.Intrinsics;
import net.one97.paytm.gtm.GTMLoader;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class RFQ3AA8 implements p136ed.AAnYcst {
    @Override // p136ed.AAnYcst
    public boolean getBoolean(String key, boolean z10) {
        Intrinsics.checkNotNullParameter(key, "key");
        return GTMLoader.pGHyP().mK94T(key, z10);
    }

    @Override // p136ed.AAnYcst
    public int getInteger(String key, int i10) {
        Intrinsics.checkNotNullParameter(key, "key");
        return GTMLoader.pGHyP().pIeOLUO0(key, i10);
    }

    @Override // p136ed.AAnYcst
    public String getString(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        String strMO2eijT = GTMLoader.pGHyP().mO2eijT(key);
        Intrinsics.checkNotNullExpressionValue(strMO2eijT, "getString(...)");
        return strMO2eijT;
    }

    @Override // p136ed.AAnYcst
    public String getString(String key, String value) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(value, "value");
        String strKHUok5hr = GTMLoader.pGHyP().kHUok5hr(key, value);
        Intrinsics.checkNotNullExpressionValue(strKHUok5hr, "getString(...)");
        return strKHUok5hr;
    }
}
