package Kb;

import p136ed.XbU7b;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class AAnYcst {
    public static final AAnYcst eszJ2B0a = new AAnYcst();

    public static final void eszJ2B0a() {
        XbU7b.eszJ2B0a.dUI84(new MY3jR());
    }
}
