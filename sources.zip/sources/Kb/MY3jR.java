package Kb;

import android.app.Activity;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public final class MY3jR implements p136ed.RFQ3AA8, p136ed.AAnYcst, p136ed.MY3jR {
    public final /* synthetic */ RFQ3AA8 eszJ2B0a = new RFQ3AA8();
    public final /* synthetic */ LNd998w aXYSYCVY = new LNd998w();

    @Override // p136ed.MY3jR
    public void eszJ2B0a(Activity activity) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        this.aXYSYCVY.eszJ2B0a(activity);
    }

    @Override // p136ed.MY3jR
    public Map getActivityMap() {
        return this.aXYSYCVY.getActivityMap();
    }

    @Override // p136ed.AAnYcst
    public boolean getBoolean(String key, boolean z10) {
        Intrinsics.checkNotNullParameter(key, "key");
        return this.eszJ2B0a.getBoolean(key, z10);
    }

    @Override // p136ed.AAnYcst
    public int getInteger(String key, int i10) {
        Intrinsics.checkNotNullParameter(key, "key");
        return this.eszJ2B0a.getInteger(key, i10);
    }

    @Override // p136ed.AAnYcst
    public String getString(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return this.eszJ2B0a.getString(key);
    }

    @Override // p136ed.AAnYcst
    public String getString(String key, String value) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(value, "value");
        return this.eszJ2B0a.getString(key, value);
    }
}
