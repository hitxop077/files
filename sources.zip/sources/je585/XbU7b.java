package je585;

import kotlin.UByte;
import l1vhbl.HicDZW;
import t3jmd7k.ZKBAd;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class XbU7b {
    public int aXYSYCVY;
    public final ZKBAd eszJ2B0a = new ZKBAd(8);

    public boolean aXYSYCVY(HicDZW hicDZW) {
        long length = hicDZW.getLength();
        long j10 = 1024;
        if (length != -1 && length <= 1024) {
            j10 = length;
        }
        int i10 = (int) j10;
        hicDZW.oZ7qYn(this.eszJ2B0a.zDWsfFRp(), 0, 4);
        long jFk0tr = this.eszJ2B0a.fk0tr();
        this.aXYSYCVY = 4;
        while (jFk0tr != 440786851) {
            int i11 = this.aXYSYCVY + 1;
            this.aXYSYCVY = i11;
            if (i11 == i10) {
                return false;
            }
            hicDZW.oZ7qYn(this.eszJ2B0a.zDWsfFRp(), 0, 1);
            jFk0tr = ((jFk0tr << 8) & (-256)) | ((long) (this.eszJ2B0a.zDWsfFRp()[0] & UByte.MAX_VALUE));
        }
        long jEszJ2B0a = eszJ2B0a(hicDZW);
        long j11 = this.aXYSYCVY;
        if (jEszJ2B0a != Long.MIN_VALUE && (length == -1 || j11 + jEszJ2B0a < length)) {
            while (true) {
                int i12 = this.aXYSYCVY;
                long j12 = j11 + jEszJ2B0a;
                if (i12 < j12) {
                    if (eszJ2B0a(hicDZW) == Long.MIN_VALUE) {
                        return false;
                    }
                    long jEszJ2B0a2 = eszJ2B0a(hicDZW);
                    if (jEszJ2B0a2 < 0 || jEszJ2B0a2 > 2147483647L) {
                        return false;
                    }
                    if (jEszJ2B0a2 != 0) {
                        int i13 = (int) jEszJ2B0a2;
                        hicDZW.q1ORKN(i13);
                        this.aXYSYCVY += i13;
                    }
                } else if (i12 == j12) {
                    return true;
                }
            }
        }
        return false;
    }

    public final long eszJ2B0a(HicDZW hicDZW) {
        int i10 = 0;
        hicDZW.oZ7qYn(this.eszJ2B0a.zDWsfFRp(), 0, 1);
        int i11 = this.eszJ2B0a.zDWsfFRp()[0] & UByte.MAX_VALUE;
        if (i11 == 0) {
            return Long.MIN_VALUE;
        }
        int i12 = 128;
        int i13 = 0;
        while ((i11 & i12) == 0) {
            i12 >>= 1;
            i13++;
        }
        int i14 = i11 & (~i12);
        hicDZW.oZ7qYn(this.eszJ2B0a.zDWsfFRp(), 1, i13);
        while (i10 < i13) {
            i10++;
            i14 = (this.eszJ2B0a.zDWsfFRp()[i10] & UByte.MAX_VALUE) + (i14 << 8);
        }
        this.aXYSYCVY += i13 + 1;
        return i14;
    }
}
