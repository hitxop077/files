package je585;

import l1vhbl.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface RFQ3AA8 {
    void aXYSYCVY(AAnYcst aAnYcst);

    boolean eszJ2B0a(HicDZW hicDZW);

    void reset();
}
