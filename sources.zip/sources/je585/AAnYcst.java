package je585;

import l1vhbl.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public interface AAnYcst {
    void aXYSYCVY(int i10, double d10);

    boolean dUI84(int i10);

    void eLbhX59K(int i10, long j10);

    void eszJ2B0a(int i10);

    void ivfTYNl(int i10, long j10, long j11);

    void oZ7qYn(int i10, int i11, HicDZW hicDZW);

    int osx7Pl0E(int i10);

    void zDWsfFRp(int i10, String str);
}
