package je585;

import com.google.android.exoplayer2.IGWlX;
import java.util.ArrayDeque;
import kotlin.UByte;
import l1vhbl.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class MY3jR implements RFQ3AA8 {
    public long dUI84;
    public int ivfTYNl;
    public int osx7Pl0E;
    public je585.AAnYcst zDWsfFRp;
    public final byte[] eszJ2B0a = new byte[8];
    public final ArrayDeque aXYSYCVY = new ArrayDeque();
    public final W7Cnq5 eLbhX59K = new W7Cnq5();

    /* JADX INFO: compiled from: Obfuscated */
    public static final class AAnYcst {
        public final long aXYSYCVY;
        public final int eszJ2B0a;

        public AAnYcst(int i10, long j10) {
            this.eszJ2B0a = i10;
            this.aXYSYCVY = j10;
        }
    }

    public static String osx7Pl0E(HicDZW hicDZW, int i10) {
        if (i10 == 0) {
            return "";
        }
        byte[] bArr = new byte[i10];
        hicDZW.readFully(bArr, 0, i10);
        while (i10 > 0 && bArr[i10 - 1] == 0) {
            i10--;
        }
        return new String(bArr, 0, i10);
    }

    @Override // je585.RFQ3AA8
    public void aXYSYCVY(je585.AAnYcst aAnYcst) {
        this.zDWsfFRp = aAnYcst;
    }

    public final long eLbhX59K(HicDZW hicDZW) {
        hicDZW.zPJpxWz();
        while (true) {
            hicDZW.oZ7qYn(this.eszJ2B0a, 0, 4);
            int iELbhX59K = W7Cnq5.eLbhX59K(this.eszJ2B0a[0]);
            if (iELbhX59K != -1 && iELbhX59K <= 4) {
                int iEszJ2B0a = (int) W7Cnq5.eszJ2B0a(this.eszJ2B0a, iELbhX59K, false);
                if (this.zDWsfFRp.dUI84(iEszJ2B0a)) {
                    hicDZW.uTIfLNK0(iELbhX59K);
                    return iEszJ2B0a;
                }
            }
            hicDZW.uTIfLNK0(1);
        }
    }

    @Override // je585.RFQ3AA8
    public boolean eszJ2B0a(HicDZW hicDZW) throws IGWlX {
        t3jmd7k.MY3jR.oZ7qYn(this.zDWsfFRp);
        while (true) {
            AAnYcst aAnYcst = (AAnYcst) this.aXYSYCVY.peek();
            if (aAnYcst != null && hicDZW.getPosition() >= aAnYcst.aXYSYCVY) {
                this.zDWsfFRp.eszJ2B0a(((AAnYcst) this.aXYSYCVY.pop()).eszJ2B0a);
                return true;
            }
            if (this.ivfTYNl == 0) {
                long jZDWsfFRp = this.eLbhX59K.zDWsfFRp(hicDZW, true, false, 4);
                if (jZDWsfFRp == -2) {
                    jZDWsfFRp = eLbhX59K(hicDZW);
                }
                if (jZDWsfFRp == -1) {
                    return false;
                }
                this.osx7Pl0E = (int) jZDWsfFRp;
                this.ivfTYNl = 1;
            }
            if (this.ivfTYNl == 1) {
                this.dUI84 = this.eLbhX59K.zDWsfFRp(hicDZW, false, true, 8);
                this.ivfTYNl = 2;
            }
            int iOsx7Pl0E = this.zDWsfFRp.osx7Pl0E(this.osx7Pl0E);
            if (iOsx7Pl0E != 0) {
                if (iOsx7Pl0E == 1) {
                    long position = hicDZW.getPosition();
                    this.aXYSYCVY.push(new AAnYcst(this.osx7Pl0E, this.dUI84 + position));
                    this.zDWsfFRp.ivfTYNl(this.osx7Pl0E, position, this.dUI84);
                    this.ivfTYNl = 0;
                    return true;
                }
                if (iOsx7Pl0E == 2) {
                    long j10 = this.dUI84;
                    if (j10 <= 8) {
                        this.zDWsfFRp.eLbhX59K(this.osx7Pl0E, ivfTYNl(hicDZW, (int) j10));
                        this.ivfTYNl = 0;
                        return true;
                    }
                    StringBuilder sb2 = new StringBuilder(42);
                    sb2.append("Invalid integer size: ");
                    sb2.append(j10);
                    throw IGWlX.createForMalformedContainer(sb2.toString(), null);
                }
                if (iOsx7Pl0E == 3) {
                    long j11 = this.dUI84;
                    if (j11 <= 2147483647L) {
                        this.zDWsfFRp.zDWsfFRp(this.osx7Pl0E, osx7Pl0E(hicDZW, (int) j11));
                        this.ivfTYNl = 0;
                        return true;
                    }
                    StringBuilder sb3 = new StringBuilder(41);
                    sb3.append("String element size: ");
                    sb3.append(j11);
                    throw IGWlX.createForMalformedContainer(sb3.toString(), null);
                }
                if (iOsx7Pl0E == 4) {
                    this.zDWsfFRp.oZ7qYn(this.osx7Pl0E, (int) this.dUI84, hicDZW);
                    this.ivfTYNl = 0;
                    return true;
                }
                if (iOsx7Pl0E != 5) {
                    StringBuilder sb4 = new StringBuilder(32);
                    sb4.append("Invalid element type ");
                    sb4.append(iOsx7Pl0E);
                    throw IGWlX.createForMalformedContainer(sb4.toString(), null);
                }
                long j12 = this.dUI84;
                if (j12 == 4 || j12 == 8) {
                    this.zDWsfFRp.aXYSYCVY(this.osx7Pl0E, zDWsfFRp(hicDZW, (int) j12));
                    this.ivfTYNl = 0;
                    return true;
                }
                StringBuilder sb5 = new StringBuilder(40);
                sb5.append("Invalid float size: ");
                sb5.append(j12);
                throw IGWlX.createForMalformedContainer(sb5.toString(), null);
            }
            hicDZW.uTIfLNK0((int) this.dUI84);
            this.ivfTYNl = 0;
        }
    }

    public final long ivfTYNl(HicDZW hicDZW, int i10) {
        hicDZW.readFully(this.eszJ2B0a, 0, i10);
        long j10 = 0;
        for (int i11 = 0; i11 < i10; i11++) {
            j10 = (j10 << 8) | ((long) (this.eszJ2B0a[i11] & UByte.MAX_VALUE));
        }
        return j10;
    }

    @Override // je585.RFQ3AA8
    public void reset() {
        this.ivfTYNl = 0;
        this.aXYSYCVY.clear();
        this.eLbhX59K.ivfTYNl();
    }

    public final double zDWsfFRp(HicDZW hicDZW, int i10) {
        long jIvfTYNl = ivfTYNl(hicDZW, i10);
        return i10 == 4 ? Float.intBitsToFloat((int) jIvfTYNl) : Double.longBitsToDouble(jIvfTYNl);
    }
}
