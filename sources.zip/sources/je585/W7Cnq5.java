package je585;

import kotlin.UByte;
import l1vhbl.HicDZW;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes8.dex */
public final class W7Cnq5 {
    public static final long[] zDWsfFRp = {128, 64, 32, 16, 8, 4, 2, 1};
    public int aXYSYCVY;
    public int eLbhX59K;
    public final byte[] eszJ2B0a = new byte[8];

    public static int eLbhX59K(int i10) {
        int i11 = 0;
        while (true) {
            long[] jArr = zDWsfFRp;
            if (i11 >= jArr.length) {
                return -1;
            }
            if ((jArr[i11] & ((long) i10)) != 0) {
                return i11 + 1;
            }
            i11++;
        }
    }

    public static long eszJ2B0a(byte[] bArr, int i10, boolean z10) {
        long j10 = ((long) bArr[0]) & 255;
        if (z10) {
            j10 &= ~zDWsfFRp[i10 - 1];
        }
        for (int i11 = 1; i11 < i10; i11++) {
            j10 = (j10 << 8) | (((long) bArr[i11]) & 255);
        }
        return j10;
    }

    public int aXYSYCVY() {
        return this.eLbhX59K;
    }

    public void ivfTYNl() {
        this.aXYSYCVY = 0;
        this.eLbhX59K = 0;
    }

    public long zDWsfFRp(HicDZW hicDZW, boolean z10, boolean z11, int i10) {
        if (this.aXYSYCVY == 0) {
            if (!hicDZW.ivfTYNl(this.eszJ2B0a, 0, 1, z10)) {
                return -1L;
            }
            int iELbhX59K = eLbhX59K(this.eszJ2B0a[0] & UByte.MAX_VALUE);
            this.eLbhX59K = iELbhX59K;
            if (iELbhX59K == -1) {
                throw new IllegalStateException("No valid varint length mask found");
            }
            this.aXYSYCVY = 1;
        }
        int i11 = this.eLbhX59K;
        if (i11 > i10) {
            this.aXYSYCVY = 0;
            return -2L;
        }
        if (i11 != 1) {
            hicDZW.readFully(this.eszJ2B0a, 1, i11 - 1);
        }
        this.aXYSYCVY = 0;
        return eszJ2B0a(this.eszJ2B0a, this.eLbhX59K, z11);
    }
}
