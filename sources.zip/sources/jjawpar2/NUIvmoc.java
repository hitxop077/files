package jjawpar2;

import android.content.pm.ShortcutManager;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class NUIvmoc {
    public static /* bridge */ /* synthetic */ Class eszJ2B0a() {
        return ShortcutManager.class;
    }
}
