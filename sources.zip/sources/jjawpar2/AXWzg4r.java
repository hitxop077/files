package jjawpar2;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public abstract /* synthetic */ class AXWzg4r {
}
