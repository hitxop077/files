package jjawpar2;

import android.content.Context;
import android.content.pm.ShortcutInfo;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class AAnYcst {
    public static /* synthetic */ ShortcutInfo.Builder eszJ2B0a(Context context, String str) {
        return new ShortcutInfo.Builder(context, str);
    }
}
