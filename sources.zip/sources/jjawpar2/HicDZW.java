package jjawpar2;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class HicDZW {
}
