package jjawpar2;

import android.app.Person;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import ypmo8tp.RkdvoZ;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes7.dex */
public class Gyx10a {
    public String aXYSYCVY;
    public CharSequence dUI84;
    public Intent[] eLbhX59K;
    public Context eszJ2B0a;
    public CharSequence ivfTYNl;
    public boolean mTWLV = true;
    public IconCompat oZ7qYn;
    public CharSequence osx7Pl0E;
    public fc6oya3h.LNd998w q1ORKN;
    public Set qLLw0g;
    public int rJCQt16;
    public boolean rjljd6i;
    public boolean uTIfLNK0;
    public int uYRSwDm;
    public PersistableBundle yxejkub;
    public ComponentName zDWsfFRp;
    public RkdvoZ[] zPJpxWz;

    /* JADX INFO: compiled from: Obfuscated */
    public static class AAnYcst {
        public boolean aXYSYCVY;
        public Set eLbhX59K;
        public final Gyx10a eszJ2B0a;
        public Uri ivfTYNl;
        public Map zDWsfFRp;

        public AAnYcst(Context context, String str) {
            Gyx10a gyx10a = new Gyx10a();
            this.eszJ2B0a = gyx10a;
            gyx10a.eszJ2B0a = context;
            gyx10a.aXYSYCVY = str;
        }

        public AAnYcst aXYSYCVY(IconCompat iconCompat) {
            this.eszJ2B0a.oZ7qYn = iconCompat;
            return this;
        }

        public AAnYcst eLbhX59K(Intent intent) {
            return zDWsfFRp(new Intent[]{intent});
        }

        public Gyx10a eszJ2B0a() {
            if (TextUtils.isEmpty(this.eszJ2B0a.ivfTYNl)) {
                throw new IllegalArgumentException("Shortcut must have a non-empty label");
            }
            Gyx10a gyx10a = this.eszJ2B0a;
            Intent[] intentArr = gyx10a.eLbhX59K;
            if (intentArr == null || intentArr.length == 0) {
                throw new IllegalArgumentException("Shortcut must have an intent");
            }
            if (this.aXYSYCVY) {
                if (gyx10a.q1ORKN == null) {
                    gyx10a.q1ORKN = new fc6oya3h.LNd998w(gyx10a.aXYSYCVY);
                }
                this.eszJ2B0a.uTIfLNK0 = true;
            }
            if (this.eLbhX59K != null) {
                Gyx10a gyx10a2 = this.eszJ2B0a;
                if (gyx10a2.qLLw0g == null) {
                    gyx10a2.qLLw0g = new HashSet();
                }
                this.eszJ2B0a.qLLw0g.addAll(this.eLbhX59K);
            }
            if (this.zDWsfFRp != null) {
                Gyx10a gyx10a3 = this.eszJ2B0a;
                if (gyx10a3.yxejkub == null) {
                    gyx10a3.yxejkub = new PersistableBundle();
                }
                for (String str : this.zDWsfFRp.keySet()) {
                    Map map = (Map) this.zDWsfFRp.get(str);
                    this.eszJ2B0a.yxejkub.putStringArray(str, (String[]) map.keySet().toArray(new String[0]));
                    for (String str2 : map.keySet()) {
                        List list = (List) map.get(str2);
                        this.eszJ2B0a.yxejkub.putStringArray(str + "/" + str2, list == null ? new String[0] : (String[]) list.toArray(new String[0]));
                    }
                }
            }
            if (this.ivfTYNl != null) {
                Gyx10a gyx10a4 = this.eszJ2B0a;
                if (gyx10a4.yxejkub == null) {
                    gyx10a4.yxejkub = new PersistableBundle();
                }
                this.eszJ2B0a.yxejkub.putString("extraSliceUri", mn8uqm.LNd998w.eszJ2B0a(this.ivfTYNl));
            }
            return this.eszJ2B0a;
        }

        public AAnYcst ivfTYNl(CharSequence charSequence) {
            this.eszJ2B0a.ivfTYNl = charSequence;
            return this;
        }

        public AAnYcst zDWsfFRp(Intent[] intentArr) {
            this.eszJ2B0a.eLbhX59K = intentArr;
            return this;
        }
    }

    /* JADX INFO: compiled from: Obfuscated */
    public static class MY3jR {
        public static void eszJ2B0a(ShortcutInfo.Builder builder, int i10) {
            builder.setExcludedFromSurfaces(i10);
        }
    }

    public final PersistableBundle aXYSYCVY() {
        if (this.yxejkub == null) {
            this.yxejkub = new PersistableBundle();
        }
        RkdvoZ[] rkdvoZArr = this.zPJpxWz;
        if (rkdvoZArr != null && rkdvoZArr.length > 0) {
            this.yxejkub.putInt("extraPersonCount", rkdvoZArr.length);
            int i10 = 0;
            while (i10 < this.zPJpxWz.length) {
                PersistableBundle persistableBundle = this.yxejkub;
                StringBuilder sb2 = new StringBuilder();
                sb2.append("extraPerson_");
                int i11 = i10 + 1;
                sb2.append(i11);
                persistableBundle.putPersistableBundle(sb2.toString(), this.zPJpxWz[i10].zPJpxWz());
                i10 = i11;
            }
        }
        fc6oya3h.LNd998w lNd998w = this.q1ORKN;
        if (lNd998w != null) {
            this.yxejkub.putString("extraLocusId", lNd998w.eszJ2B0a());
        }
        this.yxejkub.putBoolean("extraLongLived", this.uTIfLNK0);
        return this.yxejkub;
    }

    public boolean eLbhX59K(int i10) {
        return (i10 & this.rJCQt16) != 0;
    }

    public Intent eszJ2B0a(Intent intent) {
        Intent[] intentArr = this.eLbhX59K;
        intent.putExtra("android.intent.extra.shortcut.INTENT", intentArr[intentArr.length - 1]).putExtra("android.intent.extra.shortcut.NAME", this.ivfTYNl.toString());
        if (this.oZ7qYn != null) {
            Drawable activityIcon = null;
            if (this.rjljd6i) {
                PackageManager packageManager = this.eszJ2B0a.getPackageManager();
                ComponentName componentName = this.zDWsfFRp;
                if (componentName != null) {
                    try {
                        activityIcon = packageManager.getActivityIcon(componentName);
                    } catch (PackageManager.NameNotFoundException unused) {
                    }
                }
                if (activityIcon == null) {
                    activityIcon = this.eszJ2B0a.getApplicationInfo().loadIcon(packageManager);
                }
            }
            this.oZ7qYn.eszJ2B0a(intent, activityIcon, this.eszJ2B0a);
        }
        return intent;
    }

    public ShortcutInfo zDWsfFRp() {
        GU39Hcg.eszJ2B0a();
        ShortcutInfo.Builder intents = jjawpar2.AAnYcst.eszJ2B0a(this.eszJ2B0a, this.aXYSYCVY).setShortLabel(this.ivfTYNl).setIntents(this.eLbhX59K);
        IconCompat iconCompat = this.oZ7qYn;
        if (iconCompat != null) {
            intents.setIcon(iconCompat.sMxPLer(this.eszJ2B0a));
        }
        if (!TextUtils.isEmpty(this.osx7Pl0E)) {
            intents.setLongLabel(this.osx7Pl0E);
        }
        if (!TextUtils.isEmpty(this.dUI84)) {
            intents.setDisabledMessage(this.dUI84);
        }
        ComponentName componentName = this.zDWsfFRp;
        if (componentName != null) {
            intents.setActivity(componentName);
        }
        Set set = this.qLLw0g;
        if (set != null) {
            intents.setCategories(set);
        }
        intents.setRank(this.uYRSwDm);
        PersistableBundle persistableBundle = this.yxejkub;
        if (persistableBundle != null) {
            intents.setExtras(persistableBundle);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            RkdvoZ[] rkdvoZArr = this.zPJpxWz;
            if (rkdvoZArr != null && rkdvoZArr.length > 0) {
                int length = rkdvoZArr.length;
                Person[] personArr = new Person[length];
                for (int i10 = 0; i10 < length; i10++) {
                    personArr[i10] = this.zPJpxWz[i10].oZ7qYn();
                }
                intents.setPersons(personArr);
            }
            fc6oya3h.LNd998w lNd998w = this.q1ORKN;
            if (lNd998w != null) {
                intents.setLocusId(lNd998w.eLbhX59K());
            }
            intents.setLongLived(this.uTIfLNK0);
        } else {
            intents.setExtras(aXYSYCVY());
        }
        if (Build.VERSION.SDK_INT >= 33) {
            MY3jR.eszJ2B0a(intents, this.rJCQt16);
        }
        return intents.build();
    }
}
