package jjawpar2;

import android.content.pm.PackageInfo;
import android.os.Build;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract class MY3jR {

    /* JADX INFO: renamed from: jjawpar2.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static class C1479MY3jR {
        public static long eszJ2B0a(PackageInfo packageInfo) {
            return packageInfo.getLongVersionCode();
        }
    }

    public static long eszJ2B0a(PackageInfo packageInfo) {
        return Build.VERSION.SDK_INT >= 28 ? C1479MY3jR.eszJ2B0a(packageInfo) : packageInfo.versionCode;
    }
}
