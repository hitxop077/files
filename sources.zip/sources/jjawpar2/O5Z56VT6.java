package jjawpar2;

import android.content.pm.ShortcutManager;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class O5Z56VT6 {
    public static /* bridge */ /* synthetic */ ShortcutManager eszJ2B0a(Object obj) {
        return (ShortcutManager) obj;
    }
}
