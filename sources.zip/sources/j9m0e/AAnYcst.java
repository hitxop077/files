package j9m0e;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class AAnYcst {
    public final ConcurrentHashMap eszJ2B0a = new ConcurrentHashMap();

    public final void aXYSYCVY(String appId, List gateKeeperList) {
        Intrinsics.checkNotNullParameter(appId, "appId");
        Intrinsics.checkNotNullParameter(gateKeeperList, "gateKeeperList");
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        Iterator it2 = gateKeeperList.iterator();
        while (it2.hasNext()) {
            MY3jR mY3jR = (MY3jR) it2.next();
            concurrentHashMap.put(mY3jR.eszJ2B0a(), mY3jR);
        }
        this.eszJ2B0a.put(appId, concurrentHashMap);
    }

    public final List eszJ2B0a(String appId) {
        Intrinsics.checkNotNullParameter(appId, "appId");
        ConcurrentHashMap concurrentHashMap = (ConcurrentHashMap) this.eszJ2B0a.get(appId);
        if (concurrentHashMap == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(concurrentHashMap.size());
        Iterator it2 = concurrentHashMap.entrySet().iterator();
        while (it2.hasNext()) {
            arrayList.add((MY3jR) ((Map.Entry) it2.next()).getValue());
        }
        return arrayList;
    }
}
