package j9m0e;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes.dex */
public final class MY3jR {
    public final boolean aXYSYCVY;
    public final String eszJ2B0a;

    public MY3jR(String name, boolean z10) {
        Intrinsics.checkNotNullParameter(name, "name");
        this.eszJ2B0a = name;
        this.aXYSYCVY = z10;
    }

    public final boolean aXYSYCVY() {
        return this.aXYSYCVY;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MY3jR)) {
            return false;
        }
        MY3jR mY3jR = (MY3jR) obj;
        return Intrinsics.areEqual(this.eszJ2B0a, mY3jR.eszJ2B0a) && this.aXYSYCVY == mY3jR.aXYSYCVY;
    }

    public final String eszJ2B0a() {
        return this.eszJ2B0a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r1v1, types: [int] */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v3 */
    public int hashCode() {
        int iHashCode = this.eszJ2B0a.hashCode() * 31;
        boolean z10 = this.aXYSYCVY;
        ?? r10 = z10;
        if (z10) {
            r10 = 1;
        }
        return iHashCode + r10;
    }

    public String toString() {
        return "GateKeeper(name=" + this.eszJ2B0a + ", value=" + this.aXYSYCVY + ')';
    }
}
