package K1;

import android.view.View;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes8.dex */
public class MY3jR extends WeakReference {
    public MY3jR(View view) {
        super(view);
    }
}
