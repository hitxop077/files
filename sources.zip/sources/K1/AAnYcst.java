package K1;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes8.dex */
public class AAnYcst extends WeakReference {
    public AAnYcst(WebView webView) {
        super(webView);
    }
}
