package Jr;

import Or.VX4rr;
import java.util.Hashtable;
import org.bouncycastle.crypto.IMpOqqn;
import org.bouncycastle.crypto.LksRT6;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class W7Cnq5 implements ZKBAd {
    public static Hashtable oZ7qYn;
    public int aXYSYCVY;
    public byte[] dUI84;
    public int eLbhX59K;
    public LksRT6 eszJ2B0a;
    public wt.Lx1jI ivfTYNl;
    public byte[] osx7Pl0E;
    public wt.Lx1jI zDWsfFRp;

    static {
        Hashtable hashtable = new Hashtable();
        oZ7qYn = hashtable;
        hashtable.put("GOST3411", wt.HicDZW.ivfTYNl(32));
        oZ7qYn.put("MD2", wt.HicDZW.ivfTYNl(16));
        oZ7qYn.put("MD4", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("MD5", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("RIPEMD128", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("RIPEMD160", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("SHA-1", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("SHA-224", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("SHA-256", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("SHA-384", wt.HicDZW.ivfTYNl(128));
        oZ7qYn.put("SHA-512", wt.HicDZW.ivfTYNl(128));
        oZ7qYn.put("Tiger", wt.HicDZW.ivfTYNl(64));
        oZ7qYn.put("Whirlpool", wt.HicDZW.ivfTYNl(64));
    }

    public W7Cnq5(LksRT6 lksRT6) {
        this(lksRT6, eszJ2B0a(lksRT6));
    }

    public static void eLbhX59K(byte[] bArr, int i10, byte b10) {
        for (int i11 = 0; i11 < i10; i11++) {
            bArr[i11] = (byte) (bArr[i11] ^ b10);
        }
    }

    public static int eszJ2B0a(LksRT6 lksRT6) {
        if (lksRT6 instanceof IMpOqqn) {
            return ((IMpOqqn) lksRT6).getByteLength();
        }
        Integer num = (Integer) oZ7qYn.get(lksRT6.getAlgorithmName());
        if (num != null) {
            return num.intValue();
        }
        throw new IllegalArgumentException("unknown digest passed: " + lksRT6.getAlgorithmName());
    }

    public LksRT6 aXYSYCVY() {
        return this.eszJ2B0a;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        this.eszJ2B0a.doFinal(this.dUI84, this.eLbhX59K);
        wt.Lx1jI lx1jI = this.ivfTYNl;
        if (lx1jI != null) {
            ((wt.Lx1jI) this.eszJ2B0a).eszJ2B0a(lx1jI);
            LksRT6 lksRT6 = this.eszJ2B0a;
            lksRT6.update(this.dUI84, this.eLbhX59K, lksRT6.getDigestSize());
        } else {
            LksRT6 lksRT7 = this.eszJ2B0a;
            byte[] bArr2 = this.dUI84;
            lksRT7.update(bArr2, 0, bArr2.length);
        }
        int iDoFinal = this.eszJ2B0a.doFinal(bArr, i10);
        int i11 = this.eLbhX59K;
        while (true) {
            byte[] bArr3 = this.dUI84;
            if (i11 >= bArr3.length) {
                break;
            }
            bArr3[i11] = 0;
            i11++;
        }
        wt.Lx1jI lx1jI2 = this.zDWsfFRp;
        if (lx1jI2 != null) {
            ((wt.Lx1jI) this.eszJ2B0a).eszJ2B0a(lx1jI2);
            return iDoFinal;
        }
        LksRT6 lksRT8 = this.eszJ2B0a;
        byte[] bArr4 = this.osx7Pl0E;
        lksRT8.update(bArr4, 0, bArr4.length);
        return iDoFinal;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.eszJ2B0a.getAlgorithmName() + "/HMAC";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        byte[] bArr;
        this.eszJ2B0a.reset();
        byte[] bArrAXYSYCVY = ((VX4rr) jqavh).aXYSYCVY();
        int length = bArrAXYSYCVY.length;
        if (length > this.eLbhX59K) {
            this.eszJ2B0a.update(bArrAXYSYCVY, 0, length);
            this.eszJ2B0a.doFinal(this.osx7Pl0E, 0);
            length = this.aXYSYCVY;
        } else {
            System.arraycopy(bArrAXYSYCVY, 0, this.osx7Pl0E, 0, length);
        }
        while (true) {
            bArr = this.osx7Pl0E;
            if (length >= bArr.length) {
                break;
            }
            bArr[length] = 0;
            length++;
        }
        System.arraycopy(bArr, 0, this.dUI84, 0, this.eLbhX59K);
        eLbhX59K(this.osx7Pl0E, this.eLbhX59K, (byte) 54);
        eLbhX59K(this.dUI84, this.eLbhX59K, (byte) 92);
        LksRT6 lksRT6 = this.eszJ2B0a;
        if (lksRT6 instanceof wt.Lx1jI) {
            wt.Lx1jI lx1jICopy = ((wt.Lx1jI) lksRT6).copy();
            this.ivfTYNl = lx1jICopy;
            ((LksRT6) lx1jICopy).update(this.dUI84, 0, this.eLbhX59K);
        }
        LksRT6 lksRT7 = this.eszJ2B0a;
        byte[] bArr2 = this.osx7Pl0E;
        lksRT7.update(bArr2, 0, bArr2.length);
        LksRT6 lksRT8 = this.eszJ2B0a;
        if (lksRT8 instanceof wt.Lx1jI) {
            this.zDWsfFRp = ((wt.Lx1jI) lksRT8).copy();
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        wt.Lx1jI lx1jI = this.zDWsfFRp;
        if (lx1jI != null) {
            ((wt.Lx1jI) this.eszJ2B0a).eszJ2B0a(lx1jI);
            return;
        }
        this.eszJ2B0a.reset();
        LksRT6 lksRT6 = this.eszJ2B0a;
        byte[] bArr = this.osx7Pl0E;
        lksRT6.update(bArr, 0, bArr.length);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.eszJ2B0a.update(b10);
    }

    public W7Cnq5(LksRT6 lksRT6, int i10) {
        this.eszJ2B0a = lksRT6;
        int digestSize = lksRT6.getDigestSize();
        this.aXYSYCVY = digestSize;
        this.eLbhX59K = i10;
        this.osx7Pl0E = new byte[i10];
        this.dUI84 = new byte[i10 + digestSize];
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        this.eszJ2B0a.update(bArr, i10, i11);
    }
}
