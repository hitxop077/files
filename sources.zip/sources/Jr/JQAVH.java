package Jr;

import Er.UvR31Td;
import Or.VX4rr;
import org.bouncycastle.crypto.Kuh1mAB7;
import org.bouncycastle.crypto.ZKBAd;
import wt.AXWzg4r;

/* JADX INFO: loaded from: classes5.dex */
public class JQAVH implements ZKBAd, Kuh1mAB7 {
    public static final byte[] dUI84 = new byte[100];
    public final int aXYSYCVY;
    public final int eLbhX59K;
    public final Er.LNd998w eszJ2B0a;
    public boolean ivfTYNl;
    public boolean osx7Pl0E;
    public byte[] zDWsfFRp;

    public JQAVH(int i10, byte[] bArr) {
        this.eszJ2B0a = new Er.LNd998w(i10, AXWzg4r.dUI84("KMAC"), bArr);
        this.aXYSYCVY = i10;
        this.eLbhX59K = (i10 * 2) / 8;
    }

    public static byte[] eLbhX59K(byte[] bArr) {
        return wt.MY3jR.mTWLV(UvR31Td.eLbhX59K(bArr.length * 8), bArr);
    }

    @Override // org.bouncycastle.crypto.Kuh1mAB7
    public int aXYSYCVY(byte[] bArr, int i10, int i11) {
        if (this.osx7Pl0E) {
            if (!this.ivfTYNl) {
                throw new IllegalStateException("KMAC not initialized");
            }
            byte[] bArrZDWsfFRp = UvR31Td.zDWsfFRp(i11 * 8);
            this.eszJ2B0a.update(bArrZDWsfFRp, 0, bArrZDWsfFRp.length);
        }
        int iAXYSYCVY = this.eszJ2B0a.aXYSYCVY(bArr, i10, i11);
        reset();
        return iAXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        if (this.osx7Pl0E) {
            if (!this.ivfTYNl) {
                throw new IllegalStateException("KMAC not initialized");
            }
            byte[] bArrZDWsfFRp = UvR31Td.zDWsfFRp(getMacSize() * 8);
            this.eszJ2B0a.update(bArrZDWsfFRp, 0, bArrZDWsfFRp.length);
        }
        int iAXYSYCVY = this.eszJ2B0a.aXYSYCVY(bArr, i10, getMacSize());
        reset();
        return iAXYSYCVY;
    }

    public final void eszJ2B0a(byte[] bArr, int i10) {
        byte[] bArrELbhX59K = UvR31Td.eLbhX59K(i10);
        update(bArrELbhX59K, 0, bArrELbhX59K.length);
        byte[] bArrELbhX59K2 = eLbhX59K(bArr);
        update(bArrELbhX59K2, 0, bArrELbhX59K2.length);
        int length = i10 - ((bArrELbhX59K.length + bArrELbhX59K2.length) % i10);
        if (length <= 0 || length == i10) {
            return;
        }
        while (true) {
            byte[] bArr2 = dUI84;
            if (length <= bArr2.length) {
                update(bArr2, 0, length);
                return;
            } else {
                update(bArr2, 0, bArr2.length);
                length -= bArr2.length;
            }
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "KMAC" + this.eszJ2B0a.getAlgorithmName().substring(6);
    }

    @Override // org.bouncycastle.crypto.IMpOqqn
    public int getByteLength() {
        return this.eszJ2B0a.getByteLength();
    }

    @Override // org.bouncycastle.crypto.LksRT6
    public int getDigestSize() {
        return this.eLbhX59K;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.eLbhX59K;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        this.zDWsfFRp = wt.MY3jR.oZ7qYn(((VX4rr) jqavh).aXYSYCVY());
        this.ivfTYNl = true;
        reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.eszJ2B0a.reset();
        byte[] bArr = this.zDWsfFRp;
        if (bArr != null) {
            eszJ2B0a(bArr, this.aXYSYCVY == 128 ? 168 : 136);
        }
        this.osx7Pl0E = true;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        if (!this.ivfTYNl) {
            throw new IllegalStateException("KMAC not initialized");
        }
        this.eszJ2B0a.update(b10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (!this.ivfTYNl) {
            throw new IllegalStateException("KMAC not initialized");
        }
        this.eszJ2B0a.update(bArr, i10, i11);
    }
}
