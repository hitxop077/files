package Jr;

import Gr.KpPYc30;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public final class NUIvmoc implements ZKBAd {
    public int aXYSYCVY;
    public int ivfTYNl;
    public int osx7Pl0E;
    public KpPYc30 zDWsfFRp;
    public final AAnYcst eszJ2B0a = new AAnYcst();
    public final int[] eLbhX59K = new int[2];

    public static class AAnYcst extends KpPYc30 {
        public AAnYcst() {
        }

        public int oyaOvpOs() {
            return super.rJCQt16();
        }
    }

    public final int aXYSYCVY(int i10) {
        int[] iArr = this.eLbhX59K;
        int i11 = this.ivfTYNl;
        int i12 = iArr[i11];
        if (i10 == 0) {
            return i12;
        }
        int i13 = iArr[(i11 + 1) % iArr.length];
        return (i13 >>> (32 - i10)) | (i12 << i10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        zDWsfFRp();
        int iAXYSYCVY = this.aXYSYCVY ^ aXYSYCVY(this.osx7Pl0E * 8);
        this.aXYSYCVY = iAXYSYCVY;
        int iEszJ2B0a = iAXYSYCVY ^ eszJ2B0a();
        this.aXYSYCVY = iEszJ2B0a;
        KpPYc30.uYRSwDm(iEszJ2B0a, bArr, i10);
        reset();
        return getMacSize();
    }

    public final void eLbhX59K() {
        int i10 = 0;
        this.aXYSYCVY = 0;
        while (true) {
            int[] iArr = this.eLbhX59K;
            if (i10 >= iArr.length - 1) {
                this.ivfTYNl = iArr.length - 1;
                this.osx7Pl0E = 3;
                return;
            } else {
                iArr[i10] = this.eszJ2B0a.oyaOvpOs();
                i10++;
            }
        }
    }

    public final int eszJ2B0a() {
        if (this.osx7Pl0E != 0) {
            return this.eszJ2B0a.oyaOvpOs();
        }
        int i10 = this.ivfTYNl + 1;
        int[] iArr = this.eLbhX59K;
        int length = i10 % iArr.length;
        this.ivfTYNl = length;
        return iArr[length];
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "Zuc128Mac";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 4;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        this.eszJ2B0a.init(true, jqavh);
        this.zDWsfFRp = (KpPYc30) this.eszJ2B0a.copy();
        eLbhX59K();
    }

    public final void ivfTYNl(int i10) {
        this.aXYSYCVY = aXYSYCVY(i10) ^ this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        KpPYc30 kpPYc30 = this.zDWsfFRp;
        if (kpPYc30 != null) {
            this.eszJ2B0a.eszJ2B0a(kpPYc30);
        }
        eLbhX59K();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        zDWsfFRp();
        int i10 = this.osx7Pl0E * 8;
        int i11 = 128;
        int i12 = 0;
        while (i11 > 0) {
            if ((b10 & i11) != 0) {
                ivfTYNl(i10 + i12);
            }
            i11 >>= 1;
            i12++;
        }
    }

    public final void zDWsfFRp() {
        int i10 = (this.osx7Pl0E + 1) % 4;
        this.osx7Pl0E = i10;
        if (i10 == 0) {
            this.eLbhX59K[this.ivfTYNl] = this.eszJ2B0a.oyaOvpOs();
            this.ivfTYNl = (this.ivfTYNl + 1) % this.eLbhX59K.length;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        for (int i12 = 0; i12 < i11; i12++) {
            update(bArr[i10 + i12]);
        }
    }
}
