package Jr;

import Or.VX4rr;
import com.paytm.network.utils.RedirectTrail;
import easypay.manager.Constants;
import kotlin.UByte;
import kotlin.io.ConstantsKt;
import net.one97.paytm.nativesdk.emiSubvention.utils.EmiUtil;
import net.one97.storefront.utils.SFConstants;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class RFQ3AA8 implements ZKBAd {
    public byte[] aXYSYCVY;
    public int dUI84;
    public byte[] eLbhX59K;
    public byte[] eszJ2B0a;
    public int ivfTYNl;
    public byte[] oZ7qYn;
    public org.bouncycastle.crypto.N1vNRFSd osx7Pl0E;
    public byte[] rjljd6i;
    public byte[] zDWsfFRp;

    public RFQ3AA8(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd) {
        this(n1vNRFSd, n1vNRFSd.eszJ2B0a() * 8);
    }

    public static byte[] aXYSYCVY(int i10) {
        int i11 = i10 * 8;
        int i12 = 135;
        switch (i11) {
            case 64:
            case 320:
                i12 = 27;
                break;
            case 128:
            case 192:
                break;
            case Constants.ACTION_NB_PREVIOUS_BTN_CLICKED /* 160 */:
                i12 = 45;
                break;
            case 224:
                i12 = SFConstants.ITEM_BG_SMART_4XN;
                break;
            case 256:
                i12 = 1061;
                break;
            case 384:
                i12 = 4109;
                break;
            case 448:
                i12 = 2129;
                break;
            case ConstantsKt.MINIMUM_BLOCK_SIZE /* 512 */:
                i12 = 293;
                break;
            case 768:
                i12 = 655377;
                break;
            case RedirectTrail.MAX_SERIALIZED_LEN /* 1024 */:
                i12 = 524355;
                break;
            case EmiUtil.EMI_PLAN_REQUEST_CODE /* 2048 */:
                i12 = 548865;
                break;
            default:
                throw new IllegalArgumentException("Unknown block size for CMAC: " + i11);
        }
        return wt.SFMiYa.rjljd6i(i12);
    }

    public static int eLbhX59K(byte[] bArr, byte[] bArr2) {
        int length = bArr.length;
        int i10 = 0;
        while (true) {
            length--;
            if (length < 0) {
                return i10;
            }
            int i11 = bArr[length] & UByte.MAX_VALUE;
            bArr2[length] = (byte) (i10 | (i11 << 1));
            i10 = (i11 >>> 7) & 1;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        byte[] bArr2;
        if (this.ivfTYNl == this.osx7Pl0E.eszJ2B0a()) {
            bArr2 = this.oZ7qYn;
        } else {
            new Nr.RFQ3AA8().eszJ2B0a(this.zDWsfFRp, this.ivfTYNl);
            bArr2 = this.rjljd6i;
        }
        int i11 = 0;
        while (true) {
            byte[] bArr3 = this.eLbhX59K;
            if (i11 >= bArr3.length) {
                this.osx7Pl0E.eLbhX59K(this.zDWsfFRp, 0, bArr3, 0);
                System.arraycopy(this.eLbhX59K, 0, bArr, i10, this.dUI84);
                reset();
                return this.dUI84;
            }
            byte[] bArr4 = this.zDWsfFRp;
            bArr4[i11] = (byte) (bArr4[i11] ^ bArr2[i11]);
            i11++;
        }
    }

    public final byte[] eszJ2B0a(byte[] bArr) {
        byte[] bArr2 = new byte[bArr.length];
        int i10 = (-eLbhX59K(bArr, bArr2)) & 255;
        int length = bArr.length - 3;
        byte b10 = bArr2[length];
        byte[] bArr3 = this.eszJ2B0a;
        bArr2[length] = (byte) (b10 ^ (bArr3[1] & i10));
        int length2 = bArr.length - 2;
        bArr2[length2] = (byte) ((bArr3[2] & i10) ^ bArr2[length2]);
        int length3 = bArr.length - 1;
        bArr2[length3] = (byte) ((i10 & bArr3[3]) ^ bArr2[length3]);
        return bArr2;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.osx7Pl0E.getAlgorithmName();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.dUI84;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        zDWsfFRp(jqavh);
        this.osx7Pl0E.init(true, jqavh);
        byte[] bArr = this.aXYSYCVY;
        byte[] bArr2 = new byte[bArr.length];
        this.osx7Pl0E.eLbhX59K(bArr, 0, bArr2, 0);
        byte[] bArrEszJ2B0a = eszJ2B0a(bArr2);
        this.oZ7qYn = bArrEszJ2B0a;
        this.rjljd6i = eszJ2B0a(bArrEszJ2B0a);
        reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        int i10 = 0;
        while (true) {
            byte[] bArr = this.zDWsfFRp;
            if (i10 >= bArr.length) {
                this.ivfTYNl = 0;
                this.osx7Pl0E.reset();
                return;
            } else {
                bArr[i10] = 0;
                i10++;
            }
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        int i10 = this.ivfTYNl;
        byte[] bArr = this.zDWsfFRp;
        if (i10 == bArr.length) {
            this.osx7Pl0E.eLbhX59K(bArr, 0, this.eLbhX59K, 0);
            this.ivfTYNl = 0;
        }
        byte[] bArr2 = this.zDWsfFRp;
        int i11 = this.ivfTYNl;
        this.ivfTYNl = i11 + 1;
        bArr2[i11] = b10;
    }

    public void zDWsfFRp(org.bouncycastle.crypto.JQAVH jqavh) {
        if (jqavh != null && !(jqavh instanceof VX4rr)) {
            throw new IllegalArgumentException("CMac mode only permits key to be set.");
        }
    }

    public RFQ3AA8(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd, int i10) {
        if (i10 % 8 != 0) {
            throw new IllegalArgumentException("MAC size must be multiple of 8");
        }
        if (i10 > n1vNRFSd.eszJ2B0a() * 8) {
            throw new IllegalArgumentException("MAC size must be less or equal to " + (n1vNRFSd.eszJ2B0a() * 8));
        }
        this.osx7Pl0E = Kr.RFQ3AA8.oZ7qYn(n1vNRFSd);
        this.dUI84 = i10 / 8;
        this.eszJ2B0a = aXYSYCVY(n1vNRFSd.eszJ2B0a());
        this.eLbhX59K = new byte[n1vNRFSd.eszJ2B0a()];
        this.zDWsfFRp = new byte[n1vNRFSd.eszJ2B0a()];
        this.aXYSYCVY = new byte[n1vNRFSd.eszJ2B0a()];
        this.ivfTYNl = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (i11 < 0) {
            throw new IllegalArgumentException("Can't have a negative input length!");
        }
        int iEszJ2B0a = this.osx7Pl0E.eszJ2B0a();
        int i12 = this.ivfTYNl;
        int i13 = iEszJ2B0a - i12;
        if (i11 > i13) {
            System.arraycopy(bArr, i10, this.zDWsfFRp, i12, i13);
            this.osx7Pl0E.eLbhX59K(this.zDWsfFRp, 0, this.eLbhX59K, 0);
            this.ivfTYNl = 0;
            i11 -= i13;
            i10 += i13;
            while (i11 > iEszJ2B0a) {
                this.osx7Pl0E.eLbhX59K(bArr, i10, this.eLbhX59K, 0);
                i11 -= iEszJ2B0a;
                i10 += iEszJ2B0a;
            }
        }
        System.arraycopy(bArr, i10, this.zDWsfFRp, this.ivfTYNl, i11);
        this.ivfTYNl += i11;
    }
}
