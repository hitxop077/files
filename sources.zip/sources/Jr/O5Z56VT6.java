package Jr;

import Gr.KpPYc30;
import Gr.PNhZ1c;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public final class O5Z56VT6 implements ZKBAd {
    public final int aXYSYCVY;
    public int dUI84;
    public final int[] eLbhX59K;
    public final MY3jR eszJ2B0a;
    public PNhZ1c ivfTYNl;
    public int osx7Pl0E;
    public final int[] zDWsfFRp;

    public static class MY3jR extends PNhZ1c {
        public MY3jR(int i10) {
            super(i10);
        }

        public int n84TFkA9() {
            return super.rJCQt16();
        }
    }

    public O5Z56VT6(int i10) {
        this.eszJ2B0a = new MY3jR(i10);
        this.aXYSYCVY = i10;
        int i11 = i10 / 32;
        this.eLbhX59K = new int[i11];
        this.zDWsfFRp = new int[i11 + 1];
    }

    private void aXYSYCVY() {
        int i10 = 0;
        int i11 = 0;
        while (true) {
            int[] iArr = this.eLbhX59K;
            if (i11 >= iArr.length) {
                break;
            }
            iArr[i11] = this.eszJ2B0a.n84TFkA9();
            i11++;
        }
        while (true) {
            int[] iArr2 = this.zDWsfFRp;
            if (i10 >= iArr2.length - 1) {
                this.osx7Pl0E = iArr2.length - 1;
                this.dUI84 = 3;
                return;
            } else {
                iArr2[i10] = this.eszJ2B0a.n84TFkA9();
                i10++;
            }
        }
    }

    private void ivfTYNl(int i10) {
        int i11 = 0;
        while (true) {
            int[] iArr = this.eLbhX59K;
            if (i11 >= iArr.length) {
                return;
            }
            iArr[i11] = iArr[i11] ^ eszJ2B0a(i11, i10);
            i11++;
        }
    }

    private void zDWsfFRp() {
        int i10 = (this.dUI84 + 1) % 4;
        this.dUI84 = i10;
        if (i10 == 0) {
            this.zDWsfFRp[this.osx7Pl0E] = this.eszJ2B0a.n84TFkA9();
            this.osx7Pl0E = (this.osx7Pl0E + 1) % this.zDWsfFRp.length;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        eLbhX59K();
        ivfTYNl(this.dUI84 * 8);
        int i11 = 0;
        while (true) {
            int[] iArr = this.eLbhX59K;
            if (i11 >= iArr.length) {
                reset();
                return getMacSize();
            }
            KpPYc30.uYRSwDm(iArr[i11], bArr, (i11 * 4) + i10);
            i11++;
        }
    }

    public final void eLbhX59K() {
        int i10 = (this.dUI84 + 1) % 4;
        this.dUI84 = i10;
        if (i10 == 0) {
            this.osx7Pl0E = (this.osx7Pl0E + 1) % this.zDWsfFRp.length;
        }
    }

    public final int eszJ2B0a(int i10, int i11) {
        int[] iArr = this.zDWsfFRp;
        int i12 = this.osx7Pl0E;
        int i13 = iArr[(i12 + i10) % iArr.length];
        if (i11 == 0) {
            return i13;
        }
        int i14 = iArr[((i12 + i10) + 1) % iArr.length];
        return (i14 >>> (32 - i11)) | (i13 << i11);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "Zuc256Mac-" + this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY / 8;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        this.eszJ2B0a.init(true, jqavh);
        this.ivfTYNl = (PNhZ1c) this.eszJ2B0a.copy();
        aXYSYCVY();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        PNhZ1c pNhZ1c = this.ivfTYNl;
        if (pNhZ1c != null) {
            this.eszJ2B0a.eszJ2B0a(pNhZ1c);
        }
        aXYSYCVY();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        zDWsfFRp();
        int i10 = this.dUI84 * 8;
        int i11 = 128;
        int i12 = 0;
        while (i11 > 0) {
            if ((b10 & i11) != 0) {
                ivfTYNl(i10 + i12);
            }
            i11 >>= 1;
            i12++;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        for (int i12 = 0; i12 < i11; i12++) {
            update(bArr[i10 + i12]);
        }
    }
}
