package Jr;

import Or.Db8eU7XV;
import Or.VX4rr;
import org.bouncycastle.crypto.PGzD6265;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class N1vNRFSd implements ZKBAd {
    public final int aXYSYCVY = 128;
    public final Kr.O5Z56VT6 eszJ2B0a;

    public N1vNRFSd(Kr.O5Z56VT6 o5z56vt6) {
        this.eszJ2B0a = o5z56vt6;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        try {
            return this.eszJ2B0a.doFinal(bArr, i10);
        } catch (PGzD6265 e10) {
            throw new IllegalStateException(e10.toString());
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.eszJ2B0a.getUnderlyingCipher().getAlgorithmName() + "-GMAC";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY / 8;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        if (!(jqavh instanceof Db8eU7XV)) {
            throw new IllegalArgumentException("GMAC requires ParametersWithIV");
        }
        Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
        byte[] bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
        this.eszJ2B0a.init(true, new Or.MY3jR((VX4rr) db8eU7XV.aXYSYCVY(), this.aXYSYCVY, bArrEszJ2B0a));
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.eszJ2B0a.reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.eszJ2B0a.eLbhX59K(b10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        this.eszJ2B0a.aXYSYCVY(bArr, i10, i11);
    }
}
