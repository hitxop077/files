package Jr;

/* JADX INFO: loaded from: classes5.dex */
public class SFMiYa extends U080F {
    public SFMiYa() {
    }

    @Override // Jr.U080F
    public long aXYSYCVY() {
        throw new UnsupportedOperationException("doFinal() is not supported");
    }

    @Override // Jr.U080F, org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        long j10 = this.rjljd6i;
        int i11 = this.zPJpxWz;
        this.rjljd6i = ((j10 >>> ((7 - i11) << 3)) >>> 8) | ((((long) ((this.qLLw0g << 3) + i11)) & 255) << 56);
        eLbhX59K();
        this.dUI84 ^= 238;
        eszJ2B0a(this.aXYSYCVY);
        long j11 = this.ivfTYNl;
        long j12 = this.osx7Pl0E;
        long j13 = ((j11 ^ j12) ^ this.dUI84) ^ this.oZ7qYn;
        this.osx7Pl0E = j12 ^ 221;
        eszJ2B0a(this.aXYSYCVY);
        long j14 = ((this.ivfTYNl ^ this.osx7Pl0E) ^ this.dUI84) ^ this.oZ7qYn;
        reset();
        wt.SFMiYa.c1pvtY(j13, bArr, i10);
        wt.SFMiYa.c1pvtY(j14, bArr, i10 + 8);
        return 16;
    }

    @Override // Jr.U080F, org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "SipHash128-" + this.eszJ2B0a + Ac.RFQ3AA8.GTM_CONSTANTS_SEPERATER + this.aXYSYCVY;
    }

    @Override // Jr.U080F, org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 16;
    }

    @Override // Jr.U080F, org.bouncycastle.crypto.ZKBAd
    public void reset() {
        super.reset();
        this.osx7Pl0E ^= 238;
    }

    public SFMiYa(int i10, int i11) {
        super(i10, i11);
    }
}
