package Jr;

import Or.Db8eU7XV;
import Or.VX4rr;
import kotlin.UByte;
import org.bouncycastle.crypto.AXWzg4r;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class Gyx10a implements ZKBAd {
    public byte[] dUI84;
    public byte eszJ2B0a;
    public byte[] ivfTYNl;
    public byte oZ7qYn;
    public byte[] osx7Pl0E;
    public byte qLLw0g;
    public byte rjljd6i;
    public byte zPJpxWz;
    public byte aXYSYCVY = 0;
    public byte[] eLbhX59K = null;
    public byte zDWsfFRp = 0;

    private void eszJ2B0a(byte[] bArr, byte[] bArr2) {
        this.zDWsfFRp = (byte) 0;
        this.eLbhX59K = new byte[256];
        for (int i10 = 0; i10 < 256; i10++) {
            this.eLbhX59K[i10] = (byte) i10;
        }
        for (int i11 = 0; i11 < 768; i11++) {
            byte[] bArr3 = this.eLbhX59K;
            byte b10 = this.zDWsfFRp;
            int i12 = i11 & 255;
            byte b11 = bArr3[i12];
            byte b12 = bArr3[(b10 + b11 + bArr[i11 % bArr.length]) & 255];
            this.zDWsfFRp = b12;
            bArr3[i12] = bArr3[b12 & UByte.MAX_VALUE];
            bArr3[b12 & UByte.MAX_VALUE] = b11;
        }
        for (int i13 = 0; i13 < 768; i13++) {
            byte[] bArr4 = this.eLbhX59K;
            byte b13 = this.zDWsfFRp;
            int i14 = i13 & 255;
            byte b14 = bArr4[i14];
            byte b15 = bArr4[(b13 + b14 + bArr2[i13 % bArr2.length]) & 255];
            this.zDWsfFRp = b15;
            bArr4[i14] = bArr4[b15 & UByte.MAX_VALUE];
            bArr4[b15 & UByte.MAX_VALUE] = b14;
        }
        this.aXYSYCVY = (byte) 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        for (int i11 = 1; i11 < 25; i11++) {
            byte[] bArr2 = this.eLbhX59K;
            byte b10 = this.zDWsfFRp;
            byte b11 = this.aXYSYCVY;
            byte b12 = bArr2[(b10 + bArr2[b11 & UByte.MAX_VALUE]) & 255];
            this.zDWsfFRp = b12;
            byte b13 = this.qLLw0g;
            byte b14 = this.zPJpxWz;
            byte b15 = bArr2[(b13 + b14 + i11) & 255];
            this.qLLw0g = b15;
            byte b16 = this.rjljd6i;
            byte b17 = bArr2[(b14 + b16 + i11) & 255];
            this.zPJpxWz = b17;
            byte b18 = this.oZ7qYn;
            byte b19 = bArr2[(b16 + b18 + i11) & 255];
            this.rjljd6i = b19;
            byte b20 = bArr2[(b18 + b12 + i11) & 255];
            this.oZ7qYn = b20;
            byte[] bArr3 = this.ivfTYNl;
            byte b21 = this.eszJ2B0a;
            bArr3[b21 & 31] = (byte) (b20 ^ bArr3[b21 & 31]);
            bArr3[(b21 + 1) & 31] = (byte) (b19 ^ bArr3[(b21 + 1) & 31]);
            bArr3[(b21 + 2) & 31] = (byte) (b17 ^ bArr3[(b21 + 2) & 31]);
            bArr3[(b21 + 3) & 31] = (byte) (b15 ^ bArr3[(b21 + 3) & 31]);
            this.eszJ2B0a = (byte) ((b21 + 4) & 31);
            byte b22 = bArr2[b11 & UByte.MAX_VALUE];
            bArr2[b11 & UByte.MAX_VALUE] = bArr2[b12 & UByte.MAX_VALUE];
            bArr2[b12 & UByte.MAX_VALUE] = b22;
            this.aXYSYCVY = (byte) ((b11 + 1) & 255);
        }
        for (int i12 = 0; i12 < 768; i12++) {
            byte[] bArr4 = this.eLbhX59K;
            byte b23 = this.zDWsfFRp;
            int i13 = i12 & 255;
            byte b24 = bArr4[i13];
            byte b25 = bArr4[(b23 + b24 + this.ivfTYNl[i12 & 31]) & 255];
            this.zDWsfFRp = b25;
            bArr4[i13] = bArr4[b25 & UByte.MAX_VALUE];
            bArr4[b25 & UByte.MAX_VALUE] = b24;
        }
        byte[] bArr5 = new byte[20];
        for (int i14 = 0; i14 < 20; i14++) {
            byte[] bArr6 = this.eLbhX59K;
            int i15 = i14 & 255;
            byte b26 = bArr6[(this.zDWsfFRp + bArr6[i15]) & 255];
            this.zDWsfFRp = b26;
            bArr5[i14] = bArr6[(bArr6[bArr6[b26 & UByte.MAX_VALUE] & UByte.MAX_VALUE] + 1) & 255];
            byte b27 = bArr6[i15];
            bArr6[i15] = bArr6[b26 & UByte.MAX_VALUE];
            bArr6[b26 & UByte.MAX_VALUE] = b27;
        }
        System.arraycopy(bArr5, 0, bArr, i10, 20);
        reset();
        return 20;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "VMPC-MAC";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 20;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        if (!(jqavh instanceof Db8eU7XV)) {
            throw new IllegalArgumentException("VMPC-MAC Init parameters must include an IV");
        }
        Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
        VX4rr vX4rr = (VX4rr) db8eU7XV.aXYSYCVY();
        if (!(db8eU7XV.aXYSYCVY() instanceof VX4rr)) {
            throw new IllegalArgumentException("VMPC-MAC Init parameters must include a key");
        }
        byte[] bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
        this.osx7Pl0E = bArrEszJ2B0a;
        if (bArrEszJ2B0a == null || bArrEszJ2B0a.length < 1 || bArrEszJ2B0a.length > 768) {
            throw new IllegalArgumentException("VMPC-MAC requires 1 to 768 bytes of IV");
        }
        this.dUI84 = vX4rr.aXYSYCVY();
        reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        eszJ2B0a(this.dUI84, this.osx7Pl0E);
        this.aXYSYCVY = (byte) 0;
        this.qLLw0g = (byte) 0;
        this.zPJpxWz = (byte) 0;
        this.rjljd6i = (byte) 0;
        this.oZ7qYn = (byte) 0;
        this.eszJ2B0a = (byte) 0;
        this.ivfTYNl = new byte[32];
        for (int i10 = 0; i10 < 32; i10++) {
            this.ivfTYNl[i10] = 0;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        byte[] bArr = this.eLbhX59K;
        byte b11 = this.zDWsfFRp;
        byte b12 = this.aXYSYCVY;
        byte b13 = bArr[(b11 + bArr[b12 & UByte.MAX_VALUE]) & 255];
        this.zDWsfFRp = b13;
        byte b14 = (byte) (b10 ^ bArr[(bArr[bArr[b13 & UByte.MAX_VALUE] & UByte.MAX_VALUE] + 1) & 255]);
        byte b15 = this.qLLw0g;
        byte b16 = this.zPJpxWz;
        byte b17 = bArr[(b15 + b16) & 255];
        this.qLLw0g = b17;
        byte b18 = this.rjljd6i;
        byte b19 = bArr[(b16 + b18) & 255];
        this.zPJpxWz = b19;
        byte b20 = this.oZ7qYn;
        byte b21 = bArr[(b18 + b20) & 255];
        this.rjljd6i = b21;
        byte b22 = bArr[(b20 + b13 + b14) & 255];
        this.oZ7qYn = b22;
        byte[] bArr2 = this.ivfTYNl;
        byte b23 = this.eszJ2B0a;
        bArr2[b23 & 31] = (byte) (b22 ^ bArr2[b23 & 31]);
        bArr2[(b23 + 1) & 31] = (byte) (b21 ^ bArr2[(b23 + 1) & 31]);
        bArr2[(b23 + 2) & 31] = (byte) (b19 ^ bArr2[(b23 + 2) & 31]);
        bArr2[(b23 + 3) & 31] = (byte) (b17 ^ bArr2[(b23 + 3) & 31]);
        this.eszJ2B0a = (byte) ((b23 + 4) & 31);
        byte b24 = bArr[b12 & UByte.MAX_VALUE];
        bArr[b12 & UByte.MAX_VALUE] = bArr[b13 & UByte.MAX_VALUE];
        bArr[b13 & UByte.MAX_VALUE] = b24;
        this.aXYSYCVY = (byte) ((b12 + 1) & 255);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (i10 + i11 > bArr.length) {
            throw new AXWzg4r("input buffer too short");
        }
        for (int i12 = 0; i12 < i11; i12++) {
            update(bArr[i10 + i12]);
        }
    }
}
