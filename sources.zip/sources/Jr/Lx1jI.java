package Jr;

import Or.Db8eU7XV;
import org.bouncycastle.crypto.AXWzg4r;
import org.bouncycastle.crypto.AfGFIA;

/* JADX INFO: loaded from: classes5.dex */
public class Lx1jI {
    public byte[] aXYSYCVY;
    public byte[] eLbhX59K;
    public byte[] eszJ2B0a;
    public org.bouncycastle.crypto.N1vNRFSd ivfTYNl;
    public int zDWsfFRp;

    public Lx1jI(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd, int i10) {
        this.ivfTYNl = n1vNRFSd;
        this.zDWsfFRp = i10 / 8;
        this.eszJ2B0a = new byte[n1vNRFSd.eszJ2B0a()];
        this.aXYSYCVY = new byte[n1vNRFSd.eszJ2B0a()];
        this.eLbhX59K = new byte[n1vNRFSd.eszJ2B0a()];
    }

    public int aXYSYCVY() {
        return this.zDWsfFRp;
    }

    public void eLbhX59K(byte[] bArr) {
        this.ivfTYNl.eLbhX59K(this.aXYSYCVY, 0, bArr, 0);
    }

    public String eszJ2B0a() {
        return this.ivfTYNl.getAlgorithmName() + "/CFB" + (this.zDWsfFRp * 8);
    }

    public int ivfTYNl(byte[] bArr, int i10, byte[] bArr2, int i11) {
        int i12 = this.zDWsfFRp;
        if (i10 + i12 > bArr.length) {
            throw new AXWzg4r("input buffer too short");
        }
        if (i12 + i11 > bArr2.length) {
            throw new AfGFIA("output buffer too short");
        }
        this.ivfTYNl.eLbhX59K(this.aXYSYCVY, 0, this.eLbhX59K, 0);
        int i13 = 0;
        while (true) {
            int i14 = this.zDWsfFRp;
            if (i13 >= i14) {
                byte[] bArr3 = this.aXYSYCVY;
                System.arraycopy(bArr3, i14, bArr3, 0, bArr3.length - i14);
                byte[] bArr4 = this.aXYSYCVY;
                int length = bArr4.length;
                int i15 = this.zDWsfFRp;
                System.arraycopy(bArr2, i11, bArr4, length - i15, i15);
                return this.zDWsfFRp;
            }
            bArr2[i11 + i13] = (byte) (this.eLbhX59K[i13] ^ bArr[i10 + i13]);
            i13++;
        }
    }

    public void osx7Pl0E() {
        byte[] bArr = this.eszJ2B0a;
        System.arraycopy(bArr, 0, this.aXYSYCVY, 0, bArr.length);
        this.ivfTYNl.reset();
    }

    public void zDWsfFRp(org.bouncycastle.crypto.JQAVH jqavh) {
        org.bouncycastle.crypto.N1vNRFSd n1vNRFSd;
        if (jqavh instanceof Db8eU7XV) {
            Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
            byte[] bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
            int length = bArrEszJ2B0a.length;
            byte[] bArr = this.eszJ2B0a;
            if (length < bArr.length) {
                System.arraycopy(bArrEszJ2B0a, 0, bArr, bArr.length - bArrEszJ2B0a.length, bArrEszJ2B0a.length);
            } else {
                System.arraycopy(bArrEszJ2B0a, 0, bArr, 0, bArr.length);
            }
            osx7Pl0E();
            n1vNRFSd = this.ivfTYNl;
            jqavh = db8eU7XV.aXYSYCVY();
        } else {
            osx7Pl0E();
            n1vNRFSd = this.ivfTYNl;
        }
        n1vNRFSd.init(true, jqavh);
    }
}
