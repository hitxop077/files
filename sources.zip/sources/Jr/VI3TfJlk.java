package Jr;

import Er.AfGFIA;
import Or.VX4rr;
import Or.VaiTyLF;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class VI3TfJlk implements ZKBAd {
    public AfGFIA eszJ2B0a;

    public VI3TfJlk(int i10, int i11) {
        this.eszJ2B0a = new AfGFIA(i10, i11);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        return this.eszJ2B0a.osx7Pl0E(bArr, i10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "Skein-MAC-" + (this.eszJ2B0a.dUI84() * 8) + Ac.RFQ3AA8.GTM_CONSTANTS_SEPERATER + (this.eszJ2B0a.oZ7qYn() * 8);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.eszJ2B0a.oZ7qYn();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        VaiTyLF vaiTyLFEszJ2B0a;
        if (jqavh instanceof VaiTyLF) {
            vaiTyLFEszJ2B0a = (VaiTyLF) jqavh;
        } else {
            if (!(jqavh instanceof VX4rr)) {
                throw new IllegalArgumentException("Invalid parameter passed to Skein MAC init - " + jqavh.getClass().getName());
            }
            vaiTyLFEszJ2B0a = new VaiTyLF.AAnYcst().eLbhX59K(((VX4rr) jqavh).aXYSYCVY()).eszJ2B0a();
        }
        if (vaiTyLFEszJ2B0a.eszJ2B0a() == null) {
            throw new IllegalArgumentException("Skein MAC requires a key parameter.");
        }
        this.eszJ2B0a.rjljd6i(vaiTyLFEszJ2B0a);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.eszJ2B0a.uTIfLNK0();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.eszJ2B0a.jAM6dcNA(b10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        this.eszJ2B0a.rtsRj(bArr, i10, i11);
    }
}
