package Jr;

import Or.VX4rr;
import org.bouncycastle.crypto.LksRT6;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class Bv3FS implements ZKBAd {
    public int aXYSYCVY;
    public LksRT6 eszJ2B0a;
    public byte[] eLbhX59K = new byte[64];
    public byte[] zDWsfFRp = new byte[64];

    public Bv3FS(LksRT6 lksRT6) {
        this.eszJ2B0a = lksRT6;
        this.aXYSYCVY = lksRT6.getDigestSize();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        int i11 = this.aXYSYCVY;
        byte[] bArr2 = new byte[i11];
        this.eszJ2B0a.doFinal(bArr2, 0);
        LksRT6 lksRT6 = this.eszJ2B0a;
        byte[] bArr3 = this.zDWsfFRp;
        lksRT6.update(bArr3, 0, bArr3.length);
        this.eszJ2B0a.update(bArr2, 0, i11);
        int iDoFinal = this.eszJ2B0a.doFinal(bArr, i10);
        reset();
        return iDoFinal;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.eszJ2B0a.getAlgorithmName() + "/HMAC";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        this.eszJ2B0a.reset();
        byte[] bArrAXYSYCVY = ((VX4rr) jqavh).aXYSYCVY();
        if (bArrAXYSYCVY.length <= 64) {
            System.arraycopy(bArrAXYSYCVY, 0, this.eLbhX59K, 0, bArrAXYSYCVY.length);
            int length = bArrAXYSYCVY.length;
            while (true) {
                byte[] bArr = this.eLbhX59K;
                if (length >= bArr.length) {
                    break;
                }
                bArr[length] = 0;
                length++;
            }
        } else {
            this.eszJ2B0a.update(bArrAXYSYCVY, 0, bArrAXYSYCVY.length);
            this.eszJ2B0a.doFinal(this.eLbhX59K, 0);
            int i10 = this.aXYSYCVY;
            while (true) {
                byte[] bArr2 = this.eLbhX59K;
                if (i10 >= bArr2.length) {
                    break;
                }
                bArr2[i10] = 0;
                i10++;
            }
        }
        byte[] bArr3 = this.eLbhX59K;
        byte[] bArr4 = new byte[bArr3.length];
        this.zDWsfFRp = bArr4;
        System.arraycopy(bArr3, 0, bArr4, 0, bArr3.length);
        int i11 = 0;
        while (true) {
            byte[] bArr5 = this.eLbhX59K;
            if (i11 >= bArr5.length) {
                break;
            }
            bArr5[i11] = (byte) (bArr5[i11] ^ 54);
            i11++;
        }
        int i12 = 0;
        while (true) {
            byte[] bArr6 = this.zDWsfFRp;
            if (i12 >= bArr6.length) {
                LksRT6 lksRT6 = this.eszJ2B0a;
                byte[] bArr7 = this.eLbhX59K;
                lksRT6.update(bArr7, 0, bArr7.length);
                return;
            }
            bArr6[i12] = (byte) (bArr6[i12] ^ 92);
            i12++;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.eszJ2B0a.reset();
        LksRT6 lksRT6 = this.eszJ2B0a;
        byte[] bArr = this.eLbhX59K;
        lksRT6.update(bArr, 0, bArr.length);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.eszJ2B0a.update(b10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        this.eszJ2B0a.update(bArr, i10, i11);
    }
}
