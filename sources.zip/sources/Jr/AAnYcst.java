package Jr;

import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class AAnYcst implements ZKBAd {
    public byte[] aXYSYCVY;
    public int eLbhX59K;
    public byte[] eszJ2B0a;
    public Nr.MY3jR ivfTYNl;
    public int osx7Pl0E;
    public Lx1jI zDWsfFRp;

    public AAnYcst(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd) {
        this(n1vNRFSd, 8, (n1vNRFSd.eszJ2B0a() * 8) / 2, null);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        int iAXYSYCVY = this.zDWsfFRp.aXYSYCVY();
        Nr.MY3jR mY3jR = this.ivfTYNl;
        if (mY3jR == null) {
            while (true) {
                int i11 = this.eLbhX59K;
                if (i11 >= iAXYSYCVY) {
                    break;
                }
                this.aXYSYCVY[i11] = 0;
                this.eLbhX59K = i11 + 1;
            }
        } else {
            mY3jR.eszJ2B0a(this.aXYSYCVY, this.eLbhX59K);
        }
        this.zDWsfFRp.ivfTYNl(this.aXYSYCVY, 0, this.eszJ2B0a, 0);
        this.zDWsfFRp.eLbhX59K(this.eszJ2B0a);
        System.arraycopy(this.eszJ2B0a, 0, bArr, i10, this.osx7Pl0E);
        reset();
        return this.osx7Pl0E;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.zDWsfFRp.eszJ2B0a();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.osx7Pl0E;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        reset();
        this.zDWsfFRp.zDWsfFRp(jqavh);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        int i10 = 0;
        while (true) {
            byte[] bArr = this.aXYSYCVY;
            if (i10 >= bArr.length) {
                this.eLbhX59K = 0;
                this.zDWsfFRp.osx7Pl0E();
                return;
            } else {
                bArr[i10] = 0;
                i10++;
            }
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        int i10 = this.eLbhX59K;
        byte[] bArr = this.aXYSYCVY;
        if (i10 == bArr.length) {
            this.zDWsfFRp.ivfTYNl(bArr, 0, this.eszJ2B0a, 0);
            this.eLbhX59K = 0;
        }
        byte[] bArr2 = this.aXYSYCVY;
        int i11 = this.eLbhX59K;
        this.eLbhX59K = i11 + 1;
        bArr2[i11] = b10;
    }

    public AAnYcst(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd, int i10, int i11, Nr.MY3jR mY3jR) {
        this.ivfTYNl = null;
        if (i11 % 8 != 0) {
            throw new IllegalArgumentException("MAC size must be multiple of 8");
        }
        this.eszJ2B0a = new byte[n1vNRFSd.eszJ2B0a()];
        Lx1jI lx1jI = new Lx1jI(n1vNRFSd, i10);
        this.zDWsfFRp = lx1jI;
        this.ivfTYNl = mY3jR;
        this.osx7Pl0E = i11 / 8;
        this.aXYSYCVY = new byte[lx1jI.aXYSYCVY()];
        this.eLbhX59K = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (i11 < 0) {
            throw new IllegalArgumentException("Can't have a negative input length!");
        }
        int iAXYSYCVY = this.zDWsfFRp.aXYSYCVY();
        int i12 = this.eLbhX59K;
        int i13 = iAXYSYCVY - i12;
        if (i11 > i13) {
            System.arraycopy(bArr, i10, this.aXYSYCVY, i12, i13);
            this.zDWsfFRp.ivfTYNl(this.aXYSYCVY, 0, this.eszJ2B0a, 0);
            this.eLbhX59K = 0;
            i11 -= i13;
            i10 += i13;
            while (i11 > iAXYSYCVY) {
                this.zDWsfFRp.ivfTYNl(bArr, i10, this.eszJ2B0a, 0);
                i11 -= iAXYSYCVY;
                i10 += iAXYSYCVY;
            }
        }
        System.arraycopy(bArr, i10, this.aXYSYCVY, this.eLbhX59K, i11);
        this.eLbhX59K += i11;
    }
}
