package Jr;

import Or.VX4rr;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class U080F implements ZKBAd {
    public final int aXYSYCVY;
    public long dUI84;
    public long eLbhX59K;
    public final int eszJ2B0a;
    public long ivfTYNl;
    public long oZ7qYn;
    public long osx7Pl0E;
    public int qLLw0g;
    public long rjljd6i;
    public long zDWsfFRp;
    public int zPJpxWz;

    public U080F() {
        this.rjljd6i = 0L;
        this.zPJpxWz = 0;
        this.qLLw0g = 0;
        this.eszJ2B0a = 2;
        this.aXYSYCVY = 4;
    }

    public static long zDWsfFRp(long j10, int i10) {
        return (j10 >>> (-i10)) | (j10 << i10);
    }

    public long aXYSYCVY() {
        long j10 = this.rjljd6i;
        int i10 = this.zPJpxWz;
        this.rjljd6i = ((j10 >>> ((7 - i10) << 3)) >>> 8) | ((((long) ((this.qLLw0g << 3) + i10)) & 255) << 56);
        eLbhX59K();
        this.dUI84 ^= 255;
        eszJ2B0a(this.aXYSYCVY);
        long j11 = ((this.ivfTYNl ^ this.osx7Pl0E) ^ this.dUI84) ^ this.oZ7qYn;
        reset();
        return j11;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        wt.SFMiYa.c1pvtY(aXYSYCVY(), bArr, i10);
        return 8;
    }

    public void eLbhX59K() {
        this.qLLw0g++;
        this.oZ7qYn ^= this.rjljd6i;
        eszJ2B0a(this.eszJ2B0a);
        this.ivfTYNl ^= this.rjljd6i;
    }

    public void eszJ2B0a(int i10) {
        long jZDWsfFRp = this.ivfTYNl;
        long jZDWsfFRp2 = this.osx7Pl0E;
        long jZDWsfFRp3 = this.dUI84;
        long jZDWsfFRp4 = this.oZ7qYn;
        for (int i11 = 0; i11 < i10; i11++) {
            long j10 = jZDWsfFRp + jZDWsfFRp2;
            long j11 = jZDWsfFRp3 + jZDWsfFRp4;
            long jZDWsfFRp5 = zDWsfFRp(jZDWsfFRp2, 13) ^ j10;
            long jZDWsfFRp6 = zDWsfFRp(jZDWsfFRp4, 16) ^ j11;
            long j12 = j11 + jZDWsfFRp5;
            jZDWsfFRp = zDWsfFRp(j10, 32) + jZDWsfFRp6;
            jZDWsfFRp2 = zDWsfFRp(jZDWsfFRp5, 17) ^ j12;
            jZDWsfFRp4 = zDWsfFRp(jZDWsfFRp6, 21) ^ jZDWsfFRp;
            jZDWsfFRp3 = zDWsfFRp(j12, 32);
        }
        this.ivfTYNl = jZDWsfFRp;
        this.osx7Pl0E = jZDWsfFRp2;
        this.dUI84 = jZDWsfFRp3;
        this.oZ7qYn = jZDWsfFRp4;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "SipHash-" + this.eszJ2B0a + Ac.RFQ3AA8.GTM_CONSTANTS_SEPERATER + this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 8;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        if (!(jqavh instanceof VX4rr)) {
            throw new IllegalArgumentException("'params' must be an instance of KeyParameter");
        }
        byte[] bArrAXYSYCVY = ((VX4rr) jqavh).aXYSYCVY();
        if (bArrAXYSYCVY.length != 16) {
            throw new IllegalArgumentException("'params' must be a 128-bit key");
        }
        this.eLbhX59K = wt.SFMiYa.rJCQt16(bArrAXYSYCVY, 0);
        this.zDWsfFRp = wt.SFMiYa.rJCQt16(bArrAXYSYCVY, 8);
        reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        long j10 = this.eLbhX59K;
        this.ivfTYNl = 8317987319222330741L ^ j10;
        long j11 = this.zDWsfFRp;
        this.osx7Pl0E = 7237128888997146477L ^ j11;
        this.dUI84 = j10 ^ 7816392313619706465L;
        this.oZ7qYn = 8387220255154660723L ^ j11;
        this.rjljd6i = 0L;
        this.zPJpxWz = 0;
        this.qLLw0g = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.rjljd6i = (this.rjljd6i >>> 8) | ((((long) b10) & 255) << 56);
        int i10 = this.zPJpxWz + 1;
        this.zPJpxWz = i10;
        if (i10 == 8) {
            eLbhX59K();
            this.zPJpxWz = 0;
        }
    }

    public U080F(int i10, int i11) {
        this.rjljd6i = 0L;
        this.zPJpxWz = 0;
        this.qLLw0g = 0;
        this.eszJ2B0a = i10;
        this.aXYSYCVY = i11;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        int i12 = i11 & (-8);
        int i13 = this.zPJpxWz;
        char c10 = '8';
        long j10 = 255;
        int i14 = 0;
        if (i13 == 0) {
            while (i14 < i12) {
                this.rjljd6i = wt.SFMiYa.rJCQt16(bArr, i10 + i14);
                eLbhX59K();
                i14 += 8;
            }
            while (i14 < i11) {
                long j11 = this.rjljd6i >>> 8;
                this.rjljd6i = j11;
                this.rjljd6i = j11 | ((((long) bArr[i10 + i14]) & 255) << 56);
                i14++;
            }
            this.zPJpxWz = i11 - i12;
            return;
        }
        int i15 = i13 << 3;
        int i16 = 0;
        while (i16 < i12) {
            long jRJCQt16 = wt.SFMiYa.rJCQt16(bArr, i10 + i16);
            this.rjljd6i = (this.rjljd6i >>> (-i15)) | (jRJCQt16 << i15);
            eLbhX59K();
            this.rjljd6i = jRJCQt16;
            i16 += 8;
            c10 = c10;
            j10 = j10;
        }
        char c11 = c10;
        long j12 = j10;
        while (i16 < i11) {
            long j13 = this.rjljd6i >>> 8;
            this.rjljd6i = j13;
            this.rjljd6i = j13 | ((((long) bArr[i10 + i16]) & j12) << c11);
            int i17 = this.zPJpxWz + 1;
            this.zPJpxWz = i17;
            if (i17 == 8) {
                eLbhX59K();
                this.zPJpxWz = 0;
            }
            i16++;
        }
    }
}
