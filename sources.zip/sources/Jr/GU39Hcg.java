package Jr;

import Or.Db8eU7XV;
import Or.VX4rr;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class GU39Hcg implements ZKBAd {
    public byte[] aXYSYCVY;
    public VX4rr dUI84;
    public int eLbhX59K;
    public byte[] eszJ2B0a;
    public Nr.MY3jR ivfTYNl;
    public VX4rr oZ7qYn;
    public int osx7Pl0E;
    public org.bouncycastle.crypto.N1vNRFSd zDWsfFRp;

    public GU39Hcg(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd) {
        this(n1vNRFSd, n1vNRFSd.eszJ2B0a() * 8, null);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        int iEszJ2B0a = this.zDWsfFRp.eszJ2B0a();
        if (this.ivfTYNl == null) {
            while (true) {
                int i11 = this.eLbhX59K;
                if (i11 >= iEszJ2B0a) {
                    break;
                }
                this.aXYSYCVY[i11] = 0;
                this.eLbhX59K = i11 + 1;
            }
        } else {
            if (this.eLbhX59K == iEszJ2B0a) {
                this.zDWsfFRp.eLbhX59K(this.aXYSYCVY, 0, this.eszJ2B0a, 0);
                this.eLbhX59K = 0;
            }
            this.ivfTYNl.eszJ2B0a(this.aXYSYCVY, this.eLbhX59K);
        }
        this.zDWsfFRp.eLbhX59K(this.aXYSYCVY, 0, this.eszJ2B0a, 0);
        Gr.VI3TfJlk vI3TfJlk = new Gr.VI3TfJlk();
        vI3TfJlk.init(false, this.dUI84);
        byte[] bArr2 = this.eszJ2B0a;
        vI3TfJlk.eLbhX59K(bArr2, 0, bArr2, 0);
        vI3TfJlk.init(true, this.oZ7qYn);
        byte[] bArr3 = this.eszJ2B0a;
        vI3TfJlk.eLbhX59K(bArr3, 0, bArr3, 0);
        System.arraycopy(this.eszJ2B0a, 0, bArr, i10, this.osx7Pl0E);
        reset();
        return this.osx7Pl0E;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "ISO9797Alg3";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.osx7Pl0E;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        VX4rr vX4rr;
        reset();
        boolean z10 = jqavh instanceof VX4rr;
        if (!z10 && !(jqavh instanceof Db8eU7XV)) {
            throw new IllegalArgumentException("params must be an instance of KeyParameter or ParametersWithIV");
        }
        byte[] bArrAXYSYCVY = (z10 ? (VX4rr) jqavh : (VX4rr) ((Db8eU7XV) jqavh).aXYSYCVY()).aXYSYCVY();
        if (bArrAXYSYCVY.length == 16) {
            vX4rr = new VX4rr(bArrAXYSYCVY, 0, 8);
            this.dUI84 = new VX4rr(bArrAXYSYCVY, 8, 8);
            this.oZ7qYn = vX4rr;
        } else {
            if (bArrAXYSYCVY.length != 24) {
                throw new IllegalArgumentException("Key must be either 112 or 168 bit long");
            }
            vX4rr = new VX4rr(bArrAXYSYCVY, 0, 8);
            this.dUI84 = new VX4rr(bArrAXYSYCVY, 8, 8);
            this.oZ7qYn = new VX4rr(bArrAXYSYCVY, 16, 8);
        }
        if (jqavh instanceof Db8eU7XV) {
            this.zDWsfFRp.init(true, new Db8eU7XV(vX4rr, ((Db8eU7XV) jqavh).eszJ2B0a()));
        } else {
            this.zDWsfFRp.init(true, vX4rr);
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        int i10 = 0;
        while (true) {
            byte[] bArr = this.aXYSYCVY;
            if (i10 >= bArr.length) {
                this.eLbhX59K = 0;
                this.zDWsfFRp.reset();
                return;
            } else {
                bArr[i10] = 0;
                i10++;
            }
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        int i10 = this.eLbhX59K;
        byte[] bArr = this.aXYSYCVY;
        if (i10 == bArr.length) {
            this.zDWsfFRp.eLbhX59K(bArr, 0, this.eszJ2B0a, 0);
            this.eLbhX59K = 0;
        }
        byte[] bArr2 = this.aXYSYCVY;
        int i11 = this.eLbhX59K;
        this.eLbhX59K = i11 + 1;
        bArr2[i11] = b10;
    }

    public GU39Hcg(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd, int i10, Nr.MY3jR mY3jR) {
        if (i10 % 8 != 0) {
            throw new IllegalArgumentException("MAC size must be multiple of 8");
        }
        if (!(n1vNRFSd instanceof Gr.VI3TfJlk)) {
            throw new IllegalArgumentException("cipher must be instance of DESEngine");
        }
        this.zDWsfFRp = Kr.RFQ3AA8.oZ7qYn(n1vNRFSd);
        this.ivfTYNl = mY3jR;
        this.osx7Pl0E = i10 / 8;
        this.eszJ2B0a = new byte[n1vNRFSd.eszJ2B0a()];
        this.aXYSYCVY = new byte[n1vNRFSd.eszJ2B0a()];
        this.eLbhX59K = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (i11 < 0) {
            throw new IllegalArgumentException("Can't have a negative input length!");
        }
        int iEszJ2B0a = this.zDWsfFRp.eszJ2B0a();
        int i12 = this.eLbhX59K;
        int i13 = iEszJ2B0a - i12;
        if (i11 > i13) {
            System.arraycopy(bArr, i10, this.aXYSYCVY, i12, i13);
            this.zDWsfFRp.eLbhX59K(this.aXYSYCVY, 0, this.eszJ2B0a, 0);
            this.eLbhX59K = 0;
            i11 -= i13;
            i10 += i13;
            while (i11 > iEszJ2B0a) {
                this.zDWsfFRp.eLbhX59K(bArr, i10, this.eszJ2B0a, 0);
                i11 -= iEszJ2B0a;
                i10 += iEszJ2B0a;
            }
        }
        System.arraycopy(bArr, i10, this.aXYSYCVY, this.eLbhX59K, i11);
        this.eLbhX59K += i11;
    }

    public GU39Hcg(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd, Nr.MY3jR mY3jR) {
        this(n1vNRFSd, n1vNRFSd.eszJ2B0a() * 8, mY3jR);
    }
}
