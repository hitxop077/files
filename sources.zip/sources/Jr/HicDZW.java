package Jr;

import Kr.LksRT6;
import Or.Db8eU7XV;
import Or.VX4rr;
import java.io.IOException;
import org.bouncycastle.crypto.PGzD6265;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class HicDZW implements ZKBAd {
    public final int aXYSYCVY;
    public final LksRT6 eszJ2B0a;

    public HicDZW(LksRT6 lksRT6, int i10) {
        this.eszJ2B0a = lksRT6;
        this.aXYSYCVY = i10;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        try {
            return this.eszJ2B0a.doFinal(bArr, i10);
        } catch (PGzD6265 e10) {
            throw new IllegalStateException(e10.toString());
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return this.eszJ2B0a.getUnderlyingCipher().getAlgorithmName() + "-KGMAC";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY / 8;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) throws IOException {
        if (!(jqavh instanceof Db8eU7XV)) {
            throw new IllegalArgumentException("KGMAC requires ParametersWithIV");
        }
        Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
        byte[] bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
        this.eszJ2B0a.init(true, new Or.MY3jR((VX4rr) db8eU7XV.aXYSYCVY(), this.aXYSYCVY, bArrEszJ2B0a));
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() throws IOException {
        this.eszJ2B0a.reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) throws IOException {
        this.eszJ2B0a.eLbhX59K(b10);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) throws IOException {
        this.eszJ2B0a.aXYSYCVY(bArr, i10, i11);
    }
}
