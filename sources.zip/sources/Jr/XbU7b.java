package Jr;

import Or.Db8eU7XV;
import Or.Q5YIo;
import Or.VX4rr;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class XbU7b implements ZKBAd {
    public int aXYSYCVY;
    public byte[] dUI84;
    public byte[] eLbhX59K;
    public final org.bouncycastle.crypto.SFMiYa eszJ2B0a;
    public boolean ivfTYNl;
    public byte[] oZ7qYn;
    public int[] osx7Pl0E;
    public byte[] zDWsfFRp;

    public XbU7b() {
        this(org.bouncycastle.crypto.SFMiYa.AUTHENTICATION);
    }

    public static void eszJ2B0a(byte[] bArr, int i10, byte[] bArr2, byte[] bArr3) {
        for (int i11 = 0; i11 < 8; i11++) {
            bArr3[i11] = (byte) (bArr[i10 + i11] ^ bArr2[i11]);
        }
    }

    public final int[] aXYSYCVY(byte[] bArr) {
        if (bArr.length != 32) {
            throw new IllegalArgumentException("Key length invalid. Key needs to be 32 byte - 256 bit!!!");
        }
        int[] iArr = new int[8];
        for (int i10 = 0; i10 != 8; i10++) {
            iArr[i10] = wt.SFMiYa.uTIfLNK0(bArr, i10 * 4);
        }
        return iArr;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        while (true) {
            int i11 = this.aXYSYCVY;
            if (i11 >= 8) {
                break;
            }
            this.eLbhX59K[i11] = 0;
            this.aXYSYCVY = i11 + 1;
        }
        byte[] bArr2 = this.eLbhX59K;
        byte[] bArr3 = new byte[bArr2.length];
        if (this.ivfTYNl) {
            this.ivfTYNl = false;
            System.arraycopy(bArr2, 0, bArr3, 0, this.zDWsfFRp.length);
        } else {
            eszJ2B0a(bArr2, 0, this.zDWsfFRp, bArr3);
        }
        eLbhX59K(this.osx7Pl0E, bArr3, 0, this.zDWsfFRp, 0);
        byte[] bArr4 = this.zDWsfFRp;
        System.arraycopy(bArr4, (bArr4.length / 2) - 4, bArr, i10, 4);
        reset();
        return 4;
    }

    public final void eLbhX59K(int[] iArr, byte[] bArr, int i10, byte[] bArr2, int i11) {
        int iUTIfLNK0 = wt.SFMiYa.uTIfLNK0(bArr, i10);
        int iUTIfLNK1 = wt.SFMiYa.uTIfLNK0(bArr, i10 + 4);
        for (int i12 = 0; i12 < 2; i12++) {
            int i13 = 0;
            while (i13 < 8) {
                int iZDWsfFRp = iUTIfLNK1 ^ zDWsfFRp(iUTIfLNK0, iArr[i13]);
                i13++;
                int i14 = iUTIfLNK0;
                iUTIfLNK0 = iZDWsfFRp;
                iUTIfLNK1 = i14;
            }
        }
        wt.SFMiYa.zPJpxWz(iUTIfLNK0, bArr2, i11);
        wt.SFMiYa.zPJpxWz(iUTIfLNK1, bArr2, i11 + 4);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "GOST28147Mac";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 4;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        reset();
        this.eLbhX59K = new byte[8];
        this.dUI84 = null;
        ivfTYNl(jqavh);
        org.bouncycastle.crypto.Gyx10a.eszJ2B0a(new Dr.AAnYcst(getAlgorithmName(), 178, jqavh, this.eszJ2B0a));
    }

    public final void ivfTYNl(org.bouncycastle.crypto.JQAVH jqavh) {
        org.bouncycastle.crypto.JQAVH jqavhAXYSYCVY;
        if (jqavh == null) {
            return;
        }
        if (jqavh instanceof Q5YIo) {
            Q5YIo q5YIo = (Q5YIo) jqavh;
            System.arraycopy(q5YIo.aXYSYCVY(), 0, this.oZ7qYn, 0, q5YIo.aXYSYCVY().length);
            jqavhAXYSYCVY = q5YIo.eszJ2B0a();
        } else if (jqavh instanceof VX4rr) {
            this.osx7Pl0E = aXYSYCVY(((VX4rr) jqavh).aXYSYCVY());
            jqavhAXYSYCVY = null;
        } else {
            if (!(jqavh instanceof Db8eU7XV)) {
                throw new IllegalArgumentException("invalid parameter passed to GOST28147 init - " + jqavh.getClass().getName());
            }
            Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
            byte[] bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
            byte[] bArr = this.zDWsfFRp;
            System.arraycopy(bArrEszJ2B0a, 0, bArr, 0, bArr.length);
            this.dUI84 = db8eU7XV.eszJ2B0a();
            jqavhAXYSYCVY = db8eU7XV.aXYSYCVY();
        }
        ivfTYNl(jqavhAXYSYCVY);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        int i10 = 0;
        while (true) {
            byte[] bArr = this.eLbhX59K;
            if (i10 >= bArr.length) {
                this.aXYSYCVY = 0;
                this.ivfTYNl = true;
                return;
            } else {
                bArr[i10] = 0;
                i10++;
            }
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        XbU7b xbU7b;
        int i10 = this.aXYSYCVY;
        byte[] bArr = this.eLbhX59K;
        if (i10 == bArr.length) {
            byte[] bArr2 = new byte[bArr.length];
            if (this.ivfTYNl) {
                this.ivfTYNl = false;
                byte[] bArr3 = this.dUI84;
                if (bArr3 != null) {
                    eszJ2B0a(bArr, 0, bArr3, bArr2);
                } else {
                    System.arraycopy(bArr, 0, bArr2, 0, this.zDWsfFRp.length);
                }
            } else {
                eszJ2B0a(bArr, 0, this.zDWsfFRp, bArr2);
            }
            xbU7b = this;
            xbU7b.eLbhX59K(this.osx7Pl0E, bArr2, 0, this.zDWsfFRp, 0);
            xbU7b.aXYSYCVY = 0;
        } else {
            xbU7b = this;
        }
        byte[] bArr4 = xbU7b.eLbhX59K;
        int i11 = xbU7b.aXYSYCVY;
        xbU7b.aXYSYCVY = i11 + 1;
        bArr4[i11] = b10;
    }

    public final int zDWsfFRp(int i10, int i11) {
        int i12 = i11 + i10;
        byte[] bArr = this.oZ7qYn;
        int i13 = bArr[i12 & 15] + (bArr[((i12 >> 4) & 15) + 16] << 4) + (bArr[((i12 >> 8) & 15) + 32] << 8) + (bArr[((i12 >> 12) & 15) + 48] << 12) + (bArr[((i12 >> 16) & 15) + 64] << 16) + (bArr[((i12 >> 20) & 15) + 80] << 20) + (bArr[((i12 >> 24) & 15) + 96] << 24) + (bArr[((i12 >> 28) & 15) + 112] << 28);
        return (i13 << 11) | (i13 >>> 21);
    }

    public XbU7b(org.bouncycastle.crypto.SFMiYa sFMiYa) {
        this.ivfTYNl = true;
        this.osx7Pl0E = null;
        this.dUI84 = null;
        this.oZ7qYn = new byte[]{9, 6, 3, 2, 8, 11, 1, 7, 10, 4, 14, 15, 12, 0, 13, 5, 3, 7, 14, 9, 8, 10, 15, 0, 5, 2, 6, 12, 11, 4, 13, 1, 14, 4, 6, 2, 11, 3, 13, 8, 12, 15, 5, 10, 0, 7, 1, 9, 14, 7, 10, 12, 13, 1, 3, 9, 0, 2, 11, 4, 15, 8, 5, 6, 11, 5, 1, 9, 8, 13, 15, 0, 14, 4, 2, 3, 12, 7, 10, 6, 3, 10, 13, 12, 1, 2, 0, 11, 7, 5, 9, 4, 8, 15, 14, 6, 1, 13, 2, 9, 7, 10, 6, 0, 8, 12, 4, 5, 15, 3, 11, 14, 11, 10, 15, 5, 0, 12, 14, 8, 6, 2, 3, 9, 1, 7, 13, 4};
        this.eszJ2B0a = sFMiYa;
        this.zDWsfFRp = new byte[8];
        this.eLbhX59K = new byte[8];
        this.aXYSYCVY = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        XbU7b xbU7b;
        if (i11 < 0) {
            throw new IllegalArgumentException("Can't have a negative input length!");
        }
        int i12 = this.aXYSYCVY;
        int i13 = 8 - i12;
        if (i11 > i13) {
            System.arraycopy(bArr, i10, this.eLbhX59K, i12, i13);
            byte[] bArr2 = this.eLbhX59K;
            byte[] bArr3 = new byte[bArr2.length];
            if (this.ivfTYNl) {
                this.ivfTYNl = false;
                byte[] bArr4 = this.dUI84;
                if (bArr4 != null) {
                    eszJ2B0a(bArr2, 0, bArr4, bArr3);
                } else {
                    System.arraycopy(bArr2, 0, bArr3, 0, this.zDWsfFRp.length);
                }
            } else {
                eszJ2B0a(bArr2, 0, this.zDWsfFRp, bArr3);
            }
            xbU7b = this;
            xbU7b.eLbhX59K(this.osx7Pl0E, bArr3, 0, this.zDWsfFRp, 0);
            xbU7b.aXYSYCVY = 0;
            i11 -= i13;
            i10 += i13;
            while (i11 > 8) {
                eszJ2B0a(bArr, i10, xbU7b.zDWsfFRp, bArr3);
                xbU7b.eLbhX59K(xbU7b.osx7Pl0E, bArr3, 0, xbU7b.zDWsfFRp, 0);
                i11 -= 8;
                i10 += 8;
            }
        } else {
            xbU7b = this;
        }
        System.arraycopy(bArr, i10, xbU7b.eLbhX59K, xbU7b.aXYSYCVY, i11);
        xbU7b.aXYSYCVY += i11;
    }
}
