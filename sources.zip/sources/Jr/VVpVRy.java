package Jr;

import Or.Db8eU7XV;
import Or.VX4rr;
import org.bouncycastle.crypto.AfGFIA;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class VVpVRy implements ZKBAd {
    public final byte[] aXYSYCVY;
    public int bsO5Vo;
    public int dUI84;
    public int eLbhX59K;
    public final org.bouncycastle.crypto.N1vNRFSd eszJ2B0a;
    public int ivfTYNl;
    public int jAM6dcNA;
    public final byte[] mTWLV;
    public int n84TFkA9;
    public int oZ7qYn;
    public int osx7Pl0E;
    public int oyaOvpOs;
    public int q1ORKN;
    public int qLLw0g;
    public int rJCQt16;
    public int rjljd6i;
    public int rtsRj;
    public int uTIfLNK0;
    public int uYRSwDm;
    public int yxejkub;
    public int zDWsfFRp;
    public int zPJpxWz;

    public VVpVRy() {
        this.aXYSYCVY = new byte[1];
        this.mTWLV = new byte[16];
        this.rJCQt16 = 0;
        this.eszJ2B0a = null;
    }

    private void aXYSYCVY() {
        int i10 = this.rJCQt16;
        if (i10 < 16) {
            this.mTWLV[i10] = 1;
            for (int i11 = i10 + 1; i11 < 16; i11++) {
                this.mTWLV[i11] = 0;
            }
        }
        long jUTIfLNK0 = wt.SFMiYa.uTIfLNK0(this.mTWLV, 0);
        long j10 = jUTIfLNK0 & 4294967295L;
        long jUTIfLNK1 = ((long) wt.SFMiYa.uTIfLNK0(this.mTWLV, 4)) & 4294967295L;
        long jUTIfLNK2 = ((long) wt.SFMiYa.uTIfLNK0(this.mTWLV, 8)) & 4294967295L;
        long jUTIfLNK3 = 4294967295L & ((long) wt.SFMiYa.uTIfLNK0(this.mTWLV, 12));
        int i12 = (int) (((long) this.jAM6dcNA) + (jUTIfLNK0 & 67108863));
        this.jAM6dcNA = i12;
        this.rtsRj = (int) (((long) this.rtsRj) + ((((jUTIfLNK1 << 32) | j10) >>> 26) & 67108863));
        this.oyaOvpOs = (int) (((long) this.oyaOvpOs) + (((jUTIfLNK1 | (jUTIfLNK2 << 32)) >>> 20) & 67108863));
        this.n84TFkA9 = (int) (((long) this.n84TFkA9) + ((((jUTIfLNK3 << 32) | jUTIfLNK2) >>> 14) & 67108863));
        int i13 = (int) (((long) this.bsO5Vo) + (jUTIfLNK3 >>> 8));
        this.bsO5Vo = i13;
        if (this.rJCQt16 == 16) {
            this.bsO5Vo = i13 + 16777216;
        }
        long jEszJ2B0a = eszJ2B0a(i12, this.eLbhX59K) + eszJ2B0a(this.rtsRj, this.qLLw0g) + eszJ2B0a(this.oyaOvpOs, this.zPJpxWz) + eszJ2B0a(this.n84TFkA9, this.rjljd6i) + eszJ2B0a(this.bsO5Vo, this.oZ7qYn);
        long jEszJ2B0a2 = eszJ2B0a(this.jAM6dcNA, this.zDWsfFRp) + eszJ2B0a(this.rtsRj, this.eLbhX59K) + eszJ2B0a(this.oyaOvpOs, this.qLLw0g) + eszJ2B0a(this.n84TFkA9, this.zPJpxWz) + eszJ2B0a(this.bsO5Vo, this.rjljd6i);
        long jEszJ2B0a3 = eszJ2B0a(this.jAM6dcNA, this.ivfTYNl) + eszJ2B0a(this.rtsRj, this.zDWsfFRp) + eszJ2B0a(this.oyaOvpOs, this.eLbhX59K) + eszJ2B0a(this.n84TFkA9, this.qLLw0g) + eszJ2B0a(this.bsO5Vo, this.zPJpxWz);
        long jEszJ2B0a4 = eszJ2B0a(this.jAM6dcNA, this.osx7Pl0E) + eszJ2B0a(this.rtsRj, this.ivfTYNl) + eszJ2B0a(this.oyaOvpOs, this.zDWsfFRp) + eszJ2B0a(this.n84TFkA9, this.eLbhX59K) + eszJ2B0a(this.bsO5Vo, this.qLLw0g);
        long jEszJ2B0a5 = eszJ2B0a(this.jAM6dcNA, this.dUI84) + eszJ2B0a(this.rtsRj, this.osx7Pl0E) + eszJ2B0a(this.oyaOvpOs, this.ivfTYNl) + eszJ2B0a(this.n84TFkA9, this.zDWsfFRp) + eszJ2B0a(this.bsO5Vo, this.eLbhX59K);
        long j11 = jEszJ2B0a2 + (jEszJ2B0a >>> 26);
        long j12 = jEszJ2B0a3 + (j11 >>> 26);
        this.oyaOvpOs = ((int) j12) & 67108863;
        long j13 = jEszJ2B0a4 + (j12 >>> 26);
        this.n84TFkA9 = ((int) j13) & 67108863;
        long j14 = jEszJ2B0a5 + (j13 >>> 26);
        this.bsO5Vo = ((int) j14) & 67108863;
        int i14 = (((int) jEszJ2B0a) & 67108863) + (((int) (j14 >>> 26)) * 5);
        this.rtsRj = (((int) j11) & 67108863) + (i14 >>> 26);
        this.jAM6dcNA = i14 & 67108863;
    }

    private void eLbhX59K(byte[] bArr, byte[] bArr2) {
        if (bArr.length != 32) {
            throw new IllegalArgumentException("Poly1305 key must be 256 bits.");
        }
        int i10 = 16;
        if (this.eszJ2B0a != null && (bArr2 == null || bArr2.length != 16)) {
            throw new IllegalArgumentException("Poly1305 requires a 128 bit IV.");
        }
        int iUTIfLNK0 = wt.SFMiYa.uTIfLNK0(bArr, 0);
        int iUTIfLNK1 = wt.SFMiYa.uTIfLNK0(bArr, 4);
        int iUTIfLNK2 = wt.SFMiYa.uTIfLNK0(bArr, 8);
        int iUTIfLNK3 = wt.SFMiYa.uTIfLNK0(bArr, 12);
        this.eLbhX59K = 67108863 & iUTIfLNK0;
        int i11 = ((iUTIfLNK0 >>> 26) | (iUTIfLNK1 << 6)) & 67108611;
        this.zDWsfFRp = i11;
        int i12 = ((iUTIfLNK1 >>> 20) | (iUTIfLNK2 << 12)) & 67092735;
        this.ivfTYNl = i12;
        int i13 = ((iUTIfLNK2 >>> 14) | (iUTIfLNK3 << 18)) & 66076671;
        this.osx7Pl0E = i13;
        int i14 = (iUTIfLNK3 >>> 8) & 1048575;
        this.dUI84 = i14;
        this.oZ7qYn = i11 * 5;
        this.rjljd6i = i12 * 5;
        this.zPJpxWz = i13 * 5;
        this.qLLw0g = i14 * 5;
        org.bouncycastle.crypto.N1vNRFSd n1vNRFSd = this.eszJ2B0a;
        if (n1vNRFSd != null) {
            byte[] bArr3 = new byte[16];
            n1vNRFSd.init(true, new VX4rr(bArr, 16, 16));
            this.eszJ2B0a.eLbhX59K(bArr2, 0, bArr3, 0);
            i10 = 0;
            bArr = bArr3;
        }
        this.q1ORKN = wt.SFMiYa.uTIfLNK0(bArr, i10);
        this.uTIfLNK0 = wt.SFMiYa.uTIfLNK0(bArr, i10 + 4);
        this.uYRSwDm = wt.SFMiYa.uTIfLNK0(bArr, i10 + 8);
        this.yxejkub = wt.SFMiYa.uTIfLNK0(bArr, i10 + 12);
    }

    public static final long eszJ2B0a(int i10, int i11) {
        return (((long) i10) & 4294967295L) * ((long) i11);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        if (i10 + 16 > bArr.length) {
            throw new AfGFIA("Output buffer is too short.");
        }
        if (this.rJCQt16 > 0) {
            aXYSYCVY();
        }
        int i11 = this.rtsRj;
        int i12 = this.jAM6dcNA;
        int i13 = i11 + (i12 >>> 26);
        int i14 = this.oyaOvpOs + (i13 >>> 26);
        int i15 = this.n84TFkA9 + (i14 >>> 26);
        int i16 = i14 & 67108863;
        int i17 = this.bsO5Vo + (i15 >>> 26);
        int i18 = i15 & 67108863;
        int i19 = (i12 & 67108863) + ((i17 >>> 26) * 5);
        int i20 = i17 & 67108863;
        int i21 = (i13 & 67108863) + (i19 >>> 26);
        int i22 = i19 & 67108863;
        int i23 = i22 + 5;
        int i24 = (i23 >>> 26) + i21;
        int i25 = (i24 >>> 26) + i16;
        int i26 = (i25 >>> 26) + i18;
        int i27 = 67108863 & i26;
        int i28 = ((i26 >>> 26) + i20) - 67108864;
        int i29 = (i28 >>> 31) - 1;
        int i30 = ~i29;
        int i31 = (i22 & i30) | (i23 & 67108863 & i29);
        this.jAM6dcNA = i31;
        int i32 = (i21 & i30) | (i24 & 67108863 & i29);
        this.rtsRj = i32;
        int i33 = (i16 & i30) | (i25 & 67108863 & i29);
        this.oyaOvpOs = i33;
        int i34 = (i27 & i29) | (i18 & i30);
        this.n84TFkA9 = i34;
        int i35 = (i20 & i30) | (i28 & i29);
        this.bsO5Vo = i35;
        long j10 = (((long) (i31 | (i32 << 26))) & 4294967295L) + (((long) this.q1ORKN) & 4294967295L);
        long j11 = (((long) ((i32 >>> 6) | (i33 << 20))) & 4294967295L) + (((long) this.uTIfLNK0) & 4294967295L);
        long j12 = (((long) ((i33 >>> 12) | (i34 << 14))) & 4294967295L) + (((long) this.uYRSwDm) & 4294967295L);
        long j13 = (((long) ((i34 >>> 18) | (i35 << 8))) & 4294967295L) + (4294967295L & ((long) this.yxejkub));
        wt.SFMiYa.zPJpxWz((int) j10, bArr, i10);
        long j14 = j11 + (j10 >>> 32);
        wt.SFMiYa.zPJpxWz((int) j14, bArr, i10 + 4);
        long j15 = j12 + (j14 >>> 32);
        wt.SFMiYa.zPJpxWz((int) j15, bArr, i10 + 8);
        wt.SFMiYa.zPJpxWz((int) (j13 + (j15 >>> 32)), bArr, i10 + 12);
        reset();
        return 16;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        if (this.eszJ2B0a == null) {
            return "Poly1305";
        }
        return "Poly1305-" + this.eszJ2B0a.getAlgorithmName();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return 16;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        byte[] bArrEszJ2B0a;
        if (this.eszJ2B0a == null) {
            bArrEszJ2B0a = null;
        } else {
            if (!(jqavh instanceof Db8eU7XV)) {
                throw new IllegalArgumentException("Poly1305 requires an IV when used with a block cipher.");
            }
            Db8eU7XV db8eU7XV = (Db8eU7XV) jqavh;
            bArrEszJ2B0a = db8eU7XV.eszJ2B0a();
            jqavh = db8eU7XV.aXYSYCVY();
        }
        if (!(jqavh instanceof VX4rr)) {
            throw new IllegalArgumentException("Poly1305 requires a key.");
        }
        eLbhX59K(((VX4rr) jqavh).aXYSYCVY(), bArrEszJ2B0a);
        reset();
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.rJCQt16 = 0;
        this.bsO5Vo = 0;
        this.n84TFkA9 = 0;
        this.oyaOvpOs = 0;
        this.rtsRj = 0;
        this.jAM6dcNA = 0;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        byte[] bArr = this.aXYSYCVY;
        bArr[0] = b10;
        update(bArr, 0, 1);
    }

    public VVpVRy(org.bouncycastle.crypto.N1vNRFSd n1vNRFSd) {
        this.aXYSYCVY = new byte[1];
        this.mTWLV = new byte[16];
        this.rJCQt16 = 0;
        if (n1vNRFSd.eszJ2B0a() != 16) {
            throw new IllegalArgumentException("Poly1305 requires a 128 bit block cipher.");
        }
        this.eszJ2B0a = n1vNRFSd;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        int i12 = 0;
        while (i11 > i12) {
            if (this.rJCQt16 == 16) {
                aXYSYCVY();
                this.rJCQt16 = 0;
            }
            int iMin = Math.min(i11 - i12, 16 - this.rJCQt16);
            System.arraycopy(bArr, i12 + i10, this.mTWLV, this.rJCQt16, iMin);
            i12 += iMin;
            this.rJCQt16 += iMin;
        }
    }
}
