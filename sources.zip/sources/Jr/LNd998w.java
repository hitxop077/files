package Jr;

import Or.VX4rr;
import kotlin.jvm.internal.ByteCompanionObject;
import org.bouncycastle.crypto.AXWzg4r;
import org.bouncycastle.crypto.AfGFIA;
import org.bouncycastle.crypto.ZKBAd;

/* JADX INFO: loaded from: classes5.dex */
public class LNd998w implements ZKBAd {
    public int aXYSYCVY;
    public Er.N1vNRFSd eszJ2B0a;
    public long ivfTYNl;
    public byte[] eLbhX59K = null;
    public byte[] zDWsfFRp = null;

    public LNd998w(int i10) {
        this.eszJ2B0a = new Er.N1vNRFSd(i10);
        this.aXYSYCVY = i10 / 8;
    }

    public final byte[] aXYSYCVY(byte[] bArr) {
        int length = (((bArr.length + this.eszJ2B0a.getByteLength()) - 1) / this.eszJ2B0a.getByteLength()) * this.eszJ2B0a.getByteLength();
        if (length - bArr.length < 13) {
            length += this.eszJ2B0a.getByteLength();
        }
        byte[] bArr2 = new byte[length];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        bArr2[bArr.length] = ByteCompanionObject.MIN_VALUE;
        wt.SFMiYa.zPJpxWz(bArr.length * 8, bArr2, length - 12);
        return bArr2;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int doFinal(byte[] bArr, int i10) {
        if (this.eLbhX59K == null) {
            throw new IllegalStateException(getAlgorithmName() + " not initialised");
        }
        if (bArr.length - i10 < this.aXYSYCVY) {
            throw new AfGFIA("Output buffer too short");
        }
        eszJ2B0a();
        Er.N1vNRFSd n1vNRFSd = this.eszJ2B0a;
        byte[] bArr2 = this.zDWsfFRp;
        n1vNRFSd.update(bArr2, 0, bArr2.length);
        this.ivfTYNl = 0L;
        int iDoFinal = this.eszJ2B0a.doFinal(bArr, i10);
        reset();
        return iDoFinal;
    }

    public final void eszJ2B0a() {
        int byteLength = this.eszJ2B0a.getByteLength() - ((int) (this.ivfTYNl % ((long) this.eszJ2B0a.getByteLength())));
        if (byteLength < 13) {
            byteLength += this.eszJ2B0a.getByteLength();
        }
        byte[] bArr = new byte[byteLength];
        bArr[0] = ByteCompanionObject.MIN_VALUE;
        wt.SFMiYa.c1pvtY(this.ivfTYNl * 8, bArr, byteLength - 12);
        this.eszJ2B0a.update(bArr, 0, byteLength);
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public String getAlgorithmName() {
        return "DSTU7564Mac";
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public int getMacSize() {
        return this.aXYSYCVY;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void init(org.bouncycastle.crypto.JQAVH jqavh) {
        this.eLbhX59K = null;
        reset();
        if (!(jqavh instanceof VX4rr)) {
            throw new IllegalArgumentException("Bad parameter passed");
        }
        byte[] bArrAXYSYCVY = ((VX4rr) jqavh).aXYSYCVY();
        this.zDWsfFRp = new byte[bArrAXYSYCVY.length];
        this.eLbhX59K = aXYSYCVY(bArrAXYSYCVY);
        int i10 = 0;
        while (true) {
            byte[] bArr = this.zDWsfFRp;
            if (i10 >= bArr.length) {
                Er.N1vNRFSd n1vNRFSd = this.eszJ2B0a;
                byte[] bArr2 = this.eLbhX59K;
                n1vNRFSd.update(bArr2, 0, bArr2.length);
                return;
            }
            bArr[i10] = (byte) (~bArrAXYSYCVY[i10]);
            i10++;
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void reset() {
        this.ivfTYNl = 0L;
        this.eszJ2B0a.reset();
        byte[] bArr = this.eLbhX59K;
        if (bArr != null) {
            this.eszJ2B0a.update(bArr, 0, bArr.length);
        }
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte b10) {
        this.eszJ2B0a.update(b10);
        this.ivfTYNl++;
    }

    @Override // org.bouncycastle.crypto.ZKBAd
    public void update(byte[] bArr, int i10, int i11) {
        if (bArr.length - i10 < i11) {
            throw new AXWzg4r("Input buffer too short");
        }
        if (this.eLbhX59K != null) {
            this.eszJ2B0a.update(bArr, i10, i11);
            this.ivfTYNl += (long) i11;
        } else {
            throw new IllegalStateException(getAlgorithmName() + " not initialised");
        }
    }
}
