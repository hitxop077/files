package jijnq5;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.text.Typography;

/* JADX INFO: compiled from: Obfuscated */
/* JADX INFO: loaded from: classes6.dex */
public interface MY3jR extends IInterface {
    public static final String eImdmIyv = "android$support$v4$app$INotificationSideChannel".replace(Typography.dollar, '.');

    /* JADX INFO: compiled from: Obfuscated */
    public static class AAnYcst {
        public static void aXYSYCVY(Parcel parcel, Parcelable parcelable, int i10) {
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                parcel.writeInt(1);
                parcelable.writeToParcel(parcel, i10);
            }
        }
    }

    /* JADX INFO: renamed from: jijnq5.MY3jR$MY3jR, reason: collision with other inner class name */
    /* JADX INFO: compiled from: Obfuscated */
    public static abstract class AbstractBinderC1477MY3jR extends Binder implements MY3jR {

        /* JADX INFO: renamed from: jijnq5.MY3jR$MY3jR$MY3jR, reason: collision with other inner class name */
        /* JADX INFO: compiled from: Obfuscated */
        public static class C1478MY3jR implements MY3jR {
            public IBinder njNibPNp;

            public C1478MY3jR(IBinder iBinder) {
                this.njNibPNp = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.njNibPNp;
            }

            @Override // jijnq5.MY3jR
            public void bJd1xA(String str, int i10, String str2, Notification notification) {
                Parcel parcelObtain = Parcel.obtain();
                try {
                    parcelObtain.writeInterfaceToken(MY3jR.eImdmIyv);
                    parcelObtain.writeString(str);
                    parcelObtain.writeInt(i10);
                    parcelObtain.writeString(str2);
                    AAnYcst.aXYSYCVY(parcelObtain, notification, 0);
                    this.njNibPNp.transact(1, parcelObtain, null, 1);
                } finally {
                    parcelObtain.recycle();
                }
            }
        }

        public static MY3jR m8rcW6(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface(MY3jR.eImdmIyv);
            return (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof MY3jR)) ? new C1478MY3jR(iBinder) : (MY3jR) iInterfaceQueryLocalInterface;
        }
    }

    void bJd1xA(String str, int i10, String str2, Notification notification);
}
